@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Fabrica Dark - modo diagnostico
echo  Modo diagnostico: os registros aparecem nesta janela (use se algo der erro e mande o print).
if not exist ".venv\Scripts\python.exe" (
    echo  Ambiente .venv ainda nao criado. Executando configuracao inicial...
    call iniciar.bat
    exit /b 0
)
".venv\Scripts\python.exe" -c "from core import atualizador; atualizador.sincronizar_ao_iniciar()" >nul 2>nul
".venv\Scripts\python.exe" app.py
pause
