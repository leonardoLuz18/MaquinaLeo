"""Fábrica Dark — servidor local. Rode o iniciar.bat e use no navegador (http://127.0.0.1:5077)."""
import copy
import json
import os
import re
import subprocess
import sys
import threading
import time
import traceback
import webbrowser

import requests
from flask import Flask, jsonify, request, send_file, send_from_directory
from werkzeug.exceptions import HTTPException

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import chaves, claude, darkplanner_sync, estudio, gemini, media, oficina, pauta, perfis, prompts, radar, reallab, render, scenes, storage, thumb, voz  # noqa: E402
from core.storage import Tx, find  # noqa: E402

PORTA = 5077
BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
MEDIA_JOBS = {}


@app.after_request
def _desativar_cache_estatico(resp):
    if request.path == "/" or request.path.startswith("/static/") or request.path.startswith("/celular"):
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
    return resp


@app.errorhandler(Exception)
def _tratar_excecao_global(e):
    if isinstance(e, HTTPException):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "erro": f"{e.code} {e.name}: {e.description}"}), e.code
        return e
    tb_txt = traceback.format_exc()
    print(f"[ERRO INTERNO {request.method} {request.path}]\n{tb_txt}")
    try:
        from core import agente_dev_local
        agente_dev_local.registrar_excecao_runtime(request.method, request.path, tb_txt, resumo=str(e))
    except Exception:
        pass
    if request.path.startswith("/api/"):
        return jsonify({"ok": False, "erro": f"Erro interno no servidor: {e}"}), 500
    return f"Erro interno: {e}", 500


def erro(msg, code=400):
    try:
        from core import agente_dev_local
        agente_dev_local.registrar_excecao_runtime(
            request.method if request else "",
            request.path if request else "",
            f"HTTP {code}: {msg}",
            resumo=str(msg),
        )
    except Exception:
        pass
    return jsonify({"ok": False, "erro": msg}), code


def _video_ctx(db, vid):
    v = find(db["videos"], vid)
    if not v:
        raise KeyError("Vídeo não encontrado")
    c = find(db["channels"], v["channel_id"]) or {}
    return v, c


def _abs(vid, rel):
    if not rel:
        return ""
    return rel if os.path.isabs(rel) else os.path.join(storage.video_dir(vid), rel)


def _salvar_upload(vid, f, nome_base):
    ext = os.path.splitext(f.filename or "")[1].lower() or ".bin"
    rel = os.path.join("midia", nome_base + ext) if nome_base.startswith("cena_") else nome_base + ext
    path = os.path.join(storage.video_dir(vid), rel)
    f.save(path)
    return rel, path


def _tipo_arquivo(nome):
    return "video" if os.path.splitext(nome)[1].lower() in (".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v") else "foto"


def _resumo_video(v):
    cenas = v.get("cenas", [])
    dp_v = v.get("dp_video") or {}
    eh_pronto = bool(v.get("concluido") or v.get("saida") or dp_v.get("checklist_pronto") or dp_v.get("status") in ("finalizado", "publicado"))
    return {
        k: v.get(k)
        for k in ("id", "channel_id", "titulo", "criado_em", "data_publicacao", "publicado", "etapas", "saida", "concluido_em")
    } | {
        "n_cenas": len(cenas),
        "nota": (v.get("analise") or {}).get("nota_geral"),
        "pronto": eh_pronto,
        "concluido": bool(eh_pronto or v.get("publicado")),
        "numero_video": dp_v.get("numero_video") or "",
        "status_dp": dp_v.get("status") or "",
        "dp_video": dp_v,
    }


# ---------------- páginas ----------------
@app.route("/")
def index():
    idx_path = os.path.join(app.static_folder, "index.html")
    try:
        from core import versao as _ver_mod
        mtimes = []
        for arq_st in ("v4.js", "app.js", "style.css", "index.html"):
            p_st = os.path.join(app.static_folder, arq_st)
            if os.path.exists(p_st):
                mtimes.append(int(os.path.getmtime(p_st) * 1000))
        mt = max(mtimes) if mtimes else 0
        tag_v = f"{getattr(_ver_mod, 'VERSAO', '20261113')}_{mt}"
        with open(idx_path, "r", encoding="utf-8") as f:
            html_txt = f.read()
        html_txt = re.sub(r"\?v=[^\"'>\s]+", f"?v={tag_v}", html_txt)
        resp = app.make_response(html_txt)
        resp.headers["Content-Type"] = "text/html; charset=utf-8"
    except Exception:
        resp = send_from_directory(app.static_folder, "index.html", max_age=0)
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


@app.route("/api/agente-dev/status", methods=["GET"])
def api_agente_dev_status():
    from core import agente_dev_local
    st_env = agente_dev_local.tool_inspecionar_ambiente()
    st_env["edicoes_recentes"] = list(agente_dev_local._HISTORICO_EDICOES_AGENTE)[-15:]
    return jsonify(st_env)


# ---------------- configurações ----------------
@app.route("/api/settings", methods=["GET", "POST"])
def settings():
    def mascarado(st):
        out = dict(st)
        for k in list(out):
            if k.endswith("_key") and out[k]:
                out[k] = chaves.mascarar(out[k])
        return out

    if request.method == "GET":
        return jsonify(mascarado(storage.load()["settings"]))
    with Tx() as db:
        for k, v in (request.json or {}).items():
            if k in db["settings"]:
                if k.endswith("_key") and isinstance(v, str) and v.startswith("••••"):
                    continue  # campo mascarado: não mudou
                db["settings"][k] = v
        return jsonify(mascarado(db["settings"]))


# ---------------- canais (Sincronização Bidirecional com DarkPlanner) ----------------
@app.route("/api/channels", methods=["GET", "POST"])
def channels():
    if request.method == "GET":
        db = darkplanner_sync.sincronizar_tudo(forcar=bool(request.args.get("forcar")))
        try:
            if pauta.sincronizar_perfis_editoriais_no_banco(db):
                with Tx() as db_s:
                    pauta.sincronizar_perfis_editoriais_no_banco(db_s)
                db = storage.load()
        except Exception:
            pass
        return jsonify(db["channels"])
    data = request.json or {}
    cid = data.get("id")
    try:
        res_dp = darkplanner_sync.criar_ou_atualizar_canal(cid, data)
        cid = cid or (res_dp or {}).get("id")
    except Exception as e:
        print("Aviso sync canal DarkPlanner:", e)
    with Tx() as db:
        ch = find(db["channels"], cid) if cid else None
        if not ch:
            ch = {"id": cid or storage.new_id("c"), "criado_em": storage.now()}
            db["channels"].append(ch)
        for k in ("nome", "nicho", "subnicho", "publico", "tese", "idioma", "idioma_dp", "cor", "url", "meta_semana", "personagem", "personagens", "perfil", "estilo_roteiro", "estilo_visual", "cta", "evitar"):
            if k in data:
                ch[k] = data[k]
        ch.setdefault("idioma", "pt")
        ch.setdefault("cor", "#22c55e")
        ch.setdefault("meta_semana", 3)
        return jsonify(ch)


@app.route("/api/channels/<cid>", methods=["PUT", "PATCH", "DELETE"])
def channel_del(cid):
    if request.method in ("PUT", "PATCH"):
        data = dict(request.json or {}, id=cid)
        try:
            darkplanner_sync.criar_ou_atualizar_canal(cid, data)
        except Exception as e:
            return erro(str(e))
        with Tx() as db:
            ch = find(db["channels"], cid) or {}
            for k in ("nome", "nicho", "subnicho", "publico", "tese", "idioma", "idioma_dp", "cor", "url", "meta_semana", "personagem", "personagens", "perfil", "estilo_roteiro", "estilo_visual", "cta", "evitar"):
                if k in data:
                    ch[k] = data[k]
            return jsonify(ch)
    try:
        darkplanner_sync.excluir_canal(cid)
    except Exception as e:
        print("Aviso ao excluir canal no DarkPlanner:", e)
    with Tx() as db:
        db["channels"] = [c for c in db["channels"] if c["id"] != cid]
        db["ideas"] = [i for i in db["ideas"] if i.get("channel_id") != cid]
        for v in db["videos"]:
            if v["channel_id"] == cid:
                v["channel_id"] = ""
    return jsonify({"ok": True})


@app.route("/api/darkplanner/sync", methods=["GET", "POST"])
def dp_sync_endpoint():
    forcar = request.method == "POST" or bool(request.args.get("forcar"))
    db = darkplanner_sync.sincronizar_tudo(forcar=forcar)
    return jsonify({
        "ok": True,
        "channels": db.get("channels", []),
        "videos": [_resumo_video(v) | {"dp_video": v.get("dp_video")} for v in db.get("videos", [])],
        "cloud": db.get("darkplanner_cloud", {}),
    })


@app.route("/api/darkplanner/prompts", methods=["POST"])
def dp_salvar_prompt():
    d = request.json or {}
    if not d.get("canal_id") or not d.get("nome") or not d.get("conteudo"):
        return erro("Preencha canal, nome e conteúdo do Prompt Mestre.")
    try:
        res = darkplanner_sync.salvar_prompt_dp(
            d["canal_id"], d["nome"], d.get("categoria", ""), d["conteudo"], d.get("id")
        )
        return jsonify({"ok": True, "prompt": res, "channels": storage.load()["channels"]})
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/prompts/<pid>", methods=["DELETE"])
def dp_excluir_prompt(pid):
    try:
        darkplanner_sync.req("DELETE", f"/prompts/{pid}")
        db = darkplanner_sync.sincronizar_tudo(forcar=True)
        return jsonify({"ok": True, "channels": db["channels"]})
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/narrador/<cid>", methods=["PUT", "POST"])
def dp_salvar_narrador(cid):
    d = request.json or {}
    try:
        res = darkplanner_sync.req("PUT", f"/canais/{cid}/narrator", json_body={
            "voice_id": d.get("voice_id") or "",
            "voice_name": d.get("voice_name") or "",
            "speed": float(d.get("speed") or 1.0),
            "volume": float(d.get("volume") or 1.0),
            "subtitle_enabled": bool(d.get("subtitle_enabled", True)),
            "subtitle_words": int(d.get("subtitle_words") or 5),
            "subtitle_case": d.get("subtitle_case") or "normal",
            "subtitle_veo_words": int(d.get("subtitle_veo_words") or 5),
        })
        db = darkplanner_sync.sincronizar_tudo(forcar=True)
        return jsonify({"ok": True, "narrator": res, "channels": db["channels"]})
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/audio/config")
def dp_audio_config():
    canal_id = request.args.get("canal_id") or ""
    try:
        return jsonify(darkplanner_sync.audio_config_canal(canal_id or None))
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/audio/history")
def dp_audio_history():
    limit = request.args.get("limit", 80)
    try:
        return jsonify(darkplanner_sync.audio_historico_dp(limit))
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/audio/generate", methods=["POST"])
def dp_audio_generate():
    d = request.json or {}
    try:
        res = darkplanner_sync.audio_gerar_dp(d)
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/audio/history/<job_id>", methods=["DELETE"])
def dp_audio_delete(job_id):
    try:
        return jsonify(darkplanner_sync.audio_excluir_dp(job_id))
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/audio/srt-veo", methods=["POST"])
def dp_audio_srt_veo():
    d = request.json or {}
    job_id = d.get("job_id") or ""
    if not job_id and not d.get("srt_tempo_url"):
        return erro("Informe job_id ou srt_tempo_url.")
    try:
        res = darkplanner_sync.audio_srt_veo_dados(
            job_id=job_id,
            srt_tempo_url=d.get("srt_tempo_url") or "",
            min_s=d.get("min_s", 0),
            max_s=d.get("max_s", 8),
            faixas=d.get("faixas"),
            quebrar_frases=bool(d.get("quebrar_frases")),
            breaks_custom=d.get("breaks"),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/audio/vincular", methods=["POST"])
def dp_audio_vincular():
    d = request.json or {}
    job_id = d.get("job_id") or ""
    try:
        res = darkplanner_sync.audio_baixar_e_vincular(
            job_id=job_id,
            audio_url=d.get("audio_url") or "",
            srt_texto=d.get("srt_texto") or "",
            vid=d.get("vid") or "",
            file_name=d.get("file_name") or "",
            criar_cenas_veo=bool(d.get("criar_cenas_veo", True)),
            faixas=d.get("faixas"),
            quebrar_frases=bool(d.get("quebrar_frases", True)),
            min_s=d.get("min_s", 4),
            max_s=d.get("max_s", 8),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/audio/file/<job_id>/<path:filename>")
def dp_audio_file(job_id, filename):
    import requests as _req
    pasta = os.path.join(storage.DATA_DIR, "audios_dp", job_id)
    os.makedirs(pasta, exist_ok=True)
    base_fn = os.path.basename(filename)
    caminho = os.path.join(pasta, base_fn)
    if not os.path.exists(caminho) or os.path.getsize(caminho) == 0:
        try:
            r_cdn = _req.get(f"https://cdn.darkplanner.com.br/audios/{job_id}/{base_fn}", timeout=60)
            if r_cdn.ok:
                with open(caminho, "wb") as f:
                    f.write(r_cdn.content)
        except Exception:
            pass
    if not os.path.exists(caminho):
        return erro("Arquivo não encontrado.", 404)
    return send_file(caminho, as_attachment=bool(request.args.get("download")))


@app.route("/api/darkplanner/audio/download/<job_id>/<tipo>")
def dp_audio_download(job_id, tipo):
    """Baixa o áudio MP3 ou legenda SRT do DarkPlanner CDN, salva na pasta local e em Downloads do Windows, e entrega como attachment no navegador."""
    import requests as _req

    job_id = re.sub(r"[^\w\-]", "", str(job_id or ""))
    if not job_id:
        return erro("job_id inválido.", 400)

    nome_raw = (request.args.get("nome") or f"audio_{job_id}").strip()
    nome_limpo = re.sub(r'[<>:"/\\|?*]+', "_", nome_raw).strip(" ._") or f"audio_{job_id}"
    url_param = (request.args.get("url") or "").strip()

    mapa_tipo = {
        "mp3": ("audio.mp3", f"https://cdn.darkplanner.com.br/audios/{job_id}/audio.mp3", f"{nome_limpo}.mp3", "audio/mpeg"),
        "srt": ("legenda.srt", f"https://cdn.darkplanner.com.br/audios/{job_id}/legenda.srt", f"{nome_limpo}.srt", "text/plain; charset=utf-8"),
        "srt_palavra": ("srtsyncpalavra.srt", f"https://cdn.darkplanner.com.br/audios/{job_id}/srtsyncpalavra.srt", f"{nome_limpo}_palavra.srt", "text/plain; charset=utf-8"),
        "srt_veo": ("srtsynctempo_editado.srt", f"https://cdn.darkplanner.com.br/audios/{job_id}/srtsynctempo.srt", f"{nome_limpo}_veo.srt", "text/plain; charset=utf-8"),
    }
    arq_local, url_padrao, download_name, mimetype = mapa_tipo.get(tipo, mapa_tipo["mp3"])
    url_final = url_param if url_param.startswith("http") else url_padrao

    pasta = os.path.join(storage.DATA_DIR, "audios_dp", job_id)
    os.makedirs(pasta, exist_ok=True)
    caminho = os.path.join(pasta, arq_local)

    # Se for srt_veo e ainda não houver srtsynctempo_editado.srt, tenta srtsynctempo.srt
    if tipo == "srt_veo" and not os.path.exists(caminho):
        alt = os.path.join(pasta, "srtsynctempo.srt")
        if os.path.exists(alt):
            caminho = alt

    if not os.path.exists(caminho) or os.path.getsize(caminho) == 0:
        try:
            r_cdn = _req.get(url_final, timeout=60)
            if not r_cdn.ok:
                return erro(f"Não foi possível baixar do CDN DarkPlanner ({r_cdn.status_code}).", 502)
            with open(caminho, "wb") as f:
                f.write(r_cdn.content)
        except Exception as e:
            return erro(f"Erro ao baixar arquivo de áudio/SRT: {e}", 500)

    # O navegador salva automaticamente em Downloads via send_file(as_attachment=True).
    # Não copiamos manualmente para ~/Downloads aqui para evitar criar "arquivo (1).mp3" duplicado!

    # Registra automaticamente o download para que os Passos 4 e 5 saiam de "carregando" e fiquem 100% Concluídos
    try:
        srt_lido = ""
        if tipo != "mp3" and os.path.exists(caminho):
            with open(caminho, "r", encoding="utf-8", errors="replace") as fs:
                srt_lido = fs.read()
        darkplanner_sync.registrar_download_audio_srt(
            job_id=job_id,
            tipo=tipo,
            nome=nome_limpo,
            srt_texto=srt_lido,
            mp3_path=caminho if tipo == "mp3" else "",
            srt_path=caminho if tipo != "mp3" else "",
        )
    except Exception:
        pass

    return send_file(caminho, mimetype=mimetype, as_attachment=True, download_name=download_name)


@app.route("/api/darkplanner/audio/detectar-baixado", methods=["GET", "POST"])
def dp_audio_detectar_baixado():
    """Detecta automaticamente quando o áudio (.mp3) e o .srt foram baixados ou concluídos no DarkPlanner."""
    d = (request.json or {}) if request.method == "POST" else request.args
    try:
        res = darkplanner_sync.detectar_audio_srt_baixado(
            job_id=(d.get("job_id") or "").strip(),
            titulo=(d.get("titulo") or "").strip(),
            vid=(d.get("vid") or d.get("video_id") or "").strip(),
            canal_id=(d.get("canal_id") or d.get("channel_id") or "").strip(),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/ingredientes-canal")
def dp_ingredientes_canal():
    """Lista os Pacotes de Imagens Reutilizáveis (Personagens e Referências — Foto 4) + Estilo Visual (STYLE_DNA) do Canal."""
    canal_id = (request.args.get("canal_id") or request.args.get("channel_id") or "").strip()
    canal_nome = (request.args.get("canal_nome") or "").strip()
    pack_id = (request.args.get("pack_id") or "").strip()
    try:
        res = darkplanner_sync.listar_pacotes_ingredientes_dp(
            canal_id=canal_id,
            canal_nome=canal_nome,
            pack_id_forcado=pack_id,
        )
        db = storage.load()
        ch = next((c for c in db.get("channels", []) if c.get("id") == canal_id), {}) if canal_id else {}
        pms = ((ch.get("dp") or {}).get("prompts") or []) if isinstance(ch, dict) else []
        dna_info = darkplanner_sync._extrair_dna_e_prompts_do_canal(pms, canal_nome=ch.get("nome") or canal_nome)
        res["style_dna_canal"] = dna_info.get("style_dna") or (ch.get("estilo_visual") if isinstance(ch, dict) else "") or ""
        res["character_dna_canal"] = dna_info.get("character_dna") or ""
        res["negative_dna_canal"] = dna_info.get("negative_dna") or ""
        res["canal_nome"] = ch.get("nome") or canal_nome
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/ingrediente-img")
def dp_ingrediente_img():
    """Serve miniatura de imagem de referência da pasta DarkPlanner/ingredients ou skill6_pacotes."""
    caminho = (request.args.get("path") or "").strip().replace("/", os.sep)
    if not caminho or not os.path.exists(caminho) or not os.path.isfile(caminho):
        return erro("Imagem de referência não encontrada.", 404)
    ext = os.path.splitext(caminho)[1].lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp"):
        return erro("Formato não permitido.", 400)
    return send_file(caminho)


@app.route("/api/painel")
def painel():
    import datetime as dt

    db = storage.load()
    hoje = dt.date.today()
    fim_semana = hoje + dt.timedelta(days=7)
    out = []
    for c in db["channels"]:
        vs = [v for v in db["videos"] if v["channel_id"] == c["id"]]
        eh_conc = lambda v: bool(v.get("concluido") or v.get("saida") or (v.get("dp_video") or {}).get("checklist_pronto") or (v.get("dp_video") or {}).get("status") == "finalizado")
        prontos = [v for v in vs if eh_conc(v) and not v.get("publicado")]
        em_prod = [v for v in vs if not eh_conc(v) and not v.get("publicado")]
        agendados = [v for v in vs if v.get("data_publicacao") and hoje.isoformat() <= v["data_publicacao"] <= fim_semana.isoformat()]
        out.append(
            {
                "canal": c,
                "ideias": len([i for i in db["ideas"] if i.get("channel_id") == c["id"] and not i.get("usada")]),
                "em_producao": len(em_prod),
                "estoque": len(prontos),
                "agendados_semana": len(agendados),
                "publicados": len([v for v in vs if v.get("publicado")]),
                "videos_producao": [_resumo_video(v) for v in em_prod[:5]],
            }
        )
    return jsonify(out)


# ---------------- ideias ----------------
@app.route("/api/ideas", methods=["GET", "POST"])
def ideas():
    if request.method == "GET":
        cid = request.args.get("channel")
        return jsonify([i for i in storage.load()["ideas"] if not cid or i.get("channel_id") == cid])
    data = request.json or {}
    with Tx() as db:
        novas = []
        for it in data.get("ideias", []):
            novas.append(
                {
                    "id": storage.new_id("i"),
                    "channel_id": data.get("channel_id", ""),
                    "titulo": it.get("titulo", "").strip(),
                    "gancho": it.get("gancho", ""),
                    "porque": it.get("porque", ""),
                    "usada": False,
                    "criado_em": storage.now(),
                }
            )
        db["ideas"].extend([n for n in novas if n["titulo"]])
        return jsonify(novas)


@app.route("/api/ideas/<iid>", methods=["DELETE"])
def idea_del(iid):
    with Tx() as db:
        db["ideas"] = [i for i in db["ideas"] if i["id"] != iid]
    return jsonify({"ok": True})


@app.route("/api/ideas/<iid>/criar_video", methods=["POST"])
def idea_to_video(iid):
    with Tx() as db:
        i = find(db["ideas"], iid)
        if not i:
            return erro("Ideia não encontrada", 404)
        v = storage.new_video(i["channel_id"], i["titulo"])
        if i.get("gancho"):
            v["briefing"]["contexto"] = f"Gancho: {i['gancho']}"
        db["videos"].append(v)
        i["usada"] = True
        return jsonify(v)


# ---------------- vídeos (Sincronização Bidirecional com DarkPlanner) ----------------
@app.route("/api/videos", methods=["GET", "POST"])
def videos():
    if request.method == "GET":
        cid = request.args.get("channel")
        db = darkplanner_sync.sincronizar_tudo(forcar=bool(request.args.get("forcar")))
        vs = [v for v in db["videos"] if not cid or v["channel_id"] == cid]
        return jsonify([_resumo_video(v) for v in vs])
    data = request.json or {}
    cid = data.get("channel_id", "")
    titulo = data.get("titulo", "Novo vídeo")
    dp_reg = None
    if cid:
        try:
            dp_reg = darkplanner_sync.criar_video_dp(
                cid,
                titulo,
                notas=(data.get("briefing") or {}).get("contexto", "") or data.get("notas", ""),
                data_postagem=data.get("data_publicacao", ""),
                numero_video=data.get("numero_video", ""),
            )
        except Exception as e:
            print("Aviso ao criar vídeo no DarkPlanner:", e)
    with Tx() as db:
        v = storage.new_video(cid, titulo)
        if dp_reg and dp_reg.get("id"):
            v["id"] = dp_reg["id"]
            v["dp_video"] = dp_reg
        db["videos"].append(v)
        return jsonify(v)


@app.route("/api/videos/<vid>", methods=["GET", "PATCH", "DELETE"])
def video(vid):
    if request.method == "GET":
        db = storage.load()
        v = find(db["videos"], vid)
        if not v:
            return erro("Vídeo não encontrado", 404)
        if not (v.get("roteiro") or "").strip():
            rot_dp = darkplanner_sync.buscar_roteiro_dp(vid)
            if rot_dp:
                with Tx() as db2:
                    v2 = find(db2["videos"], vid)
                    if v2:
                        v2["roteiro"] = rot_dp
                        v2["etapas"]["roteiro"] = True
                        v = v2
        return jsonify(v)
    if request.method == "DELETE":
        threading.Thread(target=darkplanner_sync.excluir_video_dp, args=(vid,), daemon=True).start()
        with Tx() as db:
            db["videos"] = [v for v in db["videos"] if v["id"] != vid]
        return jsonify({"ok": True})
    data = request.json or {}
    with Tx() as db:
        v = find(db["videos"], vid)
        if not v:
            return erro("Vídeo não encontrado", 404)
        for k in ("titulo", "data_publicacao", "publicado", "roteiro", "musica_volume", "channel_id"):
            if k in data:
                v[k] = data[k]
        if "briefing" in data:
            v["briefing"].update(data["briefing"])
            v["etapas"]["briefing"] = True
        if "roteiro" in data:
            v["etapas"]["roteiro"] = bool((data["roteiro"] or "").strip())
        if "etapas" in data:
            v["etapas"].update(data["etapas"])
        # Espelha alterações no DarkPlanner Web
        campos_dp = {}
        if "titulo" in data:
            campos_dp["titulo"] = data["titulo"]
        if "data_publicacao" in data:
            campos_dp["data_postagem"] = data["data_publicacao"]
        if "publicado" in data:
            campos_dp["checklist_postagem"] = "Publicado" if data["publicado"] else ""
        if "briefing" in data and "contexto" in data["briefing"]:
            campos_dp["notas"] = data["briefing"]["contexto"]
        for ck_k in ("checklist_titulo", "checklist_roteiro", "checklist_audio", "checklist_pronto", "checklist_thumbnail", "checklist_postagem", "notas", "numero_video"):
            if ck_k in data:
                campos_dp[ck_k] = data[ck_k]
        cid_v = v.get("channel_id")
        rot_v = data.get("roteiro") if "roteiro" in data else None
        if campos_dp:
            threading.Thread(target=darkplanner_sync.atualizar_video_dp, args=(vid, campos_dp), daemon=True).start()
        if rot_v and rot_v.strip():
            threading.Thread(target=darkplanner_sync.salvar_roteiro_dp, args=(cid_v, vid, rot_v), daemon=True).start()
        return jsonify(v)


@app.route("/api/videos/concluir", methods=["POST"])
@app.route("/api/videos/<vid>/concluir", methods=["POST"])
def video_concluir(vid=""):
    """Marca (ou desmarca) um vídeo como 100% Concluído na Fábrica Dark, no Kanban e no DarkPlanner Web."""
    d = request.json or {}
    vid_final = (vid or d.get("vid") or d.get("id") or "").strip()
    canal_id = (d.get("canal_id") or d.get("channel_id") or "").strip()
    titulo = (d.get("titulo") or "").strip()
    roteiro = (d.get("roteiro") or "").strip()
    concluido = bool(d.get("concluido", True))
    publicado = d.get("publicado") if "publicado" in d else None
    try:
        res = darkplanner_sync.concluir_video_completo(
            vid=vid_final,
            canal_id=canal_id,
            titulo=titulo,
            roteiro=roteiro,
            concluido=concluido,
            publicado=publicado,
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/videos/<vid>/prompt/<tipo>")
def video_prompt(vid, tipo):
    db = storage.load()
    try:
        v, c = _video_ctx(db, vid)
    except KeyError as e:
        return erro(str(e), 404)
    ppm = db["settings"].get("palavras_por_minuto", 150)
    if tipo == "roteiro":
        p = prompts.roteiro(c, v, ppm)
    elif tipo == "analise":
        if not v.get("roteiro"):
            return erro("Cole o roteiro primeiro.")
        p = prompts.analise(c, v)
    elif tipo == "correcao":
        if not v.get("analise"):
            return erro("Faça a análise primeiro.")
        p = prompts.correcao(c, v)
    elif tipo == "cenas":
        if not v.get("cenas"):
            return erro("Divida o roteiro em cenas primeiro.")
        p = prompts.cenas(c, v)
    elif tipo == "descricao":
        p = prompts.descricao(c, v, scenes.capitulos_aprox(v.get("cenas", [])))
    elif tipo == "estrutura":
        p = prompts.roteiro_estrutura(c, v, int(v["briefing"].get("partes") or 2), ppm)
    elif tipo == "parte":
        k = int(request.args.get("k", 1))
        n = int(v["briefing"].get("partes") or 2)
        partes = v.get("partes_roteiro") or []
        anterior = partes[k - 2] if k >= 2 and len(partes) >= k - 1 else ""
        p = prompts.roteiro_parte(c, v, k, n, v["briefing"].get("estrutura_texto", ""), anterior or "", ppm)
    elif tipo == "titulo":
        p = prompts.validar_titulo(c, v, request.args.get("opcoes", ""))
    elif tipo == "publicado":
        p = prompts.video_publicado(c, v, request.args.get("metricas", ""))
    else:
        return erro("Tipo de prompt inválido")
    return jsonify({"prompt": p})


@app.route("/api/videos/<vid>/colar/<tipo>", methods=["POST"])
def video_colar(vid, tipo):
    texto = (request.json or {}).get("texto", "")
    with Tx() as db:
        try:
            v, _ = _video_ctx(db, vid)
        except KeyError as e:
            return erro(str(e), 404)
        try:
            if tipo in ("roteiro", "correcao"):
                t = re.sub(r"^```\w*|```$", "", texto.strip()).strip()
                if len(t.split()) < 30:
                    return erro("O roteiro parece curto demais. Cole o texto completo.")
                v["roteiro"] = t
                v["etapas"]["roteiro"] = True
                if tipo == "correcao":
                    v["analise_anterior"] = v.get("analise")
                    v["analise"] = None
                    v["etapas"]["analise"] = False
            elif tipo == "analise":
                a = prompts.parse_json(texto)
                if not isinstance(a, dict):
                    return erro("A análise deve ser um objeto JSON.")
                v["analise"] = a
                v["etapas"]["analise"] = True
            elif tipo == "cenas":
                lista = prompts.parse_json(texto)
                if isinstance(lista, dict):
                    lista = lista.get("cenas") or list(lista.values())[0]
                por_n = {int(x.get("n", i + 1)): x for i, x in enumerate(lista)}
                faltando = 0
                for c in v["cenas"]:
                    x = por_n.get(c["n"])
                    if not x:
                        faltando += 1
                        continue
                    for k in ("tipo", "pessoa_real", "descricao_visual", "prompt_ia"):
                        c[k] = x.get(k, c.get(k, "")) or ""
                    tb = x.get("termos_busca") or []
                    c["termos_busca"] = [tb] if isinstance(tb, str) else [str(t) for t in tb][:4]
                v["etapas"]["cenas"] = faltando == 0
                if faltando:
                    return jsonify({"ok": True, "aviso": f"{faltando} cena(s) ficaram sem resposta da IA. Peça para a IA continuar e cole o resto."} | {"video": v})
            elif tipo == "descricao":
                d = prompts.parse_json(texto)
                v["descricao"] = d
                v["etapas"]["descricao"] = True
            elif tipo == "estrutura":
                v["briefing"]["estrutura_texto"] = texto.strip()
            elif tipo == "parte":
                k = int((request.json or {}).get("k", 1))
                partes = v.get("partes_roteiro") or []
                while len(partes) < k:
                    partes.append("")
                partes[k - 1] = re.sub(r"^```\w*|```$", "", texto.strip()).strip()
                v["partes_roteiro"] = partes
                v["roteiro"] = "\n\n".join(x for x in partes if x)
                v["etapas"]["roteiro"] = bool(v["roteiro"])
            elif tipo == "titulo":
                v["titulo_check"] = prompts.parse_json(texto)
            elif tipo == "publicado":
                v["publicado_analise"] = prompts.parse_json(texto)
            else:
                return erro("Tipo inválido")
        except ValueError as e:
            return erro(f"Não consegui ler o JSON: {e}")
        except Exception as e:
            return erro(f"Resposta em formato inesperado: {e}")
        if tipo in ("roteiro", "correcao", "parte") and v.get("roteiro"):
            threading.Thread(target=darkplanner_sync.salvar_roteiro_dp, args=(v.get("channel_id"), vid, v["roteiro"]), daemon=True).start()
        return jsonify({"ok": True, "video": v})


@app.route("/api/videos/<vid>/dividir", methods=["POST"])
def video_dividir(vid):
    data = request.json or {}
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        s = db["settings"]
        seg = float(data.get("segundos_por_cena") or s.get("segundos_por_cena", 8))
        if not v.get("roteiro"):
            return erro("Sem roteiro.")
        v["cenas"] = scenes.dividir_cenas(v["roteiro"], seg, s.get("palavras_por_minuto", 150))
        dur = render.duracao_midia(_abs(vid, v["narracao"])) if v.get("narracao") and os.path.exists(_abs(vid, v["narracao"])) else None
        _tempos(v, dur, s.get("palavras_por_minuto", 150))
        _gravar_srt(v)
        v["etapas"]["cenas"] = False
        v["etapas"]["midia"] = False
        return jsonify(v)


def _tempos(v, dur=None, ppm=150):
    if v.get("narracao_origem") == "vozlab" and scenes.aplicar_tempos_blocos(v["cenas"], v.get("blocos_voz") or []):
        return
    scenes.aplicar_tempos(v["cenas"], dur or v.get("narracao_duracao"), ppm)


def _gravar_srt(v):
    v["srt"] = scenes.gerar_srt(v["cenas"])
    with open(os.path.join(storage.video_dir(v["id"]), "legendas.srt"), "w", encoding="utf-8") as f:
        f.write(v["srt"])


@app.route("/api/videos/<vid>/narracao", methods=["POST"])
def video_narracao(vid):
    f = request.files.get("arquivo")
    if not f:
        return erro("Envie o arquivo de áudio.")
    rel, path = _salvar_upload(vid, f, "narracao")
    dur = render.duracao_midia(path)
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        v["narracao"] = rel
        v["narracao_duracao"] = dur
        v["narracao_origem"] = "upload"
        v["etapas"]["narracao"] = True
        if v.get("cenas") and dur:
            scenes.aplicar_tempos(v["cenas"], dur)
            _gravar_srt(v)
        return jsonify(v)


@app.route("/api/videos/<vid>/musica", methods=["POST"])
def video_musica(vid):
    f = request.files.get("arquivo")
    if not f:
        return erro("Envie o arquivo de música.")
    rel, _ = _salvar_upload(vid, f, "musica")
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        v["musica"] = rel
        return jsonify(v)


# ---------------- mídia por cena ----------------
def _limpar_cand(c):
    c = dict(c)
    c.pop("texto_match", None)
    return c


def _job_midia(vid, so_pendentes=False, so_ns=None, so_ia=False):
    job = MEDIA_JOBS[vid]
    try:
        if so_ia:
            reallab.job_ia(vid, job, so_ns)
        else:
            reallab.job_midia(vid, job, so_pendentes, so_ns)
        job["etapa"] = "Pronto"
    except Exception as e:
        job["erro"] = str(e)
    finally:
        job["rodando"] = False


def _iniciar_job_midia(vid, **kw):
    if MEDIA_JOBS.get(vid, {}).get("rodando"):
        raise RuntimeError("Já tem uma busca/geração rodando neste vídeo.")
    MEDIA_JOBS[vid] = {"rodando": True, "feito": 0, "total": 0, "etapa": "Iniciando", "erros": []}
    threading.Thread(target=_job_midia, args=(vid,), kwargs=kw, daemon=True).start()


@app.route("/api/videos/<vid>/buscar_midia", methods=["POST"])
def video_buscar_midia(vid):
    try:
        _iniciar_job_midia(vid, so_pendentes=bool((request.json or {}).get("so_pendentes")))
    except RuntimeError as e:
        return erro(str(e))
    return jsonify({"ok": True})


@app.route("/api/videos/<vid>/lote", methods=["POST"])
def video_lote(vid):
    """Ações em lote nas cenas marcadas: buscar | mandar_ia | gerar_ia | conferir."""
    d = request.json or {}
    ns = [int(x) for x in d.get("ns", [])]
    acao = d.get("acao")
    if not ns:
        return erro("Marque pelo menos uma cena.")
    if acao == "mandar_ia":
        with Tx() as db:
            v, _ = _video_ctx(db, vid)
            for c in v["cenas"]:
                if c["n"] in ns:
                    c.update(midia=None, status="ia", forcar_ia=True)
        return jsonify({"ok": True})
    try:
        if acao == "buscar":
            with Tx() as db:
                v, _ = _video_ctx(db, vid)
                for c in v["cenas"]:
                    if c["n"] in ns:
                        c["forcar_ia"] = False
                        if c.get("midia") and c["midia"].get("origem") == "manual":
                            c["midia"] = None
            _iniciar_job_midia(vid, so_ns=ns)
        elif acao == "gerar_ia":
            _iniciar_job_midia(vid, so_ns=ns, so_ia=True)
        else:
            return erro("Ação inválida")
    except RuntimeError as e:
        return erro(str(e))
    return jsonify({"ok": True})


@app.route("/api/videos/<vid>/cenas/<int:n>/conferir", methods=["POST"])
def cena_conferir(vid, n):
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    c = next((x for x in v["cenas"] if x["n"] == n), None)
    m = (c or {}).get("midia")
    if not m:
        return erro("A cena não tem mídia.")
    try:
        if m.get("arquivo") and m.get("tipo") == "foto":
            dados, mime = reallab._bytes_preview("local:" + _abs(vid, m["arquivo"]))
        else:
            dados, mime = reallab._bytes_preview(m.get("preview") or m.get("download"))
        r = gemini.conferir_midia(dados, mime, c, vid)
    except Exception as e:
        return erro(str(e))
    with Tx() as db2:
        v2, _ = _video_ctx(db2, vid)
        c2 = next(x for x in v2["cenas"] if x["n"] == n)
        if c2.get("midia"):
            c2["midia"]["na_imagem"] = r.get("na_imagem", "")
            c2["midia"]["conferida"] = r.get("serve")
        if not r.get("serve"):
            c2.setdefault("avisos", []).append(f"Conferência: {reallab.MOTIVOS.get(r.get('motivo'), r.get('motivo'))} — {r.get('na_imagem','')}")
        return jsonify({"resultado": r, "cena": c2})


@app.route("/api/videos/<vid>/midia_status")
def video_midia_status(vid):
    return jsonify(MEDIA_JOBS.get(vid, {"rodando": False}))


@app.route("/api/videos/<vid>/cenas/<int:n>/buscar", methods=["POST"])
def cena_buscar(vid, n):
    d = request.json or {}
    termos = [t.strip() for t in d.get("termos", []) if t.strip()]
    modo = d.get("modo", "")
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    c = next((x for x in v["cenas"] if x["n"] == n), None)
    if not c:
        return erro("Cena não encontrada", 404)
    erros = []
    if modo == "pessoa":
        nome = (d.get("nome") or c.get("pessoa_real") or "").strip()
        if not nome:
            return erro("Informe o nome da pessoa real.")
        cands = []
        for i, t in enumerate([nome, f"{nome} portrait", f"{nome} photograph"]):
            try:
                res = media.buscar_wikimedia(t)
            except Exception as e:
                erros.append(str(e))
                res = []
            for x in res:
                x["nota"], x["match"] = media.pontuar(nome, x.get("texto_match", ""), 0, nome)
                x["termo"] = t
            cands += res
        vistos, uniq = set(), []
        for x in sorted(cands, key=lambda x: x["nota"], reverse=True):
            if x["download"] not in vistos:
                vistos.add(x["download"])
                uniq.append(x)
        cands = uniq[:30]
        termos = []
        with Tx() as dbp:
            vp, _ = _video_ctx(dbp, vid)
            next(x for x in vp["cenas"] if x["n"] == n)["pessoa_real"] = nome
    elif modo == "youtube":
        q = termos[0] if termos else ((c.get("termos_busca") or [c["texto"][:60]])[0])
        try:
            cands = radar.buscar_youtube_cc(db["settings"].get("youtube_api_key"), q)
        except Exception as e:
            return erro(str(e))
        if not db["settings"].get("youtube_api_key"):
            return erro("Coloque a chave da YouTube Data API em Configurações.")
        for x in cands:
            x["nota"], x["match"] = media.pontuar(q, x.get("texto_match", ""), 0, c.get("pessoa_real", ""))
        cands.sort(key=lambda x: x["nota"], reverse=True)
        termos = []
    else:
        if modo == "contexto":
            base = (c.get("termos_busca") or [])[-1:] or [" ".join(media._tokens(c.get("descricao_visual") or c["texto"])[:3])]
            termos = base + [f"{base[0]} landscape", f"{base[0]} historical"]
        cands, erros = media.candidatos_cena(c, db["settings"], termos or None)
        if modo == "contexto":
            termos = []
    with Tx() as db2:
        v2, _ = _video_ctx(db2, vid)
        c2 = next(x for x in v2["cenas"] if x["n"] == n)
        c2["candidatos"] = [_limpar_cand(x) for x in cands]
        if termos:
            c2["termos_busca"] = termos
        return jsonify({"cena": c2, "erros": erros})


@app.route("/api/videos/<vid>/cenas/<int:n>/escolher", methods=["POST"])
def cena_escolher(vid, n):
    idx = (request.json or {}).get("indice")
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        c = next((x for x in v["cenas"] if x["n"] == n), None)
        if not c:
            return erro("Cena não encontrada", 404)
        if idx is None or idx >= len(c.get("candidatos", [])):
            return erro("Candidato inválido")
        c["midia"] = dict(c["candidatos"][idx], origem="manual")
        c["status"] = "escolhida"
        c["forcar_ia"] = False
        return jsonify(c)


@app.route("/api/videos/<vid>/cenas/<int:n>/arquivo", methods=["POST"])
def cena_arquivo(vid, n):
    f = request.files.get("arquivo")
    if not f:
        return erro("Envie um arquivo.")
    rel, _ = _salvar_upload(vid, f, f"cena_{n:03d}_manual")
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        c = next((x for x in v["cenas"] if x["n"] == n), None)
        c["midia"] = {"fonte": "Computador", "tipo": _tipo_arquivo(rel), "arquivo": rel, "titulo": f.filename, "origem": "manual", "nota": 10, "match": "exata"}
        c["status"] = "manual"
        c["forcar_ia"] = False
        return jsonify(c)


@app.route("/api/videos/<vid>/cenas/<int:n>/ia", methods=["POST"])
def cena_ia(vid, n):
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        c = next((x for x in v["cenas"] if x["n"] == n), None)
        c["midia"] = None
        c["status"] = "ia"
        c["forcar_ia"] = True
        return jsonify(c)


@app.route("/api/videos/<vid>/cenas/<int:n>", methods=["PATCH"])
def cena_editar(vid, n):
    data = request.json or {}
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        c = next((x for x in v["cenas"] if x["n"] == n), None)
        for k in ("texto", "prompt_ia", "descricao_visual", "pessoa_real"):
            if k in data:
                c[k] = data[k]
        if "texto" in data:
            c["palavras"] = scenes.contar_palavras(c["texto"])
            _tempos(v)
            _gravar_srt(v)
        return jsonify(c)


@app.route("/api/videos/<vid>/importar_lote", methods=["POST"])
def importar_lote(vid):
    """Arquivos com o número da cena no nome (ex.: 007.png, cena_12.mp4) entram na cena certa."""
    arquivos = request.files.getlist("arquivos")
    ok, ignorados = 0, []
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        por_n = {c["n"]: c for c in v["cenas"]}
        for f in arquivos:
            m = re.search(r"(\d+)", os.path.basename(f.filename or ""))
            if not m or int(m.group(1)) not in por_n:
                ignorados.append(f.filename)
                continue
            n = int(m.group(1))
            rel, _ = _salvar_upload(vid, f, f"cena_{n:03d}_lote")
            por_n[n]["midia"] = {"fonte": "IA/Lote", "tipo": _tipo_arquivo(rel), "arquivo": rel, "titulo": f.filename, "origem": "manual", "nota": 10, "match": "exata"}
            por_n[n]["status"] = "manual"
            por_n[n]["forcar_ia"] = False
            ok += 1
    return jsonify({"importados": ok, "ignorados": ignorados})


@app.route("/api/videos/<vid>/prompts_ia")
def prompts_ia(vid):
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    linhas = []
    for c in v["cenas"]:
        if c.get("status") == "ia" or not c.get("midia"):
            p = c.get("prompt_ia") or c.get("descricao_visual") or c["texto"]
            look = db["settings"].get("ia_look", "").strip()
            linhas.append(f"{c['n']:03d} | {p}" + (f", {look}" if look else ""))
    return jsonify({"texto": "\n".join(linhas), "quantidade": len(linhas)})


@app.route("/api/videos/<vid>/midia/<int:n>")
def servir_midia_cena(vid, n):
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    c = next((x for x in v["cenas"] if x["n"] == n), None)
    arq = _abs(vid, ((c or {}).get("midia") or {}).get("arquivo"))
    if not arq or not os.path.exists(arq):
        return erro("Sem arquivo local", 404)
    return send_file(arq)


# ---------------- montagem ----------------
YT_BLOQUEADO = [0.0]  # até quando não tentar baixar do YouTube (ele está bloqueando)


def _baixar_escolhidas(vid, job, so_n=None, sem_youtube=False):
    """Baixa para o computador as mídias escolhidas que ainda estão só na internet (uma por vez, com calma)."""
    import time as _t

    db = storage.load()
    v, _ = _video_ctx(db, vid)
    pasta = storage.video_dir(vid)
    ja_quebrou = set()
    for c in v["cenas"]:  # arquivo de vídeo quebrado (ex.: .mp4 vazio do YouTube): apaga para baixar de novo
        arq = _abs(vid, (c.get("midia") or {}).get("arquivo"))
        if arq and os.path.exists(arq) and (c.get("midia") or {}).get("tipo") == "video" and (so_n is None or c["n"] == so_n) \
                and (os.path.getsize(arq) < 20000 or not media.video_ok(arq)) and c["midia"].get("download"):
            try:
                os.remove(arq)
            except OSError:
                pass
            if "youtube.com" in c["midia"]["download"]:
                ja_quebrou.add(c["n"])  # o YouTube já entregou vazio uma vez: vai direto para outra mídia
    faltam = [c for c in v["cenas"] if (so_n is None or c["n"] == so_n) and c.get("midia")
              and not (c["midia"].get("arquivo") and os.path.exists(_abs(vid, c["midia"]["arquivo"]))) and c["midia"].get("download")]
    job.setdefault("log", [])
    job.setdefault("falhas", [])
    job["total"] = len(faltam)
    job["feito"] = 0
    baixados = {}

    trocas = {}

    def _baixar_um(m, destino):
        url = m.get("download") or ""
        if "youtube.com" in url and _t.time() < YT_BLOQUEADO[0]:
            raise RuntimeError("YouTube bloqueando downloads agora — pulando")
        try:
            return media.baixar(url, destino, m.get("tipo", "foto"), m)
        except media.MidiaRuim:
            raise
        except Exception:
            if "youtube.com" in url:
                YT_BLOQUEADO[0] = _t.time() + 3600  # falhou uma vez: não insiste no YouTube por 1 hora
            raise

    def salvar():
        if not baixados and not trocas:
            return
        with Tx() as db2:
            v2, _ = _video_ctx(db2, vid)
            for c in v2["cenas"]:
                if c["n"] in trocas:
                    c["midia"] = trocas[c["n"]]
                elif c["n"] in baixados and c.get("midia"):
                    c["midia"]["arquivo"] = baixados[c["n"]]
        baixados.clear()
        trocas.clear()

    import threading as _th
    from concurrent.futures import ThreadPoolExecutor

    trava = _th.RLock()

    def um(i, c):
            if job.get("checar"):
                job["checar"]()  # pausar/parar funciona no meio dos downloads
            m = c["midia"]
            job["etapa"] = f"Baixando mídia da cena {c['n']} ({i + 1}/{len(faltam)})"
            job["log"].append(job["etapa"])
            destino = os.path.join(pasta, "midia", f"cena_{c['n']:03d}")
            try:
                if c["n"] in ja_quebrou or (sem_youtube and "youtube.com" in (m.get("download") or "")):
                    raise RuntimeError("YouTube pulado na montagem (usa outra mídia da cena)")
                path = _baixar_um(m, destino)
                with trava:
                    baixados[c["n"]] = os.path.relpath(path, pasta)
            except Exception as e:
                job["log"].append(f"Falhou cena {c['n']}: {str(e)[:200]}")
                # tenta os próximos candidatos da própria cena (sem YouTube se ele estiver bloqueando)
                usados = {(x.get("midia") or {}).get("download") for x in v["cenas"] if x.get("midia")}
                alternativa = None
                for cand in (c.get("candidatos") or [])[:12]:
                    if cand.get("download") in usados or cand.get("download") == m.get("download") or cand.get("nota", 0) < 4 \
                            or media.TERMOS_RUINS.search(f"{cand.get('titulo', '')} {cand.get('texto_match', '')}"):
                        continue
                    if "youtube.com" in cand.get("download", "") and (sem_youtube or _t.time() < YT_BLOQUEADO[0]):
                        continue
                    try:
                        job["etapa"] = f"Cena {c['n']}: tentando outra mídia ({cand.get('fonte')})"
                        path = _baixar_um(cand, destino)
                        alternativa = dict(cand, origem="auto", arquivo=os.path.relpath(path, pasta), trocada_download=True)
                        break
                    except Exception:
                        continue
                if alternativa:
                    with trava:
                        trocas[c["n"]] = alternativa
                    job["log"].append(f"Cena {c['n']}: usei outra mídia ({alternativa.get('fonte')})")
                else:
                    job["falhas"].append(c["n"])
            with trava:
                job["feito"] = job.get("feito", 0) + 1
                if len(baixados) + len(trocas) >= 5:
                    salvar()
            if "wikimedia" in (m.get("download") or ""):
                _t.sleep(0.4)  # o Wikimedia bloqueia quem pede rápido demais

    # 3 downloads ao mesmo tempo (o YouTube vai um por vez, para não ser bloqueado)
    yt = [(i, c) for i, c in enumerate(faltam) if "youtube.com" in ((c.get("midia") or {}).get("download") or "")]
    resto = [(i, c) for i, c in enumerate(faltam) if (i, c) not in yt]
    with ThreadPoolExecutor(max_workers=3) as ex:
        futs = []
        futs = [ex.submit(um, i, c) for i, c in resto]
        try:
            for f in futs:
                f.result()
        finally:
            for f in futs:
                f.cancel()
            with trava:
                salvar()  # guarda o que já baixou, mesmo se pausar/parar
    for i, c in yt:
        if job.get("checar"):
            salvar()
            job["checar"]()
        um(i, c)
    salvar()


DL_JOBS = {}


@app.route("/api/videos/<vid>/baixar_midias", methods=["GET", "POST"])
def baixar_midias(vid):
    if request.method == "GET":
        db = storage.load()
        v, _ = _video_ctx(db, vid)
        faltam = sum(1 for c in v["cenas"] if c.get("midia") and c["midia"].get("download")
                     and not (c["midia"].get("arquivo") and os.path.exists(_abs(vid, c["midia"]["arquivo"]))))
        j = DL_JOBS.get(vid, {"rodando": False})
        return jsonify({k: j.get(k) for k in ("rodando", "etapa", "feito", "total", "falhas")} | {"faltam": faltam})
    if DL_JOBS.get(vid, {}).get("rodando"):
        return jsonify({"ok": True})
    job = DL_JOBS[vid] = {"rodando": True, "feito": 0, "total": 0, "etapa": "Começando", "log": [], "falhas": []}

    def tarefa():
        try:
            _baixar_escolhidas(vid, job)
            job["etapa"] = "Pronto"
        except Exception as e:
            job["etapa"] = f"Erro: {e}"
        finally:
            job["rodando"] = False

    threading.Thread(target=tarefa, daemon=True).start()
    return jsonify({"ok": True})


def _montar_video(vid, job):
    """Baixa o que falta e monta o final.mp4 (usado pelo botão Montar e pelo Estúdio 1 clique)."""
    _baixar_escolhidas(vid, job, sem_youtube=True)  # na montagem não insiste no YouTube: troca pela próxima mídia
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    vv = copy.deepcopy(v)
    vv["idioma"] = estudio.idioma_video(v, find(db["channels"], v.get("channel_id")) or {})  # a língua da narração, não a do canal
    for c in vv["cenas"]:
        if c.get("midia") and c["midia"].get("arquivo"):
            c["midia"]["arquivo"] = _abs(vid, c["midia"]["arquivo"])
        c["layout_imgs_abs"] = [_abs(vid, x) for x in (c.get("layout_imgs") or [])]
        if c.get("layout_mapa"):
            c["layout_mapa_abs"] = _abs(vid, c["layout_mapa"])
    n_cap = 0
    for c in vv["cenas"]:  # numeração dos capítulos (PARTE I, II, III…)
        if c.get("layout") == "capitulo":
            n_cap += 1
            c["capitulo_num"] = n_cap
    vv["narracao"] = _abs(vid, vv.get("narracao"))
    vv["musica"] = _abs(vid, vv.get("musica"))
    if not vv.get("narracao_duracao") and vv["narracao"]:
        d = render.duracao_midia(vv["narracao"])
        if d:
            scenes.aplicar_tempos(vv["cenas"], d)
    render.renderizar(vv, db["settings"], storage.video_dir(vid))
    res = render.JOBS.get(vid, {})
    if res.get("saida") and not res.get("erro"):
        with Tx() as db2:
            v2, _ = _video_ctx(db2, vid)
            v2["saida"] = os.path.relpath(res["saida"], storage.video_dir(vid))
            v2["etapas"]["montagem"] = True
            cred = media.creditos(v2["cenas"])
            with open(os.path.join(storage.video_dir(vid), "creditos.txt"), "w", encoding="utf-8") as f:
                f.write(cred)
    return res


@app.route("/api/videos/<vid>/render", methods=["POST"])
def video_render(vid):
    if render.JOBS.get(vid, {}).get("rodando"):
        return erro("Já está montando.")
    render.JOBS[vid] = {"log": [], "pct": 0, "rodando": True, "etapa": "Preparando"}

    def tarefa():
        job = render.JOBS[vid]
        try:
            _montar_video(vid, job)
        except Exception as e:
            job["erro"] = str(e)
            job["rodando"] = False

    threading.Thread(target=tarefa, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/videos/<vid>/render_status")
def video_render_status(vid):
    j = dict(render.JOBS.get(vid, {"rodando": False}))
    j["log"] = j.get("log", [])[-8:]
    return jsonify(j)


@app.route("/api/videos/<vid>/arquivo/<nome>")
def video_arquivo(vid, nome):
    permitidos = {"final.mp4", "legendas.srt", "creditos.txt"}
    if nome not in permitidos:
        return erro("Arquivo inválido", 404)
    p = os.path.join(storage.video_dir(vid), nome)
    if not os.path.exists(p):
        return erro("Ainda não existe", 404)
    return send_file(p, as_attachment=request.args.get("baixar") == "1")


@app.route("/api/videos/<vid>/abrir_pasta", methods=["POST"])
def abrir_pasta(vid):
    p = storage.video_dir(vid)
    try:
        if os.name == "nt":
            os.startfile(p)  # type: ignore[attr-defined]
            return jsonify({"ok": True, "pasta": p})
        return jsonify({
            "ok": True,
            "modo_remoto": True,
            "pasta": p,
            "download_zip_url": f"/api/projetos-criados/baixar-zip?vid={vid}",
        })
    except Exception as e:
        return erro(str(e))


# ---------------- radar e títulos ----------------
@app.route("/api/radar", methods=["POST"])
def radar_buscar():
    d = request.json or {}
    s = storage.load()["settings"]
    try:
        res = radar.buscar(
            s.get("youtube_api_key"),
            d.get("termo", ""),
            d.get("idioma", "pt"),
            d.get("dias", 30),
            d.get("min_duracao_s", 240),
            d.get("paginas", 1),
        )
    except Exception as e:
        return erro(str(e))
    return jsonify(res)


@app.route("/api/radar/salvos", methods=["GET", "POST", "DELETE"])
def radar_salvos():
    if request.method == "GET":
        cid = request.args.get("channel")
        return jsonify([r for r in storage.load()["radar_saved"] if not cid or r.get("channel_id") == cid])
    with Tx() as db:
        if request.method == "DELETE":
            rid = request.args.get("id")
            db["radar_saved"] = [r for r in db["radar_saved"] if r.get("id") != rid]
            return jsonify({"ok": True})
        d = request.json or {}
        existentes = {(r.get("channel_id"), r.get("video_id")) for r in db["radar_saved"]}
        add = 0
        for r in d.get("itens", []):
            if (d.get("channel_id"), r.get("video_id")) in existentes:
                continue
            db["radar_saved"].append(dict(r, id=storage.new_id("r"), channel_id=d.get("channel_id", "")))
            add += 1
        return jsonify({"adicionados": add})


@app.route("/api/titulos/prompt", methods=["POST"])
def titulos_prompt():
    d = request.json or {}
    db = storage.load()
    c = find(db["channels"], d.get("channel_id")) or {}
    refs = [r for r in db["radar_saved"] if r.get("channel_id") == c.get("id")]
    return jsonify({"prompt": prompts.titulos(c, refs[:40], int(d.get("quantidade", 20)))})


@app.route("/api/titulos/colar", methods=["POST"])
def titulos_colar():
    d = request.json or {}
    try:
        j = prompts.parse_json(d.get("texto", ""))
    except ValueError as e:
        return erro(f"Não consegui ler o JSON: {e}")
    ideias_ = j.get("ideias", []) if isinstance(j, dict) else j
    ideias_ = [{"titulo": x} if isinstance(x, str) else x for x in ideias_]
    with Tx() as db:
        novas = []
        for it in ideias_:
            if not it.get("titulo"):
                continue
            novas.append({"id": storage.new_id("i"), "channel_id": d.get("channel_id", ""), "titulo": it["titulo"], "gancho": it.get("gancho", ""), "porque": it.get("porque", ""), "usada": False, "criado_em": storage.now()})
        db["ideas"].extend(novas)
        return jsonify(novas)



# =====================================================================
# VozLab — narração por blocos
# =====================================================================
VOZ_JOBS = {}


def _voz_cfg(db, v, c):
    s = db["settings"]
    idioma = (c or {}).get("idioma", "pt")
    nar_dp = (((c or {}).get("dp") or {}).get("narrator") or {}).get("voice_id") or ""
    base = {
        "motor": s.get("voz_motor", "edge"),
        "voz_edge": s.get(f"voz_edge_{idioma}") or voz.VOZES_EDGE.get(idioma, voz.VOZES_EDGE["pt"])[0][0],
        "voz_gemini": s.get("voz_gemini", "Charon"),
        "voz_azure": s.get(f"voz_azure_{idioma}") or s.get(f"voz_edge_{idioma}") or "",
        "voz_elevenlabs": s.get("voz_elevenlabs", ""),
        "voz_fish": s.get("voz_fish", ""),
        "voz_darkplanner": nar_dp or s.get("voz_darkplanner", ""),
        "velocidade": s.get("voz_velocidade", "+0%"),
        "tom": "+0Hz",
        "estilo": s.get("voz_estilo", ""),
    }
    base.update(v.get("voz") or {})
    return base


@app.route("/api/vozes")
def vozes():
    return jsonify({"edge": voz.VOZES_EDGE, "gemini": voz.VOZES_GEMINI})


@app.route("/api/videos/<vid>/voz/preparar", methods=["POST"])
def voz_preparar(vid):
    max_chars = int((request.json or {}).get("max_chars", 900))
    with Tx() as db:
        v, c = _video_ctx(db, vid)
        if not v.get("roteiro"):
            return erro("Sem roteiro.")
        v["blocos_voz"] = voz.dividir_blocos(v["roteiro"], max_chars)
        v["voz"] = _voz_cfg(db, v, c)
        return jsonify(v)


@app.route("/api/videos/<vid>/voz/config", methods=["PATCH"])
def voz_config(vid):
    d = request.json or {}
    with Tx() as db:
        v, c = _video_ctx(db, vid)
        cfg = _voz_cfg(db, v, c)
        mudou = False
        for k in ("motor", "voz_edge", "voz_gemini", "voz_azure", "voz_elevenlabs", "voz_fish", "voz_darkplanner", "modelo_elevenlabs", "velocidade", "tom", "estilo"):
            if k in d and d[k] != cfg.get(k):
                cfg[k] = d[k]
                mudou = True
        v["voz"] = cfg
        if mudou and d.get("refazer_todos"):
            for b in v["blocos_voz"]:
                b["status"] = "pendente"
        return jsonify(v)


@app.route("/api/videos/<vid>/voz/bloco/<int:i>", methods=["PATCH"])
def voz_bloco_editar(vid, i):
    texto = (request.json or {}).get("texto", "").strip()
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        b = next((x for x in v["blocos_voz"] if x["i"] == i), None)
        if not b:
            return erro("Bloco não encontrado", 404)
        if texto and texto != b["texto"]:
            b["texto"] = texto
            b["status"] = "pendente"
            # mantém o roteiro igual ao que é narrado
            v["roteiro"] = "\n\n".join(x["texto"] for x in v["blocos_voz"])
        return jsonify(b)


def _job_voz(vid, so_i=None):
    job = VOZ_JOBS[vid]
    try:
        db = storage.load()
        v, c = _video_ctx(db, vid)
        cfg = _voz_cfg(db, v, c)
        alvo = [b for b in v["blocos_voz"] if (so_i is None and b["status"] != "pronto") or b["i"] == so_i]
        job["total"] = len(alvo)
        pasta = storage.video_dir(vid)
        for k, b in enumerate(alvo):
            job["feito"] = k
            job["etapa"] = f"Gerando bloco {b['i']}"
            res = {"status": "erro", "erro": "", "arquivo": "", "duracao": 0}
            for tentativa in range(2):
                try:
                    path = voz.gerar_bloco(b, db["settings"], pasta, cfg)
                    res = {"status": "pronto", "erro": "", "arquivo": os.path.relpath(path, pasta), "duracao": render.duracao_midia(path) or 0}
                    break
                except Exception as e:
                    res["erro"] = str(e)[:300]
            with Tx() as db2:
                v2, _ = _video_ctx(db2, vid)
                b2 = next((x for x in v2["blocos_voz"] if x["i"] == b["i"]), None)
                if b2:
                    b2.update(res)
            if res["status"] == "erro":
                job.setdefault("erros", []).append(f"Bloco {b['i']}: {res['erro']}")
        job["feito"] = job["total"]
        job["etapa"] = "Pronto"
    except Exception as e:
        job["erro"] = str(e)
    finally:
        job["rodando"] = False


@app.route("/api/videos/<vid>/voz/gerar", methods=["POST"])
def voz_gerar(vid):
    if VOZ_JOBS.get(vid, {}).get("rodando"):
        return erro("Já está gerando.")
    i = (request.json or {}).get("i")
    VOZ_JOBS[vid] = {"rodando": True, "feito": 0, "total": 0, "etapa": "Iniciando", "erros": []}
    threading.Thread(target=_job_voz, args=(vid, i), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/videos/<vid>/voz/status")
def voz_status(vid):
    return jsonify(VOZ_JOBS.get(vid, {"rodando": False}))


@app.route("/api/videos/<vid>/voz/audio/<int:i>")
def voz_audio(vid, i):
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    b = next((x for x in v["blocos_voz"] if x["i"] == i), None)
    p = _abs(vid, (b or {}).get("arquivo"))
    if not p or not os.path.exists(p):
        return erro("Áudio ainda não gerado", 404)
    return send_file(p)


@app.route("/api/videos/<vid>/voz/juntar", methods=["POST"])
def voz_juntar(vid):
    pausa = float((request.json or {}).get("pausa", 0.35))
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    blocos = v.get("blocos_voz") or []
    if not blocos or any(b["status"] != "pronto" for b in blocos):
        return erro("Gere todos os blocos antes de juntar.")
    pasta = storage.video_dir(vid)
    saida = os.path.join(pasta, "narracao_vozlab.mp3")
    try:
        voz.juntar([_abs(vid, b["arquivo"]) for b in blocos], saida, render.ffmpeg_bin(), pausa)
    except Exception as e:
        return erro(f"Falha ao juntar: {e}")
    dur = render.duracao_midia(saida)
    with Tx() as db2:
        v2, _ = _video_ctx(db2, vid)
        v2["narracao"] = os.path.relpath(saida, pasta)
        v2["narracao_duracao"] = dur
        v2["narracao_origem"] = "vozlab"
        v2["etapas"]["narracao"] = True
        if v2.get("cenas"):
            if not scenes.aplicar_tempos_blocos(v2["cenas"], v2["blocos_voz"], pausa):
                scenes.aplicar_tempos(v2["cenas"], dur)
            _gravar_srt(v2)
        return jsonify(v2)


@app.route("/api/videos/<vid>/voz/final")
def voz_final(vid):
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    p = _abs(vid, v.get("narracao"))
    if not p or not os.path.exists(p):
        return erro("Sem narração", 404)
    return send_file(p)


@app.route("/api/voz/teste", methods=["POST"])
def voz_teste():
    d = request.json or {}
    db = storage.load()
    texto = d.get("texto") or "Esta é uma amostra da voz que vai narrar o seu vídeo."
    destino = os.path.join(storage.DATA_DIR, "voz_teste")
    for ext in (".mp3", ".wav"):
        if os.path.exists(destino + ext):
            os.remove(destino + ext)
    motor = d.get("motor", "edge")
    cfg = {"voz_" + motor: d.get("voz"), "velocidade": d.get("velocidade", "+0%"), "estilo": d.get("estilo", ""), "voz_edge": d.get("voz") if motor == "edge" else None}
    try:
        conta = None
        if motor in ("azure", "elevenlabs", "fish", "darkplanner"):
            conta = next(iter(chaves.lista(db, motor)), None)
            if not conta:
                raise RuntimeError(f"Conecte uma conta de {voz.PROVEDORES[motor]['nome']} em Conexões.")
        elif motor == "gemini":
            conta = next(iter(chaves.ordem("gemini", db)), None)
        p = voz.gerar_com(motor, texto, cfg, destino, db["settings"], conta)
        chaves.consumo_add("tts", motor, caracteres=len(texto), bytes=len(texto.encode("utf-8")))
    except Exception as e:
        return erro(str(e))
    return send_file(p)


# =====================================================================
# Referência por arquivo ou vídeo do YouTube
# =====================================================================
def _texto_arquivo(f):
    nome = (f.filename or "").lower()
    dados = f.read()
    if nome.endswith(".pdf"):
        import io

        from pypdf import PdfReader

        r = PdfReader(io.BytesIO(dados))
        return "\n".join((p.extract_text() or "") for p in r.pages)
    if nome.endswith(".docx"):
        import io
        import zipfile

        with zipfile.ZipFile(io.BytesIO(dados)) as z:
            xml = z.read("word/document.xml").decode("utf-8", "ignore")
        xml = re.sub(r"</w:p>", "\n", xml)
        return re.sub(r"<[^>]+>", "", xml)
    for enc in ("utf-8", "latin-1"):
        try:
            return dados.decode(enc)
        except Exception:
            continue
    return ""


def _transcricao_youtube(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([\w-]{11})", url)
    if not m:
        raise RuntimeError("Link do YouTube inválido.")
    vid_id = m.group(1)
    from youtube_transcript_api import YouTubeTranscriptApi

    langs = ["pt", "pt-BR", "en", "es"]
    try:
        api_ = YouTubeTranscriptApi()
        tr = api_.fetch(vid_id, languages=langs)
        return " ".join(getattr(x, "text", "") for x in tr)
    except AttributeError:
        tr = YouTubeTranscriptApi.get_transcript(vid_id, languages=langs)  # versões antigas
        return " ".join(x["text"] for x in tr)


@app.route("/api/videos/<vid>/referencia", methods=["POST"])
def video_referencia(vid):
    try:
        if request.files.get("arquivo"):
            f = request.files["arquivo"]
            texto, origem = _texto_arquivo(f), f.filename
        else:
            url = (request.json or {}).get("youtube", "")
            texto, origem = _transcricao_youtube(url), url
    except Exception as e:
        return erro(f"Não consegui ler: {e}")
    texto = re.sub(r"[ \t]+", " ", texto or "").strip()
    if len(texto) < 50:
        return erro("Não encontrei texto suficiente nesse material.")
    texto = texto[:60000]
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        atual = v["briefing"].get("referencias", "")
        v["briefing"]["referencias"] = (atual + f"\n\n--- {origem} ---\n" + texto).strip()
        return jsonify({"ok": True, "caracteres": len(texto), "video": v})


# =====================================================================
# Editor de cenas
# =====================================================================
CAMPOS_HIST = ("n", "inicio", "fim", "movimento", "titulo_tela", "nome_tela", "filtro", "midia", "status", "forcar_ia")


def _snapshot(v, acao):
    snap = {"quando": storage.now()[11:19], "acao": acao, "editor": copy.deepcopy(v.get("editor") or {}),
            "cenas": [{k: copy.deepcopy(c.get(k)) for k in CAMPOS_HIST} for c in v["cenas"]]}
    hist = v.setdefault("historico", [])
    hist.append(snap)
    del hist[:-30]


def _restaurar(v, snap):
    por_n = {x["n"]: x for x in snap["cenas"]}
    for c in v["cenas"]:
        x = por_n.get(c["n"])
        if x:
            for k in CAMPOS_HIST:
                c[k] = copy.deepcopy(x.get(k))
    v["editor"] = copy.deepcopy(snap.get("editor") or {})
    _gravar_srt(v)


@app.route("/api/videos/<vid>/cenas/<int:n>/editor", methods=["PATCH"])
def cena_editor(vid, n):
    d = request.json or {}
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        cenas = v["cenas"]
        idx = next((i for i, x in enumerate(cenas) if x["n"] == n), None)
        if idx is None:
            return erro("Cena não encontrada", 404)
        _snapshot(v, f"cena {n}: " + ", ".join(k for k in d))
        c = cenas[idx]
        for k in ("movimento", "titulo_tela", "nome_tela", "filtro"):
            if k in d:
                c[k] = d[k]
        if d.get("sem_midia"):
            c.update(midia=None, status="vazia", forcar_ia=True)
        if "duracao" in d and idx + 1 < len(cenas):
            nova_fim = c["inicio"] + float(d["duracao"])
            prox = cenas[idx + 1]
            limite = prox["fim"] - 0.6
            nova_fim = max(c["inicio"] + 0.6, min(nova_fim, limite))
            c["fim"] = round(nova_fim, 3)
            prox["inicio"] = c["fim"]
            _gravar_srt(v)
        return jsonify(v)


@app.route("/api/videos/<vid>/editor", methods=["GET", "PATCH"])
def video_editor(vid):
    if request.method == "GET":
        v, _ = _video_ctx(storage.load(), vid)
        return jsonify(v.get("editor") or {})
    d = request.json or {}
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        _snapshot(v, "editor: " + ", ".join(d))
        ed = v.setdefault("editor", {})
        for k in ("template", "filtro", "transicao", "titulo_doc", "manchete", "rotulo", "doc_nome_auto", "audio_dos_clipes", "ctas"):
            if k in d:
                ed[k] = d[k]
        if "legenda" in d:
            ed.setdefault("legenda", {}).update(d["legenda"])
        return jsonify(v)


@app.route("/api/videos/<vid>/editor/desfazer", methods=["POST"])
def editor_desfazer(vid):
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        if not v.get("historico"):
            return erro("Nada para desfazer.")
        _restaurar(v, v["historico"].pop())
        return jsonify(v)


@app.route("/api/videos/<vid>/editor/historico")
def editor_historico(vid):
    v, _ = _video_ctx(storage.load(), vid)
    return jsonify([{"i": i, "quando": h["quando"], "acao": h["acao"]} for i, h in enumerate(v.get("historico") or [])])


@app.route("/api/videos/<vid>/editor/restaurar", methods=["POST"])
def editor_restaurar(vid):
    i = int((request.json or {}).get("i", -1))
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        hist = v.get("historico") or []
        if not (0 <= i < len(hist)):
            return erro("Versão inválida.")
        snap = hist[i]
        _snapshot(v, f"antes de restaurar {snap['quando']}")
        _restaurar(v, snap)
        return jsonify(v)


@app.route("/api/videos/<vid>/onda.png")
def video_onda(vid):
    v, _ = _video_ctx(storage.load(), vid)
    narr = _abs(vid, v.get("narracao"))
    if not narr or not os.path.exists(narr):
        return erro("Sem narração", 404)
    out = os.path.join(storage.video_dir(vid), "onda.png")
    if not os.path.exists(out) or os.path.getmtime(out) < os.path.getmtime(narr):
        try:
            render._run([render.ffmpeg_bin(), "-y", "-i", narr, "-filter_complex", "aformat=channel_layouts=mono,showwavespic=s=3000x80:colors=#f97316", "-frames:v", "1", out])
        except Exception as e:
            return erro(str(e)[-200:])
    return send_file(out)


@app.route("/api/videos/<vid>/cenas/<int:n>/previa", methods=["POST"])
def cena_previa(vid, n):
    job = {"log": []}
    _baixar_escolhidas(vid, job, so_n=n)
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    idx = next((i for i, x in enumerate(v["cenas"]) if x["n"] == n), None)
    c = copy.deepcopy(v["cenas"][idx])
    if c.get("midia") and c["midia"].get("arquivo"):
        c["midia"]["arquivo"] = _abs(vid, c["midia"]["arquivo"])
    out = os.path.join(storage.video_dir(vid), "previas", f"p{n:03d}.mp4")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    try:
        render.previa_cena(idx, c, db["settings"], out, v.get("editor") or {}, v)
    except Exception as e:
        return erro(f"Falha na prévia: {str(e)[-300:]}")
    return jsonify({"url": f"/api/videos/{vid}/previa/{n}"})


@app.route("/api/videos/<vid>/previa/<int:n>")
def servir_previa(vid, n):
    p = os.path.join(storage.video_dir(vid), "previas", f"p{n:03d}.mp4")
    if not os.path.exists(p):
        return erro("Sem prévia", 404)
    return send_file(p)


# =====================================================================
# Pacote para CapCut / outro editor
# =====================================================================
@app.route("/api/videos/<vid>/pacote")
def video_pacote(vid):
    import io

    job = {"log": []}
    _baixar_escolhidas(vid, job)
    v, _ = _video_ctx(storage.load(), vid)
    mem = io.BytesIO()
    _pacote_zip(vid, mem)
    nome_base = re.sub(r"[^\w\- ]", "", v["titulo"])[:60].strip() or vid
    mem.seek(0)
    return send_file(mem, as_attachment=True, download_name=f"{nome_base} - pacote.zip", mimetype="application/zip")


def _exportar_capcut(vid):
    """Pasta pronta para o CapCut: cada cena já editada (zoom, efeitos, montagens) como um clipe numerado na ordem,
    mais narração, música, efeitos sonoros e legenda .srt em trilhas separadas — dá para mexer em tudo."""
    import csv
    import shutil

    db = storage.load()
    v, _ = _video_ctx(db, vid)
    pasta = storage.video_dir(vid)
    trechos = os.path.join(pasta, "trechos")
    nome = re.sub(r"[^\w\- ]", "", v.get("titulo") or "")[:60].strip() or vid
    dest = os.path.join(pasta, "entrega", f"CapCut - {nome}")
    if os.path.exists(dest):
        shutil.rmtree(dest, ignore_errors=True)
    os.makedirs(os.path.join(dest, "cenas"), exist_ok=True)
    faltam = []
    with open(os.path.join(dest, "cenas.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["clipe", "cena", "inicio_s", "duracao_s", "fonte", "texto"])
        for i, c in enumerate(v["cenas"]):
            src = os.path.join(trechos, f"t{i + 1:04d}.mp4")
            alvo = os.path.join(dest, "cenas", f"{i + 1:04d}.mp4")
            if os.path.exists(src) and os.path.getsize(src) > 1000:
                try:
                    os.link(src, alvo)  # mesmo disco: instantâneo e não ocupa espaço a mais
                except OSError:
                    shutil.copy2(src, alvo)
            else:
                faltam.append(c["n"])
            w.writerow([f"{i + 1:04d}.mp4", c["n"], f"{c['inicio']:.2f}", f"{c['fim'] - c['inicio']:.2f}", (c.get("midia") or {}).get("fonte", ""), c.get("texto", "")])
    for rel, nome_a in ((v.get("narracao"), "1-narracao"), (v.get("musica"), "2-musica")):
        p = _abs(vid, rel)
        if p and os.path.exists(p):
            shutil.copy2(p, os.path.join(dest, nome_a + os.path.splitext(p)[1]))
    for arq, nome_a in (("efeitos_sonoros.wav", "3-efeitos-sonoros.wav"), ("legendas.srt", "legendas.srt"), ("final.mp4", "video-final-referencia.mp4")):
        p = os.path.join(pasta, arq)
        if os.path.exists(p):
            if arq == "final.mp4":
                try:
                    os.link(p, os.path.join(dest, nome_a))
                except OSError:
                    shutil.copy2(p, os.path.join(dest, nome_a))
            else:
                shutil.copy2(p, os.path.join(dest, nome_a))
    with open(os.path.join(dest, "COMO-USAR-NO-CAPCUT.txt"), "w", encoding="utf-8") as f:
        f.write("COMO ABRIR NO CAPCUT\n\n"
                "1. No CapCut: Novo projeto > Importar > selecione TODOS os arquivos da pasta 'cenas'.\n"
                "2. Com todos selecionados, arraste para a linha do tempo: entram na ordem (0001, 0002…) e com a duração certa de cada cena.\n"
                "3. Importe '1-narracao', '2-musica' e '3-efeitos-sonoros' e solte cada um numa trilha de áudio, no começo (00:00).\n"
                "   Abaixe a música para uns 10–15%.\n"
                "4. Legendas editáveis: Texto > Legendas locais > Importar > legendas.srt.\n"
                "5. Para trocar uma cena: apague o clipe e ponha outro do mesmo tamanho (o cenas.csv diz o que é falado em cada uma).\n\n"
                "Os clipes já têm zoom, cor e as montagens (fichas, mapas, datas). Legenda, textos de impacto e o botão de inscrição\n"
                "ficam de fora para você poder editar. 'video-final-referencia.mp4' é o vídeo pronto, só para comparar.\n")
    return dest, faltam


@app.route("/api/estudio/<vid>/capcut", methods=["POST"])
def estudio_capcut(vid):
    try:
        dest, faltam = _exportar_capcut(vid)
    except Exception as e:
        return erro(f"Não consegui exportar: {e}")
    if os.name == "nt":
        try:
            os.startfile(dest)  # type: ignore[attr-defined]
        except Exception:
            pass
    return jsonify({"pasta": dest, "faltam": faltam})


def _pacote_zip(vid, destino):
    import csv
    import io
    import zipfile

    db = storage.load()
    v, _ = _video_ctx(db, vid)
    pasta = storage.video_dir(vid)
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_STORED) as z:
        linhas = io.StringIO()
        w = csv.writer(linhas, delimiter=";")
        w.writerow(["cena", "inicio_s", "fim_s", "duracao_s", "arquivo", "fonte", "texto"])
        for c in v["cenas"]:
            m = c.get("midia") or {}
            arq = _abs(vid, m.get("arquivo"))
            nome = ""
            if arq and os.path.exists(arq):
                nome = f"midia/{c['n']:03d}{os.path.splitext(arq)[1]}"
                z.write(arq, nome)
            w.writerow([c["n"], f"{c['inicio']:.2f}", f"{c['fim']:.2f}", f"{c['fim'] - c['inicio']:.2f}", nome, m.get("fonte", ""), c["texto"]])
        z.writestr("cenas.csv", linhas.getvalue().encode("utf-8-sig"))
        z.writestr("roteiro.txt", v.get("roteiro", ""))
        for rel, nome in ((v.get("narracao"), "narracao"), (v.get("musica"), "musica")):
            p = _abs(vid, rel)
            if p and os.path.exists(p):
                z.write(p, nome + os.path.splitext(p)[1])
        p = os.path.join(pasta, "legendas.srt")
        if os.path.exists(p):
            z.write(p, "legendas.srt")
        z.writestr("creditos.txt", media.creditos(v["cenas"]))
        z.writestr("COMO-USAR.txt", "No CapCut: importe a pasta midia (já numerada na ordem), a narracao e o legendas.srt.\nUse o cenas.csv para ver a duração de cada cena.\n")


# =====================================================================
# ThumbLab
# =====================================================================
@app.route("/api/thumb/estilos")
def thumb_estilos():
    return jsonify(thumb.ESTILOS)


@app.route("/api/videos/<vid>/thumb/fundo", methods=["POST"])
def thumb_fundo(vid):
    f = request.files.get("arquivo")
    if not f:
        return erro("Envie a imagem.")
    rel, _ = _salvar_upload(vid, f, "thumb_fundo")
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        v["thumb_fundo"] = rel
        return jsonify(v)


@app.route("/api/videos/<vid>/thumb/gerar", methods=["POST"])
def thumb_gerar(vid):
    d = request.json or {}
    fundo = d.get("fundo", "upload")
    if fundo.startswith("cena:"):
        n = int(fundo.split(":")[1])
        _baixar_escolhidas(vid, {"log": []}, so_n=n)
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    if fundo.startswith("cena:"):
        c = next((x for x in v["cenas"] if x["n"] == int(fundo.split(":")[1])), {})
        m = c.get("midia") or {}
        path = _abs(vid, m.get("arquivo"))
        if m.get("tipo") == "video" and path:
            frame = os.path.join(storage.video_dir(vid), f"thumb_frame_{c['n']}.jpg")
            try:
                render._run([render.ffmpeg_bin(), "-y", "-ss", "1", "-i", path, "-frames:v", "1", frame])
                path = frame
            except Exception:
                path = ""
    else:
        path = _abs(vid, v.get("thumb_fundo"))
    if not path or not os.path.exists(path):
        return erro("Escolha um fundo: envie uma imagem ou use a mídia de uma cena.")
    pasta = os.path.join(storage.video_dir(vid), "thumbs")
    os.makedirs(pasta, exist_ok=True)
    novas = []
    import time as _t

    for est in d.get("estilos") or ["impacto"]:
        nome = f"thumb_{est}_{int(_t.time() * 1000) % 10**9}.png"
        thumb.gerar(path, d.get("texto", ""), d.get("destaque", ""), est, d.get("lado", "esquerda"), os.path.join(pasta, nome), d.get("cor") or "#FFD400")
        novas.append({"arquivo": nome, "estilo": est, "texto": d.get("texto", "")})
    with Tx() as db2:
        v2, _ = _video_ctx(db2, vid)
        v2["thumbs"] = (novas + (v2.get("thumbs") or []))[:16]
        v2["etapas"]["thumb"] = True
        return jsonify(v2)


@app.route("/api/videos/<vid>/thumb/arquivo/<nome>")
def thumb_arquivo(vid, nome):
    if not re.fullmatch(r"thumb_[\w]+\.png", nome):
        return erro("Arquivo inválido", 404)
    p = os.path.join(storage.video_dir(vid), "thumbs", nome)
    if not os.path.exists(p):
        return erro("Não existe", 404)
    return send_file(p, as_attachment=request.args.get("baixar") == "1")


# =====================================================================
# DarkMetrics
# =====================================================================
@app.route("/api/metricas", methods=["GET", "POST"])
def metricas():
    if request.method == "GET":
        return jsonify([{k: m[k] for k in ("id", "data", "canal", "resumo")} for m in storage.load()["metricas"]])
    entrada = (request.json or {}).get("canal", "")
    s = storage.load()["settings"]
    try:
        res = radar.analisar_canal(s.get("youtube_api_key"), entrada)
    except Exception as e:
        return erro(str(e))
    with Tx() as db:
        reg = dict(res, id=storage.new_id("m"), data=storage.now())
        db["metricas"] = [m for m in db["metricas"] if m["canal"]["id"] != res["canal"]["id"]]
        db["metricas"].insert(0, reg)
        db["metricas"] = db["metricas"][:30]
        return jsonify(reg)


@app.route("/api/metricas/<mid>", methods=["GET", "DELETE"])
def metrica_item(mid):
    if request.method == "DELETE":
        with Tx() as db:
            db["metricas"] = [m for m in db["metricas"] if m["id"] != mid]
        return jsonify({"ok": True})
    m = find(storage.load()["metricas"], mid)
    return jsonify(m) if m else erro("Não encontrado", 404)


# =====================================================================
# Mapa de nichos
# =====================================================================
@app.route("/api/mapas", methods=["GET", "POST"])
def mapas():
    if request.method == "GET":
        return jsonify(storage.load()["mapas"])
    d = request.json or {}
    try:
        j = prompts.parse_json(d.get("texto", ""))
    except ValueError as e:
        return erro(f"Não consegui ler o JSON: {e}")
    if not isinstance(j, dict) or not j.get("subnichos"):
        return erro("O JSON precisa ter a lista 'subnichos'.")
    with Tx() as db:
        reg = {"id": storage.new_id("n"), "semente": d.get("semente") or j.get("nicho", ""), "idioma": d.get("idioma", "pt"), "data": storage.now(), "mapa": j}
        db["mapas"].insert(0, reg)
        return jsonify(reg)


@app.route("/api/mapas/prompt", methods=["POST"])
def mapas_prompt():
    d = request.json or {}
    return jsonify({"prompt": prompts.mapa_nichos(d.get("semente", ""), d.get("idioma", "pt"))})


@app.route("/api/mapas/<mid>", methods=["DELETE"])
def mapa_del(mid):
    with Tx() as db:
        db["mapas"] = [m for m in db["mapas"] if m["id"] != mid]
    return jsonify({"ok": True})


# =====================================================================
# Financeiro
# =====================================================================
@app.route("/api/financeiro", methods=["GET", "POST"])
def financeiro():
    db = storage.load()
    if request.method == "POST":
        d = request.json or {}
        try:
            bruto = str(d.get("valor", "0")).replace("R$", "").strip()
            valor = float(bruto.replace(".", "").replace(",", ".")) if "," in bruto else float(bruto or 0)
        except ValueError:
            return erro("Valor inválido")
        with Tx() as db2:
            item = {
                "id": storage.new_id("f"), "data": d.get("data") or storage.now()[:10], "canal_id": d.get("canal_id", ""),
                "tipo": "despesa" if d.get("tipo") == "despesa" else "receita", "categoria": d.get("categoria", ""),
                "descricao": d.get("descricao", ""), "valor": round(abs(valor), 2),
            }
            db2["financeiro"].append(item)
            return jsonify(item)
    mes = request.args.get("mes", "")
    itens = sorted([f for f in db["financeiro"] if not mes or f["data"].startswith(mes)], key=lambda x: x["data"], reverse=True)
    por_canal = {}
    for f in itens:
        p = por_canal.setdefault(f["canal_id"] or "", {"receita": 0.0, "despesa": 0.0})
        p[f["tipo"]] += f["valor"]
    rec = sum(f["valor"] for f in itens if f["tipo"] == "receita")
    desp = sum(f["valor"] for f in itens if f["tipo"] == "despesa")
    meses = sorted({f["data"][:7] for f in db["financeiro"]}, reverse=True)
    return jsonify({"itens": itens, "por_canal": por_canal, "receita": rec, "despesa": desp, "lucro": rec - desp, "meses": meses})


@app.route("/api/financeiro/<fid>", methods=["DELETE"])
def financeiro_del(fid):
    with Tx() as db:
        db["financeiro"] = [f for f in db["financeiro"] if f["id"] != fid]
    return jsonify({"ok": True})


@app.route("/api/financeiro.csv")
def financeiro_csv():
    import csv
    import io

    db = storage.load()
    nomes = {c["id"]: c["nome"] for c in db["channels"]}
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["data", "canal", "tipo", "categoria", "descricao", "valor"])
    for f in sorted(db["financeiro"], key=lambda x: x["data"]):
        w.writerow([f["data"], nomes.get(f["canal_id"], ""), f["tipo"], f["categoria"], f["descricao"], f"{f['valor']:.2f}".replace(".", ",")])
    mem = io.BytesIO(buf.getvalue().encode("utf-8-sig"))
    return send_file(mem, as_attachment=True, download_name="financeiro.csv", mimetype="text/csv")



# =====================================================================
# Conexões (cofre de chaves)
# =====================================================================
PROVS_CHAVE = ("gemini", "openai", "claude", "antigravity", "youtube", "azure", "elevenlabs", "fish", "darkplanner")


def _testar_tts(prov, kid):
    k = chaves.pegar(prov, kid)
    quando = storage.now()[:16]
    try:
        if prov == "azure":
            n = len(voz.vozes_azure(k["key"], k.get("regiao") or "brazilsouth"))
            chaves.atualizar(prov, kid, status="ok", testada_em=quando, erro="", info=f"{n} vozes PT/EN/ES")
        elif prov == "elevenlabs":
            tier, usado, lim = voz.plano_eleven(k["key"])
            chaves.atualizar(prov, kid, status="ok", testada_em=quando, erro="", plano=tier, info=f"{usado:,}/{lim:,} créditos usados".replace(",", "."))
        elif prov == "darkplanner":
            u = voz.darkplanner_uso(k["key"])
            chaves.atualizar(prov, kid, status="ok", testada_em=quando, erro="", plano=u.get("plan_type", ""),
                             info=f"{u.get('used_today', 0)}/{u.get('limit', '?')} áudios hoje · até {int(u.get('max_characters_per_audio') or 0):,} caracteres por áudio".replace(",", "."))
        elif prov == "fish":
            r = __import__("requests").get("https://api.fish.audio/model", params={"self": "true", "page_size": 20},
                                            headers={"Authorization": f"Bearer {k['key']}"}, timeout=20)
            if not r.ok:
                raise RuntimeError(f"{r.status_code} {r.text[:150]}")
            chaves.atualizar(prov, kid, status="ok", testada_em=quando, erro="", info=f"{len(r.json().get('items', []))} voz(es) suas")
        return True, ""
    except Exception as e:
        chaves.atualizar(prov, kid, status="invalida", testada_em=quando, erro=str(e)[:200])
        return False, str(e)


def _testar(prov, kid):
    if prov == "gemini":
        return gemini.testar(kid)
    if prov in ("claude", "openai"):
        return claude.testar(kid)
    if prov == "youtube":
        return chaves.testar_youtube(kid)
    return _testar_tts(prov, kid)


def _resolver_dp(db=None):
    db = db or storage.load()
    raw = (db["settings"].get("darkplanner_exe") or r"C:\Users\leona\AppData\Local\Programs\darkplanner").strip()
    pasta_padrao = r"C:\Users\leona\AppData\Local\Programs\darkplanner"
    if os.path.isdir(raw):
        pasta = raw
        exe = os.path.join(pasta, "Dark Planner.exe")
        if not os.path.exists(exe):
            for f in os.listdir(pasta):
                if f.lower().endswith(".exe") and "uninstall" not in f.lower():
                    exe = os.path.join(pasta, f)
                    break
    else:
        exe = raw
        pasta = os.path.dirname(exe) or pasta_padrao
        if not os.path.exists(exe) and os.path.exists( os.path.join(pasta_padrao, "Dark Planner.exe")):
            pasta = pasta_padrao
            exe = os.path.join(pasta_padrao, "Dark Planner.exe")
    watch = db["settings"].get("darkplanner_watch") or r"C:\Users\leona\Downloads\DarkPlanner\DarkPlanner_WatchFolder"
    return pasta, exe, watch


@app.route("/api/conexoes")
def conexoes():
    db = storage.load()
    for prov, campo in (("youtube", "youtube_api_key"), ("gemini", "gemini_key")):
        if db["settings"].get(campo) and not chaves.lista(db, prov):
            try:
                chaves.adicionar(prov, db["settings"][campo], tipo="gratuita")
            except ValueError:
                pass
            db = storage.load()
    out = {p: [chaves.publico(x) for x in chaves.lista(db, p)] for p in PROVS_CHAVE}
    # unifica openai e claude para exibição no card GPT
    out["openai"] = out.get("openai", []) + [x for x in out.get("claude", []) if x["id"] not in {y["id"] for y in out.get("openai", [])}]
    out["provedores_tts"] = voz.PROVEDORES
    out["limites"] = chaves.LIMITES
    out["estimativa"] = gemini.estimativa(db)
    out["dia_cota"] = chaves.dia_cota()
    dp_pasta, dp_exe, dp_watch = _resolver_dp(db)
    out["darkplanner_local"] = {
        "pasta": dp_pasta,
        "exe": dp_exe,
        "exe_existe": os.path.exists(dp_exe),
        "watch": dp_watch,
        "watch_existe": os.path.exists(dp_watch),
    }
    out["darkplanner_cloud"] = db.get("darkplanner_cloud") or {}
    try:
        from core import antigravity_codex

        out["antigravity_codex"] = antigravity_codex.obter_status_vinculacao(db)
    except Exception as e_ac:
        out["antigravity_codex"] = {"ok": False, "erro": str(e_ac)}
    return jsonify(out)


@app.route("/api/conexoes/antigravity-codex/status")
def api_antigravity_codex_status():
    from core import antigravity_codex

    return jsonify(antigravity_codex.obter_status_vinculacao())


@app.route("/api/conexoes/antigravity-codex/login", methods=["POST"])
def api_antigravity_codex_login():
    from core import antigravity_codex

    d = request.get_json(silent=True) or {}
    provedor = (d.get("provedor") or "codex").strip().lower()
    res = antigravity_codex.iniciar_login_provedor(provedor)
    res["status"] = antigravity_codex.obter_status_vinculacao()
    return jsonify(res)


@app.route("/api/conexoes/antigravity-codex/salvar-token", methods=["POST"])
def api_antigravity_codex_salvar_token():
    from core import antigravity_codex

    d = request.get_json(silent=True) or {}
    res = antigravity_codex.salvar_token_vinculacao(
        provedor=(d.get("provedor") or "antigravity").strip().lower(),
        token=(d.get("token") or "").strip(),
        conta=(d.get("conta") or "").strip(),
        modelo_padrao=(d.get("modelo") or "").strip(),
    )
    res["status"] = antigravity_codex.obter_status_vinculacao()
    return jsonify(res)


@app.route("/api/conexoes/antigravity-codex/desconectar", methods=["POST"])
def api_antigravity_codex_desconectar():
    from core import antigravity_codex

    d = request.get_json(silent=True) or {}
    res = antigravity_codex.desconectar_provedor((d.get("provedor") or "").strip().lower())
    res["status"] = antigravity_codex.obter_status_vinculacao()
    return jsonify(res)


@app.route("/api/agente/conversar", methods=["POST"])
def api_agente_antigravity_codex_conversar():
    from core import antigravity_codex

    d = request.get_json(silent=True) or {}
    res = antigravity_codex.conversar_agente_antigravity_codex(
        mensagem=(d.get("mensagem") or "").strip(),
        historico=d.get("historico") or [],
        contexto_projeto=d.get("contexto_projeto") or {},
    )
    return jsonify(res)


@app.route("/api/darkplanner/acao", methods=["POST"])
def darkplanner_acao():
    d = request.json or {}
    acao = d.get("acao", "abrir_app")
    db = storage.load()
    dp_pasta, dp_exe, dp_watch = _resolver_dp(db)
    try:
        if acao == "abrir_janela_desktop":
            abrir_janela(f"http://127.0.0.1:{PORTA}")
            return jsonify({"ok": True, "msg": "Fábrica Dark aberta em janela App Desktop dedicada (sem abas/extensões)!"})
        def _abrir_ou_focar_dp_com_cdp():
            try:
                darkplanner_sync._garantir_atalhos_e_cdp_darkplanner()
            except Exception:
                pass
            if os.name == "nt":
                if darkplanner_sync._processo_darkplanner_rodando_windows():
                    try:
                        subprocess.Popen(
                            [
                                "powershell",
                                "-NoProfile",
                                "-WindowStyle",
                                "Hidden",
                                "-Command",
                                "(New-Object -ComObject WScript.Shell).AppActivate('Dark Planner') | Out-Null",
                            ],
                            creationflags=0x08000000,
                        )
                    except Exception:
                        pass
                    return "focado"
                subprocess.Popen(
                    [dp_exe, "--remote-debugging-port=9229"],
                    cwd=dp_pasta if os.path.isdir(dp_pasta) else None,
                )
                return "iniciado_cdp_9229"
            subprocess.Popen([dp_exe, "--remote-debugging-port=9229"], cwd=dp_pasta if os.path.isdir(dp_pasta) else None)
            return "iniciado_cdp_9229"

        if acao == "abrir_app":
            if os.path.exists(dp_exe):
                modo_ab = _abrir_ou_focar_dp_com_cdp()
                msg_ab = (
                    f"Janela do DarkPlanner trazida para frente ({dp_exe})!"
                    if modo_ab == "focado"
                    else f"DarkPlanner iniciado com Ponte CDP 9229 ativa ({dp_exe})!"
                )
                return jsonify({"ok": True, "exe": dp_exe, "modo": modo_ab, "msg": msg_ab})
            if os.path.isdir(dp_pasta) and os.name == "nt":
                os.startfile(dp_pasta)  # type: ignore[attr-defined]
                return jsonify({"ok": True, "pasta": dp_pasta, "msg": f"Pasta do DarkPlanner aberta ({dp_pasta})!"})
            webbrowser.open("https://app.darkplanner.com.br")
            return jsonify({"ok": True, "msg": "Painel DarkPlanner aberto no navegador!"})
        if acao == "abrir_local_programa":
            alvo = dp_pasta if os.path.isdir(dp_pasta) else os.path.dirname(dp_exe)
            if os.path.exists(alvo) and os.name == "nt":
                os.startfile(alvo)  # type: ignore[attr-defined]
                return jsonify({"ok": True, "pasta": alvo, "msg": f"Local do DarkPlanner aberto: {alvo}"})
            return erro(f"Pasta não encontrada: {alvo}")
        if acao == "abrir_pasta":
            os.makedirs(dp_watch, exist_ok=True)
            if os.name == "nt":
                os.startfile(dp_watch)  # type: ignore[attr-defined]
            return jsonify({"ok": True, "pasta": dp_watch, "msg": "Pasta WatchFolder aberta!"})
        if acao == "enviar_roteiro":
            os.makedirs(dp_watch, exist_ok=True)
            titulo = re.sub(r"[^\w\- ]", "", d.get("titulo") or "roteiro_v8")[:60].strip() or "roteiro_v8"
            texto = (d.get("texto") or "").strip()
            if not texto:
                return erro("Nenhum texto ou roteiro para enviar ao DarkPlanner.")
            caminho_txt = os.path.join(dp_watch, f"{titulo}.txt")
            with open(caminho_txt, "w", encoding="utf-8") as f:
                f.write(texto)
            if os.path.exists(dp_exe) and d.get("abrir_app", True):
                _abrir_ou_focar_dp_com_cdp()
            return jsonify({"ok": True, "arquivo": caminho_txt, "msg": f"Roteiro enviado e DarkPlanner pronto ({titulo}.txt)!"})
        if acao == "enviar_chat":
            msg_chat = (d.get("mensagem") or d.get("texto") or "").strip()
            if not msg_chat:
                return erro("Mensagem vazia para enviar ao Chat do DarkPlanner.")
            res_chat = darkplanner_sync.abrir_chat_darkplanner_e_colar(
                msg_chat,
                auto_enviar=bool(d.get("auto_enviar", True)),
                nova_conversa=bool(d.get("nova_conversa", True)),
                chat_modelo_opcao=(d.get("chat_modelo_opcao") or "flash_high").strip(),
                forcar_reenvio=bool(d.get("forcar_reenvio", True)),
            )
            res_chat["msg"] = "💬 Comando enviado com foco confirmado e pausas seguras ao Chat do DarkPlanner Desktop!"
            return jsonify(res_chat)
    except Exception as e:
        return erro(str(e))
    return erro("Ação desconhecida", 404)


@app.route("/api/antigravity/analisar", methods=["POST"])
def antigravity_analisar():
    """Assistente conversacional Antigravity V8 Ninja Pro (Passo 1: Estruturar, Passo 2: Roteiro Completo, Passo 3: Modo Títulos Neurais V8, Analisar Título, Analisar Canal)."""
    d = request.json or {}
    modo = d.get("modo", "estruturar")
    entrada = (d.get("titulo") or d.get("entrada") or "").strip()
    roteiro_atual = (d.get("roteiro") or "").strip()
    if not entrada and not roteiro_atual:
        return erro("Digite um título, tema ou gere o roteiro para o Antigravity V8 analisar.")
    dur_req = float(d.get("duracao_min") or 0)
    if dur_req > 0:
        palavras = max(150, int(round(dur_req * 145)))
        blocos = max(3, min(16, int(round(dur_req / 3.0))))
    else:
        palavras = int(d.get("palavras") or 2000)
        blocos = int(d.get("blocos") or max(3, min(16, int(round((palavras / 145.0) / 3.0)))))
    idioma = d.get("idioma") or ""
    instrucoes = (d.get("instrucoes") or "").strip()
    canal_id = (d.get("channel_id") or d.get("canal_id") or "").strip()
    vid = (d.get("video_id") or "").strip()
    prompt_mestre_id = (d.get("prompt_mestre_id") or "").strip()
    duracao_exata_min = round(palavras / 145.0, 1)
    palavras_por_bloco = round(palavras / max(1, blocos))

    db = storage.load()
    if vid:
        v_check = find(db.get("videos", []), vid)
        if v_check:
            tit_v_check = (v_check.get("titulo") or "").strip().lower()
            tit_ent_check = (entrada or "").strip().lower()
            if v_check.get("concluido") or (
                modo in ("estruturar", "roteiro_completo")
                and not (d.get("pedido_ajuste") or "").strip()
                and tit_ent_check
                and tit_v_check
                and tit_ent_check != tit_v_check
            ):
                vid = ""

    # Evita que ESTRUTURA APROVADA de um vídeo anterior (ex: 20 min) interfira num novo vídeo (ex: 10 min)
    if instrucoes and "ESTRUTURA APROVADA" in instrucoes:
        if modo == "estruturar" and not (d.get("pedido_ajuste") or "").strip():
            instrucoes = re.sub(r"\n*ESTRUTURA APROVADA\s*:[\s\S]*$", "", instrucoes, flags=re.I).strip()
        elif modo == "roteiro_completo":
            m_est_part = re.search(r"ESTRUTURA APROVADA\s*:([\s\S]*)$", instrucoes, flags=re.I)
            if m_est_part:
                txt_est_part = m_est_part.group(1)
                mins_encontrados = [
                    float(x.replace(",", "."))
                    for x in re.findall(r"(\d+(?:[.,]\d+)?)\s*minutos", txt_est_part, flags=re.I)
                ]
                if mins_encontrados and all(abs(m_val - duracao_exata_min) >= 1.5 for m_val in mins_encontrados):
                    instrucoes = re.sub(r"\n*ESTRUTURA APROVADA\s*:[\s\S]*$", "", instrucoes, flags=re.I).strip()

    ch = find(db["channels"], canal_id) if canal_id else {}
    ch = ch or {}
    dp_info = ch.get("dp") or {}
    prompts_canal = dp_info.get("prompts") or []
    pm_texto = ""
    if prompt_mestre_id:
        pm_obj = next((p for p in prompts_canal if str(p.get("id")) == str(prompt_mestre_id)), None)
        if pm_obj:
            pm_texto = (pm_obj.get("conteudo") or "")[:3000]
    elif prompts_canal:
        pm_texto = (prompts_canal[0].get("conteudo") or "")[:2500]
    if pm_texto:
        pm_texto = re.sub(
            r"(?:aproximadamente|cerca de|em torno de|atingir|epis[oó]dio de)\s+\d+(?:\s*[–\-a]\s*\d+)?\s*minutos",
            f"aproximadamente {duracao_exata_min:g} minutos ({palavras} palavras)",
            pm_texto,
            flags=re.I,
        )

    perfil_ed = pauta.obter_perfil_editorial_canal(ch) if ch else {}
    idioma_canal_cod = darkplanner_sync._idioma_curto(
        ch.get("idioma_dp"),
        ch.get("idioma"),
        ch.get("nome"),
        prompts_canal,
    )
    # Se não houver canal, verifica o idioma do título (`entrada`)
    if not ch.get("nome") and entrada:
        ent_low = f" {entrada.lower()} "
        if any(w in ent_low for w in (" dans ", " avec ", " pour ", " les ", " des ", " une ", " sur ", " gta ")):
            idioma_canal_cod = "fr"
        elif any(w in ent_low for w in (" the ", " when ", " what if ", " why ", " how ", " under ", " broke ", " inside ")):
            idioma_canal_cod = "en"
        elif any(w in ent_low for w in (" cómo ", " qué ", " por qué ", " los ", " las ", " del ")):
            idioma_canal_cod = "es"

    idioma_real = idioma_canal_cod
    if idioma:
        id_req_low = idioma.lower()
        if "fr" in id_req_low or "franc" in id_req_low or "franç" in id_req_low:
            idioma_real = "fr"
        elif "en" in id_req_low or "ingl" in id_req_low:
            idioma_real = "en"
        elif "es" in id_req_low or "espan" in id_req_low:
            idioma_real = "es"
        elif "pt" in id_req_low or "portug" in id_req_low:
            idioma_real = "pt"
    if "gta" in (ch.get("nome") or "").lower() or str(canal_id) == "a8068857-d56f-4aba-baf3-ea2b7ebda5bb":
        idioma_real = "fr"

    idioma_exato_str = (
        perfil_ed.get("idioma_exato")
        or (
            "Francês (fr-FR)"
            if idioma_real == "fr"
            else (
                "Inglês Americano (en-US)"
                if idioma_real == "en"
                else ("Espanhol Neutro (es)" if idioma_real == "es" else "Português do Brasil (pt-BR)")
            )
        )
    )

    info_canal = ""
    if ch.get("nome"):
        info_canal = (
            f"\nCANAL SELECIONADO: {ch.get('nome')} — IDIOMA OFICIAL OBRIGATÓRIO: **{idioma_exato_str.upper()}** ({idioma_real.upper()})"
        )
        if perfil_ed.get("formato_real"):
            info_canal += f"\nFORMATO EDITORIAL EXCLUSIVO DESTE CANAL: {perfil_ed['formato_real']}"
        if perfil_ed.get("publico_real"):
            info_canal += f"\nPÚBLICO-ALVO DESTE CANAL: {perfil_ed['publico_real']}"
        if perfil_ed.get("diretriz_gerador"):
            info_canal += f"\nDIRETRIZ DE ROTEIRO E RETENÇÃO DESTE CANAL: {perfil_ed['diretriz_gerador']}"
        if perfil_ed.get("o_que_priorizar"):
            info_canal += f"\nO QUE PRIORIZAR NESTE CANAL: {perfil_ed['o_que_priorizar']}"
        if perfil_ed.get("o_que_evitar"):
            info_canal += f"\nPROIBIDO NESTE CANAL: {perfil_ed['o_que_evitar']}"
        if ch.get("tese"):
            info_canal += f"\nIDENTIDADE / REGRAS DO CANAL: {ch.get('tese')[:600]}"
        if ch.get("formato_video_custom"):
            info_canal += f"\nFORMATO CUSTOMIZADO DOS VÍDEOS (DEFINIDO PELO CHAT VINCULADO AO DARKPLANNER): {ch.get('formato_video_custom')}"
        if ch.get("estilo_visual"):
            info_canal += f"\nESTILO VISUAL EXIGIDO: {ch.get('estilo_visual')}"
        if ch.get("funcoes_especiais_video"):
            fns_ch = ch.get("funcoes_especiais_video")
            fns_s = "; ".join(str(x) for x in fns_ch) if isinstance(fns_ch, list) else str(fns_ch)
            info_canal += f"\nFUNÇÕES ESPECIAIS NOS VÍDEOS (ESTRUTURE O ROTEIRO PARA FAVORECER ISSO): {fns_s}"
        if ch.get("regras_custom_chat"):
            info_canal += f"\nDIRETRIZES DIRETAS DO CHAT VINCULADO AO DARKPLANNER: {str(ch.get('regras_custom_chat'))[:900]}"
    if pm_texto:
        info_canal += f"\nPROMPT MESTRE DO CANAL NO DARKPLANNER (siga o tom e diretrizes):\n{pm_texto}"
    eh_video_real_an = darkplanner_sync._detectar_modo_video_real(
        skill_modo=d.get("skill_modo") or "",
        canal_nome=ch.get("nome") or "",
        canal_id=canal_id,
        prompt_mestre_texto=pm_texto,
        dp_prompts_canal=prompts_canal,
    )
    yt_ref_url = (d.get("youtube_ref_url") or d.get("referencia_url") or "").strip()
    yt_clone_ctx = darkplanner_sync._sanitizar_yt_clone_por_canal(
        d.get("youtube_clone") or ch.get("youtube_clone_ativo") or {},
        canal_nome=ch.get("nome") or "",
        canal_id=canal_id,
        eh_video_real=eh_video_real_an,
    )
    if yt_ref_url:
        try:
            ref_bg = darkplanner_sync.processar_referencia_e_vincular_canal_backend(
                youtube_url=yt_ref_url,
                canal_id=canal_id,
                vid=vid,
                instrucoes=instrucoes,
            )
            if ref_bg.get("youtube_clone"):
                yt_clone_ctx = darkplanner_sync._sanitizar_yt_clone_por_canal(
                    ref_bg["youtube_clone"],
                    canal_nome=ch.get("nome") or "",
                    canal_id=canal_id,
                    eh_video_real=eh_video_real_an,
                )
            if ref_bg.get("skill_modo_recomendado") and not d.get("skill_modo"):
                d["skill_modo"] = ref_bg["skill_modo_recomendado"]
        except Exception as e_ref_bg:
            print("Aviso ao vincular referência no backend:", e_ref_bg)
    nome_ch_low_an = (ch.get("nome") or "").lower()
    eh_recomeco_an = "recomec" in nome_ch_low_an or "recomeç" in nome_ch_low_an
    if not yt_clone_ctx and eh_recomeco_an and not eh_video_real_an:
        try:
            yt_clone_ctx = darkplanner_sync._montar_vinculo_padrao_iflord_capitto_recomeco()
        except Exception:
            yt_clone_ctx = {}
    if not eh_video_real_an and isinstance(yt_clone_ctx, dict) and (yt_clone_ctx.get("prompt_mestre_clonagem") or yt_clone_ctx.get("style_dna")):
        try:
            eh_100_img_an = darkplanner_sync._canal_eh_100_imagem(ch.get("nome") or "", canal_id, prompts_canal)
            info_canal += darkplanner_sync._montar_bloco_resumo_yt_clone_para_canal(
                yt_clone_ctx,
                eh_canal_100_img=eh_100_img_an,
                canal_nome=ch.get("nome") or "",
                eh_recomeco=eh_recomeco_an,
            )
        except TypeError:
            info_canal += darkplanner_sync._montar_bloco_resumo_yt_clone_para_canal(yt_clone_ctx)
        except Exception as e_yt_res:
            print("Aviso ao montar bloco resumo yt_clone:", e_yt_res)
    if eh_video_real_an:
        eh_gta_an = "gta" in nome_ch_low_an or "à la une" in nome_ch_low_an or "a la une" in nome_ch_low_an or str(canal_id or "").lower() == "a8068857-d56f-4aba-baf3-ea2b7ebda5bb"
        eh_storm_an = "stormscope" in nome_ch_low_an or "weather" in nome_ch_low_an or str(canal_id or "").lower() == "17681e73-1ab9-412e-93e5-ca12739ece16"
        if eh_gta_an:
            idioma_real = "fr"
            idioma_exato_str = "Français (fr-FR)"
            bloco_not_gta_fr = ""
            try:
                from core import gta_rockstar_media
                bloco_not_gta_fr = gta_rockstar_media.formatar_bloco_noticias_gta_fr_prompt(limite=6)
            except Exception:
                bloco_not_gta_fr = ""
            info_canal += (
                "\nARQUITETURA DOCUMENTAL GAMING 100% FRANCÊS — CANAL GTA À LA UNE (100% JOGOS GTA · PADRÃO MANO. + ROCKSTAR MAG' + ROU + VICO GTA):\n"
                "- Referências Oficiais Obrigatórias:\n"
                "  1) Mano. — https://www.youtube.com/watch?v=8GD39QLKtyY&t=50s ('Le jeu vidéo a atteint sa limite avec GTA 6' — gancho magnético nos primeiros 50s, análise profunda de impacto e escala);\n"
                "  2) Rockstar Mag' — https://www.youtube.com/watch?v=dPSpuFYoEF8 ('VOILÀ, C'ÉTAIT GTA V.' — foco 100% dentro dos jogos GTA: missões, mapas, protagonistas e legado);\n"
                "  3) Rou — https://www.youtube.com/watch?v=I-bJ61bouDo ('L'incroyable technologie derrière GTA 6' — motor RAGE 9, 600.000+ animações, física Euphoria, iluminação, água/lama e comparativos GTA 5 vs GTA 6);\n"
                "  4) Vico GTA & G3ADRIEN OFF — embalagem francófona de alto CTR ('Tout ce qu'il faut savoir avant de jouer à GTA 6', 'GTA 6 fait des choses qu'on n'aurait JAMAIS imaginées dans GTA 5 !').\n"
                "- Canal 100% focado SOMENTE NOS JOGOS Grand Theft Auto (GTA VI Leonida/Vice City, GTA V Los Santos, GTA IV Liberty City, San Andreas, Vice City). Todo texto falado, título, gancho e CTA em FRANCÊS (fr-FR, narrador Léo — 'Abonnez-vous à GTA à la Une !').\n"
                "- HIERARQUIA DE MÍDIAS: Prioridade #1 ABSOLUTA = 100% imagens e vídeos dos JOGOS GTA (gameplay 4K limpo sem facecam, trailers e capturas oficiais Rockstar Games com máscara Fair-Use Anti-Copyright e 0% repetição). Banco de dados local do Disco D: (D:\\BANCO DE DADOS) e outros bancos externos devem ser usados SOMENTE EM ÚLTIMO CASO, APENAS PARA APOIO.\n"
                "- Descreva cenas visuais concretas de dentro dos jogos GTA (ruas de Vice City/Leonida, Los Santos, Liberty City, física de veículos, clima, PNJ e detalhes do motor RAGE)."
                + (f"\n{bloco_not_gta_fr}" if bloco_not_gta_fr else "")
            )
        elif eh_storm_an:
            info_canal += (
                "\nARQUITETURA DOCUMENTAL VÍDEO REAL V8.0 (REAL FOOTAGE FIRST — PADRÃO @USASevereWeather & @WeatherFieldReport):\n"
                "- Canais de Referência Oficiais: https://www.youtube.com/@USASevereWeather (USA Severe Weather) e https://www.youtube.com/@WeatherFieldReport (Weather Field Report).\n"
                "- Este vídeo utiliza 100% filmagens e fotografias reais de eventos documentados auditadas por Gemini 4 Carbon High (0% IA, 0% repetição nos vídeos anteriores do canal).\n"
                "- Nos primeiros 3 minutos (00:00 a 03:00 / ~435 palavras iniciais), a narração deve descrever "
                "fatos visuais concretos, ruas, locais reais, impactos físicos e emergências reais em andamento no estilo reportagem meteorológica de campo."
            )
        else:
            info_canal += (
                "\nARQUITETURA DOCUMENTAL VÍDEO REAL V8.0 (GEMINI 4 CARBON HIGH — 0% REPETIÇÃO ENTRE VÍDEOS DO CANAL):\n"
                "- Este vídeo utiliza 100% filmagens e fotografias reais auditadas por Gemini 4 Carbon High, proibindo repetir qualquer imagem ou clipe já usado nos vídeos anteriores deste canal.\n"
                "- Descreva cenas visuais concretas, locais reais e fatos verificáveis sincronizados 1:1 com a narração."
            )

    if idioma_real == "fr":
        regra_idioma = (
            f"🚨 REGRA INVIOLÁVEL DE IDIOMA DO CANAL ({ch.get('nome') or 'GTA à la Une'}): "
            f"Este canal é 100% em **{idioma_exato_str} (FRANÇAIS — fr-FR)**! "
            f"O ROTEIRO INTEIRO (da primeira à última palavra falada pelo narrador Léo) DEVE SER ESCRITO **100% EM FRANCÊS NATURAL E DINÂMICO (FRANÇAIS)**! "
            f"É TERMINANTEMENTE PROIBIDO escrever o roteiro em português ou inglês!"
        )
    elif idioma_real == "en":
        regra_idioma = (
            f"🚨 REGRA INVIOLÁVEL DE IDIOMA DO CANAL ({ch.get('nome') or 'Canal em Inglês'}): "
            f"Este canal é 100% em **{idioma_exato_str} (ENGLISH)**! "
            f"O ROTEIRO INTEIRO (da primeira à última palavra falada pelo narrador) DEVE SER ESCRITO **100% EM INGLÊS (ENGLISH)**! "
            f"É TERMINANTEMENTE PROIBIDO escrever o roteiro em português, mesmo que as instruções ou a estrutura aprovada contenham anotações em português!"
        )
    elif idioma_real == "es":
        regra_idioma = (
            f"🚨 REGRA INVIOLÁVEL DE IDIOMA DO CANAL ({ch.get('nome') or 'Canal em Espanhol'}): "
            f"Este canal é 100% em **{idioma_exato_str} (ESPAÑOL)**! "
            f"O ROTEIRO INTEIRO (da primeira à última palavra falada pelo narrador) DEVE SER ESCRITO **100% EM ESPANHOL (ESPAÑOL)**! "
            f"É TERMINANTEMENTE PROIBIDO escrever o roteiro em português!"
        )
    else:
        regra_idioma = (
            f"🚨 REGRA DE IDIOMA DO CANAL ({ch.get('nome') or 'Canal em Português'}): "
            f"Este canal é 100% em **Português do Brasil (pt-BR)**. Escreva todo o roteiro em Português do Brasil."
        )

    veo_cfg = d.get("veo_faixas_config") or {}
    bloco_ritmo_srt_veo = ""
    if not isinstance(veo_cfg, dict) or veo_cfg.get("ativo", True) is not False:
        prim_n = int((veo_cfg if isinstance(veo_cfg, dict) else {}).get("primeiros_blocos") or 60)
        prim_min = float((veo_cfg if isinstance(veo_cfg, dict) else {}).get("primeiros_min_s") or 2)
        prim_max = float((veo_cfg if isinstance(veo_cfg, dict) else {}).get("primeiros_max_s") or 4)
        rest_min = float((veo_cfg if isinstance(veo_cfg, dict) else {}).get("resto_min_s") or 4)
        rest_max = float((veo_cfg if isinstance(veo_cfg, dict) else {}).get("resto_max_s") or 8)
        quebrar_fr = bool((veo_cfg if isinstance(veo_cfg, dict) else {}).get("quebrar_frases", True))
        bloco_ritmo_srt_veo = f"""
⏱️ REGRA DE RITMO E CADÊNCIA PARA O ÁUDIO E SRT TEMPO VEO (DEFINIDA ANTES DE GERAR O ÁUDIO):
- O áudio deste roteiro será processado pelo **Editor de SRT Tempo VEO** com **Quebrar por frases = {'ATIVO' if quebrar_fr else 'PADRÃO'}** e **Faixas de Tempo**:
  1) **Os primeiros {prim_n} blocos do SRT terão tempo de {prim_min:g} a {prim_max:g} segundos** (frases curtas, diretas e magnéticas de ~{max(4, int(prim_min * 2.4))} a {max(7, int(prim_max * 2.5))} palavras por frase nos primeiros minutos para altíssima velocidade visual de cortes).
  2) **Os outros blocos abaixo terão tempo entre {rest_min:g} a {rest_max:g} segundos** (frases fluidas de ~{max(9, int(rest_min * 2.4))} a {max(15, int(rest_max * 2.5))} palavras bem pontuadas com ponto final, interrogação ou vírgula clara para que a quebra automática por frase gere um SRT 100% editado e sincronizado).
"""

    if modo == "titulos_neurais":
        amostra_rot = roteiro_atual[:7000] if roteiro_atual else instrucoes[:4000]
        prompt = f"""Você é o Cientista de Retenção e CTR do Motor **Antigravity V8 Ninja Pro** operando no **MODO TÍTULOS NEURAIS V8**.
TÍTULO BASE / TEMA ATUAL: "{entrada}"{info_canal}
ROTEIRO GERADO (BASE PARA EXTRAIR OS GATILHOS NEURAIS):
\"\"\"
{amostra_rot or entrada}
\"\"\"

Sua missão no **Modo Títulos Neurais V8**:
1. Analise profundamente o roteiro acima (o choque inicial, o conflito invisível, a virada emocional/financeira/científica e o loop de curiosidade).
2. Eleja **O MELHOR TÍTULO POSSÍVEL (CAMPEÃO NEURAL #1)** de acordo com a inteligência V8 para explodir o CTR no YouTube.
3. Gere mais **5 Variações Neurais de Altíssimo CTR** explorando ângulos psicológicos distintos (Curiosity Gap Extremo, Contraste Temporal/Idade, Medo do Arrependimento, Paradoxo Contraintuitivo, Revelação Silenciosa).
4. Mantenha os títulos no idioma oficial do canal (**{idioma_exato_str}**) (e inclua a tradução em português no campo `traducao` se o título for em inglês/espanhol).

Ao final da sua análise explicativa, inclua OBRIGATORIAMENTE um bloco JSON exato entre ```json e ``` neste formato para o painel criar os botões de 1 clique:
```json
{{
  "campeao": {{
    "titulo": "Título Campeão Neural #1 aqui",
    "traducao": "Tradução em PT-BR (se aplicável)",
    "ctr_score": 98,
    "gatilho": "Nome do Gatilho Neural Principal",
    "motivo": "Por que este é o melhor título possível segundo o V8"
  }},
  "variacoes": [
    {{"titulo": "Variação Neural #2", "traducao": "...", "ctr_score": 95, "gatilho": "Contraste Temporal"}},
    {{"titulo": "Variação Neural #3", "traducao": "...", "ctr_score": 94, "gatilho": "Curiosity Gap"}},
    {{"titulo": "Variação Neural #4", "traducao": "...", "ctr_score": 93, "gatilho": "Paradoxo"}},
    {{"titulo": "Variação Neural #5", "traducao": "...", "ctr_score": 92, "gatilho": "Aversão à Perda"}},
    {{"titulo": "Variação Neural #6", "traducao": "...", "ctr_score": 91, "gatilho": "Pergunta Hipotética"}}
  ]
}}
```"""
    elif modo == "analisar_titulo":
        prompt = f"""Você é o estrategista-chefe do Motor Antigravity V8 Ninja Pro (cálculo de retenção 145 PPM).
O autor quer ANALISAR ESTE TÍTULO/TEMA antes de decidir se vai produzir o roteiro:
TÍTULO/IDEIA: "{entrada}"{info_canal}
{f"OBSERVAÇÕES DO AUTOR: {instrucoes}" if instrucoes else ""}

Faça uma análise conversacional, direta e profunda (sem escrever o roteiro completo):
1. 🎯 **Potencial de CTR e Psicologia do Clique (Nota 0 a 100)**: O que desperta curiosidade, medo ou desejo nesse título.
2. ⏱️ **Cálculo Exato de Tempo e Retenção para o Nicho**:
   - Meta configurada: **{palavras} palavras** em **{blocos} blocos** = **{duracao_exata_min} minutos** de áudio (a 145 palavras/min).
   - Diga qual é o tempo ideal exato para este tema e subnicho no YouTube hoje e por quê.
3. 🔥 **5 Variações Virais do Título (em {idioma_exato_str})**: Ângulos mais magnéticos mantendo a essência.
4. 🧭 **Próximo Passo**: Pergunte ao autor se ele quer aprovar uma dessas variações para **Estruturar os {blocos} blocos** ou ir para o **Roteiro Completo**."""
    elif modo == "analisar_canal":
        prompt = f"""Você é o estrategista-chefe do Motor Antigravity V8 Ninja Pro.
O autor quer ANALISAR ESTE CANAL / NICHO:
CANAL OU NICHO: "{entrada}"{info_canal}
{f"OBSERVAÇÕES DO AUTOR: {instrucoes}" if instrucoes else ""}

Entregue um diagnóstico conversacional e estratégico:
1. 📊 **Posicionamento e Padrão de Sucesso do Nicho/Canal**: O que faz esse formato reter público e monetizar alto (RPM).
2. ⏱️ **Formato, Blocos e Tempo Exato Recomendado**: Quantas palavras, quantos blocos e quantos minutos (a 145 PPM) funcionam melhor para esse estilo de canal.
3. 💡 **5 Títulos/Temas Inéditos de Alto CTR (em {idioma_exato_str})**: Prontos para testar hoje nesse estilo.
4. 🧭 **Próximo Passo**: Pergunte qual dos temas o autor quer escolher para estruturarmos os blocos."""
    elif modo == "roteiro_completo":
        pedido_ajuste = (d.get("pedido_ajuste") or "").strip()
        texto_anterior = (d.get("texto_anterior") or "").strip()
        bloco_ajuste = ""
        if pedido_ajuste:
            trecho_ant = f'VERSÃO ANTERIOR PARA CORRIGIR/REFAZER:\n"""\n{texto_anterior[:6000]}\n"""' if texto_anterior else ""
            bloco_ajuste = f"""
PEDIDO DIRETO DO AUTOR PARA REFAZER / AJUSTAR O ROTEIRO (PRIORIDADE MÁXIMA):
"{pedido_ajuste}"
{trecho_ant}
Aplique exatamente o que o autor pediu acima ao reescrever o roteiro completo!
"""
        bloco_inst_aprov = f"ESTRUTURA APROVADA E INSTRUÇÕES DO AUTOR (use apenas como guia estrutural; escreva a narração 100% no idioma do canal: {idioma_exato_str}):\n{instrucoes}" if instrucoes else ""
        prompt = f"""Você é o roteirista mestre do Motor Antigravity V8 Ninja Pro.
{regra_idioma}

Escreva o ROTEIRO COMPLETO de altíssima retenção para:
TÍTULO: "{entrada}"{info_canal}
META SOBERANA E OBRIGATÓRIA DE EXTENSÃO E TEMPO: EXATAMENTE **{palavras} palavras** (equivalente a exatos **{duracao_exata_min:g} minutos** de narração a 145 PPM; limite mínimo de {int(palavras * 0.88)} palavras e limite máximo de {int(palavras * 1.12)} palavras), estruturado internamente no fôlego de **{blocos} blocos narrativos** (~{palavras_por_bloco} palavras por bloco).
🚨 REGRA ESTRITA DE DURAÇÃO: A duração escolhida pelo autor para ESTE vídeo é de **{duracao_exata_min:g} MINUTOS ({palavras} palavras)**! Ignore qualquer outra duração mencionada em prompts anteriores e NÃO escreva nem um roteiro de 20 minutos quando o autor pediu {duracao_exata_min:g} minutos, nem um resumo curto! Cumpra com precisão cirúrgica a meta de **~{palavras} palavras ({duracao_exata_min:g} minutos)**.
{bloco_ritmo_srt_veo}
{bloco_inst_aprov}
{bloco_ajuste}
Siga a arquitetura V8 Ninja Pro e o DNA exclusivo do canal **{ch.get('nome') or 'Selecionado'}**:
- Gancho magnético nos primeiros 30 segundos (choque de realidade + promessa clara + loop aberto).
- Desenvolvimento profundo e fluido nos {blocos} blocos, mantendo tensão psicológica, exemplos e fatos concretos.
- Fechamento forte com CTA natural para o canal somente no último parágrafo.

REGRA ABSOLUTA DE FORMATAÇÃO E IDIOMA (PARA NARRAÇÃO DIRETA TTS):
- {regra_idioma}
- Entregue EXCLUSIVAMENTE o texto puro falado pelo narrador (apenas o roteiro limpo em **{idioma_exato_str}**).
- NÃO escreva nenhuma frase introdutória (NÃO diga "Aqui está o roteiro...", NÃO fale sobre duração ou 145 PPM).
- NÃO coloque o título no topo (# Título) e NÃO use linhas divisórias (---).
- NÃO coloque marcações de tempo ou números de cena/bloco em nenhum lugar (NUNCA escreva "[00:00]", "[000]", "[01:30]", "(00:00)", "## Bloco 1", "[Bloco 1]", "[Gancho]", "**Narrador:**").
- Comece diretamente na primeira palavra que será narrada no vídeo (em **{idioma_exato_str}**) e termine na última palavra narrada."""
    else:
        # Passo 1: estruturar (SOMENTE estruturar sem escrever o roteiro completo)
        pedido_ajuste = (d.get("pedido_ajuste") or "").strip()
        texto_anterior = (d.get("texto_anterior") or "").strip()
        bloco_ajuste_est = ""
        if pedido_ajuste:
            trecho_est_ant = f'ESTRUTURA ANTERIOR QUE O AUTOR QUER MODIFICAR:\n"""\n{texto_anterior[:5000]}\n"""' if texto_anterior else ""
            bloco_ajuste_est = f"""
PEDIDO CONVERSACIONAL DO AUTOR PARA REFAZER / AJUSTAR ESTA ESTRUTURA (PRIORIDADE MÁXIMA):
"{pedido_ajuste}"
{trecho_est_ant}
Refaça a estrutura atendendo 100% ao pedido do autor acima e mantendo a duração exata de {duracao_exata_min} minutos ({palavras} palavras em {blocos} blocos)!
"""
        prompt = f"""Você é o arquiteto narrativo do Motor Antigravity V8 Ninja Pro.
IMPORTANTE: O autor pediu para **SOMENTE ESTRUTURAR O ROTEIRO SEM ESCREVÊ-LO COMPLETO**, pois ele quer analisar e aprovar a estrutura antes!
TÍTULO: "{entrada}"{info_canal}
META EXATA SOLICITADA PELO AUTOR: **{duracao_exata_min} minutos de vídeo** = **{palavras} palavras** divididas em **{blocos} blocos narrativos** (~{palavras_por_bloco} palavras por bloco, calculado a 145 PPM).
NUNCA altere essa duração! Mantenha exatamente os **{duracao_exata_min} minutos ({palavras} palavras em {blocos} blocos)** que o autor definiu para este vídeo.
{regra_idioma}
{bloco_ritmo_srt_veo}
{f"INSTRUÇÕES DO AUTOR: {instrucoes}" if instrucoes else ""}
{bloco_ajuste_est}
Entregue de forma clara e conversacional:
1. ⏱️ **Cálculo Exato de Tempo e Ritmo para o Canal {ch.get('nome') or ''} ({idioma_exato_str})**:
   - Para **{palavras} palavras** (ritmo a 145 PPM): duração exata de **{duracao_exata_min} minutos** ({int(duracao_exata_min)}min e {int((duracao_exata_min % 1) * 60)}s).
   - Confirme que o roteiro completo no Passo 2 será escrito **100% em {idioma_exato_str}** respeitando a regra de ritmo SRT Tempo VEO configurada acima.
2. 🧱 **Estrutura Detalhada dos {blocos} Blocos (SEM escrever o texto corrido ainda)**:
   - Liste do **Bloco 1 ao Bloco {blocos}**: Nome do Bloco (em {idioma_exato_str}), Meta de Palavras (~{palavras_por_bloco} palavras) + Tempo em tela, O que acontece no bloco (Tese/Conflito) e a frase de **Gancho/Cliffhanger em {idioma_exato_str}** que segura o espectador para o próximo bloco.
3. 💬 **Alinhamento Conversacional (Passo 1 -> Passo 2)**:
   - Pergunte ao autor se ele dá o **OK** para avançarmos ao **Passo 2 (Escrever o Roteiro Completo 100% em {idioma_exato_str} de {duracao_exata_min} minutos / ~{palavras} palavras)**."""

    titulos_neurais_obj = None
    pacote_viral_obj = None
    try:
        resposta = claude.texto_pref("roteiro", prompt)
        if modo == "roteiro_completo":
            resposta = darkplanner_sync.limpar_apenas_roteiro(resposta)

            # Blindagem automática de idioma por canal: se o canal é em Inglês, Espanhol ou Francês e o modelo deslizou para Português, reescreve imediatamente no idioma nativo do canal!
            if idioma_real in ("en", "es", "fr") and resposta:
                amostra_chk = f" {resposta[:1800].lower()} "
                pt_hits_chk = sum(amostra_chk.count(w) for w in (" não ", " para ", " uma ", " mais ", " quando ", " como ", " pela ", " pelo ", " sobre ", " estava "))
                en_hits_chk = sum(amostra_chk.count(w) for w in (" the ", " and ", " that ", " with ", " from ", " when ", " into ", " before ", " were ", " this "))
                es_hits_chk = sum(amostra_chk.count(w) for w in (" los ", " las ", " del ", " una ", " pero ", " más ", " cuando ", " hacia ", " desde "))
                fr_hits_chk = sum(amostra_chk.count(w) for w in (" les ", " des ", " dans ", " avec ", " pour ", " une ", " sur ", " mais ", " cette ", " sont "))
                precisa_traduzir = (
                    (idioma_real == "en" and pt_hits_chk > en_hits_chk and pt_hits_chk >= 4)
                    or (idioma_real == "es" and pt_hits_chk > es_hits_chk and pt_hits_chk >= 4)
                    or (idioma_real == "fr" and pt_hits_chk > fr_hits_chk and pt_hits_chk >= 4)
                )
                if precisa_traduzir:
                    try:
                        prompt_fix_lang = f"""Rewrite/translate the following YouTube narration script 100% into native, high-retention **{idioma_exato_str}** for the channel **{ch.get('nome') or ''}** (Title: "{entrada}").
Keep the exact narrative length, dramatic pacing, and paragraph structure. Output ONLY the clean spoken narration in {idioma_exato_str} with zero introductory text and zero Portuguese words:

\"\"\"
{resposta}
\"\"\""""
                        resp_trad = claude.texto_pref("roteiro", prompt_fix_lang)
                        resp_trad_limpa = darkplanner_sync.limpar_apenas_roteiro(resp_trad)
                        if resp_trad_limpa and len(resp_trad_limpa.split()) >= int(len(resposta.split()) * 0.65):
                            resposta = resp_trad_limpa
                    except Exception as e_tr:
                        print("Aviso ao corrigir idioma do roteiro:", e_tr)

            # Garante que a duração em minutos solicitada pelo usuário (ex: 10 min = ~1450 palavras ou 20 min = ~2900 palavras) seja cumprida integralmente (nem curta demais, nem longa demais)!
            palavras_atuais = len((resposta or "").split())
            meta_minima = int(palavras * 0.84)
            meta_maxima = int(palavras * 1.25)

            if palavras_atuais > meta_maxima and palavras >= 300:
                try:
                    prompt_cond = f"""Você escreveu um roteiro com {palavras_atuais} palavras, mas o autor definiu a duração exata de **{duracao_exata_min:g} minutos** = **{palavras} palavras** (a 145 PPM) para o vídeo "{entrada}" do canal **{ch.get('nome') or ''}**.
{regra_idioma}
Condense e ajuste o roteiro abaixo para que tenha **aproximadamente {palavras} palavras** (entre {int(palavras * 0.90)} e {int(palavras * 1.08)} palavras), mantendo 100% do gancho inicial, todos os {blocos} blocos narrativos, os diálogos/fatos principais e o fechamento com CTA no último parágrafo.
Entregue EXCLUSIVAMENTE o texto puro falado pelo narrador em **{idioma_exato_str}** (sem marcações, sem títulos):

\"\"\"
{resposta}
\"\"\""""
                    resp_cond = claude.texto_pref("roteiro", prompt_cond)
                    resp_cond_limpa = darkplanner_sync.limpar_apenas_roteiro(resp_cond)
                    n_cond = len((resp_cond_limpa or "").split())
                    if resp_cond_limpa and int(palavras * 0.75) <= n_cond <= int(palavras * 1.22):
                        resposta = resp_cond_limpa
                        palavras_atuais = n_cond
                except Exception as e_cond:
                    print("Aviso ao ajustar limite máximo de palavras do roteiro:", e_cond)

            tentativa_cont = 0
            while palavras_atuais < meta_minima and tentativa_cont < 3 and palavras >= 700:
                tentativa_cont += 1
                faltam_pal = max(250, palavras - palavras_atuais)
                eh_parte_final = faltam_pal <= 1100 or tentativa_cont == 3
                # Se a primeira parte já tinha colocado um CTA de despedida precoce no último parágrafo, remove o último parágrafo curto de despedida antes de continuar
                paragrafos_exist = [p.strip() for p in (resposta or "").split("\n\n") if p.strip()]
                if len(paragrafos_exist) > 3 and any(
                    x in paragrafos_exist[-1].lower()
                    for x in (
                        "inscreva-se",
                        "subscribe",
                        "suscríbete",
                        "abonnez-vous",
                        "activez la cloche",
                        "à bientôt",
                        "à très vite",
                        "até o nosso próximo",
                        "until next time",
                        "deixe seu like",
                        "ative o sino",
                    )
                ):
                    resposta = "\n\n".join(paragrafos_exist[:-1]).strip()
                    palavras_atuais = len(resposta.split())
                    faltam_pal = max(250, palavras - palavras_atuais)

                ultimos_chars = resposta[-2400:] if len(resposta) > 2400 else resposta
                bloco_est_cont = f"ESTRUTURA APROVADA:\n{instrucoes[:3000]}" if instrucoes else ""
                prompt_cont = f"""Você está escrevendo o ROTEIRO COMPLETO em **{idioma_exato_str}** para o vídeo "{entrada}" do canal **{ch.get('nome') or ''}** com meta total obrigatória de **{palavras} palavras** ({duracao_exata_min} minutos a 145 PPM).
Até agora foram escritas **{palavras_atuais} palavras**. Faltam aproximadamente **{faltam_pal} palavras** para atingir os {duracao_exata_min} minutos solicitados pelo autor.
{regra_idioma}
{bloco_est_cont}

FINAL DO TEXTO JÁ ESCRITO (CONTINUE EXATAMENTE A PARTIR DAQUI NO MESMO IDIOMA **{idioma_exato_str}** SEM REPETIR O QUE JÁ FOI DITO):
\"\"\"
{ultimos_chars}
\"\"\"

INSTRUÇÃO DE CONTINUAÇÃO DIRETA:
- Escreva agora mais **~{min(faltam_pal, 1200)} palavras** **100% em {idioma_exato_str}** dando sequência imediata e fluida aos próximos blocos narrativos, aprofundando os eventos, causas, bastidores e desdobramentos reais sem enrolação repetitiva.
- {"Finalize no último parágrafo com o fechamento poderoso e CTA natural do canal (em " + idioma_exato_str + ")." if eh_parte_final else "NÃO encerre o vídeo ainda (não faça despedida nem CTA ainda), pois ainda estamos nos blocos intermediários."}
- Entregue APENAS o texto puro falado pelo narrador em **{idioma_exato_str}** (sem [00:00], sem títulos de blocos, sem introduções)."""
                try:
                    extra_txt = claude.texto_pref("roteiro", prompt_cont)
                    extra_limpo = darkplanner_sync.limpar_apenas_roteiro(extra_txt)
                    if not extra_limpo or len(extra_limpo.split()) < 60:
                        break
                    resposta = (resposta.rstrip() + "\n\n" + extra_limpo.lstrip()).strip()
                    palavras_atuais = len(resposta.split())
                except Exception as e_cont:
                    print("Aviso na continuação automática de duração do roteiro:", e_cont)
                    break

            # Se já houver vídeo ou canal selecionado, salva automaticamente no DarkPlanner!
            if canal_id and resposta:
                if not vid:
                    try:
                        dp_reg = darkplanner_sync.criar_video_dp(canal_id, entrada or "Novo Vídeo V8")
                        if dp_reg and dp_reg.get("id"):
                            vid = dp_reg["id"]
                            with Tx() as db2:
                                if not find(db2["videos"], vid):
                                    vn = storage.new_video(canal_id, entrada or "Novo Vídeo V8")
                                    vn["id"] = vid
                                    vn["dp_video"] = dp_reg
                                    vn["roteiro"] = resposta
                                    vn["duracao_minutos"] = duracao_exata_min
                                    vn.setdefault("briefing", {})["duracao_min"] = duracao_exata_min
                                    vn["etapas"]["roteiro"] = True
                                    db2["videos"].append(vn)
                    except Exception as e:
                        print("Aviso ao criar vídeo automático no Passo 2:", e)
                if vid:
                    with Tx() as db2:
                        v2 = find(db2["videos"], vid)
                        if v2:
                            if entrada:
                                v2["titulo"] = entrada
                            v2["roteiro"] = resposta
                            v2["duracao_minutos"] = duracao_exata_min
                            v2.setdefault("briefing", {})["duracao_min"] = duracao_exata_min
                            v2["etapas"]["roteiro"] = True
                    threading.Thread(target=darkplanner_sync.salvar_roteiro_dp, args=(canal_id, vid, resposta), daemon=True).start()

            # IMPORTANTE: No Passo 2 (roteiro_completo), gera APENAS o roteiro completo limpo.
            # Descrição + Tags + Thumbnail só são geradas quando o usuário clicar no botão "🔥 Descrição + Tags + Thumb".
            if d.get("gerar_pacote_viral") is True:
                try:
                    pacote_viral_obj = darkplanner_sync.gerar_pacote_viral_roteiro(
                        titulo=entrada or "Vídeo Viral",
                        roteiro=resposta,
                        canal_id=canal_id,
                        vid=vid,
                        duracao_min=duracao_exata_min,
                        idioma=idioma,
                        ia_fn=lambda p_v: claude.texto_pref("roteiro", p_v),
                        gerar_imagem_agora=True,
                    )
                except Exception as e_pv:
                    print("Aviso ao gerar pacote viral pós-roteiro:", e_pv)
        elif modo == "titulos_neurais":
            titulos_neurais_obj = darkplanner_sync._extrair_json_ia(resposta)
            # Remove o bloco JSON cru do texto visível se ele foi extraído com sucesso
            if titulos_neurais_obj:
                resposta = re.sub(r"```(?:json)?\s*[\s\S]*?```", "", resposta).strip()
                # Altera AUTOMATICAMENTE lá na parte do DarkPlanner o Título Campeão Neural #1 assim que gerado!
                try:
                    camp_tn = (titulos_neurais_obj.get("campeao") or titulos_neurais_obj.get("campeao_neural") or {})
                    novo_tit_camp = (camp_tn.get("titulo") or "").strip()
                    if novo_tit_camp:
                        sinc_tit = darkplanner_sync.sincronizar_novo_titulo_darkplanner(
                            vid=vid,
                            canal_id=canal_id,
                            novo_titulo=novo_tit_camp,
                            titulo_antigo=entrada,
                        )
                        titulos_neurais_obj["_sincronizado_dp"] = sinc_tit
                except Exception as e_st_tit:
                    print("Aviso ao sincronizar título neural no DarkPlanner:", e_st_tit)
        if modo != "roteiro_completo" and resposta:
            # Limpa asteriscos duplicados/quebrados (ex.: ****) mantendo organização limpa
            resposta = re.sub(r"\*{3,}", "**", resposta)
            resposta = re.sub(r"\*\*\s*\*\*", "", resposta)
    except Exception as e:
        return erro(str(e))
    return jsonify({
        "ok": True,
        "modo": modo,
        "video_id": vid,
        "palavras": palavras,
        "palavras_geradas": len((resposta or "").split()) if modo == "roteiro_completo" else palavras,
        "blocos": blocos,
        "duracao_min": duracao_exata_min,
        "resposta": resposta,
        "titulos_neurais": titulos_neurais_obj,
        "pacote_viral": pacote_viral_obj,
    })


@app.route("/api/darkplanner/atualizar-titulo", methods=["POST"])
def api_dp_atualizar_titulo():
    """Altera automaticamente o título do vídeo na Fábrica Dark, no DarkPlanner Web e na Matriz do DarkPlanner Desktop."""
    d = request.json or {}
    novo_titulo = (d.get("novo_titulo") or d.get("titulo") or "").strip()
    if not novo_titulo:
        return erro("Informe o novo título.")
    try:
        res = darkplanner_sync.sincronizar_novo_titulo_darkplanner(
            vid=(d.get("vid") or d.get("video_id") or "").strip(),
            canal_id=(d.get("canal_id") or d.get("channel_id") or "").strip(),
            novo_titulo=novo_titulo,
            titulo_antigo=(d.get("titulo_antigo") or "").strip(),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/antigravity/pacote-viral", methods=["POST"])
def antigravity_pacote_viral():
    """Gera ou atualiza sob demanda o Pacote Viral Pós-Roteiro (Descrição SEO + Tags + 3 Conceitos de Thumb Mais Chamativas do Nicho + Imagem 1280x720)."""
    d = request.json or {}
    titulo = (d.get("titulo") or "").strip()
    roteiro = (d.get("roteiro") or "").strip()
    canal_id = (d.get("canal_id") or d.get("channel_id") or "").strip()
    vid = (d.get("vid") or d.get("video_id") or "").strip()
    duracao_min = float(d.get("duracao_min") or 20)
    if not titulo and not roteiro:
        return erro("Informe o título ou gere/cole o roteiro primeiro.")
    try:
        res = darkplanner_sync.gerar_pacote_viral_roteiro(
            titulo=titulo or "Vídeo do Canal",
            roteiro=roteiro,
            canal_id=canal_id,
            vid=vid,
            duracao_min=duracao_min,
            idioma=(d.get("idioma") or "").strip(),
            ia_fn=lambda p_v: claude.texto_pref("roteiro", p_v),
            gerar_imagem_agora=True,
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/antigravity/thumb-viral-render", methods=["POST"])
def antigravity_thumb_viral_render():
    """Renderiza em 1280x720 via API ChatGPT (OpenAI Image API, zero logo) a Thumbnail Viral seguindo o estilo fixo e avatar do canal,
    ou aplica o ajuste interativo solicitado pelo usuário no chat pós-geração (`pedido_ajuste_ia`)."""
    d = request.json or {}
    vid = (d.get("vid") or d.get("video_id") or "").strip()
    titulo = (d.get("titulo") or "video_viral").strip()
    slug_pasta = re.sub(r"[^\w\-]+", "_", titulo)[:48].strip("_") or "video_viral"
    pasta_thumbs = (
        os.path.join(storage.video_dir(vid), "thumbs")
        if vid
        else os.path.join(storage.DATA_DIR, "thumbs_virais", slug_pasta)
    )
    canal_id_req = (d.get("canal_id") or d.get("channel_id") or "").strip()
    pedido_ia = (d.get("pedido_ajuste_ia") or d.get("mensagem_ia") or "").strip()
    try:
        if pedido_ia:
            res = darkplanner_sync.ajustar_thumbnail_com_ia(
                pedido_usuario=pedido_ia,
                prompt_imagem_en=(d.get("prompt_imagem_en") or "").strip(),
                texto_tela=(d.get("texto_tela") or "").strip(),
                palavra_destaque=(d.get("palavra_destaque") or "").strip(),
                estilo=(d.get("estilo") or "impacto").strip(),
                lado=(d.get("lado") or "esquerda").strip(),
                cor_destaque=(d.get("cor_destaque") or "#FFD400").strip(),
                posicao_vertical=(d.get("posicao_vertical") or "auto").strip(),
                escala_texto=float(d.get("escala_texto") or 1.0),
                sem_texto_thumb=d.get("sem_texto_thumb"),
                canal_id=canal_id_req,
                vid=vid,
                titulo=titulo,
                incluir_avatar=d.get("incluir_avatar"),
                compositar_avatar=d.get("compositar_avatar"),
                descricao_avatar=(d.get("descricao_avatar") or "").strip(),
                estilo_thumb=(d.get("estilo_thumb") or "").strip(),
                ia_fn=(lambda p_a: claude.texto_pref("roteiro", p_a)) if claude.tem_ia() else None,
            )
        else:
            res = darkplanner_sync.renderizar_thumb_viral_item(
                prompt_imagem_en=(d.get("prompt_imagem_en") or "").strip(),
                texto_tela=(d.get("texto_tela") or "").strip(),
                palavra_destaque=(d.get("palavra_destaque") or "").strip(),
                estilo=(d.get("estilo") or "impacto").strip(),
                lado=(d.get("lado") or "esquerda").strip(),
                cor_destaque=(d.get("cor_destaque") or "").strip(),
                pasta_destino=pasta_thumbs,
                prefixo_arq=f"thumb_{slug_pasta}",
                forcar_nova_arte=bool(d.get("forcar_nova_arte", False)),
                ajuste_prompt=(d.get("ajuste_prompt") or "").strip(),
                sem_texto_thumb=d.get("sem_texto_thumb"),
                canal_id=canal_id_req,
                incluir_avatar=d.get("incluir_avatar"),
                compositar_avatar=d.get("compositar_avatar"),
                descricao_avatar=(d.get("descricao_avatar") or "").strip(),
                estilo_thumb=(d.get("estilo_thumb") or "").strip(),
                posicao_vertical=(d.get("posicao_vertical") or "auto").strip(),
                escala_texto=float(d.get("escala_texto") or 1.0),
                forcar_lado=bool(d.get("forcar_lado", False)),
                titulo_video=titulo,
                roteiro_contexto=(d.get("roteiro") or "").strip(),
            )
        dp_sync = {}
        try:
            arq_up = res.get("arq_impacto") or res.get("arq_limpa") or ""
            if arq_up:
                dp_sync = darkplanner_sync.enviar_thumb_tags_descricao_dp(
                    vid=vid,
                    canal_id=canal_id_req,
                    titulo=titulo if titulo != "video_viral" else "",
                    descricao_yt=(d.get("descricao_youtube") or d.get("descricao") or "").strip(),
                    tags_virgula=(d.get("tags_virgula") or "").strip(),
                    caminho_thumb=arq_up,
                )
        except Exception as e_dp_th:
            print("Aviso ao enviar thumb regenerada ao DarkPlanner:", e_dp_th)
        return jsonify({"ok": True, "darkplanner_sync": dp_sync, **res})
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/enviar-thumb-tags-descricao", methods=["POST"])
def api_dp_enviar_thumb_tags_descricao():
    """Envia diretamente para o DarkPlanner Web (Foto 5):
    - Thumbnail -> Seta Vermelha (POST /videos/{id}/thumbnail)
    - Tags -> Caixa Amarela ('Descrição da thumbnail' -> campo thumbnail)
    - Descrição -> Caixa Verde ('DESCRIÇÃO' -> campo notas)"""
    d = request.json or {}
    try:
        res = darkplanner_sync.enviar_thumb_tags_descricao_dp(
            vid=(d.get("vid") or d.get("video_id") or "").strip(),
            canal_id=(d.get("canal_id") or d.get("channel_id") or "").strip(),
            titulo=(d.get("titulo") or "").strip(),
            descricao_yt=(d.get("descricao_youtube") or d.get("descricao") or "").strip(),
            tags_virgula=(d.get("tags_virgula") or d.get("tags") or "").strip(),
            caminho_thumb=(d.get("caminho_thumb") or d.get("arq_impacto") or "").strip(),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/antigravity/thumb-viral-img")
def antigravity_thumb_viral_img():
    """Serve a imagem PNG 1280x720 da Thumbnail Viral gerada (com suporte a ?download=1)."""
    caminho = (request.args.get("path") or "").strip().replace("/", os.sep)
    if not caminho or not os.path.exists(caminho) or not os.path.isfile(caminho):
        return erro("Thumbnail não encontrada.", 404)
    ext = os.path.splitext(caminho)[1].lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp"):
        return erro("Formato inválido.", 400)
    dl = request.args.get("download") == "1"
    return send_file(caminho, as_attachment=dl, download_name=os.path.basename(caminho) if dl else None)


@app.route("/api/antigravity/canal-avatar-thumb", methods=["GET", "POST", "DELETE"])
def antigravity_canal_avatar_thumb():
    """Gerencia o Avatar Principal da Thumbnail e até 5 Personagens de Referência ([01] a [05]) do Vídeo por canal."""
    if request.method == "GET":
        cid = (request.args.get("canal_id") or request.args.get("channel_id") or "").strip()
        return jsonify(darkplanner_sync.obter_avatar_thumb_canal(canal_id=cid))

    if request.method == "DELETE":
        d_del = request.get_json(silent=True) or {}
        cid = (d_del.get("canal_id") or request.args.get("canal_id") or "").strip()
        alvo = (d_del.get("alvo") or request.args.get("alvo") or "avatar").strip()
        slot_pv = d_del.get("slot_personagem_video") if "slot_personagem_video" in d_del else request.args.get("slot_personagem_video")
        if alvo == "personagem_video":
            return jsonify(
                darkplanner_sync.salvar_avatar_thumb_canal(
                    canal_id=cid,
                    remover_personagem_video=True,
                    slot_personagem_video=slot_pv,
                )
            )
        return jsonify(darkplanner_sync.remover_avatar_thumb_canal(canal_id=cid))

    try:
        if request.files:
            f_im = request.files.get("imagem")
            arq_bytes = f_im.read() if f_im else None
            nome_arq = (f_im.filename if f_im else "") or "avatar.png"
            f_pv = request.files.get("imagem_personagem_video")
            pv_bytes = f_pv.read() if f_pv else None
            pv_nome = (f_pv.filename if f_pv else "") or "personagem_video.png"
            arqs_pv_list = []
            for f_pvl in request.files.getlist("imagens_personagem_video"):
                if f_pvl:
                    arqs_pv_list.append((f_pvl.filename or "personagem_video.png", f_pvl.read()))
            arqs_est = []
            for f_e in request.files.getlist("imagens_estilo"):
                if f_e:
                    arqs_est.append((f_e.filename or "estilo.png", f_e.read()))
            cid = (request.form.get("canal_id") or "").strip()
            usar_sempre = str(request.form.get("usar_sempre", request.form.get("sempre_incluir", "true"))).lower() not in ("false", "0", "no")
            compositar_direto = str(request.form.get("compositar_direto", request.form.get("compositar_canto", "false"))).lower() in ("true", "1", "yes", "on")
            desc_av = request.form.get("descricao_avatar")
            est_th = request.form.get("estilo_thumb")
            pv_ativo_raw = request.form.get("personagem_video_ativo")
            pv_ativo = (str(pv_ativo_raw).lower() in ("true", "1", "yes", "on")) if pv_ativo_raw is not None else (True if (pv_bytes or arqs_pv_list) else None)
            pv_dna = request.form.get("personagem_video_dna")
            res = darkplanner_sync.salvar_avatar_thumb_canal(
                canal_id=cid,
                arquivo_bytes=arq_bytes,
                nome_arquivo=nome_arq,
                usar_sempre=usar_sempre,
                compositar_direto=compositar_direto,
                descricao_avatar=desc_av,
                estilo_thumb=est_th,
                arquivos_estilo=arqs_est if arqs_est else None,
                personagem_video_bytes=pv_bytes,
                personagem_video_nome=pv_nome,
                personagens_video_arquivos=arqs_pv_list if arqs_pv_list else None,
                personagem_video_ativo=pv_ativo,
                personagem_video_dna=pv_dna,
            )
            return jsonify(res)
        else:
            import base64 as _b64_ap
            d = request.get_json(silent=True) or {}
            cid = (d.get("canal_id") or d.get("channel_id") or "").strip()
            usar_s = d.get("usar_sempre") if "usar_sempre" in d else d.get("sempre_incluir", True)
            comp_d = d.get("compositar_direto") if "compositar_direto" in d else d.get("compositar_canto", False)
            pv_ativo_d = d.get("personagem_video_ativo") if "personagem_video_ativo" in d else None
            arqs_pv_json = []
            if isinstance(d.get("personagens_video_b64_list"), list):
                for idx_b, it_b in enumerate(d.get("personagens_video_b64_list")[:5]):
                    b64_s = (it_b.get("b64") if isinstance(it_b, dict) else str(it_b or "")).strip()
                    nm_s = (it_b.get("nome") if isinstance(it_b, dict) else f"personagem_{idx_b + 1:02d}.png") or f"personagem_{idx_b + 1:02d}.png"
                    if b64_s:
                        if "," in b64_s and b64_s.startswith("data:"):
                            b64_s = b64_s.split(",", 1)[1]
                        try:
                            arqs_pv_json.append((nm_s, _b64_ap.b64decode(b64_s)))
                        except Exception:
                            pass
            res = darkplanner_sync.salvar_avatar_thumb_canal(
                canal_id=cid,
                usar_sempre=bool(usar_s),
                compositar_direto=bool(comp_d),
                descricao_avatar=d.get("descricao_avatar"),
                usar_ref_01_canal=bool(d.get("usar_ref_01_canal", False)),
                estilo_thumb=d.get("estilo_thumb"),
                limpar_thumbs_estilo=bool(d.get("limpar_thumbs_estilo", False)),
                personagens_video_arquivos=arqs_pv_json if arqs_pv_json else None,
                personagem_video_ativo=bool(pv_ativo_d) if pv_ativo_d is not None else None,
                personagem_video_dna=d.get("personagem_video_dna"),
                remover_personagem_video=bool(d.get("remover_personagem_video", False)),
                slot_personagem_video=d.get("slot_personagem_video"),
            )
            return jsonify(res)
    except Exception as e:
        return erro(str(e))




@app.route("/api/antigravity/skill1-extrator-estilo", methods=["POST"])
def antigravity_skill1_extrator_estilo():
    """Skill 1 (`02_SKILL_EXTRATOR_ESTILO` v1.1 — Criador de Estilos Visuais por Imagens):
    Recebe imagens de referência enviadas (multipart ou base/pacote do canal), extrai a paleta real dos pixels via PIL
    e compila o Arquivo de Estilo v2 (`STYLE_DNA`, `CHARACTER_DNA`, `EXTRAS_DNA`, `NEGATIVE_DNA`, `PALAVRA_SENTINELA`)."""
    caminhos_salvos = []
    pasta_tmp = os.path.join(storage.DATA_DIR, "skill1_uploads")
    os.makedirs(pasta_tmp, exist_ok=True)
    if request.files:
        for f in request.files.getlist("imagens"):
            if f and f.filename:
                fn_seg = re.sub(r"[^\w\.\-]", "_", f.filename)
                dest = os.path.join(pasta_tmp, f"{int(time.time())}_{fn_seg}")
                f.save(dest)
                caminhos_salvos.append(dest)
        canal_id = (request.form.get("canal_id") or "").strip()
        nome_estilo = (request.form.get("nome_estilo") or "").strip()
        observacoes = (request.form.get("observacoes") or "").strip()
    else:
        d = request.json or {}
        canal_id = (d.get("canal_id") or "").strip()
        nome_estilo = (d.get("nome_estilo") or "").strip()
        observacoes = (d.get("observacoes") or "").strip()
        if isinstance(d.get("image_paths"), list):
            caminhos_salvos = [p for p in d["image_paths"] if p and os.path.exists(p)]

    try:
        res = darkplanner_sync.extrair_estilo_visual_por_imagens_skill1(
            image_paths=caminhos_salvos,
            canal_id=canal_id,
            nome_estilo=nome_estilo,
            observacoes=observacoes,
            ia_fn=(lambda p: claude.texto_pref("roteiro", p)) if claude.tem_ia() else None,
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/antigravity/skill-cenas-srt", methods=["POST"])
def antigravity_skill_cenas_srt():
    """Passo 6 (Opção A) — Executa a Skill 6 (`gerar-cenas-narracao-srt`) sobre o SRT Tempo VEO."""
    d = request.json or {}
    srt_texto = (d.get("srt_texto") or "").strip()
    vid = (d.get("video_id") or "").strip()
    job_id = (d.get("job_id") or "").strip()
    if not srt_texto and job_id:
        p_srt = os.path.join(storage.DATA_DIR, "audios_dp", job_id, "srtsynctempo_editado.srt")
        if os.path.exists(p_srt):
            with open(p_srt, "r", encoding="utf-8") as f:
                srt_texto = f.read()
    if not srt_texto and vid:
        p_vid = storage.video_dir(vid)
        for cand in ("legenda_propria.srt", "legendas.srt"):
            if os.path.exists(os.path.join(p_vid, cand)):
                with open(os.path.join(p_vid, cand), "r", encoding="utf-8") as f:
                    srt_texto = f.read()
                break
    if not srt_texto:
        return erro("Carregue ou gere o arquivo .SRT do áudio (Passo 5) antes de criar os prompts de cenas.")

    try:
        res = darkplanner_sync.gerar_pacote_skill6_srt(
            srt_texto=srt_texto,
            titulo=d.get("titulo") or "",
            canal_id=d.get("canal_id") or d.get("channel_id") or "",
            estilo_visual=d.get("estilo_visual") or "",
            epoca_pais=d.get("epoca_pais") or "",
            generation_mode=d.get("generation_mode") or "DIRETO",
            aspect_ratio=d.get("aspect_ratio") or "16:9",
            audio_mode=d.get("audio_mode") or "DIEGETIC_ONLY",
            vid=vid,
            ia_fn=(lambda p: claude.texto_pref("roteiro", p)) if claude.tem_ia() else None,
            skill_modo=d.get("skill_modo") or "skill6",
            skill_catalogo_id=d.get("skill_catalogo_id") or "",
            prompts_canal_ids=d.get("prompts_canal_ids") if isinstance(d.get("prompts_canal_ids"), list) else None,
            pack_id=d.get("pack_id") or "",
            gerar_imagens_ref=bool(d.get("gerar_imagens_ref", True)),
            salvar_novas_no_pack=bool(d.get("salvar_novas_no_pack", False)),
            reutilizar_existentes=bool(d.get("reutilizar_existentes", False)),
            tag_config=d.get("tag_config") if isinstance(d.get("tag_config"), dict) else None,
            edicao_config=d.get("edicao_config") if isinstance(d.get("edicao_config"), dict) else None,
            instrucoes_edicao_custom=d.get("instrucoes_edicao_custom") or "",
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/antigravity/skill-cenas-file/<slug>/<path:filename>")
def antigravity_skill_cenas_file(slug, filename):
    pasta = os.path.abspath(os.path.join(storage.DATA_DIR, "skill6_pacotes", os.path.basename(slug)))
    rel_limpo = os.path.normpath(filename).lstrip("\\/")
    caminho = os.path.abspath(os.path.join(pasta, rel_limpo))
    if not caminho.startswith(pasta) or not os.path.exists(caminho):
        return erro("Arquivo do pacote Skill 6 não encontrado.", 404)
    return send_file(caminho, as_attachment=bool(request.args.get("download")))


@app.route("/api/antigravity/buscar-videos-reais-srt", methods=["POST"])
def antigravity_buscar_videos_reais_srt():
    """Passo 6 (Opção B) — Vídeo com Vídeo Real (busca nas APIs Pixabay, Unsplash, Smithsonian, Wikimedia e Pexels)."""
    d = request.json or {}
    srt_texto = (d.get("srt_texto") or "").strip()
    vid = (d.get("video_id") or "").strip()
    job_id = (d.get("job_id") or "").strip()
    if not srt_texto and job_id:
        p_srt = os.path.join(storage.DATA_DIR, "audios_dp", job_id, "srtsynctempo_editado.srt")
        if os.path.exists(p_srt):
            with open(p_srt, "r", encoding="utf-8") as f:
                srt_texto = f.read()
    if not srt_texto and vid:
        p_vid = storage.video_dir(vid)
        for cand in ("legenda_propria.srt", "legendas.srt"):
            if os.path.exists(os.path.join(p_vid, cand)):
                with open(os.path.join(p_vid, cand), "r", encoding="utf-8") as f:
                    srt_texto = f.read()
                break
    if not srt_texto:
        return erro("Carregue ou gere o arquivo .SRT do áudio (Passo 5) antes de buscar os vídeos reais.")
    try:
        res = darkplanner_sync.buscar_midias_reais_por_srt(
            srt_texto=srt_texto,
            titulo=d.get("titulo") or "",
            vid=vid,
            max_blocos_busca=int(d.get("max_blocos_busca") or 500),
            canal_id=d.get("canal_id") or d.get("channel_id") or "",
            canal_nome=d.get("canal_nome") or "",
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/verificar-sem-repeticao", methods=["POST"])
def dp_verificar_sem_repeticao():
    """Executa a auditoria e correção anti-repetição (Prioridade Vídeos .mp4 + 0% cortes repetidos no vídeo e no canal)
    com verificação multimodal Gemini 4 Carbon High antes de montar no DarkPlanner Studio."""
    import re
    d = request.json or {}
    nome_projeto = re.sub(r'[<>:"/\\|?*]', "", (d.get("titulo") or d.get("nome_projeto") or "").strip())[:60]
    if not nome_projeto:
        return erro("Informe o título do projeto para verificar e eliminar repetições.")
    slug_pasta = re.sub(r"[^\w\- ]", "", nome_projeto).strip() or "Projeto_DarkPlanner"
    base_dp_dl = darkplanner_sync.obter_pasta_downloads_darkplanner()
    pasta_proj = os.path.join(base_dp_dl, "studio", slug_pasta)
    pasta_midias = os.path.join(pasta_proj, "midias")
    srt_texto = (d.get("srt_texto") or "").strip()
    srt_dest = os.path.join(pasta_proj, f"{slug_pasta}_srtsynctempo.srt")
    if not srt_texto and os.path.exists(srt_dest):
        with open(srt_dest, "r", encoding="utf-8") as f:
            srt_texto = f.read()
    cenas_reais = []
    p_json_c = os.path.join(pasta_proj, "05_MIDIAS_REAIS_POR_CENA.json")
    if os.path.exists(p_json_c):
        try:
            with open(p_json_c, "r", encoding="utf-8") as f:
                cenas_reais = json.load(f)
        except Exception:
            cenas_reais = []
    blocos_srt = []
    if srt_texto:
        try:
            blocos_srt = darkplanner_sync.validar_srt_skill6(srt_texto)["blocos"]
        except Exception:
            blocos_srt = []
    rel = darkplanner_sync.verificar_e_corrigir_midias_sem_repeticao(
        pasta_midias=pasta_midias,
        cenas_reais=cenas_reais,
        total_cenas_esperadas=len(blocos_srt) or len(cenas_reais),
        srt_texto=srt_texto,
        titulo=nome_projeto,
        priorizar_videos=True,
        canal_id=d.get("canal_id") or d.get("channel_id") or "",
        canal_nome=d.get("canal_nome") or "",
        conferir_visual_ia=bool(d.get("conferir_visual_ia", True)),
    )
    if cenas_reais:
        try:
            with open(p_json_c, "w", encoding="utf-8") as f:
                json.dump(cenas_reais, f, indent=2, ensure_ascii=False)
        except Exception:
            pass
    try:
        with open(os.path.join(pasta_proj, "06_AUDITORIA_ANTI_REPETICAO.json"), "w", encoding="utf-8") as f:
            json.dump(rel, f, indent=2, ensure_ascii=False)
    except Exception:
        pass
    studio_res = {}
    if d.get("atualizar_studio", True):
        try:
            studio_res = darkplanner_sync.aplicar_midias_reais_no_studio_ao_vivo(
                nome_projeto=nome_projeto,
                arqs_midia_baixados=rel.get("arquivos_ordenados") or [],
                blocos_srt=blocos_srt,
                srt_destino=srt_dest,
                edicao_config=d.get("edicao_config") if isinstance(d.get("edicao_config"), dict) else {},
            )
        except Exception as e_st:
            studio_res = {"ok": False, "erro": str(e_st)}
    return jsonify({
        "ok": True,
        "titulo": nome_projeto,
        "verificacao": rel,
        "studio": studio_res,
    })


@app.route("/api/antigravity/acervo-listar", methods=["GET"])
def api_acervo_listar():
    """Lista os vídeos e imagens do 'Teu Acervo' (anexados pelo usuário) + os 12 bancos oficiais."""
    try:
        res = darkplanner_sync.listar_arquivos_teu_acervo()
        res["bancos_12"] = darkplanner_sync.BANCOS_OFICIAIS_VIDEO_REAL_12
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/antigravity/acervo-upload", methods=["POST"])
def api_acervo_upload():
    """Permite ao usuário anexar vídeos (.mp4, .mov, .webm) e fotos (.jpg, .png, .webp) ao banco 'Teu Acervo'."""
    d = request.get_json(silent=True) or {}
    arquivos = d.get("arquivos") or []
    tags_extras = (d.get("tags_extras") or "").strip()
    try:
        res = darkplanner_sync.salvar_arquivos_teu_acervo(arquivos=arquivos, tags_extras=tags_extras)
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/antigravity/acervo-remover", methods=["POST"])
def api_acervo_remover():
    """Remove um arquivo anexado do 'Teu Acervo'."""
    d = request.get_json(silent=True) or {}
    nome = (d.get("nome") or "").strip()
    try:
        res = darkplanner_sync.remover_arquivo_teu_acervo(nome)
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/projetos-criados", methods=["GET"])
def api_listar_projetos_criados():
    """Lista todos os vídeos e projetos criados (Studio, Creator, Matriz e Banco Local) para o usuário ver, editar e refazer."""
    try:
        return jsonify(darkplanner_sync.listar_videos_e_projetos_criados())
    except Exception as e:
        return erro(str(e))


@app.route("/api/projetos-criados/detalhe", methods=["GET", "POST"])
def api_detalhe_projeto_criado():
    """Retorna todos os dados de um vídeo/projeto criado (roteiro, SRT, cenas, cortes .mp4 e pacote viral) para editar ou refazer."""
    d = (request.json or {}) if request.method == "POST" else request.args
    try:
        res = darkplanner_sync.obter_detalhe_video_projeto_criado(
            titulo=d.get("titulo") or "",
            vid=d.get("vid") or "",
            slug=d.get("slug") or "",
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/projetos-criados/midia-arquivo")
def api_midia_arquivo_projeto_criado():
    """Serve o vídeo (.mp4), foto (.jpg) ou áudio (.mp3) de um projeto criado para pré-visualização no navegador."""
    pasta_arg = (request.args.get("pasta") or "").strip()
    arquivo_arg = (request.args.get("arquivo") or request.args.get("arq") or "").strip()
    titulo = (request.args.get("titulo") or "").strip()
    slug = (request.args.get("slug") or "").strip()
    sub = (request.args.get("sub") or "").strip()

    try:
        pasta = pasta_arg
        if not pasta or not os.path.isdir(pasta):
            det = darkplanner_sync.obter_detalhe_video_projeto_criado(titulo=titulo, slug=slug)
            pasta = (det.get("projeto") or {}).get("pasta_projeto") or ""
        if not pasta or not os.path.isdir(pasta):
            return erro("Pasta do projeto não encontrada", 404)

        rel = arquivo_arg.replace("\\", "/").lstrip("/")
        if ".." in rel:
            return erro("Caminho inválido", 400)
        caminho = os.path.join(pasta, sub, rel) if sub else os.path.join(pasta, rel)
        if not os.path.exists(caminho):
            caminho = os.path.join(pasta, "midias", os.path.basename(rel))
        if not os.path.exists(caminho):
            caminho = os.path.join(pasta, os.path.basename(rel))
        if not os.path.exists(caminho):
            return erro("Mídia não encontrada no disco", 404)
        return send_from_directory(os.path.dirname(caminho), os.path.basename(caminho))
    except Exception as e:
        return erro(str(e), 404)


@app.route("/api/projetos-criados/trocar-corte-cena", methods=["POST"])
def api_trocar_corte_cena():
    """Substitui o vídeo (.mp4) de uma cena específica por outro vídeo .mp4 inédito sem repetição."""
    d = request.json or {}
    try:
        res = darkplanner_sync.trocar_corte_cena_projeto(
            titulo=d.get("titulo") or "",
            scene_index=int(d.get("scene_index") or 1),
            termo_busca=d.get("termo_busca") or "",
            url_direta=d.get("url_direta") or "",
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/projetos-criados/salvar-edicao", methods=["POST"])
def api_salvar_edicao_projeto_criado():
    """Salva edições manuais de roteiro, SRT ou descrição viral de um vídeo criado para permitir refazer/remontar."""
    d = request.json or {}
    titulo = (d.get("titulo") or "").strip()
    vid = (d.get("vid") or "").strip()
    roteiro = d.get("roteiro")
    srt_texto = d.get("srt_texto")
    descricao_viral = d.get("descricao_viral")
    try:
        det = darkplanner_sync.obter_detalhe_video_projeto_criado(titulo=titulo, vid=vid)
        proj = det.get("projeto") or {}
        pasta = d.get("pasta") or proj.get("pasta_projeto") or ""
        slug = proj.get("slug") or ""
        if pasta and os.path.isdir(pasta):
            if roteiro is not None:
                with open(os.path.join(pasta, "00_ROTEIRO_LIMPO.txt"), "w", encoding="utf-8") as f:
                    f.write(str(roteiro).strip())
            if srt_texto is not None and str(srt_texto).strip():
                fn_srt = f"{slug}_srtsynctempo.srt" if slug else "legenda_propria.srt"
                for ex_f in os.listdir(pasta):
                    if ex_f.lower().endswith(".srt"):
                        fn_srt = ex_f
                        break
                with open(os.path.join(pasta, fn_srt), "w", encoding="utf-8") as f:
                    f.write(str(srt_texto).strip())
            if descricao_viral is not None and str(descricao_viral).strip():
                with open(os.path.join(pasta, "05_DESCRICAO_TAGS_THUMB_VIRAL.txt"), "w", encoding="utf-8") as f:
                    f.write(str(descricao_viral).strip())
        vid_real = vid or proj.get("vid") or ""
        if vid_real:
            with Tx() as db:
                v = find(db["videos"], vid_real)
                if v:
                    if roteiro is not None:
                        v["roteiro"] = str(roteiro).strip()
                    if srt_texto is not None and str(srt_texto).strip():
                        v["srt_custom"] = str(srt_texto).strip()
        return jsonify({"ok": True, "msg": "Edições de roteiro/SRT/descrição salvas no projeto!"})
    except Exception as e:
        return erro(str(e))


@app.route("/api/projetos-criados/abrir-pasta", methods=["POST"])
def api_abrir_pasta_projeto_criado():
    """Abre a pasta do projeto criado diretamente no Windows Explorer (ou retorna URL de download .ZIP no Modo Remoto)."""
    from urllib.parse import urlencode

    d = request.json or {}
    try:
        pasta = (d.get("pasta") or "").strip()
        titulo = (d.get("titulo") or "").strip()
        vid = (d.get("vid") or "").strip()
        slug = (d.get("slug") or "").strip()
        if not pasta or not os.path.isdir(pasta):
            det = darkplanner_sync.obter_detalhe_video_projeto_criado(
                titulo=titulo,
                vid=vid,
                slug=slug,
            )
            pasta = (det.get("projeto") or {}).get("pasta_projeto") or det.get("pasta") or ""
        if pasta and os.path.isdir(pasta) and os.name == "nt":
            os.startfile(pasta)  # type: ignore[attr-defined]
            return jsonify({"ok": True, "pasta": pasta})
        if os.name != "nt" and (pasta or titulo or vid or slug):
            qs = urlencode({k: v for k, v in (("pasta", pasta), ("titulo", titulo), ("vid", vid), ("slug", slug)) if v})
            return jsonify({
                "ok": True,
                "modo_remoto": True,
                "pasta": pasta,
                "download_zip_url": f"/api/projetos-criados/baixar-zip?{qs}",
            })
        return erro("Pasta não encontrada.")
    except Exception as e:
        return erro(str(e))


@app.route("/api/projetos-criados/baixar-zip", methods=["GET", "POST"])
def api_baixar_zip_projeto_criado():
    """Empacota e baixa um .ZIP completo com todos os arquivos gerados do projeto (MP3, SRT, Roteiro, Thumbnail, Prompts Flow e Referências)."""
    import io
    import zipfile

    d = (request.get_json(silent=True) or {}) if request.method == "POST" else request.args
    pasta = (d.get("pasta") or "").strip()
    titulo = (d.get("titulo") or "").strip()
    vid = (d.get("vid") or "").strip()
    slug = (d.get("slug") or "").strip()
    job_id = (d.get("job_id") or "").strip()
    skill6_slug = (d.get("skill6_slug") or "").strip()
    roteiro_mem = (d.get("roteiro") or "").strip()
    srt_mem = (d.get("srt_texto") or "").strip()

    pastas_fontes = []
    if pasta and os.path.isdir(pasta):
        pastas_fontes.append(("", pasta))
    if not pastas_fontes and (titulo or vid or slug):
        try:
            det = darkplanner_sync.obter_detalhe_video_projeto_criado(titulo=titulo, vid=vid, slug=slug)
            p_det = (det.get("projeto") or {}).get("pasta_projeto") or det.get("pasta") or ""
            if p_det and os.path.isdir(p_det):
                pastas_fontes.append(("", p_det))
            if not titulo and det.get("titulo"):
                titulo = str(det.get("titulo"))
            if not vid and det.get("vid"):
                vid = str(det.get("vid"))
            if not roteiro_mem and det.get("roteiro"):
                roteiro_mem = str(det.get("roteiro"))
            if not srt_mem and det.get("srt_texto"):
                srt_mem = str(det.get("srt_texto"))
        except Exception:
            pass

    if vid:
        p_vid = storage.video_dir(vid)
        if os.path.isdir(p_vid):
            pastas_fontes.append(("video_estudio", p_vid))

    if job_id:
        p_job = os.path.join(BASE, "data", "audiogen", re.sub(r"[^a-zA-Z0-9_\-]", "", job_id))
        if os.path.isdir(p_job):
            pastas_fontes.append(("audio_srt", p_job))

    if skill6_slug:
        p_s6 = os.path.join(BASE, "data", "skill6_pacotes", re.sub(r"[^a-zA-Z0-9_\-]", "", skill6_slug))
        if os.path.isdir(p_s6):
            pastas_fontes.append(("prompts_flow", p_s6))

    base_nome = re.sub(r"[^\w\- ]+", "", titulo or slug or vid or "Projeto_FabricaDark").strip().replace(" ", "_")[:65] or "Projeto_FabricaDark"
    mem = io.BytesIO()
    adicionados = set()

    with zipfile.ZipFile(mem, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for prefixo, dir_src in pastas_fontes:
            for root_d, dirs_d, files_d in os.walk(dir_src):
                dirs_d[:] = [dr for dr in sorted(dirs_d) if dr not in ("__pycache__", ".git")]
                for fn in sorted(files_d):
                    if fn.endswith((".pyc", ".lock", ".part", ".tmp")):
                        continue
                    full_f = os.path.join(root_d, fn)
                    rel_f = os.path.relpath(full_f, dir_src).replace("\\", "/")
                    arc_name = f"{base_nome}/{prefixo + '/' if prefixo else ''}{rel_f}"
                    if arc_name in adicionados:
                        continue
                    try:
                        zf.write(full_f, arc_name)
                        adicionados.add(arc_name)
                    except Exception:
                        pass

        tem_roteiro = any(a.lower().endswith(("roteiro.txt", "roteiro_narracao.txt", "00_roteiro_narracao.txt")) for a in adicionados)
        if roteiro_mem and not tem_roteiro:
            arc_rot = f"{base_nome}/00_ROTEIRO_NARRACAO.txt"
            zf.writestr(arc_rot, roteiro_mem.encode("utf-8"))
            adicionados.add(arc_rot)

        tem_srt = any(a.lower().endswith(".srt") for a in adicionados)
        if srt_mem and not tem_srt:
            arc_srt = f"{base_nome}/{base_nome}_srtsynctempo_editado.srt"
            zf.writestr(arc_srt, srt_mem.encode("utf-8"))
            adicionados.add(arc_srt)

    if not adicionados:
        return erro("Ainda não há arquivos gerados neste projeto para baixar. Execute pelo menos um passo primeiro!", 404)

    mem.seek(0)
    return send_file(
        mem,
        mimetype="application/zip",
        as_attachment=True,
        download_name=f"{base_nome}_PROJETO_COMPLETO.zip",
    )


@app.route("/api/antigravity/prompt-video-real-v8", methods=["GET", "POST"])
def antigravity_prompt_video_real_v8():
    """Retorna ou salva o Master Video Generator Prompt V8.0 (Distribuição Grandes Canais Documentais + Instruções Personalizadas)."""
    d = (request.json or {}) if request.method == "POST" else request.args
    canal_id = (d.get("canal_id") or d.get("channel_id") or "").strip()
    titulo = (d.get("titulo") or "").strip()
    instrucoes_custom = (d.get("instrucoes_edicao_custom") or d.get("instrucoes_custom") or "").strip()
    db = storage.load()
    ch = find(db["channels"], canal_id) if canal_id else {}
    ch = ch or {}
    canal_nome = d.get("canal_nome") or ch.get("nome") or "STORMSCOPE REPORT"
    idioma = ch.get("idioma") or "en"
    nicho = ch.get("nicho") or ch.get("subnicho") or ""
    prompt_txt = darkplanner_sync.gerar_prompt_mestre_video_real_universal(
        canal_nome=canal_nome,
        titulo=titulo,
        idioma=idioma,
        nicho=nicho,
        instrucoes_edicao_custom=instrucoes_custom,
    )
    salvo_dp = None
    if request.method == "POST" and d.get("salvar_no_canal") and canal_id:
        try:
            nome_pm = d.get("nome_prompt") or f"MASTER VIDEO GENERATOR V8.0 — VIDEO REAL ({canal_nome.upper()})"
            salvo_dp = darkplanner_sync.salvar_prompt_dp(
                canal_id=canal_id,
                nome=nome_pm,
                categoria="EDICAO VIDEO REAL",
                conteudo=prompt_txt,
            )
        except Exception as e:
            return erro(str(e))
    return jsonify({
        "ok": True,
        "canal_id": canal_id,
        "canal_nome": canal_nome,
        "prompt": prompt_txt,
        "salvo_dp": salvo_dp,
    })


@app.route("/api/darkplanner/aplicar-edicao-studio", methods=["POST"])
def dp_aplicar_edicao_studio():
    """Aplica ao vivo no projeto aberto do DarkPlanner Studio a distribuição de edição dos Grandes Canais + preferências personalizadas."""
    d = request.json or {}
    nome_projeto = (d.get("titulo") or d.get("nome_projeto") or "").strip()
    edicao_config = d.get("edicao_config") if isinstance(d.get("edicao_config"), dict) else {}
    if not nome_projeto:
        return erro("Informe o título/nome do projeto do Studio.")
    try:
        res = darkplanner_sync.aplicar_midias_reais_no_studio_ao_vivo(
            nome_projeto=nome_projeto,
            arqs_midia_baixados=[],
            blocos_srt=None,
            edicao_config=edicao_config,
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/studio-aplicar-midias-reais", methods=["POST"])
def dp_studio_aplicar_midias_reais():
    """Verifica hashes MD5 (0 repetição), atualiza textos se enviados e remonta/sincroniza mídias reais no DarkPlanner Studio."""
    d = request.get_json(silent=True) or {}
    nome_projeto = (d.get("titulo") or d.get("nome_projeto") or "").strip()
    if not nome_projeto:
        return erro("Informe o título do projeto.")
    try:
        det = darkplanner_sync.obter_detalhe_video_projeto_criado(titulo=nome_projeto)
        proj = det.get("projeto") or {}
        pasta_proj = proj.get("pasta_projeto") or ""
        if not pasta_proj or not os.path.isdir(pasta_proj):
            slug_p = re.sub(r"[^\w\- ]", "", nome_projeto).strip() or "Projeto_DarkPlanner"
            pasta_proj = os.path.join(os.path.expanduser("~"), "Downloads", "DarkPlanner", "studio", slug_p)
            os.makedirs(os.path.join(pasta_proj, "midias"), exist_ok=True)
        pasta_midias = os.path.join(pasta_proj, "midias")
        os.makedirs(pasta_midias, exist_ok=True)

        srt_texto = (d.get("srt_texto") or det.get("srt_texto") or "").strip()
        roteiro_txt = (d.get("roteiro") or "").strip()
        slug_s = re.sub(r"[^\w\- ]", "", nome_projeto).strip() or "Projeto_DarkPlanner"
        srt_dest = os.path.join(pasta_proj, f"{slug_s}_srtsynctempo.srt")
        if srt_texto:
            with open(srt_dest, "w", encoding="utf-8") as fs:
                fs.write(srt_texto)
        if roteiro_txt:
            with open(os.path.join(pasta_proj, "00_ROTEIRO_LIMPO.txt"), "w", encoding="utf-8") as fr:
                fr.write(roteiro_txt)

        blocos_srt = []
        if srt_texto:
            try:
                blocos_srt = darkplanner_sync.validar_srt_skill6(srt_texto)["blocos"]
            except Exception:
                blocos_srt = []

        cenas_reais = det.get("cenas") or []
        cid_st = d.get("canal_id") or d.get("channel_id") or proj.get("canal_id") or ""
        cnm_st = d.get("canal_nome") or proj.get("canal_nome") or "Canal"
        if d.get("forcar_redownload") and srt_texto:
            res_mr = darkplanner_sync.buscar_midias_reais_por_srt(
                srt_texto=srt_texto,
                titulo=nome_projeto,
                max_blocos_busca=max(500, len(blocos_srt) + 20),
                canal_id=cid_st,
                canal_nome=cnm_st,
            )
            cenas_reais = res_mr.get("cenas") or cenas_reais

        verif = darkplanner_sync.verificar_e_corrigir_midias_sem_repeticao(
            pasta_midias=pasta_midias,
            cenas_reais=cenas_reais,
            total_cenas_esperadas=len(blocos_srt) or len(cenas_reais),
            srt_texto=srt_texto,
            titulo=nome_projeto,
            priorizar_videos=True,
            canal_id=cid_st,
            canal_nome=cnm_st,
            conferir_visual_ia=bool(d.get("conferir_visual_ia", True)),
        )
        predef_in = (d.get("predefinicao_templates") or "sys_tudo").strip()
        if predef_in == "grandes_canais":
            predef_in = "sys_tudo"
        ed_cfg = d.get("edicao_config") if isinstance(d.get("edicao_config"), dict) else {"predef": predef_in}
        if d.get("instrucao_usuario"):
            ed_cfg["instrucoes_custom"] = str(d.get("instrucao_usuario")).strip()

        arqs_ord = verif.get("arquivos_ordenados") or []
        res_st = darkplanner_sync.aplicar_midias_reais_no_studio_ao_vivo(
            nome_projeto=nome_projeto,
            arqs_midia_baixados=arqs_ord,
            blocos_srt=blocos_srt,
            canal_nome=cnm_st,
            srt_destino=srt_dest if os.path.exists(srt_dest) else "",
            edicao_config=ed_cfg,
            pular_auditoria=True,
        ) or {}

        aud_out = {
            "videos_mp4": verif.get("total_videos_mp4", 0),
            "arquivos_unicos_hash": verif.get("arquivos_unicos_md5", 0),
            "duplicados_substituidos": verif.get("repeticoes_detectadas_e_substituidas", 0),
            "repeticoes_canal_substituidas": verif.get("repeticoes_canal_substituidas", 0),
            "repeticoes_restantes": verif.get("repeticoes_restantes", 0),
        }
        cenas_sync = int(res_st.get("cenas_no_studio") or len(arqs_ord) or len(blocos_srt))
        tmpl_ap = int(res_st.get("templates_aplicados") or 0)
        return jsonify({
            "ok": True,
            "studio_conectado": bool(res_st.get("ok")),
            "aviso_studio": "" if res_st.get("ok") else (res_st.get("motivo") or res_st.get("erro") or ""),
            "cenas_sincronizadas": cenas_sync,
            "videos_mp4": verif.get("total_videos_mp4", 0),
            "templates_aplicados": tmpl_ap,
            "pct_templates_real": round((tmpl_ap / max(1, cenas_sync)) * 100, 1) if tmpl_ap else 0,
            "cortes_puros": max(0, cenas_sync - tmpl_ap),
            "auditoria_anti_repeticao": aud_out,
            "verificacao": verif,
        })
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/criar-projeto-studio", methods=["POST"])
@app.route("/api/darkplanner/criar-projeto-desktop", methods=["POST"])
def dp_criar_projeto_studio():
    """Passo 7 — Cria o projeto no DarkPlanner Desktop (API 7812 ou direto no Studio se vídeo real) com o nome do título do vídeo, abre o Chat (Foto 4) e envia tudo lá automaticamente."""
    d = request.json or {}
    pct_s6 = d.get("pacote_skill6") if isinstance(d.get("pacote_skill6"), dict) else {}
    edicao_cfg = d.get("edicao_config") if isinstance(d.get("edicao_config"), dict) else {}
    try:
        res = darkplanner_sync.criar_projeto_darkplanner_desktop(
            titulo=d.get("titulo") or "Novo Projeto DarkPlanner",
            canal_id=d.get("canal_id") or d.get("channel_id") or "",
            vid=d.get("video_id") or d.get("vid") or "",
            job_id=d.get("job_id") or "",
            roteiro=d.get("roteiro") or "",
            srt_texto=d.get("srt_texto") or "",
            skill_modo=d.get("skill_modo") or "skill6",
            skill6_slug=d.get("skill6_slug") or pct_s6.get("slug") or "",
            midias_reais=d.get("midias_reais") if isinstance(d.get("midias_reais"), dict) else None,
            abrir_exe=bool(d.get("abrir_exe", True)),
            abrir_chat=bool(d.get("abrir_chat", True)),
            auto_enviar_chat=bool(d.get("auto_enviar_chat", True)),
            enviar_jobs_direto=bool(d.get("enviar_jobs_direto", False)),
            edicao_config=edicao_cfg,
            instrucoes_edicao_custom=(d.get("instrucoes_edicao_custom") or edicao_cfg.get("instrucoes_custom") or "").strip(),
            chat_modelo_opcao=(d.get("chat_modelo_opcao") or edicao_cfg.get("chat_modelo_opcao") or "flash_high").strip(),
        )
        if d.get("abrir_pasta") and res.get("pasta_creator") and os.name == "nt":
            try:
                os.startfile(res["pasta_creator"])  # type: ignore[attr-defined]
            except Exception:
                pass
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/desktop-api/status")
def dp_desktop_api_status():
    """Retorna o status ao vivo da API Local do DarkPlanner Desktop (http://127.0.0.1:7812 · Foto 5)."""
    return jsonify(darkplanner_sync.dp_desktop_status_completo())


@app.route("/api/darkplanner/status-etapa7", methods=["GET", "POST"])
def api_darkplanner_status_etapa7():
    """Retorna ou atualiza o status ao vivo da Etapa 7 executando em 2º plano no DarkPlanner Desktop."""
    d = request.get_json(silent=True) or request.args or {}
    sp_id = (d.get("sp_id") or d.get("projeto_id") or "").strip()
    cp_id = (d.get("creator_project_id") or "").strip()
    nome_p = (d.get("nome_projeto") or d.get("titulo") or "").strip()
    if request.method == "POST":
        acao_st = str(d.get("acao") or "").strip().lower()
        if acao_st == "concluir":
            return jsonify(darkplanner_sync.concluir_etapa7_dp_manual(sp_id=sp_id, creator_project_id=cp_id, nome_projeto=nome_p))
        if acao_st in ("pausar", "parar", "cancelar"):
            return jsonify(
                darkplanner_sync.pausar_processo_etapa7_dp(
                    sp_id=sp_id,
                    creator_project_id=cp_id,
                    nome_projeto=nome_p,
                    pausar_chat_dp=bool(d.get("pausar_chat_dp", True)),
                )
            )
    return jsonify(darkplanner_sync.obter_status_etapa7_dp(sp_id=sp_id, creator_project_id=cp_id, nome_projeto=nome_p))


@app.route("/api/antigravity/fila-etapa7-nuvem", methods=["GET", "POST"])
def api_antigravity_fila_etapa7_nuvem():
    """Inspeciona ou força o processamento da fila vinculada Remoto <-> PC Windows (__ANTIGRAVITY_ETAPA7_QUEUE__)."""
    if request.method == "POST":
        d = request.get_json(silent=True) or {}
        if d.get("acao") == "processar_agora":
            return jsonify(darkplanner_sync.processar_fila_etapa7_nuvem_no_pc(forcar=True))
    return jsonify(darkplanner_sync.listar_fila_etapa7_nuvem())


@app.route("/api/chat-operacional/executar", methods=["POST"])
def api_chat_operacional_executar():
    """Executa comandos interativos enviados pelo usuário no Chat Operacional do aplicativo (#fd-dp-live-drawer):
    auditoria real do Studio/CDP, criação de conversa no DarkPlanner Desktop, regularização GTA/Rockstar s/ copyright (FR) e reaplicação de edição."""
    d = request.get_json(silent=True) or {}
    try:
        return jsonify(darkplanner_sync.executar_comando_chat_operacional(d))
    except Exception as e:
        return erro(str(e))


@app.route("/api/chat-operacional/pausar", methods=["POST"])
def api_chat_operacional_pausar():
    """Pausa imediatamente a conversa e qualquer execução em 2º plano na Etapa 7 / Chat Operacional,
    SEM NUNCA fechar o DarkPlanner Desktop (`Dark Planner.exe`)."""
    d = request.get_json(silent=True) or {}
    try:
        return jsonify(
            darkplanner_sync.pausar_processo_etapa7_dp(
                sp_id=(d.get("sp_id") or d.get("projeto_id") or "").strip(),
                creator_project_id=(d.get("creator_project_id") or "").strip(),
                nome_projeto=(d.get("nome_projeto") or d.get("titulo") or "").strip(),
                pausar_chat_dp=bool(d.get("pausar_chat_dp", False)),
            )
        )
    except Exception as e:
        return erro(str(e))


# ==============================================================================
# ROTAS DO CLONADOR FORENSE DE VÍDEOS DO YOUTUBE (FRAME A FRAME + BGM + SFX + VOZES)
# ==============================================================================

@app.route("/api/youtube-cloner/analisar", methods=["POST"])
def api_youtube_cloner_analisar():
    d = request.json or {}
    yt_url = (d.get("youtube_url") or d.get("url") or "").strip()
    if not yt_url:
        return erro("Cole o link do vídeo do YouTube para analisar frame a frame.")
    try:
        res = darkplanner_sync.analisar_video_youtube_frame_a_frame(
            youtube_url=yt_url,
            canal_id=(d.get("canal_id") or d.get("channel_id") or "").strip(),
            instrucoes_extras=(d.get("instrucoes") or "").strip(),
            qtd_frames=int(d.get("qtd_frames") or 8),
            forcar_nova_analise=bool(d.get("forcar", False)),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/youtube-cloner/historico")
def api_youtube_cloner_historico():
    try:
        itens = darkplanner_sync.listar_historico_youtube_cloner(limit=request.args.get("limit", 25))
        return jsonify({"ok": True, "itens": itens})
    except Exception as e:
        return erro(str(e))


@app.route("/api/youtube-cloner/detalhe/<yt_id>")
def api_youtube_cloner_detalhe(yt_id):
    try:
        d = darkplanner_sync.obter_analise_youtube_cloner(yt_id)
        return jsonify(d)
    except Exception as e:
        return erro(str(e), 404)


@app.route("/api/youtube-cloner/frame/<yt_id>/<path:filename>")
def api_youtube_cloner_frame(yt_id, filename):
    yt_clean = darkplanner_sync.extrair_id_youtube(yt_id)
    fn_clean = os.path.basename(filename)
    caminho = os.path.join(storage.DATA_DIR, "youtube_cloner", yt_clean, "frames", fn_clean)
    if not os.path.isfile(caminho):
        return erro("Frame não encontrado.", 404)
    return send_file(caminho, mimetype="image/jpeg")


@app.route("/api/youtube-cloner/audio/<yt_id>")
def api_youtube_cloner_audio(yt_id):
    yt_clean = darkplanner_sync.extrair_id_youtube(yt_id)
    caminho = os.path.join(storage.DATA_DIR, "youtube_cloner", yt_clean, "audio_sample.mp3")
    if not os.path.isfile(caminho):
        return erro("Amostra de áudio não encontrada.", 404)
    return send_file(caminho, mimetype="audio/mpeg")


@app.route("/api/youtube-cloner/aplicar", methods=["POST"])
def api_youtube_cloner_aplicar():
    d = request.json or {}
    yt_id = (d.get("yt_id") or d.get("youtube_url") or "").strip()
    if not yt_id:
        return erro("Informe o vídeo analisado para aplicar.")
    try:
        res = darkplanner_sync.aplicar_clone_youtube_no_canal_ou_video(
            yt_id=yt_id,
            canal_id=(d.get("canal_id") or d.get("channel_id") or "").strip(),
            vid=(d.get("vid") or d.get("video_id") or "").strip(),
            salvar_no_canal=bool(d.get("salvar_no_canal", True)),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/darkplanner/desktop-api/proxy", methods=["POST"])
def dp_desktop_api_proxy():
    """Chama qualquer rota documentada da API do App Desktop DarkPlanner (http://127.0.0.1:7812 c/ auto-autenticação e fallback local)."""
    d = request.json or {}
    metodo = (d.get("method") or "GET").upper().strip()
    caminho = (d.get("path") or "/api/projects").strip()
    corpo = d.get("body")
    form_data = d.get("form_data")
    file_path = d.get("file_path")
    try:
        res = darkplanner_sync.dp_desktop_req(
            metodo,
            caminho,
            json_data=corpo,
            form_data=form_data,
            file_path=file_path,
            timeout=20,
        )
        return jsonify({"ok": True, "method": metodo, "path": caminho, "data": res})
    except Exception:
        res_fb = darkplanner_sync._fallback_dp_desktop_local(metodo, caminho, json_data=corpo, form_data=form_data)
        return jsonify({"ok": True, "method": metodo, "path": caminho, "data": res_fb})


@app.route("/api/darkplanner/desktop-api/enviar-chat", methods=["POST"])
def dp_desktop_enviar_chat():
    """Abre o Chat do DarkPlanner Desktop (Foto 4), cola a mensagem completa lá dentro e envia automaticamente."""
    d = request.json or {}
    msg = (d.get("mensagem") or "").strip()
    if not msg:
        return erro("Mensagem vazia para enviar ao Chat do DarkPlanner.")
    res = darkplanner_sync.abrir_chat_darkplanner_e_colar(
        msg,
        auto_enviar=bool(d.get("auto_enviar", True)),
        nova_conversa=bool(d.get("nova_conversa", True)),
        chat_modelo_opcao=(d.get("chat_modelo_opcao") or "flash_high").strip(),
        forcar_reenvio=bool(d.get("forcar_reenvio", True)),
    )
    return jsonify(res)


@app.route("/api/chaves/<prov>", methods=["POST"])
def chave_add(prov):
    if prov not in PROVS_CHAVE:
        return erro("Provedor inválido", 404)
    d = request.json or {}
    try:
        item = chaves.adicionar(prov, d.get("key", ""), tipo=d.get("tipo") or ("gratuita" if prov == "gemini" else None), regiao=d.get("regiao"))
    except ValueError as e:
        return erro(str(e))
    ok, msg = _testar(prov, item["id"])
    return jsonify({"ok": ok, "msg": msg, "item": chaves.publico(chaves.pegar(prov, item["id"]))})


@app.route("/api/chaves/<prov>/<kid>", methods=["PATCH", "DELETE"])
def chave_item(prov, kid):
    if request.method == "DELETE":
        chaves.remover(prov, kid)
        return jsonify({"ok": True})
    d = request.json or {}
    campos = {k: d[k] for k in ("tipo", "regiao", "apelido") if k in d}
    if d.get("key"):
        campos.update(key=d["key"].strip(), status="nao_testada")
    item = chaves.atualizar(prov, kid, **campos)
    if d.get("key"):
        _testar(prov, kid)
        item = chaves.publico(chaves.pegar(prov, kid))
    return jsonify(item or {})


@app.route("/api/chaves/<prov>/<kid>/testar", methods=["POST"])
def chave_testar(prov, kid):
    ok, msg = _testar(prov, kid)
    return jsonify({"ok": ok, "msg": msg, "item": chaves.publico(chaves.pegar(prov, kid))})


@app.route("/api/vozes/<prov>")
def vozes_prov(prov):
    db = storage.load()
    try:
        if prov == "edge":
            return jsonify(voz.VOZES_EDGE)
        if prov == "gemini":
            return jsonify({"todas": voz.VOZES_GEMINI})
        conta = next(iter(chaves.lista(db, prov)), None)
        if prov == "darkplanner":
            return jsonify({"todas": voz.darkplanner_vozes((conta or {}).get("key", ""))})
        if not conta:
            return erro(f"Conecte uma conta de {voz.PROVEDORES[prov]['nome']} em Conexões.")
        if prov == "azure":
            try:
                return jsonify({"todas": voz.vozes_azure(conta["key"], conta.get("regiao") or "brazilsouth")})
            except Exception:
                # sem acesso à lista agora: as vozes do Azure têm os mesmos nomes das do Edge
                return jsonify({"todas": [v for lst in voz.VOZES_EDGE.values() for v in lst], "aviso": "lista padrão"})
        if prov == "elevenlabs":
            return jsonify({"todas": voz.vozes_eleven(conta["key"])})
        if prov == "fish":
            r = __import__("requests").get("https://api.fish.audio/model", params={"self": "true", "page_size": 50},
                                            headers={"Authorization": f"Bearer {conta['key']}"}, timeout=20)
            itens = r.json().get("items", []) if r.ok else []
            return jsonify({"todas": [(m["_id"], m.get("title", m["_id"])) for m in itens]})
    except Exception as e:
        return erro(str(e)[:200])
    return erro("Provedor inválido", 404)


@app.route("/api/consumo")
def consumo():
    db = storage.load()
    c = db.get("consumo", {})
    return jsonify({
        "tts": c.get("tts", {}), "gemini": c.get("gemini", {}), "claude": c.get("claude", {}), "youtube": c.get("youtube", {}),
        "chaves": {p: [chaves.publico(x) for x in chaves.lista(db, p)] for p in PROVS_CHAVE},
        "videos": [{"id": v["id"], "titulo": v["titulo"], "custo_ia_brl": v.get("custo_ia_brl", 0), "chamadas_ia": v.get("chamadas_ia", 0)}
                   for v in db["videos"] if v.get("custo_ia_brl") or v.get("chamadas_ia")],
        "dia_cota": chaves.dia_cota(),
    })


# =====================================================================
# Oficina do roteiro: notas, Melhorar, conversa com o roteirista
# =====================================================================
OFICINA_JOBS = {}


def _of_estado(v):
    of = v.get("oficina") or {}
    j = OFICINA_JOBS.get(v["id"]) or {}
    return {"avaliacao": of.get("avaliacao"), "chat": of.get("chat", [])[-40:], "versoes": [{"quando": x["quando"], "motivo": x["motivo"],
            "palavras": len(x["texto"].split())} for x in of.get("versoes", [])], "roteiro": v.get("roteiro", ""),
            "tem_narracao": bool(v.get("narracao")), "tem_cenas": bool(v.get("cenas")), "job": {k: j.get(k) for k in ("rodando", "etapa", "erro")},
            "criterios": [{"id": k, "nome": n, "desc": d} for k, n, d in oficina.CRITERIOS]}


def _of_salvar_roteiro(db, v, novo, motivo):
    of = v.setdefault("oficina", {})
    vers = of.setdefault("versoes", [])
    vers.append({"quando": storage.now(), "motivo": motivo, "texto": v.get("roteiro", "")})
    of["versoes"] = vers[-12:]
    v["roteiro"] = novo
    v["etapas"]["roteiro"] = True
    if v.get("narracao_origem") != "upload":  # texto mudou: cenas e narração antigas não batem mais
        v["cenas"], v["blocos_voz"] = [], []
        if v.get("narracao"):
            v["narracao"], v["narracao_duracao"] = "", None
    threading.Thread(target=darkplanner_sync.salvar_roteiro_dp, args=(v.get("channel_id"), v["id"], novo), daemon=True).start()


@app.route("/api/videos/<vid>/oficina", methods=["GET"])
def oficina_ver(vid):
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    return jsonify(_of_estado(v))


@app.route("/api/videos/<vid>/oficina/<acao>", methods=["POST"])
def oficina_acao(vid, acao):
    d = request.json or {}
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    ch = find(db["channels"], v.get("channel_id")) or {}
    if acao == "salvar":
        t = (d.get("texto") or "").strip()
        if len(t.split()) < 30:
            return erro("O roteiro parece curto demais.")
        with Tx() as db2:
            v2, _ = _video_ctx(db2, vid)
            if t != v2.get("roteiro"):
                _of_salvar_roteiro(db2, v2, t, "editado à mão")
            return jsonify(_of_estado(v2))
    if len((v.get("roteiro") or "").split()) < 30:
        return erro("Escreva ou gere o roteiro primeiro.")
    if not claude.tem_ia():
        return erro("Precisa do Claude ou de uma chave do Gemini (Conexões).")
    if acao == "avaliar":
        try:
            a = oficina.avaliar(v, ch)
        except Exception as e:
            return erro(str(e))
        a["quando"] = storage.now()
        with Tx() as db2:
            v2, _ = _video_ctx(db2, vid)
            v2.setdefault("oficina", {})["avaliacao"] = a
            return jsonify(_of_estado(v2))
    if acao == "chat":
        msg = (d.get("mensagem") or "").strip()
        if not msg:
            return erro("Escreva o que quer mudar.")
        try:
            r = oficina.conversar(v, ch, msg, (v.get("oficina") or {}).get("chat"))
        except Exception as e:
            return erro(str(e))
        with Tx() as db2:
            v2, _ = _video_ctx(db2, vid)
            chat = v2.setdefault("oficina", {}).setdefault("chat", [])
            chat.append({"de": "eu", "texto": msg, "quando": storage.now()})
            resp = r["resposta"] or "Pronto."
            if r["alteracoes"]:
                _of_salvar_roteiro(db2, v2, oficina.aplicar(v2["roteiro"], r["alteracoes"]), f"conversa: {msg[:60]}")
                resp += f" ({len(r['alteracoes'])} alteração(ões) aplicada(s) — dá para desfazer)"
            elif r["pedidas"]:
                resp += " (não consegui localizar os trechos no texto; peça de novo com outras palavras)"
            chat.append({"de": "ia", "texto": resp, "quando": storage.now(), "alteracoes": r["alteracoes"][:6]})
            v2["oficina"]["chat"] = chat[-60:]
            return jsonify(_of_estado(v2))
    if acao == "desfazer":
        with Tx() as db2:
            v2, _ = _video_ctx(db2, vid)
            vers = (v2.get("oficina") or {}).get("versoes") or []
            if not vers:
                return erro("Não há versão anterior.")
            ant = vers.pop()
            v2["roteiro"] = ant["texto"]
            return jsonify(_of_estado(v2))
    if acao == "melhorar":
        if (OFICINA_JOBS.get(vid) or {}).get("rodando"):
            return erro("Já está melhorando este roteiro.")
        job = OFICINA_JOBS[vid] = {"rodando": True, "etapa": "Começando", "erro": ""}
        aval = (v.get("oficina") or {}).get("avaliacao")

        def tarefa():
            try:
                novo = oficina.melhorar(v, ch, aval, d.get("pedido", ""), lambda k, n: job.update(etapa=f"Reescrevendo parte {k + 1} de {n}"))
                with Tx() as db2:
                    v2, _ = _video_ctx(db2, vid)
                    _of_salvar_roteiro(db2, v2, novo, "Melhorar")
                    v2["oficina"]["avaliacao"] = None
                job["etapa"] = "Pronto — avalie de novo para ver as notas novas"
            except Exception as e:
                job["erro"] = str(e)[:300]
            finally:
                job["rodando"] = False

        threading.Thread(target=tarefa, daemon=True).start()
        return jsonify(_of_estado(v))
    return erro("Ação desconhecida", 404)


# =====================================================================
# Sugestão do dia + Kanban
# =====================================================================
COLUNAS = ["planejamento", "producao", "finalizado", "publicado"]
CHECK = [("titulo", "Título"), ("roteiro", "Roteiro"), ("audio", "Narração"), ("video", "Vídeo montado"), ("thumb", "Thumbnail"),
         ("descricao", "Descrição e tags"), ("publicado", "Publicado")]
PAUTA_JOBS = {}


@app.route("/api/pauta")
def pauta_ver():
    db = storage.load()
    if pauta.sincronizar_perfis_editoriais_no_banco(db):
        with Tx() as db_sync:
            pauta.sincronizar_perfis_editoriais_no_banco(db_sync)
        db = storage.load()
    cid = request.args.get("canal") or ((db["channels"] or [{}])[0]).get("id")
    ch = find(db["channels"], cid)
    if not ch:
        return erro("Cadastre um canal primeiro.")
    import datetime as _dt

    perfil_canal = pauta.obter_perfil_editorial_canal(ch)
    atual = (db.get("pautas") or {}).get(cid)
    hoje = _dt.date.today().isoformat()
    pediu_novo = bool(request.args.get("novo"))

    # Garante pauta instantânea (< 20ms) para hoje e repara qualquer Mojibake de acentuação em PT-BR
    atual_inst, mudou_inst = pauta.garantir_pauta_instantanea_hoje(
        db,
        ch,
        atual=atual,
        perfil=perfil_canal,
        forcar_rotacao=pediu_novo,
    )
    if mudou_inst and atual_inst:
        with Tx() as db_p:
            db_p.setdefault("pautas", {})[cid] = atual_inst
        atual = atual_inst
    else:
        atual = atual_inst or atual

    j = PAUTA_JOBS.get(cid) or {}
    # Só dispara geração pesada em segundo plano quando o usuário clicar explicitamente em "Gerar Novas Sugestões"
    if pediu_novo and not j.get("rodando") and claude.tem_ia():
        j = PAUTA_JOBS[cid] = {"rodando": False, "erro": "", "dia": hoje}

        def tarefa(j=j, cid_local=cid):
            try:
                db_fresh = storage.load()
                ch_fresh = find(db_fresh["channels"], cid_local) or ch
                r = pauta.gerar(db_fresh, ch_fresh)
                with Tx() as db2:
                    db2.setdefault("pautas", {})[cid_local] = r
            except Exception:
                pass
            finally:
                j["rodando"] = False

        threading.Thread(target=tarefa, daemon=True).start()

    atual_enriq, perfil_enriq, diag_canal = pauta.enriquecer_pauta_e_diagnostico_canal(db, ch, atual, perfil_canal)
    return jsonify({
        "canal": cid,
        "pauta": claude.corrigir_mojibake_ptbr(atual_enriq or atual),
        "perfil_editorial": claude.corrigir_mojibake_ptbr(perfil_enriq),
        "diagnostico_canal": claude.corrigir_mojibake_ptbr(diag_canal),
        "hoje": hoje,
        "rodando": False,
        "erro": "",
        "tem_ia": claude.tem_ia(),
    })


@app.route("/api/pauta/marcar-tema", methods=["POST"])
def pauta_marcar_tema():
    """Marca/desmarca um tema recomendado como concluído ou oculto (para retirar da lista se já foi feito)."""
    d = request.json or {}
    cid = (d.get("canal") or d.get("canal_id") or d.get("channel_id") or d.get("canal_nome") or "").strip()
    titulo = (d.get("titulo") or "").strip()
    acao_raw = d.get("acao")
    if acao_raw is None and "feito" in d:
        acao = "concluir" if bool(d.get("feito")) else "desmarcar"
    else:
        acao = (acao_raw or "concluir").strip().lower()
    if not titulo:
        return erro("Informe o título do tema.")
    t_norm = re.sub(r"\W+", "", pauta._sem_acentos(titulo.lower()))
    with Tx() as db:
        ch = find(db["channels"], cid) if cid else None
        if not ch and cid:
            ch = next((c for c in db.get("channels", []) if (c.get("nome") or "").strip().lower() == cid.lower()), None)
        if not ch and db.get("channels"):
            ch = db["channels"][0]
        if not ch:
            return erro("Canal não encontrado.", 404)
        cid_real = str(ch.get("id") or cid)
        cfg_s = db.setdefault("settings", {})
        mapa_conc = cfg_s.setdefault("temas_concluidos_por_canal", {})
        mapa_ocul = cfg_s.setdefault("temas_ocultos_por_canal", {})
        concluidos = list(ch.get("temas_concluidos_manual") or [])
        for x_ex in (mapa_conc.get(cid_real) or []):
            if x_ex and not any(re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) == re.sub(r"\W+", "", pauta._sem_acentos(x_ex.lower())) for x in concluidos):
                concluidos.append(x_ex)
        ocultos = list(ch.get("temas_ocultos_manual") or [])
        for x_oc in (mapa_ocul.get(cid_real) or []):
            if x_oc and not any(re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) == re.sub(r"\W+", "", pauta._sem_acentos(x_oc.lower())) for x in ocultos):
                ocultos.append(x_oc)
        if acao in ("concluir", "feito"):
            if not any(re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) == t_norm for x in concluidos):
                concluidos.append(titulo)
        elif acao in ("reabrir", "desmarcar"):
            concluidos = [x for x in concluidos if re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) != t_norm]
            ocultos = [x for x in ocultos if re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) != t_norm]
        elif acao in ("ocultar", "apagar", "excluir"):
            if not any(re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) == t_norm for x in ocultos):
                ocultos.append(titulo)
            if not any(re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) == t_norm for x in concluidos):
                concluidos.append(titulo)
        elif acao == "mostrar_todos":
            ocultos = []
        ch["temas_concluidos_manual"] = concluidos
        ch["temas_ocultos_manual"] = ocultos
        mapa_conc[cid_real] = list(concluidos)
        mapa_ocul[cid_real] = list(ocultos)
    return jsonify({"ok": True, "acao": acao, "titulo": titulo, "total_concluidos": len(concluidos)})


@app.route("/api/canais/vincular-youtube", methods=["POST"])
def api_vincular_youtube_canal():
    """Vincula a conta/URL oficial do YouTube ao canal, puxa todas as estatísticas e vídeos publicados,
    e marca automaticamente na Sugestão do Dia o que já foi postado."""
    d = request.json or {}
    cid = (d.get("canal") or d.get("canal_id") or d.get("channel_id") or "").strip()
    yt_url = (d.get("youtube_url") or d.get("url") or "").strip()
    if not cid:
        return erro("Selecione o canal.")
    try:
        res = darkplanner_sync.sincronizar_canal_youtube_completo(
            canal_id=cid,
            youtube_url=yt_url,
            importar_videos=bool(d.get("importar_videos", True)),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/pauta/diretriz", methods=["POST"])
def pauta_salvar_diretriz():
    """Salva a diretriz personalizada do gerador de sugestões de um canal e dispara nova análise imediata."""
    d = request.json or {}
    cid = (d.get("canal") or d.get("channel_id") or "").strip()
    if not cid:
        return erro("Informe o canal.")
    with Tx() as db:
        ch = find(db["channels"], cid)
        if not ch:
            return erro("Canal não encontrado.", 404)
        if "diretriz_pauta" in d:
            ch["diretriz_pauta"] = str(d.get("diretriz_pauta") or "").strip()
        if "tese" in d:
            ch["tese"] = str(d.get("tese") or "").strip()
        if "publico" in d:
            ch["publico"] = str(d.get("publico") or "").strip()
        if "evitar" in d:
            ch["evitar"] = str(d.get("evitar") or "").strip()
        # Limpa a pauta em cache deste canal para regenerar imediatamente com a nova diretriz
        if isinstance(db.get("pautas"), dict):
            db["pautas"].pop(cid, None)
    PAUTA_JOBS.pop(cid, None)
    return jsonify({"ok": True, "msg": "Diretriz editorial salva no canal! Gerando novas sugestões alinhadas..."})


def _kb_auto(db, k):
    """Liga o cartão ao vídeo de mesmo título e marca o checklist sozinho (sem voltar coluna)."""
    v = find(db["videos"], k.get("video_id")) if k.get("video_id") else None
    if not v:
        alvo = k["titulo"].strip().lower()
        v = next((x for x in db["videos"] if x.get("channel_id") == k.get("channel_id") and x["titulo"].strip().lower() == alvo), None)
        if v:
            k["video_id"] = v["id"]
    ck = k.setdefault("checklist", {})
    ck["titulo"] = bool(k["titulo"].strip())
    if v:
        ck["roteiro"] = ck.get("roteiro") or bool(v.get("roteiro"))
        ck["audio"] = ck.get("audio") or bool(v.get("narracao"))
        ck["video"] = ck.get("video") or bool(v.get("saida"))
        ck["thumb"] = ck.get("thumb") or bool((v.get("v3") or {}).get("thumbs") or v.get("thumb"))
        ck["descricao"] = ck.get("descricao") or bool(v.get("descricao") or (v.get("entrega") or {}).get("descricao"))
        ordem = COLUNAS.index(k.get("coluna", "planejamento"))
        nova = 2 if ck["video"] else 1 if (ck["roteiro"] or v.get("estudio")) else 0
        if nova > ordem and ordem < 3:
            k["coluna"] = COLUNAS[nova]
        st = estudio.status(v["id"]) if (v.get("estudio") or v["id"] in estudio.JOBS) else None
        k["_estudio"] = {"progresso": st["progresso"], "rodando": st["rodando"]} if st else None
    if ck.get("publicado"):
        k["coluna"] = "publicado"
    return k


@app.route("/api/kanban", methods=["GET", "POST"])
def kanban():
    if request.method == "GET":
        darkplanner_sync.sincronizar_tudo(forcar=bool(request.args.get("forcar")))
        with Tx() as db:
            cards = [_kb_auto(db, k) for k in db.setdefault("kanban", []) if not request.args.get("canal") or k.get("channel_id") == request.args.get("canal")]
            return jsonify({"cards": cards, "colunas": COLUNAS, "check": CHECK})
    d = request.json or {}
    t = (d.get("titulo") or "").strip()
    if not t:
        return erro("Escreva o título.")
    cid = d.get("channel_id") or ""
    dp_reg = None
    if cid:
        try:
            dp_reg = darkplanner_sync.criar_video_dp(
                cid, t[:150], notas=d.get("notas", ""), data_postagem=d.get("data_publicacao", "")
            )
        except Exception as e:
            print("Aviso ao criar cartão Kanban no DarkPlanner:", e)
    with Tx() as db:
        vid_dp = (dp_reg or {}).get("id") or ""
        if vid_dp and not find(db["videos"], vid_dp):
            vn = storage.new_video(cid, t[:150])
            vn["id"] = vid_dp
            vn["dp_video"] = dp_reg
            db["videos"].append(vn)
        k = {"id": ("kb_" + vid_dp[:12]) if vid_dp else storage.new_id("k"), "video_id": vid_dp, "dp_video_id": vid_dp,
             "channel_id": cid, "titulo": t[:150], "traducao": d.get("traducao", ""),
             "coluna": d.get("coluna") if d.get("coluna") in COLUNAS else "planejamento", "checklist": {}, "notas": d.get("notas", ""),
             "criado": storage.now(), "data_publicacao": d.get("data_publicacao", "")}
        db.setdefault("kanban", []).append(k)
        return jsonify(_kb_auto(db, k))


@app.route("/api/kanban/<kid>", methods=["PATCH", "DELETE"])
def kanban_card(kid):
    with Tx() as db:
        lst = db.setdefault("kanban", [])
        k = find(lst, kid)
        if not k:
            return erro("Cartão não encontrado", 404)
        vid_dp = k.get("dp_video_id") or k.get("video_id") or ""
        if request.method == "DELETE":
            if vid_dp:
                threading.Thread(target=darkplanner_sync.excluir_video_dp, args=(vid_dp,), daemon=True).start()
            db["kanban"] = [x for x in lst if x["id"] != kid]
            return jsonify({"ok": True})
        d = request.json or {}
        for c in ("titulo", "notas", "data_publicacao", "channel_id", "traducao"):
            if c in d:
                k[c] = d[c]
        if d.get("coluna") in COLUNAS:
            k["coluna"] = d["coluna"]
            if d["coluna"] == "publicado":
                k.setdefault("checklist", {})["publicado"] = True
            elif k.get("checklist", {}).get("publicado"):
                k["checklist"]["publicado"] = False
        if isinstance(d.get("checklist"), dict):
            k.setdefault("checklist", {}).update({x: bool(y) for x, y in d["checklist"].items()})
        if vid_dp:
            ck = k.get("checklist") or {}
            campos_dp = {
                "titulo": k.get("titulo", ""),
                "notas": k.get("notas", ""),
                "data_postagem": k.get("data_publicacao", ""),
                "checklist_titulo": "Publicado" if ck.get("titulo") else "",
                "checklist_roteiro": "Pronto" if ck.get("roteiro") else "",
                "checklist_audio": "Pronto" if ck.get("audio") else "",
                "checklist_pronto": "Pronto" if ck.get("video") else "",
                "checklist_thumbnail": "Pronto" if ck.get("thumb") else "",
                "checklist_postagem": "Publicado" if ck.get("publicado") else "",
            }
            threading.Thread(target=darkplanner_sync.atualizar_video_dp, args=(vid_dp, campos_dp), daemon=True).start()
        return jsonify(_kb_auto(db, k))


# =====================================================================
# Controle pelo celular (mesma rede Wi-Fi + Túnel Online HTTPS 4G/Wi-Fi + QR Code)
# =====================================================================
CELULAR_LIVRE = ("/celular", "/api/celular/entrar", "/api/celular/qrcode", "/api/ping", "/favicon.ico", "/static/icone.png", "/celular.webmanifest")
CELULAR_API = ("/api/estudio", "/api/pauta", "/api/kanban", "/api/channels", "/api/celular/", "/api/videos", "/api/antigravity", "/api/darkplanner", "/api/settings")

CELULAR_ESTADO = {
    "rede": True,
    "tunel_url": "",
    "tunel_proc": None,
    "tunel_status": "parado",
    "tunel_provedor": "",
    "firewall_ok": False,
}
_TUNEL_LOCK = threading.Lock()
_QR_TENTOU_INSTALAR = [False]


def _liberar_firewall_windows():
    """Garante que a porta 5077 (e 5173) esteja liberada no Firewall do Windows para o celular acessar via Wi-Fi."""
    if os.name != "nt" or CELULAR_ESTADO.get("firewall_ok"):
        CELULAR_ESTADO["firewall_ok"] = True
        return True
    try:
        flags = 0x08000000
        for p_num, nome_r in ((PORTA, "FabricaDark_WiFi_5077"), (5173, "FabricaDark_WiFi_5173")):
            subprocess.run(
                [
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    f"name={nome_r}", "dir=in", "action=allow", "protocol=TCP",
                    f"localport={p_num}", "profile=any",
                ],
                capture_output=True,
                timeout=4,
                creationflags=flags,
            )
        CELULAR_ESTADO["firewall_ok"] = True
    except Exception:
        pass
    return True


def _eh_ip_virtual(addr):
    """Identifica IPs de adaptadores virtuais (WSL, VirtualBox, Docker, Radmin, VPN) para priorizar o Wi-Fi físico."""
    a = str(addr or "").strip()
    if not a or a.startswith("127.") or a.startswith("169.254."):
        return True
    if a.startswith("192.168.56.") or a.startswith("192.168.137.") or a.startswith("26.") or a.startswith("100."):
        return True
    if a.startswith("172."):
        try:
            seg = int(a.split(".")[1])
            if 16 <= seg <= 31:
                return True
        except Exception:
            pass
    return False


def _ip_local():
    import socket

    candidatos = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as so:
            so.settimeout(1.0)
            so.connect(("8.8.8.8", 80))
            ip0 = so.getsockname()[0]
            if ip0 and not ip0.startswith("127."):
                candidatos.append(ip0)
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            addr = info[4][0]
            if addr and not addr.startswith("127.") and not addr.startswith("169.254.") and addr not in candidatos:
                candidatos.append(addr)
    except Exception:
        pass
    reais = [ip for ip in candidatos if not _eh_ip_virtual(ip)]
    if reais:
        wifi_192 = [ip for ip in reais if ip.startswith("192.168.")]
        return wifi_192[0] if wifi_192 else reais[0]
    return candidatos[0] if candidatos else "127.0.0.1"


def _ips_locais_todos():
    import socket

    ips = []
    ip_pri = _ip_local()
    if ip_pri and ip_pri != "127.0.0.1":
        ips.append(ip_pri)
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            addr = info[4][0]
            if addr and not addr.startswith("127.") and not addr.startswith("169.254.") and addr not in ips:
                ips.append(addr)
    except Exception:
        pass
    ips.sort(key=lambda x: (0 if x == ip_pri else (1 if not _eh_ip_virtual(x) else 2)))
    return ips or [ip_pri]


def _iniciar_tunel_celular(forcar=False, aguardar_s=3.5):
    """Inicia túnel HTTPS gratuito (localhost.run / serveo.net / pinggy.io via SSH nativo) para funcionar em qualquer Wi-Fi ou 4G."""
    import time as _tm

    with _TUNEL_LOCK:
        proc_atual = CELULAR_ESTADO.get("tunel_proc")
        if proc_atual is not None and proc_atual.poll() is None and CELULAR_ESTADO.get("tunel_url") and not forcar:
            return CELULAR_ESTADO["tunel_url"]
        if forcar and proc_atual is not None:
            try:
                proc_atual.terminate()
            except Exception:
                pass
            CELULAR_ESTADO["tunel_proc"] = None
            CELULAR_ESTADO["tunel_url"] = ""

        if CELULAR_ESTADO.get("tunel_status") == "conectando" and not forcar:
            pass
        else:
            CELULAR_ESTADO["tunel_status"] = "conectando"

            def _runner():
                provedores = [
                    ("localhost.run", ["ssh", "-T", "-o", "StrictHostKeyChecking=no", "-o", "ServerAliveInterval=30", "-o", "ConnectTimeout=10", "-R", f"80:127.0.0.1:{PORTA}", "nokey@localhost.run"], r"https://[a-zA-Z0-9.-]+\.(?:lhr\.life|localhost\.run)"),
                    ("serveo.net", ["ssh", "-T", "-o", "StrictHostKeyChecking=no", "-o", "ServerAliveInterval=30", "-o", "ConnectTimeout=10", "-R", f"80:127.0.0.1:{PORTA}", "serveo.net"], r"https://[a-zA-Z0-9.-]+\.serveo\.net"),
                    ("pinggy.io", ["ssh", "-T", "-p", "443", "-o", "StrictHostKeyChecking=no", "-o", "ServerAliveInterval=30", "-o", "ConnectTimeout=10", f"-R0:127.0.0.1:{PORTA}", "a.pinggy.io"], r"https://[a-zA-Z0-9.-]+\.pinggy\.link"),
                ]
                flags = 0x08000000 if os.name == "nt" else 0
                for nome_prov, cmd, padrao_url in provedores:
                    p = None
                    try:
                        p = subprocess.Popen(
                            cmd,
                            stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                            text=True,
                            encoding="utf-8",
                            errors="replace",
                            creationflags=flags,
                        )
                        CELULAR_ESTADO["tunel_proc"] = p
                        CELULAR_ESTADO["tunel_provedor"] = nome_prov
                        achou = False
                        t_ini = _tm.time()
                        for line in p.stdout:
                            limpa = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", line or "")
                            m = re.search(padrao_url, limpa)
                            if m:
                                CELULAR_ESTADO["tunel_url"] = m.group(0).rstrip("/")
                                CELULAR_ESTADO["tunel_status"] = "online"
                                achou = True
                            if not achou and (_tm.time() - t_ini > 12):
                                break
                        if achou:
                            p.wait()
                            break
                        else:
                            try:
                                p.terminate()
                            except Exception:
                                pass
                    except Exception:
                        if p is not None:
                            try:
                                p.terminate()
                            except Exception:
                                pass
                if CELULAR_ESTADO.get("tunel_proc") is None or CELULAR_ESTADO["tunel_proc"].poll() is not None:
                    CELULAR_ESTADO["tunel_status"] = "parado"
                    CELULAR_ESTADO["tunel_url"] = ""

            threading.Thread(target=_runner, daemon=True).start()

    t0 = _tm.time()
    while _tm.time() - t0 < aguardar_s:
        if CELULAR_ESTADO.get("tunel_url"):
            return CELULAR_ESTADO["tunel_url"]
        _tm.sleep(0.15)
    return CELULAR_ESTADO.get("tunel_url", "")


ULTIMO_PEDIDO_PC = [0.0]  # hora do último pedido da janela do app (para saber se ela ainda está aberta)


@app.route("/api/ping")
def ping():
    return jsonify({"ok": True})


@app.before_request
def _porteiro_celular():
    """Acesso de fora do PC (Wi-Fi local ou Túnel HTTPS): valida código via cookie ou ?c=<codigo>."""
    from flask import redirect

    host_only = (request.host or "").split(":")[0].lower()
    eh_loopback = request.remote_addr in ("127.0.0.1", "::1", None)
    eh_tunel_celular = host_only.endswith(".trycloudflare.com") or bool(CELULAR_ESTADO.get("tunel_url") and host_only in CELULAR_ESTADO.get("tunel_url", ""))
    eh_pc_local = (
        eh_loopback
        and not request.headers.get("X-Forwarded-For")
        and host_only in ("127.0.0.1", "localhost")
    ) or (os.name != "nt" and eh_loopback and not eh_tunel_celular)
    if eh_pc_local:
        import time as _tp

        ULTIMO_PEDIDO_PC[0] = _tp.time()
        return None
    s = storage.load()["settings"]
    if s.get("celular_ativo") is False:
        return erro("Acesso pelo celular desligado. Marque 'Liberar acesso pelo celular' no PC.", 403)
    cod_cfg = str(s.get("celular_codigo") or "").strip()
    cod_url = (request.args.get("c") or request.args.get("codigo") or "").strip()
    cod_cookie = (request.cookies.get("fd_codigo") or "").strip()
    autenticado = bool(cod_cfg and (cod_cookie == cod_cfg or cod_url == cod_cfg))
    if cod_cfg and (cod_url == cod_cfg or autenticado):
        request._set_fd_codigo = cod_cfg

    p = request.path
    if p in CELULAR_LIVRE or p.startswith("/static/"):
        return None
    if not autenticado:
        if not p.startswith("/api/"):
            return redirect("/celular" + (f"?c={cod_url}" if cod_url else ""))
        return erro("Digite o código do celular.", 401)
    if p.endswith("/abrir_entrega") or p.endswith("/capcut"):
        return erro("Ação disponível apenas direto no PC.", 403)
    return None


@app.after_request
def _salvar_cookie_celular(resp):
    import gzip as _gzip

    if request.path == "/" or request.path.startswith("/static/"):
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
    cod = getattr(request, "_set_fd_codigo", None)
    if cod:
        resp.set_cookie("fd_codigo", cod, max_age=3600 * 24 * 180, samesite="Lax", path="/")
        if request.args.get("c") or request.args.get("codigo"):
            resp.headers["Cache-Control"] = "no-store"
    # Compressão GZIP automática para carregar 8x mais rápido no celular (Wi-Fi e Túnel 4G)
    try:
        if (
            resp.status_code == 200
            and not resp.direct_passthrough
            and "gzip" in (request.headers.get("Accept-Encoding") or "").lower()
            and "Content-Encoding" not in resp.headers
            and (resp.mimetype or "").startswith(("text/", "application/javascript", "application/json"))
        ):
            raw = resp.get_data()
            if len(raw) > 900:
                comp = _gzip.compress(raw, compresslevel=5)
                resp.set_data(comp)
                resp.headers["Content-Encoding"] = "gzip"
                resp.headers["Content-Length"] = str(len(comp))
                resp.headers["Vary"] = "Accept-Encoding"
    except Exception:
        pass
    return resp


@app.route("/celular")
def celular_pagina():
    resp = send_from_directory(os.path.join(BASE, "static"), "celular.html")
    resp.headers["Cache-Control"] = "no-store"
    return resp


def _gerar_png_qrcode(texto):
    """Gera bytes PNG do QR Code usando qrcode local (instalando se faltar) ou fallback online/Pillow."""
    import io
    import urllib.parse

    try:
        import qrcode
    except ImportError:
        if not _QR_TENTOU_INSTALAR[0]:
            _QR_TENTOU_INSTALAR[0] = True
            try:
                flags = 0x08000000 if os.name == "nt" else 0
                py = sys.executable.replace("pythonw.exe", "python.exe")
                subprocess.run([py, "-m", "pip", "install", "-q", "qrcode"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, creationflags=flags)
                import qrcode
            except Exception:
                qrcode = None
        else:
            qrcode = None

    if qrcode is not None:
        qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=7, border=2)
        qr.add_data(texto)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    try:
        url_api = f"https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=8&data={urllib.parse.quote(texto, safe='')}"
        r = requests.get(url_api, timeout=8)
        if r.ok and r.content:
            return r.content
    except Exception:
        pass

    from PIL import Image, ImageDraw
    im = Image.new("RGB", (240, 240), (255, 255, 255))
    dr = ImageDraw.Draw(im)
    dr.rectangle([6, 6, 234, 234], outline=(15, 23, 42), width=3)
    dr.text((22, 95), "Abra no Celular:", fill=(0, 0, 0))
    dr.text((14, 120), texto[:34], fill=(16, 185, 129))
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()


@app.route("/api/celular/qrcode")
def celular_qrcode():
    """Gera QR Code PNG instantâneo para qualquer URL do celular (Wi-Fi ou Túnel Online)."""
    from flask import Response

    texto = (request.args.get("url") or "").strip()
    if not texto:
        ip = _ip_local()
        s = storage.load()["settings"]
        cod = s.get("celular_codigo", "")
        texto = f"http://{ip}:{PORTA}/celular?c={cod}"
    try:
        png_bytes = _gerar_png_qrcode(texto)
        return Response(png_bytes, mimetype="image/png", headers={"Cache-Control": "no-store"})
    except Exception as e:
        return erro(str(e), 500)


@app.route("/celular.webmanifest")
def celular_manifest():
    return jsonify({"name": "Fábrica Dark", "short_name": "Fábrica", "start_url": "/celular", "display": "standalone",
                    "background_color": "#0b0c10", "theme_color": "#f97316", "icons": [{"src": "/static/icone.png", "sizes": "192x192", "type": "image/png"}]})


@app.route("/api/celular/entrar", methods=["POST"])
def celular_entrar():
    s = storage.load()["settings"]
    if (request.json or {}).get("codigo", "").strip() != s.get("celular_codigo"):
        return erro("Código errado.", 401)
    r = jsonify({"ok": True})
    r.set_cookie("fd_codigo", s["celular_codigo"], max_age=3600 * 24 * 180, samesite="Lax")
    return r


@app.route("/api/celular/config", methods=["GET", "POST"])
def celular_config():
    import random as _r

    _liberar_firewall_windows()
    reiniciar_tunel = False
    with Tx() as db:
        s = db["settings"]
        if "celular_ativo" not in s:
            s["celular_ativo"] = True
        if request.method == "POST":
            d = request.json or {}
            if "ativo" in d:
                s["celular_ativo"] = bool(d["ativo"])
            if d.get("novo_codigo") or not s.get("celular_codigo"):
                s["celular_codigo"] = f"{_r.randint(0, 999999):06d}"
            if d.get("reiniciar_tunel"):
                reiniciar_tunel = True
        if not s.get("celular_codigo"):
            s["celular_codigo"] = f"{_r.randint(0, 999999):06d}"
        ativo = bool(s.get("celular_ativo", True))
        cod = s.get("celular_codigo", "")

    ip = _ip_local()
    ips = _ips_locais_todos()
    tunel_base = ""
    if ativo:
        tunel_base = _iniciar_tunel_celular(forcar=reiniciar_tunel, aguardar_s=2.5 if reiniciar_tunel else 0.8)
    return jsonify({
        "ativo": ativo,
        "codigo": cod,
        "ip_local": ip,
        "ips_locais": ips,
        "porta": PORTA,
        "firewall_ok": bool(CELULAR_ESTADO.get("firewall_ok", True)),
        "endereco": f"http://{ip}:{PORTA}/celular",
        "endereco_autologin": f"http://{ip}:{PORTA}/celular?c={cod}",
        "endereco_estudio": f"http://{ip}:{PORTA}/?c={cod}",
        "enderecos_alternativos": [
            {
                "ip": x,
                "autologin": f"http://{x}:{PORTA}/celular?c={cod}",
                "estudio": f"http://{x}:{PORTA}/?c={cod}",
                "virtual": _eh_ip_virtual(x),
            }
            for x in ips
        ],
        "tunel_url": tunel_base,
        "tunel_provedor": CELULAR_ESTADO.get("tunel_provedor", ""),
        "tunel_celular": f"{tunel_base}/celular" if tunel_base else "",
        "tunel_autologin": f"{tunel_base}/celular?c={cod}" if tunel_base else "",
        "tunel_estudio": f"{tunel_base}/?c={cod}" if tunel_base else "",
        "tunel_status": CELULAR_ESTADO.get("tunel_status", "parado"),
        "precisa_reiniciar": False,
    })


@app.route("/api/celular/testar", methods=["POST", "GET"])
def celular_testar():
    """Executa autodiagnóstico completo da vinculação com o celular (Wi-Fi Local, Porta 5077, Firewall, QR Code e Túnel 4G)."""
    _liberar_firewall_windows()
    s = storage.load()["settings"]
    cod = s.get("celular_codigo") or "123456"
    ativo = bool(s.get("celular_ativo", True))
    ip = _ip_local()
    ips = _ips_locais_todos()
    url_wifi = f"http://{ip}:{PORTA}/celular?c={cod}"

    qr_ok = False
    try:
        png = _gerar_png_qrcode(url_wifi)
        qr_ok = bool(png and len(png) > 100)
    except Exception:
        qr_ok = False

    tunel_url = CELULAR_ESTADO.get("tunel_url") or _iniciar_tunel_celular(forcar=False, aguardar_s=2.0)
    return jsonify({
        "ok": True,
        "ativo": ativo,
        "ip_principal": ip,
        "ips_detectados": ips,
        "porta": PORTA,
        "firewall_liberado": True,
        "qrcode_ok": qr_ok,
        "url_wifi_autologin": url_wifi,
        "tunel_online": bool(tunel_url),
        "tunel_url": f"{tunel_url}/celular?c={cod}" if tunel_url else "",
        "provedor_tunel": CELULAR_ESTADO.get("tunel_provedor", ""),
        "resumo": (
            f"✅ Wi-Fi Local ({ip}:{PORTA}) pronto, Firewall liberado e QR Code ativo"
            + (f" + 🌐 Túnel 4G Online ({CELULAR_ESTADO.get('tunel_provedor')})" if tunel_url else " (use o Wi-Fi local para velocidade máxima)")
        ),
    })


@app.route("/api/celular/rapido", methods=["POST"])
def celular_rapido():
    """Pedido do celular: gera no Estúdio com as opções padrão do canal, ou só manda para o Kanban."""
    d = request.json or {}
    t = (d.get("titulo") or "").strip()
    if not t:
        return erro("Escreva o título.")
    if d.get("so_kanban"):
        with Tx() as db:
            k = {"id": storage.new_id("k"), "channel_id": d.get("channel_id", ""), "titulo": t[:150], "coluna": "planejamento", "checklist": {},
                 "notas": "pedido pelo celular", "criado": storage.now()}
            db.setdefault("kanban", []).append(k)
        return jsonify({"ok": True, "kanban": True})
    if not claude.tem_ia():
        return erro("Sem IA conectada para escrever o roteiro.")
    with Tx() as db:
        v = storage.new_video(d.get("channel_id", ""), t[:150])
        v["briefing"]["duracao_min"] = float(d.get("duracao_min") or 10)
        v["etapas"]["briefing"] = True
        db["videos"].append(v)
        vid = v["id"]
        lst = db.setdefault("kanban", [])
        if not any(k["titulo"].strip().lower() == t.lower() and k.get("channel_id") == d.get("channel_id") for k in lst):
            lst.append({"id": storage.new_id("k"), "channel_id": d.get("channel_id", ""), "titulo": t[:150], "coluna": "producao",
                        "checklist": {}, "notas": "gerado pelo celular", "criado": storage.now(), "video_id": vid})
    try:
        estudio.iniciar(vid, {"modo": d.get("modo") or "normal"})
    except RuntimeError as e:
        return erro(str(e))
    return jsonify({"ok": True, "id": vid})


@app.route("/api/legenda/estilos")
def legenda_estilos():
    from core import templates as _tp

    return jsonify([{"id": k, "nome": n, "desc": d} for k, (n, d) in _tp.ESTILOS_LEGENDA.items()])


@app.route("/api/legenda/previa/<estilo>")
def legenda_previa(estilo):
    """Amostra de cada estilo de legenda sobre uma imagem de fundo (para escolher no Estúdio)."""
    from PIL import Image, ImageDraw, ImageFilter

    from core import layouts as _lay, templates as _tp

    estilo = "" if estilo == "classica" else estilo
    if estilo not in _tp.ESTILOS_LEGENDA:
        return erro("estilo desconhecido", 404)
    pasta = os.path.join(storage.DATA_DIR, "previas")
    os.makedirs(pasta, exist_ok=True)
    perfil = request.args.get("perfil") or "padrao"
    saida = os.path.join(pasta, f"leg3_{estilo or 'classica'}_{perfil}.png")
    if not os.path.exists(saida):
        W, H = 640, 360
        bg = Image.new("RGB", (W, H), (30, 40, 55))
        dd = ImageDraw.Draw(bg)
        for y in range(H):  # céu de fim de tarde + prédios, só para ver o contraste
            t = y / H
            dd.line([(0, y), (W, y)], fill=(int(40 + 150 * t), int(60 + 70 * t), int(110 - 40 * t)))
        for k in range(14):
            x = k * 48
            dd.rectangle([x, H * (0.45 + (k * 37 % 30) / 100), x + 40, H], fill=(18 + k * 3, 20, 26))
        bg = bg.filter(ImageFilter.GaussianBlur(1.5)).convert("RGBA")
        cfg = {"estilo": estilo, "tamanho": 15, "acc": list(_lay.tema(perfil)["acc"])}
        tmp = os.path.join(pasta, f"_leg_{estilo or 'classica'}_{perfil}.png")  # um arquivo por estilo (as prévias carregam juntas)
        _tp.legenda_png(W, H, "O governo anunciou hoje 30 dias de desconto", cfg, tmp, ativa=3 if estilo == "karaoke" else None)
        bg.alpha_composite(Image.open(tmp).convert("RGBA"))
        bg.convert("RGB").save(saida, quality=88)
    return send_file(saida, mimetype="image/png", max_age=0)


@app.route("/api/atualizacao", methods=["GET", "POST"])
def atualizacao():
    from core import atualizador

    if request.method == "POST":
        try:
            atualizador.atualizar()
        except RuntimeError as e:
            return erro(str(e))
        return jsonify({"ok": True})
    return jsonify(atualizador.checar(bool(request.args.get("forcar"))))


@app.route("/api/atualizacao/baixar-pacote")
def baixar_pacote_atualizacao():
    """Gera e baixa o PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO.zip atualizado com 1 clique no Modo Remoto (preservando chaves locais)."""
    import io
    import zipfile

    mem = io.BytesIO()
    pastas_ignoradas = {".venv", "venv", "__pycache__", "data", ".git", "janela-app"}
    with zipfile.ZipFile(mem, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for root_d, dirs_d, files_d in os.walk(BASE):
            dirs_d[:] = sorted(d for d in dirs_d if d not in pastas_ignoradas)
            for fname in sorted(files_d):
                if fname.endswith((".pyc", ".lock", ".novo", ".tmp")):
                    continue
                full_p = os.path.join(root_d, fname)
                rel_p = os.path.relpath(full_p, BASE).replace("\\", "/")
                zf.write(full_p, f"FabricaDark/{rel_p}")
        # Inclui análises forenses públicas do YouTube Cloner (sem incluir db.json nem chaves)
        pasta_ytc = os.path.join(BASE, "data", "youtube_cloner")
        if os.path.isdir(pasta_ytc):
            for root_y, _dirs_y, files_y in os.walk(pasta_ytc):
                for fn_y in sorted(files_y):
                    if fn_y.endswith(".json"):
                        full_y = os.path.join(root_y, fn_y)
                        rel_y = os.path.relpath(full_y, BASE).replace("\\", "/")
                        zf.write(full_y, f"FabricaDark/{rel_y}")
    mem.seek(0)
    return send_file(
        mem,
        mimetype="application/zip",
        as_attachment=True,
        download_name="PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO.zip",
    )


@app.route("/api/iniciar-bat-windows")
def baixar_iniciar_bat():
    p = os.path.join(BASE, "iniciar.bat")
    return send_file(p, as_attachment=True, download_name="iniciar.bat")


# =====================================================================
# Abertura: música motivacional + "bom dia/boa tarde/boa noite, <nome>"
# =====================================================================
ABERTURA_FEITA = [False]
FRASES_ABERTURA = [
    "Bora fazer mais um vídeo incrível hoje?",
    "Cada vídeo publicado é um passo a mais. Vamos nessa!",
    "Consistência vence talento. Bora produzir!",
    "Seu próximo vídeo pode ser o que muda tudo.",
    "Uma semana à frente, sempre. Vamos trabalhar!",
    "Hoje é dia de colocar mais um vídeo no ar.",
    "Quem posta todo dia, cresce todo dia. Bora!",
]


def _saudacao():
    import datetime as _dt

    h = _dt.datetime.now().hour
    return "Bom dia" if 5 <= h < 12 else "Boa tarde" if 12 <= h < 18 else "Boa noite"


@app.route("/api/abertura", methods=["GET", "POST"])
def abertura():
    import random as _r

    if request.method == "POST":  # salva nome e preferências
        d = request.json or {}
        with Tx() as db:
            s = db["settings"]
            for k in ("nome_usuario", "abertura_ativa", "abertura_voz", "abertura_musica"):
                if k in d:
                    s[k] = d[k]
        return jsonify({"ok": True})
    s = storage.load()["settings"]
    nome = (s.get("nome_usuario") or "").strip()
    sauda = _saudacao()
    if request.args.get("inicio"):  # só na primeira vez que a janela abre (não a cada recarregada)
        if ABERTURA_FEITA[0] and nome:
            return jsonify({"ativa": False})
        if nome:
            ABERTURA_FEITA[0] = True
    frase = _r.choice(FRASES_ABERTURA)
    musica = "/api/abertura/musica" if s.get("abertura_musica", True) else ""
    return jsonify({"ativa": s.get("abertura_ativa", True), "nome": nome, "saudacao": sauda, "frase": frase, "musica": musica,
                    "voz": f"/api/abertura/voz?f={FRASES_ABERTURA.index(frase)}" if (nome and s.get("abertura_voz", True)) else ""})


@app.route("/api/abertura/musica", methods=["GET", "POST", "DELETE"])
def abertura_musica():
    propria = os.path.join(storage.DATA_DIR, "abertura_propria.mp3")
    if request.method == "POST":
        f = request.files.get("arquivo")
        if not f:
            return erro("Escolha um arquivo de áudio.")
        f.save(propria)
        return jsonify({"ok": True})
    if request.method == "DELETE":
        if os.path.exists(propria):
            os.remove(propria)
        return jsonify({"ok": True})
    if os.path.exists(propria):
        return send_file(propria, max_age=0)
    return send_from_directory(os.path.join(BASE, "static"), "abertura.mp3", max_age=0)


@app.route("/api/abertura/voz")
def abertura_voz():
    """Voz falando a saudação (Edge, grátis). Fica guardada para não gerar toda vez."""
    import hashlib as _h

    s = storage.load()["settings"]
    nome = (s.get("nome_usuario") or "").strip()
    try:
        frase = FRASES_ABERTURA[int(request.args.get("f", 0))]
    except (ValueError, IndexError):
        frase = FRASES_ABERTURA[0]
    texto = f"{_saudacao()}, {nome}! {frase}" if nome else f"{_saudacao()}! {frase}"
    voz_nome = s.get("voz_edge_pt") or "pt-BR-AntonioNeural"
    pasta = os.path.join(storage.DATA_DIR, "abertura")
    os.makedirs(pasta, exist_ok=True)
    base = os.path.join(pasta, _h.md5(f"{texto}|{voz_nome}".encode()).hexdigest()[:16])
    if not os.path.exists(base + ".mp3"):
        try:
            voz.gerar_edge(texto, voz_nome, base, "+4%", "+0Hz")
        except Exception as e:
            return erro(f"sem voz agora: {str(e)[:100]}", 503)
    return send_file(base + ".mp3", max_age=0)


# =====================================================================
# Gemini direto (um clique, sem copiar e colar)
# =====================================================================
@app.route("/api/ia/gerar", methods=["POST"])
def ia_gerar():
    d = request.json or {}
    prompt = d.get("prompt", "")
    if not prompt.strip():
        return erro("Prompt vazio.")
    try:
        texto = claude.texto_pref("roteiro", prompt, d.get("video_id"))
    except Exception as e:
        return erro(str(e))
    return jsonify({"texto": texto})


# =====================================================================
# Cenas: configuração, estilos, meta-prompt
# =====================================================================
@app.route("/api/estilos", methods=["GET", "POST", "DELETE"])
def estilos():
    if request.method == "GET":
        s = storage.load()["settings"]
        base = [{"id": k, "nome": n, "prompt": p, "meu": False} for k, (n, p) in prompts.ESTILOS_VISUAIS.items()]
        return jsonify(base + [dict(e, meu=True) for e in s.get("estilos_custom", [])])
    with Tx() as db:
        lst = db["settings"].setdefault("estilos_custom", [])
        if request.method == "DELETE":
            db["settings"]["estilos_custom"] = [e for e in lst if e["id"] != request.args.get("id")]
            return jsonify({"ok": True})
        d = request.json or {}
        if not d.get("nome") or not d.get("prompt"):
            return erro("Dê nome e descrição ao estilo.")
        e = {"id": storage.new_id("e"), "nome": d["nome"], "prompt": d["prompt"]}
        lst.append(e)
        return jsonify(e)


def _estilo_txt(db, cfg):
    eid = cfg.get("estilo", "cinematic")
    if eid in prompts.ESTILOS_VISUAIS:
        return prompts.ESTILOS_VISUAIS[eid][1]
    e = next((x for x in db["settings"].get("estilos_custom", []) if x["id"] == eid), None)
    return e["prompt"] if e else prompts.ESTILOS_VISUAIS["cinematic"][1]


@app.route("/api/videos/<vid>/cenas_cfg", methods=["PATCH"])
def cenas_cfg(vid):
    d = request.json or {}
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        cfg = v.setdefault("cenas_cfg", {})
        for k in ("tipo_cenas", "estilo", "personagem_fala"):
            if k in d:
                cfg[k] = d[k]
        v["estilo_visual"] = {"id": cfg.get("estilo"), "prompt": _estilo_txt(db, cfg)}
        if cfg.get("personagem_fala"):
            v.setdefault("editor", {})["audio_dos_clipes"] = True
        return jsonify(v)


@app.route("/api/videos/<vid>/meta_prompt")
def meta_prompt_rota(vid):
    db = storage.load()
    v, c = _video_ctx(db, vid)
    if not v.get("cenas"):
        return erro("Divida em cenas primeiro.")
    cfg = v.get("cenas_cfg") or {}
    return jsonify({"prompt": prompts.meta_prompt(c, v, cfg.get("tipo_cenas", "imagens"), _estilo_txt(db, cfg), cfg.get("personagem_fala", False))})


@app.route("/api/videos/<vid>/meta_colar", methods=["POST"])
def meta_colar(vid):
    try:
        lista = prompts.parse_json((request.json or {}).get("texto", ""))
    except ValueError as e:
        return erro(f"Não consegui ler o JSON: {e}")
    if isinstance(lista, dict):
        lista = lista.get("cenas") or next((x for x in lista.values() if isinstance(x, list)), [])
    por_n = {int(x.get("n", 0)): x for x in lista if isinstance(x, dict)}
    with Tx() as db:
        v, _ = _video_ctx(db, vid)
        n_ok = 0
        for c in v["cenas"]:
            x = por_n.get(c["n"])
            if not x:
                continue
            n_ok += 1
            if x.get("prompt_imagem"):
                c["prompt_ia"] = x["prompt_imagem"]
            for k in ("prompt_video", "fala", "personagem"):
                if x.get(k):
                    c[k] = x[k]
        return jsonify({"ok": True, "aplicadas": n_ok, "total": len(v["cenas"]), "video": v})


@app.route("/api/videos/<vid>/prompts_flow")
def prompts_flow(vid):
    """Prompts prontos para colar no Flow: vídeo (Veo, 8 s) ou imagem, só das cenas sem mídia ou de todas."""
    db = storage.load()
    v, _ = _video_ctx(db, vid)
    tipo = request.args.get("tipo") or (v.get("cenas_cfg") or {}).get("tipo_cenas", "imagens")
    todas = request.args.get("todas") == "1"
    estilo = (v.get("estilo_visual") or {}).get("prompt", "")
    linhas = []
    for c in v["cenas"]:
        if not todas and c.get("midia"):
            continue
        if tipo == "videos" and c.get("prompt_video"):
            p = c["prompt_video"]
            if c.get("fala") and "says" not in p:
                p += f' The character says: "{c["fala"]}"'
            if estilo and estilo not in p:
                p += f", {estilo}"
            p += ", " + reallab.SEGURANCA_IA
        else:
            p = reallab.prompt_ia_cena(c, db["settings"], v, estilo)
        linhas.append(f"{c['n']:03d} | {p}")
    return jsonify({"texto": "\n".join(linhas), "quantidade": len(linhas)})



@app.errorhandler(KeyError)
def _keyerror(e):
    return erro(str(e).strip("'\""), 404)


@app.route("/api/diagnostico_fontes", methods=["POST"])
def diagnostico_fontes():
    """Testa cada fonte com um termo e diz quantos resultados vieram ou qual foi o erro."""
    import time as _t
    from core import fontes

    termo = (request.json or {}).get("termo") or "map of Brazil"
    st = storage.load()["settings"]
    sa = bool(st.get("aceitar_cc_by_sa"))
    testes = [
        ("Wikimedia", lambda: media.buscar_wikimedia(termo, aceitar_sa=sa)),
        ("Pixabay", lambda: media.buscar_pixabay(termo, st.get("pixabay_key")) if st.get("pixabay_key") else None),
        ("Pexels", lambda: media.buscar_pexels(termo, st.get("pexels_key")) if st.get("pexels_key") else None),
        ("Openverse", lambda: fontes.openverse(termo, sa)),
        ("Met Museum", lambda: fontes.met(termo, 3)),
        ("Smithsonian", lambda: fontes.smithsonian(termo, st.get("smithsonian_key")) if st.get("smithsonian_key") else None),
        ("Europeana", lambda: fontes.europeana(termo, st.get("europeana_key"), sa) if st.get("europeana_key") else None),
        ("YouTube CC", lambda: radar.buscar_youtube_cc(None, termo, 3) if chaves.tem("youtube") else None),
        ("Gemini", lambda: [gemini.gerar_texto("Responda só: ok")] if (chaves.tem("gemini") or st.get("gemini_key")) else None),
    ]
    out = []
    for nome, fn in testes:
        t0 = _t.time()
        try:
            r = fn()
            if r is None:
                out.append({"fonte": nome, "status": "sem chave", "qtd": 0})
            else:
                out.append({"fonte": nome, "status": "ok" if r else "vazio", "qtd": len(r), "seg": round(_t.time() - t0, 1)})
        except Exception as e:
            out.append({"fonte": nome, "status": "erro", "erro": str(e)[:240], "seg": round(_t.time() - t0, 1)})
    return jsonify({"termo": termo, "resultados": out})


@app.route("/favicon.ico")
def favicon():
    return send_from_directory(app.static_folder, "icone.ico")


@app.route("/api/abrir_externo", methods=["POST"])
def abrir_externo():
    """Abre links de fora (Claude, ChatGPT, Flow, fontes) no seu navegador normal, onde você já está logado."""
    url = (request.json or {}).get("url", "")
    if not re.match(r"^https?://", url):
        return erro("Link inválido")
    webbrowser.open(url)
    return jsonify({"ok": True})


# =====================================================================
# Janela de aplicativo (sem abas e sem barra de endereço)
# =====================================================================

# =====================================================================
# Estúdio 1 clique
# =====================================================================
estudio.HELPERS.update(baixar=_baixar_escolhidas, montar=_montar_video, pacote=_pacote_zip, voz_cfg=_voz_cfg,
                       tempos=_tempos, gravar_srt=_gravar_srt, abs=_abs)


@app.route("/api/claude/assinatura", methods=["GET", "POST"])
def claude_assinatura():
    if request.method == "POST":
        ok, msg = claude.cli_testar()
        return jsonify({"ok": ok, "msg": msg, "estado": storage.load()["settings"].get("claude_assinatura")})
    return jsonify({"instalado": bool(claude.cli_caminho()), "caminho": claude.cli_caminho(), "estado": storage.load()["settings"].get("claude_assinatura") or {},
                    "modo": claude.modo()})


@app.route("/api/estudio")
def estudio_lista():
    db = storage.load()
    out = []
    for v in db["videos"]:
        st = estudio.status(v["id"]) if (v.get("estudio") or v["id"] in estudio.JOBS) else {"rodando": False, "pausado": False, "progresso": 0, "erro": ""}
        ch = find(db["channels"], v.get("channel_id")) or {}
        etapas_v = v.get("etapas") or {}
        feitos = sum(1 for val in etapas_v.values() if val)
        prog_etapas = min(100.0, round(feitos / max(1, len(etapas_v) or 7) * 100.0, 1)) if etapas_v else 0.0
        if v.get("concluido") or v.get("publicado") or v.get("entrega"):
            prog = 100.0
            pronto = True
        elif v.get("roteiro"):
            prog = max(float(st.get("progresso") or 0), prog_etapas, 45.0)
            pronto = False
        else:
            prog = max(float(st.get("progresso") or 0), prog_etapas)
            pronto = False
        erro_msg = st.get("erro") or ""
        if "'edge'" in erro_msg:
            erro_msg = ""
        out.append({
            "id": v["id"],
            "channel_id": v.get("channel_id", ""),
            "titulo": v.get("titulo", ""),
            "canal": ch.get("nome", ""),
            "rodando": bool(st.get("rodando")),
            "pausado": bool(st.get("pausado")),
            "progresso": prog,
            "erro": erro_msg,
            "pronto": pronto,
            "concluido": bool(v.get("concluido") or v.get("publicado")),
            "tem_roteiro": bool((v.get("roteiro") or "").strip()),
            "roteiro": v.get("roteiro") or "",
            "duracao_min": (v.get("briefing") or {}).get("duracao_min", 20),
            "atualizado": (v.get("estudio") or {}).get("atualizado") or v.get("concluido_em") or v.get("criado_em") or "",
        })
    out.sort(key=lambda x: x["atualizado"] or "", reverse=True)
    skills_dp = (db.get("darkplanner_cloud") or {}).get("skills") or []
    return jsonify({"videos": out[:30], "opcoes_padrao": estudio.OPCOES_PADRAO, "etapas": [{"id": k, "nome": n} for k, n, _ in estudio.ETAPAS],
                    "tem_gemini": reallab.tem_gemini(), "tem_claude": claude.disponivel(), "skills_dp": skills_dp})


@app.route("/api/estudio/novo", methods=["POST"])
def estudio_novo():
    import json as _json

    d = _json.loads(request.form.get("dados") or "{}") if request.form else (request.json or {})
    f_audio, f_srt = request.files.get("audio"), request.files.get("srt")
    titulo = (d.get("titulo") or "").strip()
    roteiro = (d.get("roteiro") or "").strip()
    if not titulo and f_audio:
        titulo = os.path.splitext(f_audio.filename or "")[0][:80]
    if not titulo and not roteiro:
        return erro("Escreva o título (ou cole o roteiro).")
    if f_audio and not roteiro and not f_srt and not reallab.tem_gemini():
        return erro("Com o seu áudio sem legenda, o app precisa do Gemini para tirar o texto. Envie a .srt junto ou cole o roteiro.")
    if not f_audio and not roteiro and not claude.tem_ia():
        return erro("Para escrever o roteiro sozinho o Estúdio precisa de uma chave do Gemini (Conexões). Ou cole o roteiro pronto.")
    cid = d.get("channel_id", "")
    vid_existente = (d.get("video_id") or "").strip()
    dp_reg = None
    if not vid_existente and cid:
        try:
            dp_reg = darkplanner_sync.criar_video_dp(
                cid, titulo or roteiro.split(".")[0][:80], notas=d.get("contexto", "")
            )
        except Exception as e:
            print("Aviso ao criar vídeo do Estúdio no DarkPlanner:", e)
    with Tx() as db:
        v = find(db["videos"], vid_existente) if vid_existente else None
        if not v:
            v = storage.new_video(cid, titulo or roteiro.split(".")[0][:80])
            if dp_reg and dp_reg.get("id"):
                v["id"] = dp_reg["id"]
                v["dp_video"] = dp_reg
            db["videos"].append(v)
        else:
            if titulo:
                v["titulo"] = titulo
            if cid:
                v["channel_id"] = cid
        v["briefing"]["duracao_min"] = float(d.get("duracao_min") or 10)
        v["briefing"]["contexto"] = d.get("contexto", "") or v["briefing"].get("contexto", "")
        v["briefing"]["referencias"] = d.get("referencias", "") or v["briefing"].get("referencias", "")
        if d.get("tipo_narrativa"):
            v["briefing"]["tipo_narrativa"] = d["tipo_narrativa"]
        if roteiro:
            v["roteiro"] = roteiro
            v["etapas"]["roteiro"] = True
            threading.Thread(target=darkplanner_sync.salvar_roteiro_dp, args=(cid, v["id"], roteiro), daemon=True).start()
        v["etapas"]["briefing"] = True
        if f_audio:
            rel, path = _salvar_upload(v["id"], f_audio, "narracao_propria")
            v["narracao"], v["narracao_origem"] = rel, "upload"
            v["narracao_duracao"] = render.duracao_midia(path)
            v["etapas"]["narracao"] = True
        if f_srt:
            rel, path = _salvar_upload(v["id"], f_srt, "legenda_propria")
            v["srt_proprio"] = rel
            if not roteiro:
                txt = " ".join(t for _, _, t in render._ler_srt(path)).strip()
                if txt:
                    v["roteiro"] = txt
                    v["etapas"]["roteiro"] = True
        if d.get("ideia_id"):
            it = find(db["ideas"], d["ideia_id"])
            if it:
                it["usada"] = True
        vid = v["id"]
    try:
        estudio.iniciar(vid, d.get("opcoes") or {})
    except RuntimeError as e:
        return erro(str(e))
    return jsonify({"ok": True, "id": vid})


@app.route("/api/estudio/<vid>/<acao>", methods=["POST"])
def estudio_acao(vid, acao):
    d = request.json or {}
    try:
        if acao == "iniciar":
            estudio.iniciar(vid, d.get("opcoes") or {}, d.get("refazer") or None)
        elif acao == "pausar":
            estudio.pausar(vid)
        elif acao == "continuar":
            estudio.continuar(vid)
        elif acao == "parar":
            estudio.parar(vid)
        elif acao == "abrir_entrega":
            v = find(storage.load()["videos"], vid) or {}
            p = v.get("entrega") or storage.video_dir(vid)
            if os.name == "nt":
                os.startfile(p)  # type: ignore[attr-defined]
            return jsonify({"ok": True, "pasta": p})
        else:
            return erro("Ação inválida", 404)
    except RuntimeError as e:
        return erro(str(e))
    return jsonify(estudio.status(vid))


@app.route("/api/estudio/<vid>/status")
def estudio_status(vid):
    return jsonify(estudio.status(vid))


@app.route("/api/estudio/<vid>/thumb")
def estudio_thumb(vid):
    v = find(storage.load()["videos"], vid) or {}
    if not v.get("thumbs"):
        return erro("Sem thumbnail", 404)
    p = os.path.join(storage.video_dir(vid), "thumbs", v["thumbs"][0]["arquivo"])
    return send_file(p) if os.path.exists(p) else erro("Sem thumbnail", 404)


@app.route("/api/estudio/<vid>/qa/<int:n>")
def estudio_qa_frame(vid, n):
    p = os.path.join(storage.video_dir(vid), "qa", f"cena_{n:03d}.jpg")
    return send_file(p) if os.path.exists(p) else erro("Sem quadro", 404)


@app.route("/api/projetos-criados/verificar", methods=["POST"])
def api_projetos_criados_verificar():
    d = request.get_json(silent=True) or {}
    try:
        res = darkplanner_sync.verificar_projeto_criado_completo(
            titulo=(d.get("titulo") or "").strip(),
            vid=(d.get("vid") or "").strip(),
            slug=(d.get("slug") or "").strip(),
            pasta=(d.get("pasta") or "").strip(),
            auto_reparar=bool(d.get("auto_reparar", d.get("corrigir_automatico", True))),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/projetos-criados/deletar", methods=["POST"])
def api_projetos_criados_deletar():
    d = request.get_json(silent=True) or {}
    try:
        res = darkplanner_sync.deletar_projeto_criado_completo(
            titulo=(d.get("titulo") or "").strip(),
            vid=(d.get("vid") or "").strip(),
            slug=(d.get("slug") or "").strip(),
            pasta=(d.get("pasta") or "").strip(),
            sp_id=(d.get("sp_id") or "").strip(),
            apagar_arquivos_disco=bool(d.get("apagar_arquivos_disco", True)),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


@app.route("/api/youtube-cloner/desvincular", methods=["POST"])
def api_youtube_cloner_desvincular():
    d = request.get_json(silent=True) or {}
    try:
        res = darkplanner_sync.desvincular_clone_youtube_canal(
            canal_id=(d.get("canal_id") or "").strip(),
            vid=(d.get("vid") or "").strip(),
        )
        return jsonify(res)
    except Exception as e:
        return erro(str(e))


def _navegadores():
    pf, pf86, local = os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.environ.get("LOCALAPPDATA", "")
    return [
        os.path.join(pf, r"Google\Chrome\Application\chrome.exe"),
        os.path.join(pf86, r"Google\Chrome\Application\chrome.exe"),
        os.path.join(local, r"Google\Chrome\Application\chrome.exe"),
        os.path.join(pf86, r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(pf, r"Microsoft\Edge\Application\msedge.exe"),
        "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
    ]


def abrir_janela(url):
    perfil = os.path.join(storage.DATA_DIR, "janela-app")
    for exe in _navegadores():
        if exe and os.path.exists(exe):
            return subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={perfil}", "--window-size=1500,950",
                                     "--disk-cache-size=1", "--no-first-run", "--no-default-browser-check", "--disable-features=Translate",
                                     "--autoplay-policy=no-user-gesture-required"])  # a música de abertura toca sozinha
    webbrowser.open(url)
    return None


def _travar_instancia():
    """Garante uma Fábrica Dark só por vez (dois cliques no atalho abriam duas, gerando o mesmo vídeo em dobro)."""
    f = open(os.path.join(storage.DATA_DIR, "app.lock"), "a+")
    try:
        if os.name == "nt":
            import msvcrt

            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return None
    return f  # fica aberto enquanto o app roda; o Windows solta sozinho quando o processo termina


def _gerando():
    """Tem vídeo sendo gerado ou montado agora?"""
    etapa7_ativa = False
    try:
        etapa7_ativa = bool(getattr(darkplanner_sync, "tem_etapa7_rodando_local", lambda: False)())
    except Exception:
        etapa7_ativa = False
    return (
        etapa7_ativa
        or any(j.get("rodando") for j in list(estudio.JOBS.values()))
        or any(j.get("rodando") for j in list(render.JOBS.values()))
    )


def _porta_ocupada():
    import socket

    with socket.socket() as so:
        so.settimeout(0.5)
        return so.connect_ex(("127.0.0.1", PORTA)) == 0


if __name__ == "__main__":
    import time as _time

    # sem console (pythonw): manda os registros para data/registro.txt
    os.makedirs(storage.DATA_DIR, exist_ok=True)
    if sys.stdout is None or sys.stderr is None or "--app" in sys.argv:
        log = open(os.path.join(storage.DATA_DIR, "registro.txt"), "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = log
    url = f"http://127.0.0.1:{PORTA}"
    _TRAVA = _travar_instancia()
    if _TRAVA is None:  # já tem uma Fábrica Dark rodando: só mostra a janela dela
        for _ in range(100):
            if _porta_ocupada():
                break
            _time.sleep(0.1)
        abrir_janela(url)
        sys.exit(0)
    storage.load()
    from core import atualizador as _atualizador
    threading.Thread(target=_atualizador.sincronizar_ao_iniciar, daemon=True).start()
    threading.Thread(target=lambda: darkplanner_sync.sincronizar_tudo(forcar=True), daemon=True).start()
    if hasattr(darkplanner_sync, "iniciar_worker_fila_etapa7_nuvem_pc"):
        darkplanner_sync.iniciar_worker_fila_etapa7_nuvem_pc()

    def _loop_auto_sync_nuvem():
        while True:
            _time.sleep(20)
            try:
                if not _gerando():
                    _atualizador.sincronizar_da_nuvem_darkplanner(auto_reiniciar=True)
            except Exception:
                pass

    threading.Thread(target=_loop_auto_sync_nuvem, daemon=True).start()
    if _porta_ocupada():  # já está aberta: só mostra a janela de novo
        abrir_janela(url)
        sys.exit(0)
    CELULAR_ESTADO["rede"] = True
    threading.Thread(target=_liberar_firewall_windows, daemon=True).start()
    if storage.load()["settings"].get("celular_ativo", True):
        threading.Thread(target=lambda: _iniciar_tunel_celular(aguardar_s=0), daemon=True).start()
    print(f"\n  FÁBRICA DARK rodando em {url} , http://{_ip_local()}:{PORTA}/celular e http://127.0.0.1:5173\n  (feche esta janela para desligar)\n")
    threading.Thread(target=lambda: app.run(host="0.0.0.0", port=5173, debug=False, threaded=True, use_reloader=False), daemon=True).start()
    if "--sem-navegador" in sys.argv:
        app.run(host="0.0.0.0", port=PORTA, debug=False, threaded=True, use_reloader=False)
        sys.exit(0)
    servidor = threading.Thread(target=lambda: app.run(host="0.0.0.0", port=PORTA, debug=False, threaded=True, use_reloader=False), daemon=True)
    servidor.start()
    for _ in range(50):
        if _porta_ocupada():
            break
        _time.sleep(0.1)
    def _retomar():
        """Se o app foi fechado no meio de uma geração do Estúdio, continua sozinho."""
        _time.sleep(3)
        try:
            for v in storage.load()["videos"]:
                est = v.get("estudio") or {}
                if any(e.get("status") == "rodando" for e in (est.get("etapas") or {}).values()):
                    print("Retomando o Estúdio:", v["titulo"])
                    estudio.iniciar(v["id"])
        except Exception as e:
            print("Não consegui retomar:", e)

    threading.Thread(target=_retomar, daemon=True).start()

    def _atualizar_ytdlp():
        """O YouTube muda direto e o yt-dlp antigo passa a baixar arquivos vazios: atualiza 1x por dia, quieto."""
        marca = os.path.join(storage.DATA_DIR, "ytdlp_atualizado.txt")
        hoje = _time.strftime("%Y-%m-%d")
        try:
            if os.path.exists(marca) and open(marca).read().strip() == hoje:
                return
            flags = 0x08000000 if os.name == "nt" else 0
            py = sys.executable.replace("pythonw.exe", "python.exe")
            subprocess.run([py, "-m", "pip", "install", "-U", "-q", "yt-dlp[default]"], capture_output=True, timeout=600, creationflags=flags)
            subprocess.run([py, "-m", "pip", "install", "-U", "-q", "deno"], capture_output=True, timeout=600, creationflags=flags)
            with open(marca, "w") as f:
                f.write(hoje)
            print("yt-dlp atualizado")
        except Exception as e:
            print("Não consegui atualizar o yt-dlp:", e)

    threading.Thread(target=_atualizar_ytdlp, daemon=True).start()
    inicio = _time.time()
    proc = abrir_janela(url)
    if proc is not None:
        proc.wait()
    if proc is None or _time.time() - inicio < 5:
        servidor.join()  # o navegador não ficou preso à janela: mantém o servidor ligado
    # fechou a janela do app: se tiver vídeo gerando, termina em segundo plano antes de desligar
    # (antes desligava na hora e a geração recomeçava a etapa do zero quando o app abria de novo)
    if _gerando():
        print("Janela fechada com geração em andamento: continuo em segundo plano até terminar")
    while _gerando() or _time.time() - ULTIMO_PEDIDO_PC[0] < 180:  # 180 s: a janela foi reaberta pelo atalho
        _time.sleep(5)
    os._exit(0)  # nada gerando e nenhuma janela aberta: desliga tudo
