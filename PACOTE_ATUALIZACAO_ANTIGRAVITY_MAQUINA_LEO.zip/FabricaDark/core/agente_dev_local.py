"""Agente Desenvolvedor Autônomo Local (Estilo Antigravity / Codex IDE dentro do Chat da Fábrica Dark).

Permite que o usuário converse no Chat da Fábrica Dark exatamente como se estivesse dando comandos
diretamente aqui no Antigravity:
- Lê arquivos reais do código-fonte (`app.py`, `core/*.py`, `static/*.js`, `static/*.html`, `static/*.css`);
- Pesquisa símbolos, rotas e funções (`buscar_codigo`);
- Inspeciona tracebacks Python reais capturados pelo servidor, logs das etapas e status do DarkPlanner Desktop;
- Edita/cria arquivos de código com backup automático + validação de sintaxe (`compile` Python / `node --check` JS)
  + hot-reload imediato em memória (`importlib.reload`) + invalidação automática de cache do frontend;
- Executa diagnósticos e ajustes diretos no banco (`data/db.json`), nos canais e na integração com
  `C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner\\Dark Planner.exe`.
"""
import ast
import collections
import datetime
import fnmatch
import importlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from contextlib import redirect_stdout

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKUP_DIR = os.path.join(BASE_DIR, "data", "backups_agente")

_LOCK_ERROS = threading.Lock()
_ERROS_RUNTIME_RECENTES = collections.deque(maxlen=35)
_HISTORICO_EDICOES_AGENTE = collections.deque(maxlen=50)

PASTAS_IGNORADAS = {
    ".venv",
    "venv",
    "__pycache__",
    ".git",
    "node_modules",
    "janela-app",
    "audios_dp",
    "skill6_pacotes",
    "videos",
    "backups_agente",
}
CAMINHOS_PROTEGIDOS_ESCRITA = {
    "data/app.lock",
    "data/registro.txt",
}
EXTENSOES_CODIGO_BUSCA = (".py", ".js", ".html", ".css", ".bat", ".ps1", ".md", ".txt")


def registrar_excecao_runtime(metodo="", rota="", tb_texto="", resumo=""):
    """Registra qualquer exceção ou erro HTTP 4xx/5xx ocorrido no servidor Flask para o Agente diagnosticar e corrigir."""
    with _LOCK_ERROS:
        _ERROS_RUNTIME_RECENTES.append({
            "hora": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "ts": time.time(),
            "metodo": str(metodo or ""),
            "rota": str(rota or ""),
            "resumo": str(resumo or "")[:300],
            "traceback": str(tb_texto or "")[-3500:],
        })


def obter_erros_runtime_recentes(limite=8):
    with _LOCK_ERROS:
        itens = list(_ERROS_RUNTIME_RECENTES)[-max(1, int(limite or 8)):]
    return itens


def _resolver_caminho_seguro(caminho_rel):
    """Resolve `caminho_rel` estritamente dentro da pasta raiz `FabricaDark` (`BASE_DIR`)."""
    raw = str(caminho_rel or "").strip().replace("\\", "/")
    while raw.startswith("./"):
        raw = raw[2:]
    if raw.startswith("FabricaDark/"):
        raw = raw[len("FabricaDark/"):]
    raw = raw.lstrip("/")
    alvo = os.path.abspath(os.path.join(BASE_DIR, *raw.split("/"))) if raw else BASE_DIR
    base_norm = os.path.normcase(os.path.abspath(BASE_DIR))
    alvo_norm = os.path.normcase(alvo)
    if alvo_norm != base_norm and not alvo_norm.startswith(base_norm + os.sep):
        raise ValueError(f"Caminho fora do workspace FabricaDark bloqueado: {caminho_rel}")
    rel_limpo = os.path.relpath(alvo, BASE_DIR).replace("\\", "/")
    if rel_limpo == ".":
        rel_limpo = ""
    return alvo, rel_limpo


def _validar_permissao_escrita(rel_limpo):
    if not rel_limpo:
        raise ValueError("Especifique um arquivo válido dentro da FabricaDark.")
    partes = rel_limpo.split("/")
    if partes[0] in (".venv", "venv", ".git", "janela-app"):
        raise ValueError(f"Pasta protegida contra edição direta: {partes[0]}")
    if rel_limpo in CAMINHOS_PROTEGIDOS_ESCRITA:
        raise ValueError(f"Arquivo protegido contra sobrescrita direta: {rel_limpo}")


def _validar_sintaxe_conteudo(rel_limpo, conteudo):
    """Valida sintaxe antes de gravar no disco:
    - `.py`: `ast.parse` + `compile`
    - `.js`: `node --check` (se Node estiver disponível)
    - `.json`: `json.loads`
    Retorna `(True, "")` ou `(False, mensagem_erro_detalhada)`."""
    ext = os.path.splitext(rel_limpo)[1].lower()
    if ext == ".py":
        try:
            ast.parse(conteudo, filename=rel_limpo)
            compile(conteudo, rel_limpo, "exec")
            return True, ""
        except SyntaxError as e_syn:
            return False, f"SyntaxError em {rel_limpo} (linha {e_syn.lineno}, col {e_syn.offset}): {e_syn.msg}\nTrecho: {e_syn.text or ''}"
        except Exception as e_py:
            return False, f"Erro de compilação Python em {rel_limpo}: {e_py}"

    if ext == ".json":
        try:
            json.loads(conteudo)
            return True, ""
        except Exception as e_jsn:
            return False, f"JSON inválido em {rel_limpo}: {e_jsn}"

    if ext == ".js":
        bin_node = shutil.which("node")
        if bin_node:
            tf_path = ""
            try:
                with tempfile.NamedTemporaryFile(mode="w", suffix=".js", delete=False, encoding="utf-8") as tf:
                    tf.write(conteudo)
                    tf_path = tf.name
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000) if os.name == "nt" else 0
                r_chk = subprocess.run(
                    [bin_node, "--check", tf_path],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="ignore",
                    timeout=8,
                    creationflags=flags,
                )
                if r_chk.returncode != 0:
                    err_node = (r_chk.stderr or r_chk.stdout or "").replace(tf_path, rel_limpo).strip()
                    return False, f"Erro de sintaxe JavaScript em {rel_limpo}:\n{err_node[:700]}"
            except Exception:
                pass
            finally:
                if tf_path and os.path.exists(tf_path):
                    try:
                        os.remove(tf_path)
                    except Exception:
                        pass
    return True, ""


def _salvar_backup_arquivo(abs_path, rel_limpo):
    if not os.path.isfile(abs_path):
        return ""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    nome_seguro = rel_limpo.replace("/", "__")
    bak_path = os.path.join(BACKUP_DIR, f"{ts}__{nome_seguro}.bak")
    shutil.copy2(abs_path, bak_path)
    # Mantém no máximo 40 backups recentes para não crescer indefinidamente
    try:
        baks = sorted(
            [os.path.join(BACKUP_DIR, f) for f in os.listdir(BACKUP_DIR) if f.endswith(".bak")],
            key=lambda p: os.path.getmtime(p),
        )
        for p_old in baks[:-40]:
            try:
                os.remove(p_old)
            except Exception:
                pass
    except Exception:
        pass
    return bak_path


def _pos_edicao_hot_reload_e_versao(rel_limpo, conteudo):
    """Após editar um arquivo de código:
    1. Atualiza `core/versao.py` com timestamp novo para que o sincronizador de nuvem não sobrescreva a edição local;
    2. Espelha em `D:\\AUTOMAÇÃO DARK\\MAQUINA LEO\\FabricaDark` no Windows caso esteja rodando de outra pasta;
    3. Faz hot-reload automático em `sys.modules` se for `core/*.py`."""
    info = {"recarregou_python": False, "recarregar_frontend": False, "nova_versao": ""}

    # 1. Espelha na pasta fixa Windows se existir e for diferente de BASE_DIR
    if os.name == "nt" and os.path.exists("D:\\"):
        try:
            from core import versao as _v_mod
            alvo_win = getattr(_v_mod, "PASTA_FIXA_WINDOWS", r"D:\AUTOMAÇÃO DARK\MAQUINA LEO\FabricaDark")
            if alvo_win and os.path.isdir(os.path.dirname(alvo_win)):
                if os.path.normcase(os.path.abspath(BASE_DIR)) != os.path.normcase(os.path.abspath(alvo_win)):
                    dst_win = os.path.join(alvo_win, *rel_limpo.split("/"))
                    os.makedirs(os.path.dirname(dst_win), exist_ok=True)
                    with open(dst_win, "w", encoding="utf-8", newline="\n") as fw:
                        fw.write(conteudo)
        except Exception:
            pass

    # 2. Bump de versão local para blindar contra reversão acidental de cache antigo
    if rel_limpo != "core/versao.py" and not rel_limpo.startswith("data/"):
        try:
            from core import versao as _v_mod
            nova_v = datetime.datetime.now().strftime("2026.11.%d.%H%M%S")
            arq_v = os.path.join(BASE_DIR, "core", "versao.py")
            if os.path.isfile(arq_v):
                with open(arq_v, "r", encoding="utf-8") as fv:
                    txt_v = fv.read()
                txt_v_novo = re.sub(r'VERSAO\s*=\s*"[^"]+"', f'VERSAO = "{nova_v}"', txt_v, count=1)
                if txt_v_novo != txt_v:
                    with open(arq_v, "w", encoding="utf-8", newline="\n") as fv_w:
                        fv_w.write(txt_v_novo)
                _v_mod.VERSAO = nova_v
                info["nova_versao"] = nova_v
        except Exception:
            pass

    # 3. Hot-reload imediato se for módulo em `core/`
    if rel_limpo.startswith("core/") and rel_limpo.endswith(".py"):
        nome_mod = "core." + os.path.splitext(os.path.basename(rel_limpo))[0]
        if nome_mod in sys.modules and nome_mod != "core.agente_dev_local":
            try:
                importlib.reload(sys.modules[nome_mod])
                info["recarregou_python"] = True
            except Exception as e_rel:
                info["aviso_reload"] = str(e_rel)[:200]

    # 4. Marca invalidação automática para arquivos estáticos (HTML / JS / CSS)
    if rel_limpo.startswith("static/") and rel_limpo.endswith((".js", ".html", ".css")):
        info["recarregar_frontend"] = True
        # Toca mtime do v4.js para garantir cache-bust imediato na rota `/`
        try:
            v4_p = os.path.join(BASE_DIR, "static", "v4.js")
            if os.path.isfile(v4_p):
                os.utime(v4_p, None)
        except Exception:
            pass

    return info


# ==============================================================================
# FERRAMENTAS REAIS DO AGENTE (IGUAIS ÀS DO ANTIGRAVITY IDE)
# ==============================================================================

def tool_listar_arquivos(pasta_rel=""):
    abs_p, rel_p = _resolver_caminho_seguro(pasta_rel)
    if not os.path.isdir(abs_p):
        return {"ok": False, "erro": f"Pasta não encontrada: {pasta_rel}"}
    itens = []
    for root, dirs, files in os.walk(abs_p):
        dirs[:] = sorted(d for d in dirs if d not in PASTAS_IGNORADAS)
        for fn in sorted(files):
            if fn.endswith((".pyc", ".bak", ".lock", ".novo")):
                continue
            full = os.path.join(root, fn)
            rel_f = os.path.relpath(full, BASE_DIR).replace("\\", "/")
            try:
                tam = os.path.getsize(full)
                itens.append({"arquivo": rel_f, "bytes": tam})
            except Exception:
                itens.append({"arquivo": rel_f})
            if len(itens) >= 120:
                break
        if len(itens) >= 120:
            break
    return {"ok": True, "pasta": rel_p or ".", "total": len(itens), "arquivos": itens}


def tool_buscar_codigo(padrao, pasta_rel="", filtro_arquivo="", max_resultados=35):
    if not padrao:
        return {"ok": False, "erro": "Informe `padrao` (texto ou regex) para pesquisar no código."}
    abs_p, _ = _resolver_caminho_seguro(pasta_rel)
    try:
        rx = re.compile(str(padrao), re.IGNORECASE)
    except re.error:
        rx = re.compile(re.escape(str(padrao)), re.IGNORECASE)

    resultados = []
    max_res = max(1, min(80, int(max_resultados or 35)))

    if os.path.isfile(abs_p):
        arquivos_alvo = [abs_p]
    else:
        arquivos_alvo = []
        for root, dirs, files in os.walk(abs_p):
            dirs[:] = sorted(d for d in dirs if d not in PASTAS_IGNORADAS)
            for fn in sorted(files):
                if not fn.endswith(EXTENSOES_CODIGO_BUSCA):
                    continue
                if filtro_arquivo and not fnmatch.fnmatch(fn, filtro_arquivo):
                    continue
                arquivos_alvo.append(os.path.join(root, fn))

    for full in arquivos_alvo:
        rel_f = os.path.relpath(full, BASE_DIR).replace("\\", "/")
        try:
            if os.path.getsize(full) > 4 * 1024 * 1024:
                continue
            with open(full, "r", encoding="utf-8", errors="ignore") as f:
                for idx_ln, ln in enumerate(f, 1):
                    if rx.search(ln):
                        resultados.append({
                            "arquivo": rel_f,
                            "linha": idx_ln,
                            "trecho": ln.rstrip("\r\n")[:220],
                        })
                        if len(resultados) >= max_res:
                            return {"ok": True, "padrao": padrao, "resultados": resultados, "truncado": True}
        except Exception:
            continue

    return {"ok": True, "padrao": padrao, "resultados": resultados, "truncado": False}


def tool_ler_arquivo(caminho_rel, linha_ini=1, linha_fim=180):
    abs_p, rel_p = _resolver_caminho_seguro(caminho_rel)
    if not os.path.isfile(abs_p):
        return {"ok": False, "erro": f"Arquivo não encontrado: {caminho_rel}"}
    try:
        with open(abs_p, "r", encoding="utf-8", errors="replace") as f:
            linhas = f.read().splitlines()
    except Exception as e_r:
        return {"ok": False, "erro": f"Erro ao ler {rel_p}: {e_r}"}

    total = len(linhas)
    ini = max(1, int(linha_ini or 1))
    fim = min(total, max(ini, int(linha_fim or (ini + 179))))
    if fim - ini > 260:
        fim = ini + 260

    numeradas = "\n".join(f"{i}: {linhas[i - 1]}" for i in range(ini, fim + 1))
    if len(numeradas) > 22000:
        numeradas = numeradas[:22000] + "\n... (trecho truncado por tamanho; leia em faixas menores)"
    return {
        "ok": True,
        "arquivo": rel_p,
        "total_linhas": total,
        "exibindo_linhas": f"{ini}-{fim}",
        "conteudo": numeradas,
    }


def tool_editar_arquivo(caminho_rel, trecho_antigo, trecho_novo, descricao="", substituir_todos=False):
    abs_p, rel_p = _resolver_caminho_seguro(caminho_rel)
    _validar_permissao_escrita(rel_p)
    if not os.path.isfile(abs_p):
        return {"ok": False, "erro": f"Arquivo não existe: {rel_p}. Use `escrever_arquivo` para criar um arquivo novo."}
    if not trecho_antigo:
        return {"ok": False, "erro": "`trecho_antigo` não pode ser vazio em `editar_arquivo`."}

    with open(abs_p, "r", encoding="utf-8", errors="replace") as f:
        conteudo_orig = f.read()

    orig_lf = conteudo_orig.replace("\r\n", "\n")
    antigo_lf = str(trecho_antigo).replace("\r\n", "\n")
    novo_lf = str(trecho_novo if trecho_novo is not None else "").replace("\r\n", "\n")

    ocorrencias = orig_lf.count(antigo_lf)
    if ocorrencias == 0:
        # Tenta match ignorando espaços à direita de cada linha caso a IA tenha omitido trailing spaces
        linhas_orig = [l.rstrip() for l in orig_lf.split("\n")]
        linhas_ant = [l.rstrip() for l in antigo_lf.strip("\n").split("\n")]
        bloco_busca = "\n".join(linhas_ant)
        texto_norm = "\n".join(linhas_orig)
        if bloco_busca and bloco_busca in texto_norm:
            # Localiza índice de linha exato
            n_ant = len(linhas_ant)
            orig_raw_lines = orig_lf.split("\n")
            idx_achado = -1
            for i_s in range(0, len(linhas_orig) - n_ant + 1):
                if linhas_orig[i_s:i_s + n_ant] == linhas_ant:
                    idx_achado = i_s
                    break
            if idx_achado >= 0:
                antes = orig_raw_lines[:idx_achado]
                depois = orig_raw_lines[idx_achado + n_ant:]
                conteudo_novo = "\n".join(antes + [novo_lf] + depois)
                ocorrencias = 1
            else:
                return {
                    "ok": False,
                    "erro": f"`trecho_antigo` não encontrado exatamente em `{rel_p}`. Chame `ler_arquivo` antes para ver as linhas exatas.",
                }
        else:
            return {
                "ok": False,
                "erro": f"`trecho_antigo` não encontrado em `{rel_p}`. Chame `ler_arquivo` nas linhas desejadas antes de editar.",
            }
    else:
        if ocorrencias > 1 and not substituir_todos:
            return {
                "ok": False,
                "erro": f"`trecho_antigo` aparece {ocorrencias} vezes em `{rel_p}`. Inclua mais linhas de contexto para tornar único ou passe `substituir_todos: true`.",
            }
        conteudo_novo = orig_lf.replace(antigo_lf, novo_lf) if substituir_todos else orig_lf.replace(antigo_lf, novo_lf, 1)

    ok_syn, msg_syn = _validar_sintaxe_conteudo(rel_p, conteudo_novo)
    if not ok_syn:
        return {
            "ok": False,
            "erro_sintaxe": True,
            "erro": f"Edição bloqueada automaticamente porque geraria erro de sintaxe! Corrija e tente novamente:\n{msg_syn}",
        }

    bak = _salvar_backup_arquivo(abs_p, rel_p)
    tmp_p = abs_p + ".agente_tmp"
    with open(tmp_p, "w", encoding="utf-8", newline="\n") as fw:
        fw.write(conteudo_novo)
    os.replace(tmp_p, abs_p)

    pos_info = _pos_edicao_hot_reload_e_versao(rel_p, conteudo_novo)
    reg = {
        "hora": datetime.datetime.now().strftime("%H:%M:%S"),
        "arquivo": rel_p,
        "descricao": str(descricao or f"Editado {rel_p}")[:180],
        "backup": os.path.basename(bak) if bak else "",
        **pos_info,
    }
    _HISTORICO_EDICOES_AGENTE.append(reg)
    return {"ok": True, **reg}


def tool_escrever_arquivo(caminho_rel, conteudo, descricao=""):
    abs_p, rel_p = _resolver_caminho_seguro(caminho_rel)
    _validar_permissao_escrita(rel_p)
    conteudo_lf = str(conteudo if conteudo is not None else "").replace("\r\n", "\n")

    ok_syn, msg_syn = _validar_sintaxe_conteudo(rel_p, conteudo_lf)
    if not ok_syn:
        return {
            "ok": False,
            "erro_sintaxe": True,
            "erro": f"Gravação bloqueada por erro de sintaxe:\n{msg_syn}",
        }

    bak = _salvar_backup_arquivo(abs_p, rel_p) if os.path.isfile(abs_p) else ""
    os.makedirs(os.path.dirname(abs_p), exist_ok=True)
    tmp_p = abs_p + ".agente_tmp"
    with open(tmp_p, "w", encoding="utf-8", newline="\n") as fw:
        fw.write(conteudo_lf)
    os.replace(tmp_p, abs_p)

    pos_info = _pos_edicao_hot_reload_e_versao(rel_p, conteudo_lf)
    reg = {
        "hora": datetime.datetime.now().strftime("%H:%M:%S"),
        "arquivo": rel_p,
        "descricao": str(descricao or f"Gravado {rel_p}")[:180],
        "backup": os.path.basename(bak) if bak else "",
        **pos_info,
    }
    _HISTORICO_EDICOES_AGENTE.append(reg)
    return {"ok": True, **reg}


def tool_inspecionar_ambiente():
    """Inspeciona o estado ao vivo da Fábrica Dark, erros recentes, canais e conexão com DarkPlanner Desktop."""
    from core import antigravity_codex, darkplanner_sync, storage, versao

    db = storage.load()
    exe_dp = darkplanner_sync._localizar_exe_darkplanner_desktop()
    porta_cdp, ws_cdp = darkplanner_sync._descobrir_porta_cdp_darkplanner()
    ponte_dp = darkplanner_sync._ler_ponte_local_dp(incluir_scan_portas=False) or {}
    proc_dp = darkplanner_sync._processo_darkplanner_rodando_windows()
    api_7812 = darkplanner_sync._dp_desktop_api_real_ativa()

    canais_info = [
        {
            "id": c.get("id"),
            "nome": c.get("nome"),
            "idioma": c.get("idioma"),
            "modo_midia_custom": c.get("modo_midia_custom") or "",
            "proporcao_midia": c.get("proporcao_midia") or {},
            "estilo_visual": (c.get("estilo_visual") or "")[:120],
            "formato_video_custom": (c.get("formato_video_custom") or "")[:120],
        }
        for c in (db.get("channels") or [])
    ]

    return {
        "ok": True,
        "plataforma": sys.platform,
        "os_name": os.name,
        "versao_fabrica_dark": getattr(versao, "VERSAO", ""),
        "workspace_dir": BASE_DIR,
        "darkplanner_desktop": {
            "exe_path": exe_dp,
            "exe_existe_no_disco": os.path.isfile(exe_dp) if os.name == "nt" else None,
            "processo_rodando": proc_dp,
            "api_7812_ativa": api_7812,
            "porta_cdp": porta_cdp,
            "cdp_ws_conectado": bool(ws_cdp),
            "ponte_studio_porta": ponte_dp.get("DARKPLANNER_PONTE_PORT") or None,
        },
        "vinculacao_ia": antigravity_codex.obter_status_vinculacao(db),
        "erros_runtime_recentes": obter_erros_runtime_recentes(limite=6),
        "ultimas_edicoes_agente": list(_HISTORICO_EDICOES_AGENTE)[-6:],
        "canais": canais_info,
    }


def tool_executar_python_diagnostico(codigo_python):
    """Executa código Python seguro de diagnóstico/manutenção de dados no contexto da Fábrica Dark."""
    cod = str(codigo_python or "").strip()
    if not cod:
        return {"ok": False, "erro": "Código Python vazio."}
    # Bloqueia comandos destrutivos de processo/disco fora de contexto
    proibidos = ("taskkill", "stop-process", "shutil.rmtree('/'", "os._exit", "sys.exit")
    cod_low = cod.lower()
    if any(p in cod_low for p in proibidos):
        return {"ok": False, "erro": "Comando bloqueado pelas regras de segurança (nunca fechar processos do usuário)."}

    from core import antigravity_codex, chaves, darkplanner_sync, pauta, prompts, storage
    from core.storage import Tx

    ns = {
        "__builtins__": __builtins__,
        "os": os,
        "re": re,
        "json": json,
        "time": time,
        "BASE_DIR": BASE_DIR,
        "storage": storage,
        "Tx": Tx,
        "darkplanner_sync": darkplanner_sync,
        "prompts": prompts,
        "pauta": pauta,
        "chaves": chaves,
        "antigravity_codex": antigravity_codex,
        "resultado": None,
    }
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            exec(compile(cod, "<agente_diagnostico>", "exec"), ns, ns)
        out_txt = buf.getvalue().strip()
        res_val = ns.get("resultado")
        if res_val is not None:
            try:
                res_serial = json.loads(json.dumps(res_val, default=str, ensure_ascii=False))
            except Exception:
                res_serial = str(res_val)[:2000]
        else:
            res_serial = None
        return {
            "ok": True,
            "stdout": out_txt[:4000],
            "resultado": res_serial,
        }
    except Exception:
        return {
            "ok": False,
            "stdout": buf.getvalue().strip()[:2000],
            "erro": traceback.format_exc()[-2000:],
        }


def tool_enviar_darkplanner_desktop(mensagem_chat="", titulo_projeto="", nova_conversa=True, chat_modelo_opcao="flash_high"):
    """Abre/foca `C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner\\Dark Planner.exe` e envia diretamente no Chat dele."""
    from core import darkplanner_sync

    msg = str(mensagem_chat or "").strip()
    if not msg and titulo_projeto:
        # Tenta carregar 09_INSTRUCOES_IA_DARKPLANNER.txt já gerada para o projeto
        base_dl = darkplanner_sync.obter_pasta_downloads_darkplanner()
        slug = re.sub(r"[^\w\- ]", "", titulo_projeto).strip()
        for sub in ("creator", "studio"):
            cand_f = os.path.join(base_dl, sub, slug, "09_INSTRUCOES_IA_DARKPLANNER.txt")
            if os.path.isfile(cand_f):
                with open(cand_f, "r", encoding="utf-8", errors="ignore") as f:
                    msg = f.read().strip()
                break
    if not msg:
        return {"ok": False, "erro": "Nenhuma mensagem ou instrução pronta encontrada para enviar ao DarkPlanner Desktop."}

    if os.name == "nt":
        res = darkplanner_sync.abrir_chat_darkplanner_e_colar(
            mensagem_chat=msg,
            auto_enviar=True,
            nova_conversa=bool(nova_conversa),
            chat_modelo_opcao=chat_modelo_opcao or "flash_high",
            forcar_reenvio=True,
            titulo_conversa=titulo_projeto or "Projeto Fábrica Dark",
            auto_reconectar_cdp=True,
            focar_janela=True,
        )
        return res

    sp_rem = f"sp_op_{int(time.time())}"
    darkplanner_sync.enfileirar_etapa7_remoto_nuvem({
        "sp_id": sp_rem,
        "nome_projeto": titulo_projeto or "Comando Fábrica Dark",
        "titulo": titulo_projeto or "Comando Fábrica Dark",
        "chat_modelo_opcao": chat_modelo_opcao or "flash_high",
        "pausado": False,
        "comando_chat_operacional": {
            "mensagem": msg,
            "acao_rapida": "criar_conversa_dp",
            "nome_projeto": titulo_projeto,
            "chat_modelo_opcao": chat_modelo_opcao or "flash_high",
            "nova_conversa": bool(nova_conversa),
        },
        "acao_tecnica": "aguardando_comando_pc",
        "progresso_pct": 25,
        "etapa_atual": f"🌐 Enviando pacote para `Dark Planner.exe` no seu PC ('{titulo_projeto or 'Projeto'}')...",
    })
    return {"ok": True, "enfileirado_pc_windows": True, "sp_id": sp_rem}


# ==============================================================================
# DETECTOR E LOOP MULTI-PASSOS DO AGENTE DESENVOLVEDOR
# ==============================================================================

def deve_usar_agente_dev_codigo(mensagem, modo_agente="", etapas_app=None, logs_recentes_app=None):
    """Retorna True quando o pedido do usuário envolve inspecionar/alterar código, UI, botões, etapas,
    funções do site, corrigir bugs/tracebacks técnicos ou executar comandos como no Antigravity."""
    msg = str(mensagem or "").strip()
    ml = msg.lower()
    if not msg or len(msg) > 2500:
        return False
    if str(modo_agente or "").strip().lower() == "antigravity_codex":
        return True

    gatilhos_dev = (
        "codigo",
        "código",
        "arquivo",
        "app.py",
        "v4.js",
        "app.js",
        "index.html",
        "style.css",
        "darkplanner_sync",
        "botao",
        "botão",
        "botoes",
        "botões",
        "tela",
        "interface",
        "layout",
        "aba ",
        "modal",
        "painel",
        "site",
        "aplicativo",
        "funcao",
        "função",
        "implement",
        "crie ",
        "criar uma ",
        "adicione",
        "adicionar",
        "remova",
        "remover",
        "retire",
        "retirar",
        "altere",
        "alterar",
        "modifique",
        "modificar",
        "conserte",
        "consertar",
        "corrija",
        "corrigir",
        "regularize",
        "regularizar",
        "bug",
        "traceback",
        "exception",
        "typeerror",
        "keyerror",
        "syntaxerror",
        "etapa 7",
        "passo 7",
        "darkplanner desktop",
        "appdata\\local\\programs\\darkplanner",
        "nao esta mandando",
        "não está mandando",
        "nao esta gerando",
        "não está gerando",
        "como voce faz",
        "como você faz",
        "antigravity",
        "codex",
    )
    if any(g in ml for g in gatilhos_dev):
        return True

    # Se há erro real de Python no buffer do servidor e o usuário fala de erro/problema
    if any(k in ml for k in ("erro", "falha", "travou", "deu problema", "nao funciona", "não funciona")):
        if obter_erros_runtime_recentes(limite=2):
            return True
    return False


def _chamar_llm_json_agente(prompt, sistema):
    """Chama a cascata Multi-IA (Gemini -> Antigravity Tokens -> OpenAI Codex -> GPT-4o) e extrai JSON estruturado."""
    from core import antigravity_codex, claude

    provedor = "antigravity+gemini"
    raw_txt = ""
    try:
        res_j = claude.gerar_json(
            prompt,
            sistema=sistema,
            max_tokens=4096,
            temperatura=0.2,
            tarefa="roteiro",
        )
        if isinstance(res_j, dict):
            return res_j, provedor
    except Exception:
        pass

    raw_txt, prov_fb = antigravity_codex.gerar_texto_fallback_cascata(
        prompt=prompt,
        sistema=sistema,
        max_tokens=4096,
        temperatura=0.2,
        json_mode=True,
    )
    if prov_fb:
        provedor = prov_fb
    if raw_txt:
        try:
            m = re.search(r"\{[\s\S]*\}", raw_txt)
            return json.loads(m.group(0) if m else raw_txt), provedor
        except Exception:
            return {"finalizado": True, "resposta_markdown": raw_txt.strip()}, provedor

    return None, provedor


def executar_agente_dev_chat(mensagem, historico=None, contexto_projeto=None, max_passos=5):
    """Executa o loop autônomo estilo Antigravity IDE (até `max_passos` iterações de ferramentas reais)
    diretamente sobre o código e estado da `Fábrica Dark`."""
    ctx = dict(contexto_projeto) if isinstance(contexto_projeto, dict) else {}
    hist = list(historico) if isinstance(historico, list) else []

    erros_srv = obter_erros_runtime_recentes(limite=5)
    hist_resumo = "\n".join(
        f"{'USUÁRIO' if m.get('de') == 'eu' else 'AGENTE'}: {str(m.get('texto') or '')[:600]}"
        for m in hist[-8:]
    )

    sistema_dev = """Você é o **Agente Desenvolvedor Autônomo Antigravity + Codex** integrado diretamente dentro do Chat da **Fábrica Dark**.
O usuário está falando com você exatamente como se estivesse dando um comando no Antigravity IDE!
Você tem ACESSO TOTAL E REAL ao código-fonte e ao ambiente da `Fábrica Dark` através das ferramentas abaixo.

ARQUITETURA DO SISTEMA (MUITO IMPORTANTE):
- Workspace raiz (`FabricaDark`):
  - `app.py`: Servidor Flask (rotas `/api/...`, página principal `/`).
  - `core/darkplanner_sync.py`: Integração com DarkPlanner Cloud e com o **DarkPlanner Desktop** (`C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner\\Dark Planner.exe`, porta API `7812`, CDP `9229`, Ponte `/studio`).
  - `core/antigravity_codex.py`: Cascata Multi-IA (Gemini -> Antigravity Tokens -> OpenAI Codex -> GPT) e ações de canais.
  - `core/prompts.py`, `core/pauta.py`, `core/claude.py`, `core/gemini.py`, `core/thumb.py`, `core/gta_rockstar_media.py`.
  - `static/v4.js`: Esteira 1 Clique (Etapas 1 a 7), Fila de Produção e este Chat (`#fd-dp-live-drawer`).
  - `static/app.js`, `static/index.html`, `static/style.css`: Interface principal, canais, configurações.
  - `data/db.json`: Banco de dados local (canais, vídeos, chaves, settings).
- PAPEL DA FÁBRICA DARK vs DARKPLANNER DESKTOP:
  - A **Fábrica Dark** é a automação das Etapas 1 a 6 (análise de canais, estrutura, roteiro, pacote viral/thumb, áudio MP3 + SRT e prompts/mídias) que leva o pacote pronto no final (Etapa 7) para o Chat do **DarkPlanner Desktop** (`C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner\\Dark Planner.exe`).
  - NUNCA feche nem mate (`taskkill`) o `Dark Planner.exe`!
  - Sempre leia as linhas exatas com `ler_arquivo` ou pesquise com `buscar_codigo` ANTES de chamar `editar_arquivo`!

FERRAMENTAS DISPONÍVEIS (chame de 1 a 4 por passo em `"ferramentas"`):
1. `{"nome": "inspecionar_ambiente", "args": {}}`
2. `{"nome": "listar_arquivos", "args": {"pasta_rel": "core"}}`
3. `{"nome": "buscar_codigo", "args": {"padrao": "termo_ou_regex", "pasta_rel": ""}}`
4. `{"nome": "ler_arquivo", "args": {"caminho_rel": "core/prompts.py", "linha_ini": 1, "linha_fim": 160}}`
5. `{"nome": "editar_arquivo", "args": {"caminho_rel": "static/v4.js", "trecho_antigo": "texto exato atual", "trecho_novo": "novo texto", "descricao": "o que mudou"}}`
6. `{"nome": "escrever_arquivo", "args": {"caminho_rel": "caminho/arquivo.py", "conteudo": "codigo completo", "descricao": "criado/atualizado"}}`
7. `{"nome": "executar_python_diagnostico", "args": {"codigo_python": "db = storage.load()\\nresultado = len(db.get('channels', []))"}}`
8. `{"nome": "enviar_darkplanner_desktop", "args": {"titulo_projeto": "...", "mensagem_chat": "...", "nova_conversa": true}}` (Use SOMENTE se o usuário pediu explicitamente para enviar/abrir agora no DarkPlanner Desktop!).

FORMATO DE RESPOSTA JSON OBRIGATÓRIO:
- Enquanto precisar inspecionar ou editar arquivos:
  `{"finalizado": false, "pensamento": "Vou localizar a função X e ler as linhas...", "ferramentas": [{"nome": "buscar_codigo", "args": {"padrao": "..."}}]}`
- Quando já tiver concluído as inspeções/edições necessárias:
  `{"finalizado": true, "resposta_markdown": "Resumo claro, objetivo e direto em Português do que foi inspecionado/alterado", "reexecutar_etapa_app": ""}`"""

    arquivos_modificados = []
    acoes_resumo = []
    recarregar_frontend = False
    enviado_dp = False
    reexecutar_etapa_app = ""
    provedor_final = "antigravity-dev-agent"
    rastro_passos = []

    resumo_etapas = json.dumps(ctx.get("etapas_app") or [], ensure_ascii=False)[:1200]
    resumo_logs = "\n".join(str(x) for x in (ctx.get("logs_recentes_app") or [])[-15:])[:1500]
    resumo_erros_srv = json.dumps(erros_srv, ensure_ascii=False)[:1800] if erros_srv else "Nenhum traceback recente no servidor."

    for passo in range(max(1, min(6, int(max_passos or 5)))):
        bloco_rastro = ""
        if rastro_passos:
            bloco_rastro = "\n\nRESULTADOS DAS FERRAMENTAS JÁ EXECUTADAS NESTA TAREFA:\n" + json.dumps(
                rastro_passos, ensure_ascii=False
            )[-14000:]

        prompt_passo = f"""CONTEXTO ATUAL DA FÁBRICA DARK:
- Canal selecionado: {ctx.get('canal_nome') or ctx.get('canal_id') or '(nenhum)'} (id={ctx.get('canal_id') or '-'})
- Projeto atual: {ctx.get('nome_projeto') or '(nenhum)'} (vid={ctx.get('vid') or '-'}, sp_id={ctx.get('sp_id') or '-'})
- Etapas na tela: {resumo_etapas}
- Últimos logs na tela:
{resumo_logs or '(vazio)'}
- Tracebacks Python recentes no servidor Flask:
{resumo_erros_srv}

HISTÓRICO DA CONVERSA:
{hist_resumo or '(início)'}

COMANDO ATUAL DO USUÁRIO (Passo {passo + 1}/{max_passos}):
"{mensagem}"{bloco_rastro}

Responda APENAS com o JSON válido (`finalizado: false` com `ferramentas`, ou `finalizado: true` com `resposta_markdown`)."""

        decisao, prov = _chamar_llm_json_agente(prompt_passo, sistema_dev)
        if prov:
            provedor_final = f"agente-dev:{prov}"
        if not isinstance(decisao, dict):
            break

        calls = decisao.get("ferramentas") if isinstance(decisao.get("ferramentas"), list) else []
        if decisao.get("finalizado") or not calls:
            resp_md = str(decisao.get("resposta_markdown") or "").strip()
            if decisao.get("reexecutar_etapa_app"):
                reexecutar_etapa_app = str(decisao.get("reexecutar_etapa_app")).strip()
            if resp_md:
                if arquivos_modificados:
                    lista_arqs = ", ".join(f"`{a}`" for a in dict.fromkeys(arquivos_modificados))
                    resp_md += f"\n\n🛠️ **Arquivos editados e validados ao vivo:** {lista_arqs}"
                if recarregar_frontend:
                    resp_md += "\n🔄 *Interface atualizada — recarregando ativos visuais automaticamente.*"
                arqs_unicos = list(dict.fromkeys(arquivos_modificados))
                return {
                    "ok": True,
                    "modo_agente_dev": True,
                    "provedor": provedor_final,
                    "arquivos_modificados": arqs_unicos,
                    "arquivos_editados": arqs_unicos,
                    "alteracoes": acoes_resumo,
                    "recarregar_frontend": recarregar_frontend,
                    "enviado_direto_chat_dp": enviado_dp,
                    "reexecutar_etapa_app": reexecutar_etapa_app,
                    "resposta": resp_md,
                }
            break

        resultados_rodada = []
        for call in calls[:4]:
            if not isinstance(call, dict):
                continue
            nm = str(call.get("nome") or call.get("tool") or "").strip()
            args = call.get("args") if isinstance(call.get("args"), dict) else {}
            caminho_arg = args.get("caminho_rel") or args.get("caminho") or args.get("arquivo") or args.get("path") or ""
            pasta_arg = args.get("pasta_rel") or args.get("pasta") or args.get("dir") or ""
            try:
                if nm == "inspecionar_ambiente":
                    out = tool_inspecionar_ambiente()
                elif nm == "listar_arquivos":
                    out = tool_listar_arquivos(pasta_arg)
                elif nm == "buscar_codigo":
                    out = tool_buscar_codigo(
                        args.get("padrao") or args.get("query") or "",
                        pasta_rel=pasta_arg,
                        filtro_arquivo=args.get("filtro_arquivo") or args.get("filtro") or "",
                        max_resultados=args.get("max_resultados", 30),
                    )
                elif nm == "ler_arquivo":
                    out = tool_ler_arquivo(
                        caminho_arg,
                        linha_ini=args.get("linha_ini") or args.get("start_line") or 1,
                        linha_fim=args.get("linha_fim") or args.get("end_line") or 180,
                    )
                elif nm == "editar_arquivo":
                    out = tool_editar_arquivo(
                        caminho_arg,
                        args.get("trecho_antigo") or args.get("old_string") or "",
                        args.get("trecho_novo") or args.get("new_string") or "",
                        descricao=args.get("descricao") or "",
                        substituir_todos=bool(args.get("substituir_todos", False)),
                    )
                    if out.get("ok"):
                        arquivos_modificados.append(out["arquivo"])
                        acoes_resumo.append(f"Código atualizado em `{out['arquivo']}`: {out.get('descricao') or 'ajuste aplicado'}")
                        if out.get("recarregar_frontend"):
                            recarregar_frontend = True
                elif nm == "escrever_arquivo":
                    out = tool_escrever_arquivo(
                        caminho_arg,
                        args.get("conteudo") or args.get("content") or "",
                        descricao=args.get("descricao") or "",
                    )
                    if out.get("ok"):
                        arquivos_modificados.append(out["arquivo"])
                        acoes_resumo.append(f"Arquivo gravado `{out['arquivo']}`: {out.get('descricao') or 'salvo'}")
                        if out.get("recarregar_frontend"):
                            recarregar_frontend = True
                elif nm == "executar_python_diagnostico":
                    out = tool_executar_python_diagnostico(args.get("codigo_python") or args.get("code") or "")
                    if out.get("ok"):
                        acoes_resumo.append("Diagnóstico/script Python executado no workspace da Fábrica Dark.")
                elif nm == "enviar_darkplanner_desktop":
                    out = tool_enviar_darkplanner_desktop(
                        mensagem_chat=args.get("mensagem_chat") or args.get("mensagem") or "",
                        titulo_projeto=args.get("titulo_projeto") or ctx.get("nome_projeto") or "",
                        nova_conversa=bool(args.get("nova_conversa", True)),
                        chat_modelo_opcao=ctx.get("chat_modelo_opcao") or "flash_high",
                    )
                    if out.get("ok"):
                        enviado_dp = True
                        acoes_resumo.append("Pacote enviado diretamente ao `Dark Planner.exe` (`AppData\\Local\\Programs\\darkplanner`).")
                else:
                    out = {"ok": False, "erro": f"Ferramenta desconhecida: {nm}"}
            except Exception as e_tool:
                out = {"ok": False, "erro": str(e_tool)[:400]}

            resultados_rodada.append({"ferramenta": nm, "args_resumo": {k: str(v)[:90] for k, v in args.items()}, "retorno": out})

        rastro_passos.extend(resultados_rodada)

    if arquivos_modificados or acoes_resumo:
        arqs_unicos = list(dict.fromkeys(arquivos_modificados))
        lista_arqs = ", ".join(f"`{a}`" for a in arqs_unicos)
        linhas_fim = ["✅ **Alterações executadas diretamente na Fábrica Dark:**"]
        for ac_r in acoes_resumo:
            linhas_fim.append(f"• {ac_r}")
        if lista_arqs:
            linhas_fim.append(f"• Arquivos validados: {lista_arqs}")
        return {
            "ok": True,
            "modo_agente_dev": True,
            "provedor": provedor_final,
            "arquivos_modificados": arqs_unicos,
            "arquivos_editados": arqs_unicos,
            "alteracoes": acoes_resumo,
            "recarregar_frontend": recarregar_frontend,
            "enviado_direto_chat_dp": enviado_dp,
            "resposta": "\n".join(linhas_fim),
        }

    return {"ok": False, "sem_acao_dev": True}
