"""Vinculação unificada com Antigravity (Tokens/OAuth) + OpenAI Codex (Conta ChatGPT/CLI/API)
+ Cascata Multi-IA Blindada Zero-Erro (Gemini -> Antigravity Tokens -> Codex -> GPT)
+ Agente Conversacional capaz de inspecionar e alterar canais, projetos, roteiros e configurações do site.
"""
import glob
import json
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.request

from core import chaves, storage
from core.storage import Tx

_LOCK_AG_CODEX = threading.Lock()
_PROCESSOS_LOGIN = {}


def _win_no_window_flags():
    if os.name == "nt":
        return getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    return 0


def _caminhos_codex_auth():
    cands = []
    codex_home = os.environ.get("CODEX_HOME", "").strip()
    if codex_home:
        cands.append(os.path.join(codex_home, "auth.json"))
    home = os.path.expanduser("~")
    cands.append(os.path.join(home, ".codex", "auth.json"))
    if os.name == "nt":
        up = os.environ.get("USERPROFILE", "")
        if up:
            cands.append(os.path.join(up, ".codex", "auth.json"))
        cands.append(r"C:\Users\leona\.codex\auth.json")
    vistos = []
    for p in cands:
        if p and p not in vistos:
            vistos.append(p)
    return vistos


def _encontrar_binario_codex():
    bin_path = shutil.which("codex")
    if bin_path:
        return bin_path
    cands = []
    if os.name == "nt":
        appdata = os.environ.get("APPDATA", r"C:\Users\leona\AppData\Roaming")
        localapp = os.environ.get("LOCALAPPDATA", r"C:\Users\leona\AppData\Local")
        cands.extend([
            os.path.join(appdata, "npm", "codex.cmd"),
            os.path.join(appdata, "npm", "codex.exe"),
            os.path.join(localapp, "Programs", "darkplanner", "resources", "bin", "codex.exe"),
            os.path.join(localapp, "Programs", "codex", "codex.exe"),
        ])
    else:
        cands.extend([
            "/usr/local/bin/codex",
            os.path.expanduser("~/.npm-global/bin/codex"),
            os.path.expanduser("~/.local/bin/codex"),
        ])
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return ""


def _ler_sessao_codex_disco():
    """Lê credenciais locais do OpenAI Codex CLI (`~/.codex/auth.json`) ou configurações salvas no banco."""
    db = storage.load()
    cfg_salva = (db.get("settings") or {}).get("codex_auth") or {}
    res = {
        "conectado": False,
        "metodo": "",
        "conta": "",
        "access_token": "",
        "api_key": "",
        "arquivo_auth": "",
        "binario_cli": _encontrar_binario_codex(),
    }

    # 1) Token/chave salvos diretamente pelo usuário na UI
    tok_manual = str(cfg_salva.get("token") or "").strip()
    if tok_manual:
        res["conectado"] = True
        res["metodo"] = cfg_salva.get("metodo") or ("api_key" if tok_manual.startswith("sk-") else "oauth_token")
        res["conta"] = cfg_salva.get("conta") or ("OpenAI API Key" if tok_manual.startswith("sk-") else "Conta Codex Vinculada")
        if tok_manual.startswith("sk-"):
            res["api_key"] = tok_manual
        else:
            res["access_token"] = tok_manual

    # 2) Arquivo ~/.codex/auth.json criado pelo `codex login` (ChatGPT Plus/Pro/Team OAuth)
    for arq in _caminhos_codex_auth():
        if os.path.isfile(arq):
            try:
                with open(arq, "r", encoding="utf-8", errors="ignore") as f:
                    d = json.load(f) or {}
                res["arquivo_auth"] = arq
                k_api = str(d.get("OPENAI_API_KEY") or d.get("api_key") or "").strip()
                tokens = d.get("tokens") if isinstance(d.get("tokens"), dict) else {}
                acc_tok = str(tokens.get("access_token") or d.get("access_token") or "").strip()
                email_c = str(
                    d.get("email")
                    or tokens.get("email")
                    or tokens.get("account_id")
                    or d.get("account_id")
                    or ""
                ).strip()
                if acc_tok:
                    res["conectado"] = True
                    res["metodo"] = "chatgpt_oauth_codex"
                    res["access_token"] = acc_tok
                    res["conta"] = email_c or "Conta ChatGPT / Codex OAuth"
                    break
                if k_api:
                    res["conectado"] = True
                    res["metodo"] = "codex_api_key"
                    res["api_key"] = k_api
                    res["conta"] = email_c or f"Chave Codex (...{k_api[-4:]})"
                    break
            except Exception:
                continue

    # 3) Chaves OpenAI já cadastradas no gerenciador de chaves do site
    if not res["conectado"]:
        lista_oai = [k for k in chaves.lista(db, "openai") if not k.get("esgotada")]
        if lista_oai:
            k0 = lista_oai[0]["key"]
            res["conectado"] = True
            res["metodo"] = "openai_chaves_site"
            res["api_key"] = k0
            res["conta"] = f"OpenAI Site (...{k0[-4:]})"

    return res


def _ler_sessao_antigravity_disco():
    """Detecta sessão/tokens do Antigravity no computador ou no ambiente:
    - Token Antigravity salvo pelo usuário em `settings.antigravity_auth`
    - Sessão Antigravity (`agy`) do DarkPlanner Desktop (`%APPDATA%\\darkplanner`)
    - OAuth Google / Gemini CLI (`~/.gemini/oauth_creds.json` ou `application_default_credentials.json`)
    - Motor Antigravity V8 integrado."""
    db = storage.load()
    s = db.get("settings") or {}
    cfg_ag = s.get("antigravity_auth") or {}

    res = {
        "conectado": False,
        "metodo": "",
        "conta": "",
        "oauth_access_token": "",
        "refresh_token": "",
        "client_id": "",
        "client_secret": "",
        "api_token": "",
        "dp_agy_vinculado": False,
        "dp_modelo": "",
        "gemini_cli": shutil.which("gemini") or "",
        "tokens_consumidos": int(cfg_ag.get("tokens_consumidos") or 0),
        "chamadas_sucesso": int(cfg_ag.get("chamadas_sucesso") or 0),
    }

    # 1) Token Antigravity salvo manualmente na UI
    tok_ag = str(cfg_ag.get("token") or "").strip()
    if tok_ag:
        res["conectado"] = True
        res["metodo"] = cfg_ag.get("metodo") or ("oauth_bearer" if tok_ag.startswith("ya29.") else "antigravity_token")
        res["conta"] = cfg_ag.get("conta") or "Conta Antigravity Vinculada"
        if tok_ag.startswith("ya29."):
            res["oauth_access_token"] = tok_ag
        else:
            res["api_token"] = tok_ag

    # 2) Credenciais OAuth locais do Gemini CLI / Google (`~/.gemini/oauth_creds.json`)
    home = os.path.expanduser("~")
    cands_oauth = [
        os.path.join(home, ".gemini", "oauth_creds.json"),
        os.path.join(home, ".antigravity", "auth.json"),
        os.path.join(home, ".config", "gcloud", "application_default_credentials.json"),
    ]
    if os.name == "nt":
        cands_oauth.extend([
            r"C:\Users\leona\.gemini\oauth_creds.json",
            os.path.join(os.environ.get("APPDATA", ""), "gcloud", "application_default_credentials.json"),
        ])
    for p_oa in cands_oauth:
        if p_oa and os.path.isfile(p_oa):
            try:
                with open(p_oa, "r", encoding="utf-8", errors="ignore") as f:
                    d_oa = json.load(f) or {}
                acc = str(d_oa.get("access_token") or "").strip()
                ref = str(d_oa.get("refresh_token") or "").strip()
                cid = str(d_oa.get("client_id") or "").strip()
                csec = str(d_oa.get("client_secret") or "").strip()
                if acc or ref:
                    res["conectado"] = True
                    res["metodo"] = res["metodo"] or "google_oauth_tokens"
                    res["oauth_access_token"] = res["oauth_access_token"] or acc
                    res["refresh_token"] = ref
                    res["client_id"] = cid
                    res["client_secret"] = csec
                    res["conta"] = res["conta"] or d_oa.get("email") or "Conta Google / Antigravity OAuth (Tokens)"
                    break
            except Exception:
                continue

    # 3) Sessão Antigravity (`agy`) ativa no DarkPlanner Desktop
    pastas_dp = []
    if os.environ.get("APPDATA"):
        pastas_dp.append(os.path.join(os.environ["APPDATA"], "darkplanner"))
    pastas_dp.extend([
        r"C:\Users\leona\AppData\Roaming\darkplanner",
        os.path.expanduser("~/.darkplanner"),
    ])
    for p_dp in pastas_dp:
        arq_prefs = os.path.join(p_dp, "prefs-agentes.json")
        if os.path.isfile(arq_prefs):
            try:
                with open(arq_prefs, "r", encoding="utf-8", errors="ignore") as f:
                    dp_p = json.load(f) or {}
                agy = dp_p.get("agy") or {}
                if agy:
                    res["dp_agy_vinculado"] = True
                    res["dp_modelo"] = f"{agy.get('modelo', 'gemini-3.8-flash')} ({agy.get('esforco', 'high')})"
                    if not res["conectado"]:
                        res["conectado"] = True
                        res["metodo"] = "darkplanner_antigravity_session"
                        res["conta"] = f"Antigravity via DarkPlanner ({res['dp_modelo']})"
            except Exception:
                pass
        # Procura tokens ya29. salvos pelo Antigravity no diretório do DarkPlanner
        if os.path.isdir(p_dp) and not res["oauth_access_token"]:
            for arq_cand in sorted(glob.glob(os.path.join(p_dp, "*.json")), key=lambda x: os.path.getmtime(x), reverse=True)[:12]:
                try:
                    with open(arq_cand, "r", encoding="utf-8", errors="ignore") as f:
                        txt_c = f.read()
                    m_ya = re.search(r"\b(ya29\.[A-Za-z0-9_\-\.]{30,800})\b", txt_c)
                    if m_ya:
                        res["oauth_access_token"] = m_ya.group(1)
                        res["conectado"] = True
                        res["metodo"] = "antigravity_oauth_dp"
                        break
                except Exception:
                    continue

    # 4) Ambiente Antigravity Remoto (VM Antigravity ativa)
    if not res["conectado"] and (os.path.isdir("/opt/antigravity") or os.environ.get("USER") == "antigravity"):
        res["conectado"] = True
        res["metodo"] = "antigravity_cloud_vm"
        res["conta"] = cfg_ag.get("conta") or "Sessão Antigravity Remota Ativa"

    return res


def obter_status_vinculacao(db=None):
    """Retorna o status completo de vinculação com Antigravity + OpenAI Codex + Gemini + GPT."""
    if db is None:
        db = storage.load()
    codex_st = _ler_sessao_codex_disco()
    ag_st = _ler_sessao_antigravity_disco()
    chaves_gem = chaves.lista(db, "gemini")
    chaves_gpt = chaves.lista(db, "openai")

    return {
        "ok": True,
        "antigravity": {
            "conectado": ag_st["conectado"],
            "metodo": ag_st["metodo"],
            "conta": ag_st["conta"] or ("Conectado" if ag_st["conectado"] else "Aguardando login / token"),
            "dp_agy_vinculado": ag_st["dp_agy_vinculado"],
            "dp_modelo": ag_st["dp_modelo"],
            "tem_oauth_token": bool(ag_st["oauth_access_token"] or ag_st["refresh_token"] or ag_st["api_token"]),
            "tokens_consumidos": ag_st["tokens_consumidos"],
            "chamadas_sucesso": ag_st["chamadas_sucesso"],
        },
        "codex": {
            "conectado": codex_st["conectado"],
            "metodo": codex_st["metodo"],
            "conta": codex_st["conta"] or ("Conectado" if codex_st["conectado"] else "Aguardando login / chave"),
            "tem_cli": bool(codex_st["binario_cli"]),
            "binario_cli": codex_st["binario_cli"],
            "arquivo_auth": codex_st["arquivo_auth"],
        },
        "cascata_roteiro": {
            "ativa": True,
            "ordem": [
                f"1. Gemini Multi-Chaves ({len(chaves_gem)} chave(s) c/ rotação automática 2.5-Flash / Flash-Lite / 2.0-Flash)",
                "2. Antigravity (Tokens da Conta / OAuth / CLI — zero erro de cota de API)",
                "3. OpenAI Codex (Sessão ChatGPT OAuth ~/.codex/auth.json / Codex CLI)",
                f"4. OpenAI GPT-4o / GPT-4o-mini ({len(chaves_gpt)} chave(s))",
            ],
        },
    }


def salvar_token_vinculacao(provedor, token="", conta="", metodo="", modelo_padrao="", **kwargs):
    """Salva token/chave ou conta vinculada para `antigravity` ou `codex`."""
    prov = str(provedor or "").strip().lower()
    tok = str(token or "").strip()
    if not tok:
        return {"ok": False, "erro": "Cole o token ou chave de acesso para vincular."}

    with Tx() as db:
        s = db.setdefault("settings", {})
        if prov == "codex":
            s["codex_auth"] = {
                "token": tok,
                "conta": conta.strip() or ("OpenAI API Key" if tok.startswith("sk-") else "Conta OpenAI Codex"),
                "metodo": metodo or ("api_key" if tok.startswith("sk-") else "oauth_token"),
                "modelo_padrao": modelo_padrao.strip(),
                "vinculado_em": storage.now(),
            }
        else:
            ag_ant = s.get("antigravity_auth") or {}
            s["antigravity_auth"] = {
                "token": tok,
                "conta": conta.strip() or "Conta Antigravity (Tokens)",
                "metodo": metodo or ("oauth_bearer" if tok.startswith("ya29.") else "antigravity_token"),
                "modelo_padrao": modelo_padrao.strip(),
                "vinculado_em": storage.now(),
                "tokens_consumidos": int(ag_ant.get("tokens_consumidos") or 0),
                "chamadas_sucesso": int(ag_ant.get("chamadas_sucesso") or 0),
            }

    if prov == "codex" and tok.startswith("sk-"):
        try:
            chaves.adicionar("openai", tok, apelido="Codex / GPT Vinculado")
        except Exception:
            pass
    elif prov != "codex" and tok.startswith(("AIza", "AQ.")):
        try:
            chaves.adicionar("gemini", tok, tipo="paga", apelido="Antigravity Token")
        except Exception:
            pass

    st = obter_status_vinculacao()
    return {
        "ok": True,
        "provedor": prov,
        "msg": f"Conta {prov.upper()} vinculada e salva com sucesso!",
        "status": st,
    }


def desconectar_provedor(provedor):
    prov = str(provedor or "").strip().lower()
    with Tx() as db:
        s = db.setdefault("settings", {})
        if prov == "codex":
            s.pop("codex_auth", None)
        else:
            s.pop("antigravity_auth", None)
    return {"ok": True, "provedor": prov, "status": obter_status_vinculacao()}


def iniciar_login_provedor(provedor):
    """Dispara o fluxo oficial de login no navegador do PC (Codex OAuth / Antigravity OAuth) sem travar o servidor."""
    prov = str(provedor or "").strip().lower()
    if prov == "codex":
        bin_codex = _encontrar_binario_codex()
        if bin_codex and os.name == "nt":
            try:
                proc = subprocess.Popen(
                    [bin_codex, "login"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    creationflags=_win_no_window_flags(),
                )
                _PROCESSOS_LOGIN["codex"] = proc
                return {
                    "ok": True,
                    "abriu_navegador": True,
                    "msg": "Navegador aberto para login na sua conta OpenAI Codex! Conclua o login no navegador e clique em Atualizar Status.",
                    "status": obter_status_vinculacao(),
                }
            except Exception as e:
                return {
                    "ok": False,
                    "precisa_token_manual": True,
                    "msg": f"Não foi possível abrir o CLI automaticamente ({e}). Cole sua chave sk-... ou token de ~/.codex/auth.json no campo abaixo.",
                    "url_login": "https://platform.openai.com/api-keys",
                }
        st_atual = _ler_sessao_codex_disco()
        if st_atual["conectado"]:
            return {
                "ok": True,
                "ja_conectado": True,
                "msg": f"Sua conta Codex já está conectada ({st_atual['conta']})!",
                "status": obter_status_vinculacao(),
            }
        return {
            "ok": True,
            "precisa_token_manual": True,
            "url_login": "https://chatgpt.com/",
            "url_api": "https://platform.openai.com/api-keys",
            "msg": (
                "No Modo Remoto (ou sem CLI instalado), cole sua chave OpenAI (sk-...) ou rode `codex login` no terminal do seu PC "
                "(a FabricaDark lê `~/.codex/auth.json` automaticamente!)."
            ),
            "status": obter_status_vinculacao(),
        }

    # Antigravity Login
    bin_gem = shutil.which("gemini")
    if bin_gem and os.name == "nt":
        try:
            proc = subprocess.Popen(
                [bin_gem],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                creationflags=_win_no_window_flags(),
            )
            _PROCESSOS_LOGIN["antigravity"] = proc
            return {
                "ok": True,
                "abriu_navegador": True,
                "msg": "Fluxo de login Antigravity / Google iniciado no seu PC! Conclua a autenticação na janela/navegador.",
                "status": obter_status_vinculacao(),
            }
        except Exception:
            pass

    st_ag = _ler_sessao_antigravity_disco()
    if st_ag["conectado"]:
        return {
            "ok": True,
            "ja_conectado": True,
            "msg": f"Antigravity conectado e ativo ({st_ag['conta']})!",
            "status": obter_status_vinculacao(),
        }
    return {
        "ok": True,
        "precisa_token_manual": True,
        "url_login": "https://aistudio.google.com/apikey",
        "msg": "Cole seu Token Antigravity / OAuth (ya29... ou AQ...) abaixo ou mantenha o Antigravity logado no DarkPlanner Desktop.",
        "status": obter_status_vinculacao(),
    }


def _registrar_uso_tokens_antigravity(qtd_tokens):
    try:
        with Tx() as db:
            ag = db.setdefault("settings", {}).setdefault("antigravity_auth", {})
            ag["tokens_consumidos"] = int(ag.get("tokens_consumidos") or 0) + max(1, int(qtd_tokens or 0))
            ag["chamadas_sucesso"] = int(ag.get("chamadas_sucesso") or 0) + 1
            ag["ultimo_uso"] = storage.now()
    except Exception:
        pass


def _renovar_oauth_token_google(ag_st):
    """Se houver refresh_token em ~/.gemini/oauth_creds.json, renova o access_token automaticamente."""
    ref = ag_st.get("refresh_token")
    cid = ag_st.get("client_id")
    csec = ag_st.get("client_secret")
    if not (ref and cid and csec):
        return ""
    try:
        import urllib.parse
        form = urllib.parse.urlencode({
            "client_id": cid,
            "client_secret": csec,
            "refresh_token": ref,
            "grant_type": "refresh_token",
        }).encode("utf-8")
        req = urllib.request.Request(
            "https://oauth2.googleapis.com/token",
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as r:
            j = json.loads(r.read().decode("utf-8"))
        return str(j.get("access_token") or "").strip()
    except Exception:
        return ""


def chamar_antigravity_tokens(prompt, sistema="", max_tokens=8192, temperatura=0.65, json_mode=False):
    """Executa geração usando os TOKENS da conta Antigravity (OAuth Bearer / Token dedicado / Gemini CLI),
    independente do limite gratuito de API key do Google AI Studio."""
    ag_st = _ler_sessao_antigravity_disco()

    # Caminho A: OAuth Bearer Token (ya29...) contra Google Generative Language API (cota de conta OAuth!)
    bearer = ag_st.get("oauth_access_token") or ""
    if not bearer and ag_st.get("refresh_token"):
        bearer = _renovar_oauth_token_google(ag_st)

    if bearer:
        for mod in ("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-pro"):
            try:
                body = {
                    "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                    "generationConfig": {
                        "temperature": temperatura,
                        "maxOutputTokens": max_tokens,
                    },
                }
                if sistema:
                    body["systemInstruction"] = {"parts": [{"text": sistema}]}
                if json_mode:
                    body["generationConfig"]["responseMimeType"] = "application/json"
                req = urllib.request.Request(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent",
                    data=json.dumps(body).encode("utf-8"),
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {bearer}",
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=150) as r:
                    j = json.loads(r.read().decode("utf-8"))
                cand = ((j.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []
                txt = "".join(p.get("text", "") for p in cand if not p.get("thought")).strip()
                if txt:
                    uso = j.get("usageMetadata") or {}
                    tot_tok = int(uso.get("totalTokenCount") or (len(prompt) // 4 + len(txt) // 4))
                    _registrar_uso_tokens_antigravity(tot_tok)
                    return txt, f"antigravity-oauth:{mod}"
            except urllib.error.HTTPError as e_http:
                if e_http.code == 401 and ag_st.get("refresh_token"):
                    novo_b = _renovar_oauth_token_google(ag_st)
                    if novo_b and novo_b != bearer:
                        bearer = novo_b
                        continue
            except Exception:
                continue

    # Caminho B: Token de API dedicado salvo em Antigravity (se diferente das chaves esgotadas)
    api_tok = ag_st.get("api_token") or ""
    if api_tok:
        for mod in ("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.0-flash"):
            try:
                body = {
                    "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                    "generationConfig": {
                        "temperature": temperatura,
                        "maxOutputTokens": max_tokens,
                    },
                }
                if sistema:
                    body["systemInstruction"] = {"parts": [{"text": sistema}]}
                if json_mode:
                    body["generationConfig"]["responseMimeType"] = "application/json"
                req = urllib.request.Request(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{mod}:generateContent?key={api_tok}",
                    data=json.dumps(body).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=150) as r:
                    j = json.loads(r.read().decode("utf-8"))
                cand = ((j.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []
                txt = "".join(p.get("text", "") for p in cand if not p.get("thought")).strip()
                if txt:
                    uso = j.get("usageMetadata") or {}
                    tot_tok = int(uso.get("totalTokenCount") or (len(prompt) // 4 + len(txt) // 4))
                    _registrar_uso_tokens_antigravity(tot_tok)
                    return txt, f"antigravity-token:{mod}"
            except Exception:
                continue

    # Caminho C: CLI oficial `gemini -p` logado com conta OAuth no PC
    bin_gem = ag_st.get("gemini_cli") or shutil.which("gemini")
    if bin_gem:
        try:
            full_p = f"{sistema}\n\n{prompt}".strip() if sistema else prompt
            r_cli = subprocess.run(
                [bin_gem, "-p", full_p],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                timeout=180,
                creationflags=_win_no_window_flags(),
            )
            if r_cli.returncode == 0 and (r_cli.stdout or "").strip():
                txt_cli = r_cli.stdout.strip()
                _registrar_uso_tokens_antigravity(len(full_p) // 4 + len(txt_cli) // 4)
                return txt_cli, "antigravity-cli"
        except Exception:
            pass

    return "", ""


def chamar_codex_ou_gpt(prompt, sistema="", max_tokens=8192, temperatura=0.65, json_mode=False):
    """Executa geração via OpenAI Codex (CLI / conta ~/.codex/auth.json) ou API OpenAI GPT (gpt-4o / gpt-4o-mini)."""
    codex_st = _ler_sessao_codex_disco()
    db = storage.load()

    # 1. Chaves da API OpenAI (do ~/.codex/auth.json, da UI Codex ou do gerenciador de chaves)
    chaves_candidatas = []
    if codex_st.get("api_key"):
        chaves_candidatas.append(codex_st["api_key"])
    for k_obj in chaves.lista(db, "openai"):
        if not k_obj.get("esgotada") and k_obj.get("key") and k_obj["key"] not in chaves_candidatas:
            chaves_candidatas.append(k_obj["key"])

    modelo_pref = (db.get("settings") or {}).get("gpt_modelo") or "gpt-4o"
    cadeia_gpt = [modelo_pref] + [m for m in ("gpt-4o", "gpt-4o-mini") if m != modelo_pref]

    for key_oai in chaves_candidatas:
        for mod_gpt in cadeia_gpt:
            try:
                msgs = []
                if sistema:
                    msgs.append({"role": "system", "content": sistema})
                msgs.append({"role": "user", "content": prompt})
                body = {
                    "model": mod_gpt,
                    "messages": msgs,
                    "temperature": temperatura,
                    "max_tokens": min(int(max_tokens or 8192), 16384),
                }
                if json_mode:
                    body["response_format"] = {"type": "json_object"}
                req = urllib.request.Request(
                    "https://api.openai.com/v1/chat/completions",
                    data=json.dumps(body).encode("utf-8"),
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {key_oai}",
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=180) as r:
                    j = json.loads(r.read().decode("utf-8"))
                txt = (((j.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
                if txt:
                    return txt, f"gpt:{mod_gpt}"
            except Exception:
                continue

    # 2. OpenAI Codex CLI (`codex exec`) usando a conta ChatGPT OAuth (`~/.codex/auth.json`) — timeout de 240s p/ roteiros longos!
    bin_codex = codex_st.get("binario_cli")
    if bin_codex and codex_st.get("conectado"):
        try:
            import tempfile
            full_prompt = f"{sistema}\n\n{prompt}".strip() if sistema else prompt
            if json_mode:
                full_prompt += "\n\nRespond ONLY with valid JSON, without markdown fences."
            with tempfile.NamedTemporaryFile(mode="w+", suffix=".txt", delete=False, encoding="utf-8") as tf_out:
                arq_out = tf_out.name
            try:
                cmd = [
                    bin_codex,
                    "exec",
                    "--skip-git-repo-check",
                    "-o",
                    arq_out,
                    "-",
                ]
                proc = subprocess.run(
                    cmd,
                    input=full_prompt,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="ignore",
                    timeout=240,
                    creationflags=_win_no_window_flags(),
                )
                txt_out = ""
                if os.path.isfile(arq_out):
                    with open(arq_out, "r", encoding="utf-8", errors="ignore") as f_r:
                        txt_out = f_r.read().strip()
                if not txt_out and proc.returncode == 0:
                    txt_out = (proc.stdout or "").strip()
                if txt_out:
                    return txt_out, "openai-codex-oauth"
            finally:
                try:
                    if os.path.exists(arq_out):
                        os.remove(arq_out)
                except Exception:
                    pass
        except Exception:
            pass

    return "", ""


def gerar_texto_fallback_cascata(prompt, sistema="", max_tokens=8192, temperatura=0.65, json_mode=False, timeout=240, aviso=None, **_kwargs):
    """Acionado automaticamente sempre que o Gemini apresentar limite/cota/sobrecarga (429/503/erro):
    1º Tenta Antigravity (Tokens OAuth / CLI / Token dedicado)
    2º Tenta OpenAI Codex / GPT-4o / GPT-4o-mini."""
    if callable(aviso):
        try:
            aviso("Alternando automaticamente para Antigravity Tokens / OpenAI Codex...")
        except Exception:
            pass
    txt_ag, prov_ag = chamar_antigravity_tokens(
        prompt=prompt,
        sistema=sistema,
        max_tokens=max_tokens,
        temperatura=temperatura,
        json_mode=json_mode,
    )
    if txt_ag:
        return txt_ag, prov_ag

    txt_cx, prov_cx = chamar_codex_ou_gpt(
        prompt=prompt,
        sistema=sistema,
        max_tokens=max_tokens,
        temperatura=temperatura,
        json_mode=json_mode,
    )
    if txt_cx:
        return txt_cx, prov_cx

    return "", ""


# ==============================================================================
# AGENTE CONVERSACIONAL ANTIGRAVITY + CODEX (CAPAZ DE MEXER E FAZER ALTERAÇÕES NO SITE)
# ==============================================================================
def _inferir_acoes_deterministicas_chat_dp(mensagem, canal_id="", canal_nome="", nome_projeto="", canais_resumo=None, nova_conversa=False):
    """Parser determinístico de segurança: garante que pedidos de mudança de formato, estilo, proporção de mídia,
    funções especiais de vídeo ou correção direta no DarkPlanner funcionem 100% mesmo se alguma API externa oscilar."""
    msg = str(mensagem or "").strip()
    ml = msg.lower()
    acoes_det = []

    # Detecta canal mencionado pelo nome na frase (se houver)
    alvo_canal = canal_id or canal_nome or ""
    for c_it in (canais_resumo or []):
        nm_c = str(c_it.get("nome") or "").strip()
        if not nm_c:
            continue
        nm_low = nm_c.lower()
        nm_alt = nm_low.replace("cappito", "capitto")
        if nm_low in ml or nm_alt in ml.replace("cappito", "capitto"):
            alvo_canal = str(c_it.get("id") or nm_c)
            break

    campos_c = {}
    ed_patch = {}
    funcoes_det = []

    # 1. Proporções explícitas (ex: "80% vídeo e 20% imagem", "70% video 30% imagem", "100% imagem")
    m_v = re.search(r"(\d{1,3})\s*%\s*(?:de\s+)?v[ií]deos?", ml)
    m_i = re.search(r"(\d{1,3})\s*%\s*(?:de\s+)?imagens?", ml)
    if m_v and m_i:
        vp = max(0, min(100, int(m_v.group(1))))
        ip = max(0, min(100, int(m_i.group(1))))
        campos_c["proporcao_midia"] = {"video_pct": vp, "imagem_pct": ip}
        if vp == 70 and ip == 30:
            campos_c["modo_midia_custom"] = "70v_30i"
        elif vp == 0 or ip == 100:
            campos_c["modo_midia_custom"] = "100_img"
        else:
            campos_c["modo_midia_custom"] = "flow_iv"
    elif m_i and int(m_i.group(1)) == 100:
        campos_c["modo_midia_custom"] = "100_img"
        campos_c["proporcao_midia"] = {"video_pct": 0, "imagem_pct": 100}
    elif m_v and int(m_v.group(1)) == 100:
        campos_c["modo_midia_custom"] = "flow_iv"
        campos_c["proporcao_midia"] = {"video_pct": 100, "imagem_pct": 0}
    elif any(k in ml for k in ("video real", "vídeo real", "videos reais", "vídeos reais", "fotos e videos reais", "mídias reais")):
        campos_c["modo_midia_custom"] = "video_real"

    # 2. Estilos visuais, presets do DarkPlanner Studio, legendas e cores
    if any(k in ml for k in ("documentario", "documentário", "investigativo", "jornalistico", "jornalístico")):
        ed_patch["predef"] = "sys_doc"
        campos_c.setdefault("estilo_visual", "Documentário Cinematográfico Investigativo")
    elif any(k in ml for k in ("minimalista", "limpo", "clean", "discreto")):
        ed_patch["predef"] = "sys_minimalista"
        ed_patch["densidade_destaques"] = "discreto"
        campos_c.setdefault("estilo_visual", "Minimalista Sofisticado")
    elif any(k in ml for k in ("dinamico", "dinâmico", "cortes rapidos", "cortes rápidos", "ritmo acelerado", "frenetico", "frenético")):
        ed_patch["predef"] = "sys_tudo"
        ed_patch["densidade_destaques"] = "dinamico"
        campos_c["veo_faixas_padrao"] = [3.5, 5.5]
        campos_c.setdefault("formato_video_custom", "Ritmo dinâmico com cortes rápidos (3.5s–5.5s), ganchos visuais fortes e zooms de impacto")

    if any(k in ml for k in ("marca-texto", "marca texto", "amarela", "destaque amarelo")):
        ed_patch["legenda_estilo"] = "marca_texto"
    elif any(k in ml for k in ("karaoke", "karaokê", "palavra por palavra")):
        ed_patch["legenda_estilo"] = "karaoke"
    elif "sem legenda" in ml or "tirar legenda" in ml or "remover legenda" in ml:
        ed_patch["legenda_estilo"] = "sem_legenda"
    elif "caixa escura" in ml:
        ed_patch["legenda_estilo"] = "caixa_escura"

    if any(k in ml for k in ("cor fria", "tom frio", "azulado", "frio")):
        ed_patch["look_cor"] = "frio"
    elif any(k in ml for k in ("cor quente", "tom quente", "dourado")):
        ed_patch["look_cor"] = "quente"
    elif any(k in ml for k in ("cinematografico", "cinematográfico", "cinema", "dark", "escuro")):
        ed_patch["look_cor"] = "cinematografico"

    # 3. Funções especiais nos vídeos pedidas pelo usuário
    mapa_funcoes = [
        (("capitulo", "capítulo", "divisao em blocos", "separador de capitulo"), "Capítulos / títulos animados na tela em cada virada de bloco"),
        (("contador", "cronometro", "cronômetro", "barra de progresso"), "Barra de progresso / contador visual nos momentos de tensão"),
        (("lower third", "tarja", "credito na tela", "nome na tela", "card informativo"), "Cards / lower-thirds informativos destacando nomes, datas e dados"),
        (("zoom", "aproximacao", "ken burns"), "Zoom dramático progressivo e câmera viva nas cenas-chave"),
        (("efeito sonoro", "sfx", "whoosh", "impacto sonoro"), "Reforço de transições com marcação de impacto visual sincronizada"),
        (("mascara", "máscara", "anti-copyright", "sem copyright", "copyhite"), "Máscara óptica anti-copyright + cortes curtos fair-use + 0% áudio original"),
    ]
    for gatilhos, desc_fn in mapa_funcoes:
        if any(g in ml for g in gatilhos):
            funcoes_det.append(desc_fn)

    pediu_estilo_formato_funcao = bool(campos_c or ed_patch or funcoes_det) or any(
        k in ml
        for k in (
            "estilo",
            "estilos",
            "formato",
            "formatos",
            "formas diferentes",
            "forma diferente",
            "funcoes",
            "funções",
            "funcao",
            "função",
            "mudar os videos",
            "mudar os vídeos",
            "videos sejam",
            "vídeos sejam",
            "padrao do canal",
            "padrão do canal",
            "transiç",
            "transic",
            "legenda",
            "edicao",
            "edição",
        )
    )

    if pediu_estilo_formato_funcao:
        if funcoes_det:
            campos_c["funcoes_especiais_video"] = funcoes_det
        campos_c["regras_custom_chat"] = msg
        if not campos_c.get("formato_video_custom") and any(k in ml for k in ("formato", "forma", "videos sejam", "vídeos sejam", "corte", "ritmo")):
            campos_c["formato_video_custom"] = msg[:280]
        if not campos_c.get("estilo_visual") and "estilo" in ml:
            campos_c["estilo_visual"] = msg[:240]
        ed_patch["instrucoes_custom"] = msg[:400]
        acoes_det.append({
            "tipo": "atualizar_formato_estilo_funcoes_canal",
            "canal_id_ou_nome": alvo_canal,
            "campos": campos_c,
            "edicao_patch": ed_patch,
        })

    # Proteção absoluta: se o texto for um pacote da Etapa 7 colado por engano, encaminha DIRETO para o DarkPlanner Desktop sem pausar!
    if (
        "# produção automática no darkplanner desktop" in ml
        or "# montagem e edição imediata no darkplanner studio" in ml
    ):
        return [{
            "tipo": "enviar_direto_chat_darkplanner",
            "instrucao_dp": msg,
            "nova_conversa": True,
        }]

    # 4. Pedidos curtos operacionais de parar/pausar projeto ou reexecutar etapa DENTRO DA NOSSA AUTOMAÇÃO (FÁBRICA DARK)
    pediu_parar_app = len(msg) < 400 and any(
        k in ml
        for k in (
            "parar projeto",
            "pausar projeto",
            "interromper projeto",
            "cancelar projeto",
            "parar processo",
            "pausar processo",
            "parar a esteira",
            "pausar a esteira",
        )
    ) or ml in ("parar", "pausar", "interromper", "cancelar")
    pediu_corrigir_erro_etapa_curto = len(msg) < 180 and any(
        k in ml
        for k in (
            "parar projeto e corrigir",
            "corrigir erro da etapa",
            "tentar novamente a etapa",
            "reexecutar etapa",
        )
    )
    pediu_continuar_depois = any(
        k in ml
        for k in (
            "e continuar",
            "e rodar",
            "tentar novamente",
            "tentar de novo",
            "reexecutar",
            "rodar de novo",
        )
    )
    if pediu_parar_app or pediu_corrigir_erro_etapa_curto:
        acoes_det.append({
            "tipo": "parar_e_corrigir_automacao_local",
            "parar_esteira": bool(pediu_parar_app or True),
            "corrigir_erro": bool(pediu_corrigir_erro_etapa_curto),
            "auto_reexecutar": bool(pediu_continuar_depois and not pediu_parar_app),
        })

    # SOMENTE envia direto ao Chat do DarkPlanner Desktop se o usuário pedir EXPLICITAMENTE para mandar ao DarkPlanner agora!
    pediu_envio_explicito_dp = any(
        fr in ml
        for fr in (
            "enviar para o darkplanner",
            "enviar pro darkplanner",
            "mandar para o darkplanner",
            "mandar pro darkplanner",
            "enviar no chat do darkplanner",
            "mandar no chat do darkplanner",
            "levar para o darkplanner agora",
        )
    )
    if pediu_envio_explicito_dp and not pediu_parar_app:
        acoes_det.append({
            "tipo": "enviar_direto_chat_darkplanner",
            "instrucao_dp": msg,
            "nova_conversa": bool(nova_conversa),
        })

    return acoes_det


def conversar_agente_antigravity_codex(dados=None, mensagem="", historico=None, contexto_projeto=None, **kwargs):
    """Agente Oficial da Automação **Fábrica Dark** (com motor Antigravity + OpenAI Codex + Gemini + Acesso Real ao Código):
    O usuário pode conversar neste Chat exatamente como se estivesse dando comandos diretamente no Antigravity:
    - Inspecionar, buscar, ler e editar arquivos reais do projeto (`app.py`, `core/*.py`, `static/*.js`, `static/*.html`, `static/*.css`) com backup + validação de sintaxe + hot-reload imediato;
    - Diagnosticar e corrigir qualquer erro/traceback real nas Etapas 1–7;
    - Analisar canais, ajustar estrutura/roteiro na mesma conversa e configurar estilos/formatos/funções dos vídeos;
    - Entregar na Etapa 7 diretamente no `C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner\\Dark Planner.exe`."""
    from core import agente_dev_local, claude, darkplanner_sync, pauta

    d = dict(dados) if isinstance(dados, dict) else {}
    if isinstance(contexto_projeto, dict):
        for k_cp, v_cp in contexto_projeto.items():
            if v_cp is not None and not d.get(k_cp):
                d[k_cp] = v_cp
    for k_kw, v_kw in kwargs.items():
        if v_kw is not None and not d.get(k_kw):
            d[k_kw] = v_kw
    if mensagem and not d.get("mensagem"):
        d["mensagem"] = mensagem
    if historico is not None and not d.get("historico"):
        d["historico"] = historico

    mensagem = str(d.get("mensagem") or "").strip()
    if not mensagem:
        return {"ok": False, "erro": "Escreva o que deseja ajustar, analisar ou programar aqui na Fábrica Dark."}

    canal_id = str(d.get("canal_id") or "").strip()
    canal_nome = str(d.get("canal_nome") or "").strip()
    nome_projeto = str(d.get("nome_projeto") or d.get("titulo") or d.get("titulo_atual") or "").strip()
    vid = str(d.get("vid") or "").strip()
    job_id = str(d.get("job_id") or "").strip()
    sp_id = str(d.get("sp_id") or d.get("projeto_id") or "").strip()
    srt_texto = str(d.get("srt_texto") or "").strip()
    pasta_creator = str(d.get("pasta_creator") or "").strip()
    roteiro_atual = str(d.get("roteiro") or d.get("roteiro_atual") or "").strip()
    estrutura_atual = str(d.get("estrutura_atual") or "").strip()
    etapas_app = d.get("etapas_app") if isinstance(d.get("etapas_app"), (dict, list)) else []
    logs_recentes_app = d.get("logs_recentes_app") if isinstance(d.get("logs_recentes_app"), list) else []
    esteira_rodando = bool(d.get("esteira_rodando", False))
    ja_na_etapa7 = bool(d.get("ja_na_etapa7", False))
    nova_conversa_req = bool(d.get("nova_conversa", False))
    origem_nuvem = bool(d.get("origem_nuvem", False))
    chat_modelo_opcao = str(d.get("chat_modelo_opcao") or "flash_high").strip()
    dp_vivo = d.get("dp_vivo") if isinstance(d.get("dp_vivo"), dict) else {}
    historico_chat = d.get("historico") if isinstance(d.get("historico"), list) else []

    db = storage.load()
    canais_resumo = []
    for c in (db.get("channels") or []):
        canais_resumo.append({
            "id": c.get("id"),
            "nome": c.get("nome"),
            "idioma": c.get("idioma"),
            "modo_visual": (
                f"Custom ({c.get('proporcao_midia')})"
                if c.get("proporcao_midia")
                else (
                    "70% Vídeo + 30% Imagem (Flow)"
                    if darkplanner_sync._canal_eh_70_video_30_imagem(c.get("nome", ""), c.get("id", ""))
                    else (
                        "Imagens e Vídeos (Flow)"
                        if darkplanner_sync._canal_eh_flow_imagem_e_video(c.get("nome", ""), c.get("id", ""))
                        else (
                            "100% Imagem (Flow)"
                            if darkplanner_sync._canal_eh_100_imagem(c.get("nome", ""), c.get("id", ""))
                            else "Vídeo e Imagens Reais"
                        )
                    )
                )
            ),
            "estilo_visual": c.get("estilo_visual") or "",
            "formato_video_custom": c.get("formato_video_custom") or "",
            "funcoes_especiais_video": c.get("funcoes_especiais_video") or [],
            "edicao_padrao": c.get("edicao_padrao") or {},
        })

    msg_low = mensagem.lower().strip()
    alteracoes_aplicadas = []
    ui_patch = {}
    enviado_direto_dp = False
    sincronizado_dp_cloud = False
    disparar_regularizacao_midias = ""
    parar_automacao_app = False
    limpar_erros_etapas = False
    reexecutar_etapa_app = ""
    etapa_sugerida_botao = None

    # Atalho rápido se o usuário pedir para excluir/apagar o projeto diretamente na conversa
    if any(
        fr in msg_low
        for fr in (
            "excluir o projeto",
            "excluir projeto",
            "apagar o projeto",
            "apagar projeto",
            "deletar o projeto",
            "deletar projeto",
            "excluir esse projeto",
            "apagar esse projeto",
        )
    ) and (nome_projeto or vid or sp_id):
        res_del = darkplanner_sync.deletar_projeto_criado_completo(
            titulo=nome_projeto if nome_projeto != "Projeto Atual" else "",
            vid=vid,
            sp_id=sp_id,
            apagar_arquivos_disco=True,
        )
        return {
            "ok": True,
            "parar_automacao_app": True,
            "projeto_excluido": True,
            "sp_id_excluido": sp_id,
            "titulo_excluido": nome_projeto,
            "vid_excluido": vid,
            "alteracoes": [f"Projeto '{nome_projeto or vid}' excluído do Chat, da Fila, do banco e do disco."],
            "resposta": (
                f"🗑️ **Projeto `{nome_projeto or vid}` excluído completamente na Fábrica Dark!**\n"
                f"• Removido do seletor do Chat, da Fila de Produção, do banco de dados e das pastas locais (`{len(res_del.get('removidos') or [])}` itens limpos)."
            ),
        }

    acoes_det_seguranca = _inferir_acoes_deterministicas_chat_dp(
        mensagem=mensagem,
        canal_id=canal_id,
        canal_nome=canal_nome,
        nome_projeto=nome_projeto,
        canais_resumo=canais_resumo,
        nova_conversa=nova_conversa_req,
    )
    acao_local_fix = next((a for a in acoes_det_seguranca if a.get("tipo") == "parar_e_corrigir_automacao_local"), None)
    pediu_envio_dp_expl = any(a.get("tipo") == "enviar_direto_chat_darkplanner" for a in acoes_det_seguranca)

    # ==========================================================================
    # MODO DESENVOLVEDOR AUTÔNOMO (ESTILO ANTIGRAVITY / CODEX IDE DIRETO NO CHAT)
    # ==========================================================================
    usar_agente_dev = agente_dev_local.deve_usar_agente_dev_codigo(
        mensagem=mensagem,
        modo_agente=str(d.get("modo_agente") or ""),
        etapas_app=etapas_app,
        logs_recentes_app=logs_recentes_app,
    )
    if usar_agente_dev and not pediu_envio_dp_expl and msg_low not in ("parar", "pausar", "cancelar", "interromper"):
        pediu_parar_junto = len(mensagem) < 400 and any(p in msg_low for p in ("parar ", "pausar ", "interromper "))
        if pediu_parar_junto:
            try:
                darkplanner_sync.pausar_processo_etapa7_dp(sp_id=sp_id, nome_projeto=nome_projeto, pausar_chat_dp=False)
            except Exception:
                pass
        res_dev = agente_dev_local.executar_agente_dev_chat(
            mensagem=mensagem,
            historico=historico_chat,
            contexto_projeto=d,
            max_passos=6,
        )
        if isinstance(res_dev, dict) and res_dev.get("ok") and res_dev.get("resposta"):
            if pediu_parar_junto:
                res_dev["parar_automacao_app"] = True
                res_dev["pausado"] = True
            if res_dev.get("arquivos_editados"):
                res_dev["limpar_erros_etapas"] = True
            return res_dev

    if acao_local_fix and not pediu_envio_dp_expl:
        diag_local = darkplanner_sync.diagnosticar_e_corrigir_erro_automacao_local({
            "mensagem": mensagem,
            "canal_id": canal_id,
            "canal_nome": canal_nome,
            "nome_projeto": nome_projeto,
            "vid": vid,
            "sp_id": sp_id,
            "etapas_app": etapas_app,
            "logs_recentes_app": logs_recentes_app,
            "esteira_rodando": esteira_rodando,
            "parar_esteira": bool(acao_local_fix.get("parar_esteira", True)),
            "auto_reexecutar": bool(acao_local_fix.get("auto_reexecutar", False)),
        })
        # Se na mesma mensagem também pediu mudança de estilo/formato, aplica na Fábrica Dark junto!
        for ac_est in acoes_det_seguranca:
            if ac_est.get("tipo") == "atualizar_formato_estilo_funcoes_canal":
                res_s = darkplanner_sync.sincronizar_diretrizes_chat_no_darkplanner(
                    canal_id=canal_id,
                    canal_nome=canal_nome,
                    campos=ac_est.get("campos") or {},
                    edicao_patch=ac_est.get("edicao_patch") or {},
                    nome_projeto=nome_projeto,
                    pasta_creator=pasta_creator,
                    srt_texto=srt_texto,
                    aplicar_studio_agora=False,
                )
                if res_s.get("ok"):
                    ui_patch["edicao_config"] = res_s.get("edicao_padrao") or {}
                    diag_local.setdefault("correcoes_locais", []).append(
                        f"Formato/estilo atualizado na automação do canal `{res_s.get('canal_nome')}`."
                    )
        if ui_patch:
            diag_local["ui_patch"] = ui_patch
        return diag_local

    hist_txt = "\n".join(
        f"{'USUÁRIO' if m.get('de') == 'eu' else 'AGENTE'}: {str(m.get('texto') or '')[:500]}"
        for m in historico_chat[-8:]
    )

    sistema_agente = """Você é o **Agente Oficial da Automação Fábrica Dark** (com motor Antigravity + OpenAI Codex + Gemini).
IMPORTANTE — ENTENDA A ARQUITETURA DO NOSSO SISTEMA:
- A **Fábrica Dark** é o nosso aplicativo de automação criado para **analisar canais**, **estruturar e gerar roteiros**, **gerar descrição/tags/thumbnail**, **gerar áudio MP3 + SRT** e **preparar todas as cenas/prompts** (Etapas 1 a 6), para **SOMENTE NO FINAL (Etapa 7)** levar o pacote completo pronto para o Chat do DarkPlanner!
- Portanto, quando o usuário pedir neste Chat para **parar o projeto**, **corrigir um erro**, **ajustar ou melhorar o roteiro/estrutura**, **analisar um canal** ou **mudar formatos/estilos/funções dos vídeos**, você DEVE resolver e configurar isso **100% AQUI NA NOSSA AUTOMAÇÃO FÁBRICA DARK**, **SEM enviar comandos avulsos para o Chat do DarkPlanner Desktop**!
- Só use `enviar_direto_chat_darkplanner` se o usuário pedir EXPLICITAMENTE com todas as letras para enviar algo agora ao Chat do DarkPlanner Desktop (ex.: "envie isso agora lá no chat do DarkPlanner").

SUAS CAPACIDADES NA AUTOMAÇÃO FÁBRICA DARK:
1. `parar_e_corrigir_automacao_local`: Para imediatamente a esteira/fila na Fábrica Dark, diagnostica o erro real das Etapas 1 a 6 pelos logs do app, aplica o auto-reparo local (recarrega módulos, ativa failover Antigravity/Codex/GPT, renova sessão) e prepara a etapa afetada para reexecução aqui na Fábrica Dark.
2. `reexecutar_etapa_automacao`: Manda a própria Fábrica Dark rodar novamente uma etapa específica (`p1_estruturar`, `p2_roteiro`, `p4_pacote_viral`, `p5_audio_srt`, `p6_cenas`, `p7_projeto_dp`).
3. `ajustar_roteiro_atual`: Ajusta cirurgicamente o roteiro aberto na Fábrica Dark na mesma conversa (preservando ponto de vista e sem regerar narração à toa).
4. `atualizar_formato_estilo_funcoes_canal`: Configura formatos (ex.: 80% vídeo / 20% imagem, 100% imagem, vídeo real), estilos visuais, legendas e funções especiais aqui na automação Fábrica Dark (para já valer no roteiro, nas cenas e ir pronto no final para o DarkPlanner).
5. `marcar_tema_feito`, `atualizar_settings`, `excluir_projeto`.

Responda em JSON estrito neste formato:
{
  "resposta_markdown": "Explicação clara e direta em Português confirmando o que foi ajustado/corrigido aqui na automação Fábrica Dark",
  "acoes": [
    // {"tipo": "parar_e_corrigir_automacao_local", "parar_esteira": true, "auto_reexecutar": false},
    // {"tipo": "reexecutar_etapa_automacao", "etapa": "p1_estruturar|p2_roteiro|p4_pacote_viral|p5_audio_srt|p6_cenas"},
    // {"tipo": "ajustar_roteiro_atual", "novo_roteiro": "texto ajustado mantendo mesmo ponto de vista"},
    // {
    //   "tipo": "atualizar_formato_estilo_funcoes_canal",
    //   "canal_id_ou_nome": "ID ou nome do canal alvo",
    //   "campos": {
    //     "modo_midia_custom": "70v_30i|flow_iv|100_img|video_real|gta_rockstar_real",
    //     "proporcao_midia": {"video_pct": 70, "imagem_pct": 30},
    //     "estilo_visual": "Estilo visual dos vídeos",
    //     "formato_video_custom": "Formato/ritmo dos vídeos",
    //     "funcoes_especiais_video": ["Função 1"],
    //     "regras_custom_chat": "Diretriz salva na automação",
    //     "idioma": "pt|en|es|fr",
    //     "veo_faixas_padrao": [4.0, 6.0]
    //   },
    //   "edicao_patch": {
    //     "predef": "sys_tudo|sys_doc|sys_minimalista",
    //     "look_cor": "cinematografico|quente|frio|contraste|neutro",
    //     "legenda_estilo": "marca_texto|karaoke|minimalista|caixa_escura|sem_legenda",
    //     "densidade_destaques": "discreto|equilibrado|dinamico",
    //     "instrucoes_custom": "Instrução que irá pronta no pacote final para o Studio"
    //   }
    // },
    // {"tipo": "marcar_tema_feito", "canal_id_ou_nome": "...", "titulo_tema": "..."},
    // {"tipo": "atualizar_settings", "campos": {"palavras_por_minuto": 145}},
    // {"tipo": "excluir_projeto", "titulo": "..."}
  ]
}"""

    resumo_etapas_app = json.dumps(etapas_app, ensure_ascii=False)[:1400] if etapas_app else "{}"
    resumo_logs_app = "\n".join(str(x) for x in logs_recentes_app[-15:])[:1600] if logs_recentes_app else "(sem logs recentes)"
    prompt_ag = f"""CANAIS NA AUTOMAÇÃO FÁBRICA DARK:
{json.dumps(canais_resumo, ensure_ascii=False)}

ESTADO ATUAL DA AUTOMAÇÃO FÁBRICA DARK:
- Canal selecionado: {canal_nome or canal_id or 'nenhum'} (id={canal_id or '-'})
- Projeto na Fábrica Dark: {nome_projeto or 'nenhum'} (vid={vid or '-'}, sp_id={sp_id or '-'})
- Esteira rodando agora: {'SIM' if esteira_rodando else 'NÃO'} | Já chegou na Etapa 7 final: {'SIM' if ja_na_etapa7 else 'NÃO (ainda nas etapas internas da Fábrica Dark)'}
- Status das Etapas 1 a 7 na Fábrica Dark: {resumo_etapas_app}
- Últimos Logs da Fábrica Dark:
{resumo_logs_app}
- Estrutura atual (se houver): {estrutura_atual[:900] if estrutura_atual else '(vazia)'}
- Trecho do roteiro atual (se houver): {roteiro_atual[:1800] if roteiro_atual else '(sem roteiro aberto na tela)'}

HISTÓRICO DESTA MESMA CONVERSA:
{hist_txt or '(início da conversa)'}

PEDIDO ATUAL DO USUÁRIO:
"{mensagem}"
"""

    dados_resp = None
    provedor_usado = "fabrica-dark+antigravity"
    try:
        dados_resp = claude.gerar_json(
            prompt_ag,
            sistema=sistema_agente,
            vid=vid or None,
            max_tokens=3500,
            temperatura=0.3,
            tarefa="roteiro",
        )
    except Exception:
        txt_fb, prov_fb = gerar_texto_fallback_cascata(
            prompt_ag,
            sistema=sistema_agente,
            max_tokens=3500,
            temperatura=0.3,
            json_mode=True,
        )
        if prov_fb:
            provedor_usado = f"fabrica-dark+{prov_fb}"
        if txt_fb:
            try:
                m_j = re.search(r"\{[\s\S]*\}", txt_fb)
                dados_resp = json.loads(m_j.group(0) if m_j else txt_fb)
            except Exception:
                dados_resp = {"resposta_markdown": txt_fb, "acoes": []}

    if not isinstance(dados_resp, dict):
        dados_resp = {
            "resposta_markdown": (
                "✅ **Configuração salva diretamente aqui na automação Fábrica Dark!**"
                if acoes_det_seguranca
                else "Entendido! Ajuste processado aqui na nossa automação Fábrica Dark."
            ),
            "acoes": [],
        }

    acoes = list(dados_resp.get("acoes")) if isinstance(dados_resp.get("acoes"), list) else []
    # Bloqueia envio acidental ao DarkPlanner caso o usuário não tenha pedido explicitamente enviar ao DarkPlanner!
    if not pediu_envio_dp_expl and not ja_na_etapa7:
        acoes = [
            a for a in acoes
            if isinstance(a, dict) and str(a.get("tipo") or "").strip().lower() not in ("enviar_direto_chat_darkplanner", "encaminhar_correcao_dp_mesma_conversa")
        ]

    tipos_ja_presentes = {str(a.get("tipo") or "").strip().lower() for a in acoes if isinstance(a, dict)}
    if "atualizar_canal" in tipos_ja_presentes:
        tipos_ja_presentes.add("atualizar_formato_estilo_funcoes_canal")
    for ac_det in acoes_det_seguranca:
        if ac_det["tipo"] not in tipos_ja_presentes:
            acoes.append(ac_det)
            tipos_ja_presentes.add(ac_det["tipo"])

    novo_roteiro_aplicado = ""
    projeto_excluido = False
    instrucao_dp_remota_pendente = ""

    for ac in acoes:
        if not isinstance(ac, dict):
            continue
        tipo = str(ac.get("tipo") or "").strip().lower()

        if tipo == "parar_e_corrigir_automacao_local":
            diag_l = darkplanner_sync.diagnosticar_e_corrigir_erro_automacao_local({
                "mensagem": mensagem,
                "canal_id": canal_id,
                "canal_nome": canal_nome,
                "nome_projeto": nome_projeto,
                "vid": vid,
                "sp_id": sp_id,
                "etapas_app": etapas_app,
                "logs_recentes_app": logs_recentes_app,
                "esteira_rodando": esteira_rodando,
                "parar_esteira": bool(ac.get("parar_esteira", True)),
                "auto_reexecutar": bool(ac.get("auto_reexecutar", False)),
            })
            parar_automacao_app = bool(diag_l.get("parar_automacao_app", True))
            limpar_erros_etapas = bool(diag_l.get("limpar_erros_etapas", True))
            if diag_l.get("reexecutar_etapa_app"):
                reexecutar_etapa_app = str(diag_l["reexecutar_etapa_app"])
            if diag_l.get("etapa_sugerida_botao"):
                etapa_sugerida_botao = diag_l["etapa_sugerida_botao"]
            for c_loc in (diag_l.get("correcoes_locais") or []):
                alteracoes_aplicadas.append(c_loc)

        elif tipo == "reexecutar_etapa_automacao":
            et_r = str(ac.get("etapa") or "").strip()
            if et_r:
                reexecutar_etapa_app = et_r
                alteracoes_aplicadas.append(f"Reexecução da etapa `{et_r}` agendada aqui na Fábrica Dark.")

        elif tipo in ("atualizar_formato_estilo_funcoes_canal", "atualizar_canal", "aplicar_edicao_studio_direto"):
            alvo_c = str(ac.get("canal_id_ou_nome") or canal_id or canal_nome or "").strip()
            campos = ac.get("campos") if isinstance(ac.get("campos"), dict) else {}
            ed_patch = ac.get("edicao_patch") if isinstance(ac.get("edicao_patch"), dict) else {}
            res_sync_dp = darkplanner_sync.sincronizar_diretrizes_chat_no_darkplanner(
                canal_id=alvo_c if len(alvo_c) >= 24 and "-" in alvo_c else canal_id,
                canal_nome=alvo_c if not (len(alvo_c) >= 24 and "-" in alvo_c) else canal_nome,
                campos=campos,
                edicao_patch=ed_patch,
                nome_projeto=nome_projeto,
                pasta_creator=pasta_creator,
                srt_texto=srt_texto,
                aplicar_studio_agora=bool(ja_na_etapa7),
            )
            if res_sync_dp.get("ok"):
                cn_ok = res_sync_dp.get("canal_nome") or alvo_c or "Canal"
                sincronizado_dp_cloud = bool(res_sync_dp.get("sincronizado_dp_cloud"))
                ed_salva = res_sync_dp.get("edicao_padrao") or {}
                ch_atu = res_sync_dp.get("canal_atualizado") or {}
                ui_patch["canal_id"] = res_sync_dp.get("canal_id") or canal_id
                ui_patch["canal_nome"] = cn_ok
                if ed_salva:
                    ui_patch["edicao_config"] = ed_salva
                if ch_atu.get("estilo_visual"):
                    ui_patch["estilo_visual"] = ch_atu["estilo_visual"]
                if ch_atu.get("modo_midia_custom"):
                    ui_patch["modo_midia_custom"] = ch_atu["modo_midia_custom"]
                if ch_atu.get("proporcao_midia"):
                    ui_patch["proporcao_midia"] = ch_atu["proporcao_midia"]
                if ch_atu.get("formato_video_custom"):
                    ui_patch["formato_video_custom"] = ch_atu["formato_video_custom"]
                if ch_atu.get("funcoes_especiais_video"):
                    ui_patch["funcoes_especiais_video"] = ch_atu["funcoes_especiais_video"]

                alteracoes_aplicadas.append(
                    f"Configurado na automação Fábrica Dark para o canal `{cn_ok}` (será levado pronto ao DarkPlanner no final, na Etapa 7)."
                )

        elif tipo in ("enviar_direto_chat_darkplanner", "encaminhar_correcao_dp_mesma_conversa"):
            if not (pediu_envio_dp_expl or ja_na_etapa7):
                continue
            inst_dp = str(ac.get("instrucao_dp") or mensagem).strip()
            usar_nova_conv = bool(ac.get("nova_conversa", False) or nova_conversa_req)
            if inst_dp:
                proj_ref = nome_projeto if (nome_projeto and nome_projeto != "Projeto Atual") else ""
                if usar_nova_conv or not proj_ref:
                    msg_chat_direto = (
                        f"[COMANDO ENVIADO PELA FÁBRICA DARK"
                        + (f" — PROJETO '{proj_ref}'" if proj_ref else "")
                        + f"]\n{inst_dp}"
                    )
                else:
                    msg_chat_direto = (
                        f"[CONTINUAÇÃO NA MESMA CONVERSA — PROJETO '{proj_ref}']\n"
                        f"PROIBIDO gerar novo roteiro, novo ponto de vista ou nova narração MP3! "
                        f"Mantenha 100% dos arquivos já prontos deste projeto e aplique diretamente no DarkPlanner Studio/Creator:\n{inst_dp}"
                    )

                if os.name == "nt":
                    res_env_dp = darkplanner_sync.abrir_chat_darkplanner_e_colar(
                        mensagem_chat=msg_chat_direto,
                        auto_enviar=True,
                        nova_conversa=usar_nova_conv,
                        chat_modelo_opcao=chat_modelo_opcao,
                        forcar_reenvio=True,
                        titulo_conversa=proj_ref or "Comando Fábrica Dark",
                        auto_reconectar_cdp=True,
                        focar_janela=True,
                    )
                    enviado_direto_dp = bool(res_env_dp.get("cdp_enviou") or res_env_dp.get("enviado_direto_chat"))
                    alteracoes_aplicadas.append(
                        f"Comando enviado ao Chat do DarkPlanner Desktop ({'nova conversa' if usar_nova_conv else 'mesma conversa'})."
                    )
                elif not origem_nuvem:
                    instrucao_dp_remota_pendente = inst_dp

        elif tipo == "regularizar_midias_projeto":
            modo_reg = str(ac.get("modo") or "").strip()
            if modo_reg in ("regularizar_gta_rockstar", "reaplicar_edicao_studio"):
                disparar_regularizacao_midias = modo_reg

        elif tipo == "ajustar_roteiro_atual":
            nr = str(ac.get("novo_roteiro") or "").strip()
            if nr:
                novo_roteiro_aplicado = nr
                ui_patch["novo_roteiro"] = nr
                if vid:
                    with Tx() as db_w:
                        v_w = storage.find(db_w.get("videos") or [], vid)
                        if v_w:
                            v_w["roteiro"] = nr
                alteracoes_aplicadas.append("Roteiro atual ajustado aqui na Fábrica Dark (mesma conversa, sem recriar narração/ponto de vista).")

        elif tipo == "marcar_tema_feito":
            alvo_c = str(ac.get("canal_id_ou_nome") or canal_id or canal_nome or "").strip()
            tit_t = str(ac.get("titulo_tema") or "").strip()
            if tit_t:
                with Tx() as db_w:
                    ch_w = darkplanner_sync._localizar_canal_flexivel_db(
                        db_w.get("channels") or [],
                        canal_id=alvo_c if len(alvo_c) >= 24 and "-" in alvo_c else canal_id,
                        canal_nome=alvo_c if not (len(alvo_c) >= 24 and "-" in alvo_c) else canal_nome,
                    )
                    if not ch_w and db_w.get("channels"):
                        ch_w = db_w["channels"][0]
                    if ch_w:
                        t_n = re.sub(r"\W+", "", pauta._sem_acentos(tit_t.lower()))
                        concl = list(ch_w.get("temas_concluidos_manual") or [])
                        if not any(re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) == t_n for x in concl):
                            concl.append(tit_t)
                        ch_w["temas_concluidos_manual"] = concl
                        mapa_g = db_w.setdefault("settings", {}).setdefault("temas_concluidos_por_canal", {})
                        lista_g = list(mapa_g.get(ch_w["id"]) or [])
                        if not any(re.sub(r"\W+", "", pauta._sem_acentos(x.lower())) == t_n for x in lista_g):
                            lista_g.append(tit_t)
                        mapa_g[ch_w["id"]] = lista_g
                        alteracoes_aplicadas.append(f"Tema `{tit_t}` marcado permanentemente como ✅ Já Feito em `{ch_w.get('nome')}`.")

        elif tipo == "atualizar_settings":
            campos_s = ac.get("campos") if isinstance(ac.get("campos"), dict) else {}
            if campos_s:
                with Tx() as db_w:
                    st_w = db_w.setdefault("settings", {})
                    for k_s, v_s in campos_s.items():
                        st_w[k_s] = v_s
                alteracoes_aplicadas.append(f"Configurações da Fábrica Dark atualizadas: {', '.join(campos_s.keys())}.")

        elif tipo == "excluir_projeto":
            tit_del = str(ac.get("titulo") or nome_projeto or "").strip()
            if tit_del or vid or sp_id:
                darkplanner_sync.deletar_projeto_criado_completo(
                    titulo=tit_del if tit_del != "Projeto Atual" else "",
                    vid=vid,
                    sp_id=sp_id,
                    apagar_arquivos_disco=True,
                )
                projeto_excluido = True
                parar_automacao_app = True
                alteracoes_aplicadas.append(f"Projeto `{tit_del or vid}` excluído por completo da Fábrica Dark.")

    # Só despacha para o PC/DarkPlanner se houve pedido EXPLÍCITO de enviar ao DarkPlanner agora
    if instrucao_dp_remota_pendente and pediu_envio_dp_expl and os.name != "nt" and not origem_nuvem:
        try:
            sp_rem_dp = sp_id if sp_id and not sp_id.startswith("sp_op_") else f"sp_op_{int(time.time())}"
            darkplanner_sync.enfileirar_etapa7_remoto_nuvem({
                "sp_id": sp_rem_dp,
                "nome_projeto": nome_projeto or "Comando Fábrica Dark",
                "titulo": nome_projeto or "Comando Fábrica Dark",
                "canal_id": ui_patch.get("canal_id") or canal_id,
                "canal_nome": ui_patch.get("canal_nome") or canal_nome,
                "vid": vid,
                "job_id": job_id,
                "srt_texto": srt_texto,
                "chat_modelo_opcao": chat_modelo_opcao,
                "pausado": False,
                "comando_chat_operacional": {
                    "mensagem": instrucao_dp_remota_pendente,
                    "acao_rapida": "",
                    "nome_projeto": nome_projeto,
                    "canal_id": ui_patch.get("canal_id") or canal_id,
                    "canal_nome": ui_patch.get("canal_nome") or canal_nome,
                    "chat_modelo_opcao": chat_modelo_opcao,
                    "nova_conversa": bool(nova_conversa_req),
                },
                "acao_tecnica": "aguardando_comando_pc",
                "progresso_pct": 25,
                "etapa_atual": f"🌐 Enviando comando solicitado ao Chat do DarkPlanner ('{nome_projeto or 'Canal'}')...",
            })
            enviado_direto_dp = True
            alteracoes_aplicadas.append("Comando enviado ao Chat do DarkPlanner conforme solicitado.")
        except Exception:
            pass

    resp_md = str(dados_resp.get("resposta_markdown") or "Pronto!").strip()
    if alteracoes_aplicadas:
        resp_md += "\n\n**Aplicado aqui na Automação Fábrica Dark:**\n" + "\n".join(f"• ✅ {x}" for x in alteracoes_aplicadas)

    return {
        "ok": True,
        "provedor": provedor_usado,
        "parar_automacao_app": parar_automacao_app,
        "limpar_erros_etapas": limpar_erros_etapas,
        "reexecutar_etapa_app": reexecutar_etapa_app,
        "etapa_sugerida_botao": etapa_sugerida_botao,
        "sincronizado_darkplanner": sincronizado_dp_cloud or enviado_direto_dp,
        "enviado_direto_chat_dp": enviado_direto_dp,
        "disparar_regularizacao_midias": disparar_regularizacao_midias,
        "alteracoes": alteracoes_aplicadas,
        "ui_patch": ui_patch,
        "novo_roteiro": novo_roteiro_aplicado,
        "projeto_excluido": projeto_excluido,
        "sp_id_excluido": sp_id if projeto_excluido else "",
        "titulo_excluido": nome_projeto if projeto_excluido else "",
        "resposta": resp_md,
    }

