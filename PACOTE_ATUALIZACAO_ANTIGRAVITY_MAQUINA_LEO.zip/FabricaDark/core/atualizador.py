"""Atualização e sincronização automática com o Antigravity e com D:\\AUTOMAÇÃO DARK\\MAQUINA LEO\\FabricaDark.

1. Sincroniza automaticamente a pasta local (e espelha em D:\\AUTOMAÇÃO DARK\\MAQUINA LEO\\FabricaDark no Windows)
   a partir do Google Drive (pasta AUTOMAÇÃO), do Google Drive Desktop ou da pasta Downloads.
2. Preserva integralmente as chaves locais em data/db.json e o ambiente .venv/.
"""
import glob
import hashlib
import io
import os
import shutil
import subprocess
import sys
import threading
import time
import zipfile

import requests

from core import versao

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROTEGIDOS = ("data/db.json", ".venv/", "venv/", "data/app.lock", "data/registro.txt")
_CACHE = {"quando": 0, "info": None, "erro": ""}
ESTADO = {"rodando": False, "etapa": "", "erro": "", "ultima_sync": ""}


def _num(v):
    try:
        return tuple(int(x) for x in str(v).replace("-", ".").split("."))
    except ValueError:
        return (0,)


def _link_direto(url):
    """Aceita link de compartilhamento do Google Drive ou do Dropbox e transforma em download direto."""
    import re

    m = re.search(r"drive\.google\.com/(?:file/d/|open\?id=|uc\?.*id=)([\w-]{20,})", url)
    if m:
        return f"https://drive.usercontent.google.com/download?id={m.group(1)}&export=download&confirm=t"
    if "dropbox.com" in url:
        return re.sub(r"([?&])dl=0", r"\1dl=1", url) if "dl=0" in url else url + ("&" if "?" in url else "?") + "dl=1"
    return url


def _info_do_zip(dados):
    """Modo 'um arquivo só': a versão e as novidades vêm de dentro do próprio zip."""
    import re

    z = zipfile.ZipFile(io.BytesIO(dados))
    nome_v = next((n for n in z.namelist() if n.endswith("core/versao.py")), None)
    if not nome_v:
        raise RuntimeError("o arquivo de atualização não é da Fábrica Dark")
    m = re.search(r'VERSAO\s*=\s*"([^"]+)"', z.read(nome_v).decode("utf-8", "replace"))
    nov = next((z.read(n).decode("utf-8", "replace").strip() for n in z.namelist() if n.endswith("NOVIDADES.txt")), "")
    return {"versao": m.group(1) if m else "", "novidades": nov[:300], "_dados": dados}


def _candidatos_zip_locais():
    """Procura pacotes de atualização sincronizados pelo Google Drive Desktop, pasta MAQUINA LEO ou Downloads."""
    candidatos = []
    up = os.environ.get("USERPROFILE", "")
    padroes = [
        r"D:\AUTOMAÇÃO DARK\MAQUINA LEO\PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip",
        r"D:\AUTOMAÇÃO DARK\PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip",
        r"G:\Meu Drive\AUTOMAÇÃO\PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip",
        r"G:\My Drive\AUTOMAÇÃO\PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip",
        r"D:\Meu Drive\AUTOMAÇÃO\PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip",
    ]
    if up:
        padroes.extend([
            os.path.join(up, "Google Drive", "AUTOMAÇÃO", "PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip"),
            os.path.join(up, "Meu Drive", "AUTOMAÇÃO", "PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip"),
            os.path.join(up, "Downloads", "PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip"),
            os.path.join(up, "Desktop", "PACOTE_ATUALIZACAO_ANTIGRAVITY_MAQUINA_LEO*.zip"),
        ])
    for pad in padroes:
        for arq in glob.glob(pad):
            if os.path.isfile(arq):
                candidatos.append(arq)
    candidatos.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return candidatos


def _extrair_zip_em_pasta(dados_zip, pasta_destino):
    """Extrai arquivos de código do pacote para pasta_destino preservando chaves locais em data/db.json e .venv."""
    z = zipfile.ZipFile(io.BytesIO(dados_zip))
    nomes = z.namelist()
    raiz = next((n[: -len("app.py")] for n in nomes if n.endswith("app.py") and n.count("/") <= 1), None)
    if raiz is None:
        return 0
    trocados = 0
    os.makedirs(pasta_destino, exist_ok=True)
    for n in nomes:
        if not n.startswith(raiz) or n.endswith("/"):
            continue
        rel = n[len(raiz):]
        if not rel or ".." in rel.split("/"):
            continue
        # Se data/db.json já existe no destino, preserva as chaves e vídeos locais
        if rel == "data/db.json" and os.path.exists(os.path.join(pasta_destino, "data", "db.json")):
            continue
        if any(rel.startswith(p) for p in (".venv/", "venv/", "data/app.lock", "data/registro.txt")):
            continue
        destino = os.path.join(pasta_destino, *rel.split("/"))
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        novo_bytes = z.read(n)
        if os.path.exists(destino):
            try:
                with open(destino, "rb") as f_ant:
                    if f_ant.read() == novo_bytes:
                        continue
            except Exception:
                pass
        tmp = destino + ".novo"
        with open(tmp, "wb") as f:
            f.write(novo_bytes)
        os.replace(tmp, destino)
        trocados += 1
    return trocados


def espelhar_para_pasta_fixa_windows():
    """Garante que toda alteração na pasta atual também esteja sincronizada em D:\\AUTOMAÇÃO DARK\\MAQUINA LEO\\FabricaDark."""
    if os.name != "nt":
        return 0
    alvo = getattr(versao, "PASTA_FIXA_WINDOWS", r"D:\AUTOMAÇÃO DARK\MAQUINA LEO\FabricaDark")
    if not alvo:
        return 0
    try:
        if os.path.normcase(os.path.abspath(BASE)) == os.path.normcase(os.path.abspath(alvo)):
            return 0
        pai_alvo = os.path.dirname(alvo)
        if not os.path.exists(pai_alvo) and not os.path.exists("D:\\"):
            return 0
        os.makedirs(alvo, exist_ok=True)
        copiados = 0
        for root, dirs, files in os.walk(BASE):
            dirs[:] = [d for d in dirs if d not in (".venv", "venv", "__pycache__", "janela-app", ".git")]
            rel_dir = os.path.relpath(root, BASE)
            dest_dir = alvo if rel_dir == "." else os.path.join(alvo, rel_dir)
            os.makedirs(dest_dir, exist_ok=True)
            for fname in files:
                if fname.endswith((".pyc", ".lock", ".novo")) or fname == "registro.txt":
                    continue
                orig_f = os.path.join(root, fname)
                dest_f = os.path.join(dest_dir, fname)
                if rel_dir == "data" and fname == "db.json" and os.path.exists(dest_f):
                    continue
                precisa = not os.path.exists(dest_f)
                if not precisa:
                    try:
                        precisa = os.path.getsize(orig_f) != os.path.getsize(dest_f) or int(os.path.getmtime(orig_f)) > int(os.path.getmtime(dest_f))
                    except Exception:
                        precisa = True
                if precisa:
                    shutil.copy2(orig_f, dest_f)
                    copiados += 1
        return copiados
    except Exception:
        return 0


def _gravar_arquivos_em_pasta(mapa_arquivos, pasta_destino):
    """Grava os arquivos descompactados da nuvem em pasta_destino se houver diferença."""
    trocados = 0
    os.makedirs(pasta_destino, exist_ok=True)
    for rel, conteudo in (mapa_arquivos or {}).items():
        if not rel or ".." in rel.split("/"):
            continue
        if rel == "data/db.json" and os.path.exists(os.path.join(pasta_destino, "data", "db.json")):
            continue
        destino = os.path.join(pasta_destino, *rel.split("/"))
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        novo_bytes = conteudo.encode("utf-8") if isinstance(conteudo, str) else conteudo
        if os.path.exists(destino):
            try:
                with open(destino, "rb") as f_ant:
                    if f_ant.read() == novo_bytes:
                        continue
            except Exception:
                pass
        tmp = destino + ".novo"
        with open(tmp, "wb") as f:
            f.write(novo_bytes)
        os.replace(tmp, destino)
        trocados += 1
    return trocados


def sincronizar_da_nuvem_darkplanner(refs_dp=None, auto_reiniciar=False):
    """Puxa automaticamente do canal seguro da nuvem (__ANTIGRAVITY_SYNC__) todas as atualizações feitas no Antigravity
    e grava direto na pasta local e em D:\\AUTOMAÇÃO DARK\\MAQUINA LEO\\FabricaDark sem precisar baixar arquivo manual."""
    import base64
    import json
    import lzma

    if os.name != "nt" and os.path.exists("/home/antigravity/sincronizar_maquina_leo.py"):
        return 0
    try:
        from core import darkplanner_sync
        if refs_dp is None:
            refs_dp = darkplanner_sync.req("GET", "/referencias", timeout=20) or []
        item_sync = next((r for r in (refs_dp or []) if isinstance(r, dict) and r.get("nome_canal") == "__ANTIGRAVITY_SYNC__"), None)
        if not item_sync:
            return 0
        remota_v = (item_sync.get("nicho") or "").strip()
        b64_payload = (item_sync.get("anotacoes") or "").strip()
        if not b64_payload:
            return 0
        local_v = getattr(versao, "VERSAO", "0")
        if remota_v and _num(remota_v) < _num(local_v):
            return 0
        ja_verificou = _CACHE.get("ultima_versao_nuvem_verificada") == remota_v
        if ja_verificou and remota_v and _num(remota_v) <= _num(local_v):
            return 0
        raw_comp = base64.b64decode(b64_payload)
        pacote = json.loads(lzma.decompress(raw_comp).decode("utf-8"))
        arquivos = pacote.get("arquivos") or {}
        trocados = _gravar_arquivos_em_pasta(arquivos, BASE)
        if os.name == "nt" and os.path.exists("D:\\"):
            alvo_win = getattr(versao, "PASTA_FIXA_WINDOWS", r"D:\AUTOMAÇÃO DARK\MAQUINA LEO\FabricaDark")
            if os.path.normcase(os.path.abspath(BASE)) != os.path.normcase(os.path.abspath(alvo_win)):
                trocados += _gravar_arquivos_em_pasta(arquivos, alvo_win)
        if remota_v:
            versao.VERSAO = remota_v
            _CACHE["ultima_versao_nuvem_verificada"] = remota_v
        if trocados > 0:
            for pasta_c in ("Cache", "Code Cache", "GPUCache", os.path.join("Network", "Cache")):
                shutil.rmtree(os.path.join(BASE, "data", "janela-app", "Default", pasta_c), ignore_errors=True)
            try:
                import importlib
                from core import (
                    storage as _st_mod,
                    prompts as _pr_mod,
                    antigravity_codex as _ac_mod,
                    gemini as _gm_mod,
                    claude as _cl_mod,
                    pauta as _pt_mod,
                    thumb as _th_mod,
                )
                for _m_rel in (_st_mod, _pr_mod, _ac_mod, _gm_mod, _cl_mod, _th_mod, darkplanner_sync, _pt_mod):
                    try:
                        importlib.reload(_m_rel)
                    except Exception:
                        pass
            except Exception:
                pass
            ESTADO["ultima_sync"] = time.strftime("%d/%m/%Y %H:%M:%S")
            if auto_reiniciar and os.name == "nt":
                _reiniciar()
        return trocados
    except Exception:
        return 0


def sincronizar_ao_iniciar():
    """Executado pelo iniciar.bat e pelo app.py ao abrir: aplica pacotes da nuvem e locais e garante regras dos canais."""
    trocados_total = 0
    try:
        trocados_total += sincronizar_da_nuvem_darkplanner(auto_reiniciar=True)
    except Exception:
        pass
    try:
        for arq_zip in _candidatos_zip_locais():
            try:
                with open(arq_zip, "rb") as f:
                    dados = f.read()
                info = _info_do_zip(dados)
                if info.get("versao") and _num(info["versao"]) > _num(versao.VERSAO):
                    trocados_total += _extrair_zip_em_pasta(dados, BASE)
                    if os.name == "nt" and os.path.exists("D:\\"):
                        alvo_win = getattr(versao, "PASTA_FIXA_WINDOWS", r"D:\AUTOMAÇÃO DARK\MAQUINA LEO\FabricaDark")
                        if os.path.normcase(os.path.abspath(BASE)) != os.path.normcase(os.path.abspath(alvo_win)):
                            _extrair_zip_em_pasta(dados, alvo_win)
                    break
            except Exception:
                continue
    except Exception:
        pass
    try:
        espelhar_para_pasta_fixa_windows()
    except Exception:
        pass
    try:
        from core import darkplanner_sync
        if hasattr(darkplanner_sync, "garantir_regras_canais_padrao"):
            darkplanner_sync.garantir_regras_canais_padrao()
    except Exception:
        pass
    ESTADO["ultima_sync"] = time.strftime("%d/%m/%Y %H:%M:%S")
    return trocados_total


def checar(forcar=False):
    # Primeiro verifica pacotes locais (Google Drive Desktop / MAQUINA LEO / Downloads)
    for arq_zip in _candidatos_zip_locais():
        try:
            with open(arq_zip, "rb") as f:
                dados = f.read()
            info = _info_do_zip(dados)
            if info.get("versao") and _num(info["versao"]) > _num(versao.VERSAO):
                _CACHE.update(info=info, erro="", quando=time.time())
                return {
                    "ativo": True,
                    "atual": versao.VERSAO,
                    "nova": True,
                    "versao": info.get("versao", ""),
                    "novidades": info.get("novidades", "") or f"Pacote local detectado ({os.path.basename(arq_zip)})",
                    "erro": "",
                    "estado": dict(ESTADO),
                }
        except Exception:
            continue

    url = versao.URL_ATUALIZACAO
    if not url:
        return {"ativo": False, "atual": versao.VERSAO}
    if forcar or time.time() - _CACHE["quando"] > 3600:
        try:
            r = requests.get(_link_direto(url), timeout=60, headers={"Cache-Control": "no-cache"})
            r.raise_for_status()
            if r.content[:2] == b"PK":  # o link é o próprio zip (Google Drive / Dropbox)
                info = _info_do_zip(r.content)
            elif r.text.strip().startswith("{"):
                info = r.json()
            else:
                info = {}
            _CACHE.update(info=info, erro="", quando=time.time())
        except Exception as e:
            _CACHE.update(erro=str(e)[:200], quando=time.time())
    info = _CACHE["info"] or {}
    nova = bool(info.get("versao")) and _num(info["versao"]) > _num(versao.VERSAO)
    return {
        "ativo": True,
        "atual": versao.VERSAO,
        "nova": nova,
        "versao": info.get("versao", ""),
        "novidades": info.get("novidades", ""),
        "erro": _CACHE["erro"],
        "estado": dict(ESTADO),
    }


def _aplicar(info):
    ESTADO.update(rodando=True, etapa="Baixando a versão nova", erro="")
    try:
        if info.get("_dados"):
            dados = info["_dados"]
        else:
            r = requests.get(_link_direto(info["zip"]), timeout=300)
            r.raise_for_status()
            dados = r.content
        if info.get("sha256") and hashlib.sha256(dados).hexdigest() != info["sha256"].lower():
            raise RuntimeError("o arquivo baixado não confere (tente de novo mais tarde)")
        ESTADO["etapa"] = "Trocando os arquivos em FabricaDark"
        _extrair_zip_em_pasta(dados, BASE)
        if os.name == "nt" and os.path.exists("D:\\"):
            alvo_win = getattr(versao, "PASTA_FIXA_WINDOWS", r"D:\AUTOMAÇÃO DARK\MAQUINA LEO\FabricaDark")
            if os.path.normcase(os.path.abspath(BASE)) != os.path.normcase(os.path.abspath(alvo_win)):
                _extrair_zip_em_pasta(dados, alvo_win)
        ESTADO["etapa"] = "Reiniciando"
        _reiniciar()
    except Exception as e:
        ESTADO.update(rodando=False, erro=str(e)[:300], etapa="")


def _reiniciar():
    if os.name == "nt":
        env = dict(os.environ, FD_BASE_DIR=BASE)
        ps_cmd = (
            "Start-Sleep -Milliseconds 1200; "
            "$p = $env:FD_BASE_DIR; "
            "Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | "
            "Where-Object { (($_.Name -match '^(chrome|msedge)\\.exe$') -and ($_.CommandLine -like '*janela-app*')) } | "
            "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; "
            "Start-Sleep -Milliseconds 900; "
            "Remove-Item \"$p\\data\\app.lock\" -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$p\\data\\janela-app\\Default\\Cache\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "Remove-Item \"$p\\data\\janela-app\\Default\\Code Cache\" -Recurse -Force -ErrorAction SilentlyContinue; "
            "$py = \"$p\\.venv\\Scripts\\pythonw.exe\"; "
            "if (!(Test-Path $py)) { $py = \"$p\\.venv\\Scripts\\python.exe\" }; "
            "if (Test-Path $py) { Start-Process -FilePath $py -ArgumentList 'app.py --app' -WorkingDirectory $p }"
        )
        subprocess.Popen(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-Command", ps_cmd],
            cwd=BASE,
            env=env,
            creationflags=0x08000000,
        )
    threading.Timer(0.6, lambda: os._exit(0)).start()


def atualizar():
    st = checar(True)
    if not st.get("nova"):
        raise RuntimeError("Já está na versão mais nova.")
    if ESTADO["rodando"]:
        raise RuntimeError("Já está atualizando.")
    threading.Thread(target=_aplicar, args=(_CACHE["info"],), daemon=True).start()
