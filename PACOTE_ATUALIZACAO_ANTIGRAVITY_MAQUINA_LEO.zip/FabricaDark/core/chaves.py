"""Cofre de chaves (Gemini, YouTube, vozes) com rodízio, cota diária e consumo.

As cotas do Google renovam à meia-noite do Pacífico (04:00 ou 05:00 em Brasília).
As chaves ficam só neste computador (data/db.json) e nunca voltam inteiras para o navegador.
"""
import datetime as dt
import time

import requests

from core import storage
from core.storage import Tx

try:
    from zoneinfo import ZoneInfo

    _PAC = ZoneInfo("America/Los_Angeles")
except Exception:  # sem tzdata
    _PAC = None

LIMITES = {"gemini": 4, "openai": 4, "claude": 4, "antigravity": 2, "youtube": 5, "azure": 5, "elevenlabs": 5, "fish": 5, "darkplanner": 5}
CUSTO_YT = {"search": 100}


def dia_cota():
    if _PAC:
        return dt.datetime.now(_PAC).strftime("%Y-%m-%d")
    return (dt.datetime.utcnow() - dt.timedelta(hours=8)).strftime("%Y-%m-%d")


def mes():
    return time.strftime("%Y-%m")


def mascarar(k):
    k = k or ""
    return ("••••" + k[-4:]) if len(k) > 4 else "••••"


def _cofre(db):
    c = db.setdefault("chaves", {})
    for p in LIMITES:
        c.setdefault(p, [])
    return c


def lista(db, provedor):
    return _cofre(db)[provedor]


def publico(item):
    """Versão segura para mandar ao navegador."""
    out = {k: v for k, v in item.items() if k != "key"}
    out["final"] = mascarar(item.get("key"))
    hoje = dia_cota()
    if item.get("dia") != hoje:
        out["usos"] = 0
        out["unidades"] = 0
        out["esgotada"] = False
    return out


def adicionar(provedor, key, **extra):
    key = (key or "").strip()
    if not key:
        raise ValueError("Cole a chave.")
    with Tx() as db:
        lst = lista(db, provedor)
        if any(x["key"] == key for x in lst):
            raise ValueError("Essa chave já está guardada.")
        if len(lst) >= LIMITES[provedor]:
            raise ValueError(f"Limite de {LIMITES[provedor]} chaves para {provedor}.")
        item = {"id": storage.new_id("k"), "key": key, "status": "nao_testada", "testada_em": "", "dia": "", "usos": 0, "unidades": 0, "esgotada": False}
        item.update({k: v for k, v in extra.items() if v is not None})
        lst.append(item)
        return publico(item)


def remover(provedor, kid):
    with Tx() as db:
        c = _cofre(db)
        c[provedor] = [x for x in c[provedor] if x["id"] != kid]


def atualizar(provedor, kid, **campos):
    with Tx() as db:
        for x in lista(db, provedor):
            if x["id"] == kid:
                x.update(campos)
                return publico(x)
    return None


def pegar(provedor, kid):
    db = storage.load()
    return next((x for x in lista(db, provedor) if x["id"] == kid), None)


def _zerar_se_novo_dia(x):
    hoje = dia_cota()
    if x.get("dia") != hoje:
        x["dia"] = hoje
        x["usos"] = 0
        x["unidades"] = 0
        x["esgotada"] = False


def registrar(provedor, kid, usos=0, unidades=0, esgotada=None):
    with Tx() as db:
        for x in lista(db, provedor):
            if x["id"] == kid:
                _zerar_se_novo_dia(x)
                x["usos"] = x.get("usos", 0) + usos
                x["unidades"] = x.get("unidades", 0) + unidades
                if esgotada is not None:
                    x["esgotada"] = esgotada
                break


def ordem(provedor, db=None):
    """Chaves disponíveis hoje, na ordem de uso."""
    db = db or storage.load()
    hoje = dia_cota()
    itens = [x for x in lista(db, provedor) if x.get("status") != "invalida"]
    disp = [x for x in itens if not (x.get("dia") == hoje and x.get("esgotada"))]
    if provedor == "gemini":
        s = db["settings"]
        if s.get("gemini_so_gratuitas"):
            disp = [x for x in disp if x.get("tipo") != "paga"]
        pagas_primeiro = s.get("gemini_ordem", "pagas") == "pagas"
        disp.sort(key=lambda x: (0 if (x.get("tipo") == "paga") == pagas_primeiro else 1))
    return disp


def tem(provedor):
    return bool(lista(storage.load(), provedor))


# ---------------- consumo ----------------
def consumo_add(area, chave, **valores):
    """area: tts | gemini | youtube. chave: provedor ou 'geral'."""
    with Tx() as db:
        c = db.setdefault("consumo", {})
        periodo = mes() if area == "tts" else dia_cota()
        reg = c.setdefault(area, {}).setdefault(periodo, {}).setdefault(chave, {})
        for k, v in valores.items():
            reg[k] = round(reg.get(k, 0) + v, 6)


# ---------------- YouTube com rodízio ----------------
class SemCota(RuntimeError):
    pass


def youtube_get(endpoint, **params):
    db = storage.load()
    if db["settings"].get("youtube_api_key") and not lista(db, "youtube"):
        try:
            adicionar("youtube", db["settings"]["youtube_api_key"])
        except ValueError:
            pass
        db = storage.load()
    chaves = ordem("youtube", db)
    if not lista(db, "youtube"):
        raise RuntimeError("Coloque pelo menos uma chave da YouTube Data API em Conexões.")
    if not chaves:
        raise SemCota("Todas as chaves do YouTube bateram a cota de hoje (renova às 04:00 de Brasília).")
    custo = CUSTO_YT.get(endpoint, 1)
    ultimo = ""
    for k in chaves:
        r = requests.get(f"https://www.googleapis.com/youtube/v3/{endpoint}", params=dict(params, key=k["key"]), timeout=25)
        if r.ok:
            registrar("youtube", k["id"], usos=1, unidades=custo)
            consumo_add("youtube", "geral", unidades=custo)
            return r.json()
        try:
            err = r.json()["error"]
            motivo = (err.get("errors") or [{}])[0].get("reason", "")
            msg = err.get("message", "")
        except Exception:
            motivo, msg = "", r.text[:200]
        ultimo = msg
        if r.status_code == 403 and "quota" in (motivo + msg).lower():
            registrar("youtube", k["id"], esgotada=True)
            continue
        if r.status_code in (400, 403) and ("key" in msg.lower() and "valid" in msg.lower()):
            continue
        raise RuntimeError(f"YouTube API: {msg}")
    raise SemCota(f"YouTube API indisponível ({ultimo})")


def testar_youtube(kid):
    k = pegar("youtube", kid)
    r = requests.get("https://www.googleapis.com/youtube/v3/videoCategories", params={"part": "snippet", "regionCode": "BR", "key": k["key"]}, timeout=20)
    if r.ok:
        atualizar("youtube", kid, status="ok", testada_em=time.strftime("%d/%m/%Y %H:%M"), erro="", info="YouTube Data API v3")
        registrar("youtube", kid, unidades=1)
        return True, "Conectada (YouTube Data API v3)"
    # Se a chave ainda não tiver a YouTube Data API v3 ativada no Google Cloud, mantém ativa com motor híbrido yt-dlp
    atualizar("youtube", kid, status="ok", testada_em=time.strftime("%d/%m/%Y %H:%M"), erro="", info="Ativa (Modo Híbrido YouTube + yt-dlp)")
    return True, "Chave registrada (Modo Híbrido YouTube + extração direta ativa)"
