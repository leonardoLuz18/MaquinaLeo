"""GPT (OpenAI) + Antigravity (Motor V8 Ninja Pro) + Gemini para os textos do vídeo.

- Conecta exclusivamente com GPT (OpenAI API), Gemini (Google AI Studio) e Antigravity (Motor V8 Ninja Pro).
- Sem vínculo com Claude.
- Se houver chave da OpenAI (GPT-4o / GPT-4o Mini / o3-mini), usa nas etapas marcadas; se não houver ou falhar,
  usa automaticamente o Gemini turbinado com a diretriz narrativa do Antigravity V8 Ninja Pro.
"""
import os
import time

import requests

from core import chaves, gemini, storage
from core.prompts import parse_json
from core.storage import Tx

API_OPENAI = "https://api.openai.com/v1/chat/completions"

# id -> (modelo OpenAI, US$/1M entrada, US$/1M saída, rótulo)
MODELOS = {
    "gpt-4o": ("gpt-4o", 2.50, 10.0, "GPT-4o (mais inteligente para roteiros e narrativa)"),
    "gpt-4o-mini": ("gpt-4o-mini", 0.15, 0.60, "GPT-4o Mini (rápido e econômico)"),
    "o3-mini": ("o3-mini", 1.10, 4.40, "OpenAI o3-mini (raciocínio avançado e estrutura)"),
    # aliases para compatibilidade caso o banco tenha valores antigos
    "sonnet": ("gpt-4o", 2.50, 10.0, "GPT-4o"),
    "haiku": ("gpt-4o-mini", 0.15, 0.60, "GPT-4o Mini"),
    "opus": ("o3-mini", 1.10, 4.40, "OpenAI o3-mini"),
}

ANTIGRAVITY_V8_SYSTEM = (
    "Você opera com a inteligência do Motor Antigravity V8 Ninja Pro para canais Dark de alta retenção. "
    "Regras absolutas: ritmo de 145 palavras por minuto, ganchos magnéticos nos primeiros 30 segundos, "
    "loops abertos entre blocos, zero clichês robóticos ('mergulhe', 'jornada', 'em suma', 'vale ressaltar'), "
    "narrativa humana, cinematográfica, envolvente e 100% segura para monetização no YouTube."
)


def _chaves_gpt(db=None):
    import json as _json
    db = db or storage.load()
    # Aceita chaves guardadas em 'openai', no bucket legado 'claude', em config.json, OPENAI_API_KEY ou ~/.codex/auth.json
    lista = list(chaves.ordem("openai", db) + chaves.ordem("claude", db))
    vistas = {str(x.get("key") or "").strip() for x in lista if isinstance(x, dict)}
    extras = [os.environ.get("OPENAI_API_KEY") or ""]
    try:
        p_cfg = os.path.join(storage.BASE_DIR, "config.json")
        if os.path.exists(p_cfg):
            with open(p_cfg, "r", encoding="utf-8") as f_c:
                dc = _json.load(f_c) or {}
            extras.append(dc.get("openai_api_key") or dc.get("OPENAI_API_KEY") or "")
    except Exception:
        pass
    try:
        p_cx = os.path.expanduser(r"~\.codex\auth.json")
        if os.path.exists(p_cx):
            with open(p_cx, "r", encoding="utf-8") as f_x:
                dx = _json.load(f_x) or {}
            extras.append(dx.get("OPENAI_API_KEY") or dx.get("api_key") or "")
    except Exception:
        pass
    for idx_e, k_ex in enumerate(extras):
        k_s = str(k_ex or "").strip()
        if k_s and k_s.startswith("sk-") and k_s not in vistas:
            vistas.add(k_s)
            lista.append({"id": f"auto_oai_{idx_e}", "key": k_s, "status": "ok"})
    return lista


_MAPA_MOJIBAKE_PTBR = [
    ("â€™", "’"), ("â€˜", "‘"), ("â€œ", "“"), ("â€\x9d", "”"), ("â€”", "—"), ("â€“", "–"), ("â€¦", "…"),
    ("Ã¡", "á"), ("Ã\xa1", "á"), ("Ã©", "é"), ("Ã\xa9", "é"), ("Ã­", "í"), ("Ã\xad", "í"),
    ("Ã³", "ó"), ("Ã\xb3", "ó"), ("Ãº", "ú"), ("Ã\xba", "ú"), ("Ã£", "ã"), ("Ã\xa3", "ã"),
    ("Ãµ", "õ"), ("Ã\xb5", "õ"), ("Ã§", "ç"), ("Ã\xa7", "ç"), ("Ãª", "ê"), ("Ã\xaa", "ê"),
    ("Ã´", "ô"), ("Ã\xb4", "ô"), ("Ã¢", "â"), ("Ã\xa2", "â"), ("Ã\xa0", "à"), ("Ã  ", "à "), (" Ã ", " à "),
    ("Ã±", "ñ"), ("Ã¼", "ü"),
    ("Ã\x81", "Á"), ("Ã‰", "É"), ("Ã\x89", "É"), ("Ã\x8d", "Í"), ("Ã“", "Ó"), ("Ã\x93", "Ó"),
    ("Ãš", "Ú"), ("Ã\x9a", "Ú"), ("Ãƒ", "Ã"), ("Ã\x83", "Ã"), ("Ã•", "Õ"), ("Ã\x95", "Õ"),
    ("Ã‡", "Ç"), ("Ã\x87", "Ç"), ("ÃŠ", "Ê"), ("Ã\x8a", "Ê"), ("Ã”", "Ô"), ("Ã\x94", "Ô"),
    ("Ã‚", "Â"), ("Ã\x82", "Â"), ("Ã€", "À"), ("Ã\x80", "À"),
    ("Â°", "°"), ("Âº", "º"), ("Âª", "ª"), ("Â·", "·"), ("Â«", "«"), ("Â»", "»"), ("Â¡", "¡"), ("Â¿", "¿"),
]


def corrigir_mojibake_ptbr(val):
    """Repara textos UTF-8 que foram lidos como CP1252/Latin-1 no Windows (ex.: 'RefÃºgio' -> 'Refúgio',
    'inundaÃ§Ã£o da superfÃcie' -> 'inundação da superfície', 'Zhengzhouâ€™s' -> 'Zhengzhou’s')."""
    import re as _re
    if isinstance(val, dict):
        return {k: corrigir_mojibake_ptbr(v) for k, v in val.items()}
    if isinstance(val, list):
        return [corrigir_mojibake_ptbr(x) for x in val]
    if not isinstance(val, str) or not val:
        return val
    if not any(m in val for m in ("Ã", "Â", "â€", "\ufffd")):
        return val
    out = val
    for _ in range(2):
        mudou = False
        for enc_src in ("cp1252", "latin1"):
            try:
                dec = out.encode(enc_src).decode("utf-8")
                if dec != out:
                    out = dec
                    mudou = True
                    break
            except Exception:
                pass
        if not mudou:
            break
    for k_m, v_m in _MAPA_MOJIBAKE_PTBR:
        if k_m in out:
            out = out.replace(k_m, v_m)
    out = _re.sub(
        r"(?<=[a-zA-Zçáéíóúãõêôâ])Ã(?=[bcdfghjklmnpqrstvwxyz]|o\b|da\b|do\b|dos\b|das\b|na\b|nas\b|no\b|nos\b|sta\b|smo\b)",
        "í",
        out,
    )
    out = _re.sub(r"\bÃ(?=[bcdfghjklmnpqrstvwxyz][a-z])", "Í", out)
    return out


def _chamar_codex_cli(prompt, timeout=55):
    """Executa prompt via ChatGPT / Codex CLI oficial logado no PC com UTF-8 estrito (zero Mojibake)."""
    import shutil as _sh
    import subprocess as _sp
    import tempfile as _tf
    codex_exe = _sh.which("codex")
    if not codex_exe:
        for cand_c in (
            os.path.expanduser(r"~\AppData\Local\Programs\OpenAI\Codex\bin\codex.EXE"),
            os.path.expanduser(r"~\AppData\Local\Programs\codex\codex.exe"),
            os.path.expanduser(r"~\AppData\Roaming\npm\codex.cmd"),
        ):
            if os.path.exists(cand_c):
                codex_exe = cand_c
                break
    if not codex_exe or not os.path.exists(os.path.expanduser(r"~\.codex\auth.json")):
        return ""
    tmp_out = ""
    try:
        fd_o, tmp_out = _tf.mkstemp(prefix="ag_codex_out_", suffix=".txt")
        os.close(fd_o)
        prompt_full = (
            f"{ANTIGRAVITY_V8_SYSTEM}\n\n"
            "IMPORTANTE: Responda em UTF-8 puro (Português-BR com acentuação correta, sem caracteres corrompidos). "
            "Respond ONLY with the requested output (do not run shell commands or tools):\n\n"
            f"{prompt}"
        )
        env_utf8 = dict(os.environ)
        env_utf8["PYTHONIOENCODING"] = "utf-8"
        env_utf8["PYTHONUTF8"] = "1"
        r_cx = _sp.run(
            [
                codex_exe,
                "exec",
                "--skip-git-repo-check",
                "--ignore-user-config",
                "-o",
                tmp_out,
                "-",
            ],
            input=prompt_full,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env_utf8,
            timeout=timeout,
            creationflags=0x08000000 if os.name == "nt" else 0,
        )
        out = ""
        if tmp_out and os.path.exists(tmp_out):
            try:
                with open(tmp_out, "r", encoding="utf-8", errors="replace") as f_o:
                    out = (f_o.read() or "").strip()
            except Exception:
                pass
        if not out:
            out = (r_cx.stdout or "").strip()
        out = corrigir_mojibake_ptbr(out)
        return out if len(out) > 10 else ""
    except Exception:
        return ""
    finally:
        if tmp_out and os.path.exists(tmp_out):
            try:
                os.remove(tmp_out)
            except Exception:
                pass



def tem_chave(db=None):
    return bool(_chaves_gpt(db))


def cli_caminho():
    """Retorna o status nativo do Motor Multi-IA (Antigravity V8 + ChatGPT + Gemini + Codex)."""
    return "Antigravity V8 + ChatGPT + Gemini + Codex (Ativos)"


def cli_testar():
    """Testa a disponibilidade do Motor Antigravity V8 + Gemini/GPT."""
    quando = time.strftime("%d/%m/%Y %H:%M")
    try:
        db = storage.load()
        if tem_chave(db):
            txt = _chamar_api("Responda só: ok", max_tokens=20, temperatura=0.0)
            msg = f"Antigravity V8 + GPT conectado ({txt.strip()[:20]})"
        else:
            txt = gemini.gerar_texto("Responda só: ok")
            msg = f"Antigravity V8 + Gemini conectado ({txt.strip()[:20]})"
        with Tx() as db2:
            db2["settings"]["claude_assinatura"] = {"ok": True, "testado_em": quando, "erro": "", "motor": "Antigravity V8"}
            db2["settings"]["antigravity_ativo"] = True
        return True, msg
    except Exception as e:
        msg = str(e)[:220]
        with Tx() as db2:
            db2["settings"]["claude_assinatura"] = {"ok": False, "testado_em": quando, "erro": msg}
        return False, msg


def modo(db=None):
    """'api' (chave GPT), 'antigravity' (Motor V8 + Gemini), ou ''."""
    db = db or storage.load()
    if tem_chave(db):
        return "api"
    if db["settings"].get("antigravity_ativo", True):
        return "antigravity"
    return ""


def disponivel(db=None):
    return bool(modo(db))


def usar_para(tarefa, db=None):
    db = db or storage.load()
    if not disponivel(db):
        return False
    t = db["settings"].get("gpt_tarefas") or db["settings"].get("claude_tarefas") or {}
    return bool(t.get(tarefa, True))


def _modelo(settings):
    m = settings.get("gpt_modelo") or settings.get("claude_modelo", "gpt-4o")
    return MODELOS.get(m, MODELOS["gpt-4o"])


def _chamar_api(prompt, video_id=None, max_tokens=16000, temperatura=0.7):
    db = storage.load()
    s = db["settings"]
    fila = _chaves_gpt(db)
    if not fila:
        raise RuntimeError("Nenhuma chave da OpenAI (GPT) configurada.")
    modelo, p_in, p_out, _ = _modelo(s)
    limite = float(s.get("limite_gasto_video", 10) or 0)
    gasto = float((storage.find(db["videos"], video_id) or {}).get("custo_ia_brl", 0)) if video_id else 0.0
    if video_id and limite and gasto >= limite:
        raise RuntimeError(f"Limite de gasto do vídeo (R$ {limite:.2f}) atingido.")
    ultimo = ""
    for k in fila:
        prov_k = "openai" if any(x["id"] == k["id"] for x in chaves.lista(db, "openai")) else "claude"
        for tentativa in range(2):
            body = {
                "model": modelo,
                "messages": [
                    {"role": "system", "content": ANTIGRAVITY_V8_SYSTEM},
                    {"role": "user", "content": prompt},
                ],
                "temperature": temperatura,
            }
            if modelo.startswith("o3") or modelo.startswith("o1"):
                body.pop("temperature", None)
                body["max_completion_tokens"] = min(max_tokens, 16384)
            else:
                body["max_tokens"] = min(max_tokens, 16384)
            r = requests.post(
                API_OPENAI,
                headers={"Authorization": f"Bearer {k['key']}", "Content-Type": "application/json"},
                json=body,
                timeout=300,
            )
            if r.status_code == 429:
                ultimo = _erro(r)
                if "quota" in ultimo.lower() or "billing" in ultimo.lower() or tentativa == 1:
                    chaves.registrar(prov_k, k["id"], esgotada=True)
                    break
                time.sleep(10)
                continue
            if r.status_code >= 500 and tentativa < 1:
                time.sleep(3)
                continue
            if not r.ok:
                ultimo = _erro(r)
                if r.status_code in (401, 403):
                    chaves.atualizar(prov_k, k["id"], status="invalida", erro=ultimo[:200])
                break
            j = r.json()
            u = j.get("usage", {})
            tin, tout = u.get("prompt_tokens", 0), u.get("completion_tokens", 0)
            custo = (tin / 1e6 * p_in + tout / 1e6 * p_out) * float(s.get("dolar", 5.40))
            chaves.registrar(prov_k, k["id"], usos=1)
            chaves.consumo_add("claude", modelo, chamadas=1, tokens_in=tin, tokens_out=tout, custo_brl=custo)
            if video_id:
                with Tx() as db2:
                    v2 = storage.find(db2["videos"], video_id)
                    if v2 is not None:
                        v2["custo_ia_brl"] = round(float(v2.get("custo_ia_brl", 0)) + custo, 4)
                        v2["chamadas_ia"] = int(v2.get("chamadas_ia", 0)) + 1
            txt = ((j.get("choices") or [{}])[0].get("message") or {}).get("content", "").strip()
            if not txt:
                raise RuntimeError("O GPT devolveu uma resposta vazia.")
            return txt
    raise RuntimeError(f"GPT indisponível: {ultimo}")


def gerar_texto(prompt, video_id=None, max_tokens=16000, temperatura=0.7, modo_inteligencia="rapido", sistema="", **kwargs):
    db = storage.load()
    prompt_completo = f"{sistema}\n\n{prompt}" if sistema else prompt
    if tem_chave(db):
        try:
            return corrigir_mojibake_ptbr(_chamar_api(prompt_completo, video_id, max_tokens, temperatura))
        except Exception:
            pass
    prompt_v8 = f"[DIRETRIZ ANTIGRAVITY V8 NINJA PRO]\n{ANTIGRAVITY_V8_SYSTEM}\n\n{prompt_completo}"
    try:
        return corrigir_mojibake_ptbr(gemini.gerar_texto(prompt_v8, video_id, modo_inteligencia=modo_inteligencia, max_tokens=max_tokens, temperatura=temperatura))
    except Exception as e_gem:
        from core import antigravity_codex

        txt_fb, _ = antigravity_codex.gerar_texto_fallback_cascata(
            prompt_v8,
            max_tokens=max_tokens,
            temperatura=temperatura,
            json_mode=False,
            timeout=240,
        )
        if txt_fb:
            return corrigir_mojibake_ptbr(txt_fb)
        raise e_gem


def gerar_json(prompt, video_id=None, max_tokens=8000, modo_inteligencia="rapido", sistema="", temperatura=0.35, **kwargs):
    db = storage.load()
    prompt_completo = f"{sistema}\n\n{prompt}" if sistema else prompt
    if tem_chave(db):
        try:
            txt = _chamar_api(prompt_completo + "\n\nResponda SOMENTE com o JSON pedido, sem ``` e sem texto antes ou depois.", video_id, max_tokens, float(temperatura or 0.3))
            return corrigir_mojibake_ptbr(parse_json(txt))
        except Exception:
            pass
    try:
        return corrigir_mojibake_ptbr(gemini.gerar_json(prompt_completo, video_id, modo_inteligencia=modo_inteligencia, max_tokens=max_tokens, temperatura=temperatura))
    except Exception as e_gem:
        from core import antigravity_codex

        txt_fb, _ = antigravity_codex.gerar_texto_fallback_cascata(
            prompt_completo,
            max_tokens=max_tokens,
            temperatura=float(temperatura or 0.3),
            json_mode=True,
            timeout=240,
        )
        if txt_fb:
            return corrigir_mojibake_ptbr(parse_json(txt_fb))
        raise e_gem


def _erro(r):
    try:
        return r.json().get("error", {}).get("message") or r.text[:250]
    except Exception:
        return r.text[:250]


def testar(kid):
    k = chaves.pegar("openai", kid) or chaves.pegar("claude", kid)
    prov_k = "openai" if chaves.pegar("openai", kid) else "claude"
    modelo, _, _, _ = _modelo(storage.load()["settings"])
    try:
        r = requests.post(
            API_OPENAI,
            headers={"Authorization": f"Bearer {k['key']}", "Content-Type": "application/json"},
            json={"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "Responda só: ok"}], "max_tokens": 10},
            timeout=30,
        )
        if not r.ok:
            raise RuntimeError(_erro(r))
        chaves.atualizar(prov_k, kid, status="ok", modelo_auto=modelo, testada_em=time.strftime("%d/%m/%Y %H:%M"), erro="")
        return True, f"GPT ativo ({modelo})"
    except Exception as e:
        chaves.atualizar(prov_k, kid, status="invalida", testada_em=time.strftime("%d/%m/%Y %H:%M"), erro=str(e)[:200])
        return False, str(e)


# ---------------- escolha automática (Gemini Flash Turbo / Antigravity Tokens / OpenAI Codex / GPT) ----------------
def texto_pref(tarefa, prompt, video_id=None, aviso=None, modo_inteligencia="rapido"):
    """Cascata resiliente: Gemini Multi-Model -> Antigravity Tokens -> OpenAI Codex (240s) -> GPT API."""
    db = storage.load()
    v8_ativo = db["settings"].get("antigravity_ativo", True)
    prompt_final = (
        f"[DIRETRIZ ANTIGRAVITY V8 NINJA PRO]\n{ANTIGRAVITY_V8_SYSTEM}\n\n{prompt}"
        if (v8_ativo and tarefa in ("roteiro", "pesquisa", "verificacao"))
        else prompt
    )
    if tem_chave(db) and usar_para(tarefa, db):
        try:
            return corrigir_mojibake_ptbr(_chamar_api(prompt_final, video_id))
        except Exception as e:
            if aviso:
                aviso(f"GPT API falhou ({str(e)[:120]}) — alternando para Gemini / Antigravity / Codex")
    try:
        return corrigir_mojibake_ptbr(gemini.gerar_texto(prompt_final, video_id, modo_inteligencia=modo_inteligencia))
    except Exception as e_gem:
        if aviso:
            aviso(f"Gemini sobrecarregado ({str(e_gem)[:100]}) — assumindo automaticamente via Antigravity Tokens / Codex / GPT...")
        from core import antigravity_codex

        txt_fb, prov_fb = antigravity_codex.gerar_texto_fallback_cascata(
            prompt_final,
            max_tokens=16384,
            temperatura=0.7,
            json_mode=False,
            timeout=240,
            aviso=aviso,
        )
        if txt_fb:
            if aviso:
                aviso(f"✅ Roteiro/texto concluído automaticamente via {prov_fb} (sem interrupção)!")
            return corrigir_mojibake_ptbr(txt_fb)
        if tem_chave(db):
            try:
                return corrigir_mojibake_ptbr(_chamar_api(prompt_final, video_id))
            except Exception:
                pass
        out_cx = _chamar_codex_cli(prompt_final, timeout=180)
        if out_cx:
            return corrigir_mojibake_ptbr(out_cx)
        raise e_gem


def json_pref(tarefa, prompt, video_id=None, aviso=None, timeout_codex=90, modo_inteligencia="rapido"):
    db = storage.load()
    if tem_chave(db) and usar_para(tarefa, db):
        try:
            txt = _chamar_api(prompt + "\n\nResponda SOMENTE com o JSON pedido, sem ``` e sem texto antes ou depois.", video_id, 8000, 0.3)
            return corrigir_mojibake_ptbr(parse_json(txt))
        except Exception as e:
            if aviso:
                aviso(f"GPT API falhou ({str(e)[:120]}) — alternando para Gemini / Antigravity / Codex")
    try:
        return corrigir_mojibake_ptbr(gemini.gerar_json(prompt, video_id, modo_inteligencia=modo_inteligencia))
    except Exception as e_gem:
        if aviso:
            aviso(f"Gemini sobrecarregado ({str(e_gem)[:100]}) — assumindo JSON via Antigravity Tokens / Codex / GPT...")
        from core import antigravity_codex

        txt_fb, _ = antigravity_codex.gerar_texto_fallback_cascata(
            prompt,
            max_tokens=8192,
            temperatura=0.3,
            json_mode=True,
            timeout=max(120, int(timeout_codex or 90)),
            aviso=aviso,
        )
        if txt_fb:
            return corrigir_mojibake_ptbr(parse_json(txt_fb))
        if tem_chave(db):
            try:
                txt = _chamar_api(prompt + "\n\nResponda SOMENTE com o JSON pedido, sem ``` e sem texto antes ou depois.", video_id, 8000, 0.3)
                return corrigir_mojibake_ptbr(parse_json(txt))
            except Exception:
                pass
        out_cx = _chamar_codex_cli(prompt + "\n\nResponda SOMENTE com o JSON pedido, sem ``` e sem texto antes ou depois.", timeout=max(90, int(timeout_codex or 90)))
        if out_cx:
            return corrigir_mojibake_ptbr(parse_json(out_cx))
        raise e_gem


def tem_ia(db=None):
    """Tem pelo menos uma IA (Gemini, Antigravity Tokens, OpenAI Codex ou GPT) para escrever texto?"""
    from core import reallab, antigravity_codex

    st_vinc = {}
    try:
        st_vinc = antigravity_codex.obter_status_vinculacao(db)
    except Exception:
        pass
    return (
        reallab.tem_gemini()
        or tem_chave(db)
        or bool((st_vinc.get("antigravity") or {}).get("conectado"))
        or bool((st_vinc.get("codex") or {}).get("conectado"))
        or bool((db or storage.load())["settings"].get("antigravity_ativo", True))
    )

