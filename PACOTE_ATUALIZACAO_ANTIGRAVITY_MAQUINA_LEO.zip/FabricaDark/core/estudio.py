"""Estúdio 1 clique: do título ao vídeo pronto, sem editor.

Etapas (cada uma pode ser retomada — "Continuar de onde parou" pula o que já está pronto):
 1 Roteiro · 2 Cenas · 3 Pesquisa profunda · 4 Narração · 5 Mídia (busca + conferência, vídeo primeiro)
 6 Cenas sem mídia · 7 Download · 8 Legendas e textos de impacto · 9 Montagem · 10 Revisão automática (QA)
 11 Descrição/SEO e thumbnail · 12 Pasta de entrega
"""
import json
import os
import re
import shutil
import threading
import time

from core import claude, gemini, layouts, media, perfis, prompts, reallab, render, scenes, storage, thumb, voz
from core.storage import Tx

ETAPAS = [
    ("roteiro", "Roteiro", 5),
    ("cenas", "Dividir em cenas", 1),
    ("pesquisa", "Pesquisa profunda por cena", 6),
    ("narracao", "Narração", 10),
    ("midia", "Buscar e conferir mídia (vídeo primeiro)", 34),
    ("ia", "Cenas sem mídia", 5),
    ("download", "Baixar mídias", 10),
    ("impacto", "Legendas e textos de impacto", 3),
    ("render", "Montagem do vídeo", 18),
    ("qa", "Revisão automática (QA)", 5),
    ("seo", "Descrição, títulos e thumbnail", 3),
    ("entrega", "Pasta de entrega", 1),
]
NOMES = {k: n for k, n, _ in ETAPAS}
# segundos de trabalho por minuto de vídeo — chute inicial; depois o app usa a média real deste PC (settings.tempos_etapas)
SEG_POR_MIN = {"roteiro": 20, "cenas": 2, "pesquisa": 25, "narracao": 20, "midia": 390, "ia": 10, "download": 65,
               "impacto": 2, "render": 130, "qa": 110, "seo": 15, "entrega": 5}
PESOS = {k: w for k, _, w in ETAPAS}

OPCOES_PADRAO = {
    "preferencia_midia": "videos",
    "permitir_ia": True,
    "ia_motor": "pollinations",
    "template": "nenhum",
    "filtro": "auto",
    "transicao": "auto",
    "textos_impacto": True,
    "cta": True,
    "musica_volume": 0.12,
    "qa_refazer": True,
    "thumb_estilo": "impacto",
    "segundos_por_cena": 0,
    "velocidade": "caprichado",
    "estilo_edicao": "",
    "montagens": True,
    "efeitos_sonoros": True,
    "modo": "normal",
    "noticia_horas": 48,
    "noticia_canais": False,
    "revisar_roteiro": True,
    "legenda_estilo": "auto",
}

JOBS = {}
HELPERS = {}  # preenchido pelo app.py: baixar, montar, pacote, voz_cfg, tempos, gravar_srt, abs


class Parado(Exception):
    def __str__(self):
        return "Parado pelo usuário"


# ---------------------------------------------------------------- estado
def _novo_job(vid, opcoes):
    return {
        "vid": vid,
        "rodando": True,
        "pausado": False,
        "parar": False,
        "opcoes": opcoes,
        "etapas": {k: {"status": "pendente", "pct": 0, "msg": "", "inicio": 0, "fim": 0} for k, _, _ in ETAPAS},
        "atual": "",
        "log": [],
        "inicio": time.time(),
        "pausado_total": 0.0,
        "pausado_desde": 0,
        "erro": "",
        "sub": {},
        "resultado": {},
    }


def _log(job, msg, nivel="info"):
    linha = f"[{time.strftime('%H:%M:%S')}] {msg}"
    job["log"].append({"t": linha, "nivel": nivel})
    del job["log"][:-400]


def _checar(job):
    if job["parar"]:
        raise Parado()
    if job["pausado"]:
        job["pausado_desde"] = time.time()
        _log(job, "Pausado.")
        while job["pausado"] and not job["parar"]:
            time.sleep(0.4)
        job["pausado_total"] += time.time() - job["pausado_desde"]
        job["pausado_desde"] = 0
        if job["parar"]:
            raise Parado()
        _log(job, "Continuando.")


def _persistir(job):
    try:
        with Tx() as db:
            v = storage.find(db["videos"], job["vid"])
            if v is None:
                return
            v["estudio"] = {
                "opcoes": job["opcoes"],
                "etapas": {k: {"status": e["status"], "msg": e["msg"]} for k, e in job["etapas"].items()},
                "log": job["log"][-150:],
                "erro": job["erro"],
                "resultado": job["resultado"],
                "atualizado": storage.now(),
                "inicio_total": job.get("inicio_total"),
            }
    except Exception:
        pass


def progresso(job):
    """(fração 0–1, segundos restantes estimados ou None)."""
    total = sum(PESOS.values())
    feito = 0.0
    for k, e in job["etapas"].items():
        if e["status"] in ("ok", "pulada"):
            feito += PESOS[k]
        elif e["status"] == "rodando":
            feito += PESOS[k] * max(0, min(1, e["pct"] / 100))
    frac = feito / total
    # só conta o tempo das etapas feitas nesta execução (as puladas não custaram nada)
    pulado = sum(PESOS[k] for k, e in job["etapas"].items() if e.get("ja_pronta"))
    frac_rodada = (feito - pulado) / max(1, total - pulado)
    gasto = time.time() - job["inicio"] - job["pausado_total"] - ((time.time() - job["pausado_desde"]) if job["pausado_desde"] else 0)
    eta = None
    if job["rodando"] and frac_rodada > 0.03 and gasto > 10:
        eta = max(0, gasto * (1 - frac_rodada) / frac_rodada)
    if job["rodando"]:
        eta2 = _eta_por_etapa(job)
        if eta2 is not None:
            eta = eta2
    return frac, eta


def _eta_por_etapa(job):
    """Tempo que falta somando etapa por etapa: a atual pelo ritmo dela, as próximas pela média deste PC."""
    mins = max(1.0, job.get("min_video") or 10)
    hist = job.get("hist") or {}
    agora = time.time()
    total = 0.0
    for k, _, _ in ETAPAS:
        e = job["etapas"][k]
        if e["status"] in ("ok", "pulada"):
            continue
        media_k = float(hist.get(k) or SEG_POR_MIN.get(k, 30)) * mins
        if e["status"] == "rodando":
            gasto_e = max(0.0, agora - (e.get("inicio") or agora))
            if job.get("pausado_desde"):
                gasto_e = max(0.0, gasto_e - (agora - job["pausado_desde"]))
            p = max(0.0, min(1.0, (e.get("pct") or 0) / 100))
            if p >= 0.05 and gasto_e > 20:
                total += gasto_e * (1 - p) / p
            else:
                total += max(media_k * (1 - p) - gasto_e, media_k * 0.1)
        else:
            total += media_k
    return total


def _aprender_tempo(job, k, segundos):
    """Guarda quanto cada etapa levou (por minuto de vídeo) para a próxima estimativa sair mais certa."""
    try:
        mins = max(1.0, job.get("min_video") or 10)
        por_min = segundos / mins
        with Tx() as db:
            t = db["settings"].setdefault("tempos_etapas", {})
            t[k] = round(por_min if not t.get(k) else t[k] * 0.5 + por_min * 0.5, 1)
            job.setdefault("hist", {})[k] = t[k]
    except Exception:
        pass


def status(vid):
    job = JOBS.get(vid)
    if not job:
        v = storage.find(storage.load()["videos"], vid) or {}
        est = v.get("estudio") or {}
        etapas = []
        for k, n, _ in ETAPAS:
            e = (est.get("etapas") or {}).get(k, {})
            etapas.append({"id": k, "nome": n, "status": e.get("status", "pendente"), "pct": 100 if e.get("status") == "ok" else 0, "msg": e.get("msg", "")})
        feito = sum(PESOS[x["id"]] for x in etapas if x["status"] in ("ok", "pulada")) / sum(PESOS.values())
        return {"rodando": False, "pausado": False, "etapas": etapas, "log": est.get("log", []), "erro": est.get("erro", ""),
                "progresso": round(feito * 100, 1), "eta": None, "resultado": est.get("resultado", {}), "opcoes": est.get("opcoes") or {}, "existe": bool(est)}
    _atualizar_sub(job)
    frac, eta = progresso(job)
    return {
        "rodando": job["rodando"], "pausado": job["pausado"], "atual": job["atual"], "erro": job["erro"],
        "etapas": [{"id": k, "nome": n, **{x: job["etapas"][k][x] for x in ("status", "pct", "msg")}} for k, n, _ in ETAPAS],
        "log": job["log"][-200:], "progresso": round(frac * 100, 1), "eta": eta, "resultado": job["resultado"],
        "opcoes": job["opcoes"], "decorrido": time.time() - job["inicio"], "existe": True,
        "decorrido_total": time.time() - (job.get("inicio_total") or job["inicio"]),
        "decorrido_etapa": (time.time() - job["etapas"][job["atual"]]["inicio"]) if job.get("atual") and job["etapas"][job["atual"]].get("inicio") else None,
    }


def _atualizar_sub(job):
    """Traduz o andamento das funções internas (feito/total, pct do render) para a etapa atual."""
    k = job.get("atual")
    if not k or job["etapas"][k]["status"] != "rodando":
        return
    sub = job.get("sub") or {}
    e = job["etapas"][k]
    r = render.JOBS.get(job["vid"]) or {}
    if k == "render":
        if r.get("pct") is not None:
            e["pct"] = r.get("pct", 0)
        if r.get("etapa"):
            e["msg"] = r["etapa"]
    elif r.get("rodando"):  # remontagem dentro de outra etapa (ex.: revisão): mostra o andamento da montagem
        e["pct"] = r.get("pct") or 0
        e["msg"] = "Remontando — " + (r.get("etapa") or "preparando")
    elif sub.get("total"):
        e["pct"] = int(100 * sub.get("feito", 0) / max(1, sub["total"]))
        if sub.get("etapa"):
            e["msg"] = sub["etapa"]
    elif sub.get("etapa"):
        e["msg"] = sub["etapa"]


# ---------------------------------------------------------------- controle
def iniciar(vid, opcoes=None, refazer=None):
    if JOBS.get(vid, {}).get("rodando"):
        raise RuntimeError("Este vídeo já está sendo gerado.")
    v = storage.find(storage.load()["videos"], vid)
    if not v:
        raise RuntimeError("Vídeo não encontrado")
    salvo = (v.get("estudio") or {}).get("opcoes") or {}
    op = dict(OPCOES_PADRAO, **salvo, **(opcoes or {}))
    job = JOBS[vid] = _novo_job(vid, op)
    anteriores = (v.get("estudio") or {}).get("etapas") or {}
    for k in job["etapas"]:
        if anteriores.get(k, {}).get("status") == "ok" and k not in (refazer or []):
            job["etapas"][k].update(status="ok", pct=100, msg=anteriores[k].get("msg", ""), ja_pronta=True)
    if refazer:
        # refazer uma etapa obriga a refazer as que dependem dela
        ordem = [k for k, _, _ in ETAPAS]
        primeiro = min(ordem.index(k) for k in refazer if k in ordem)
        for k in ordem[primeiro:]:
            job["etapas"][k].update(status="pendente", pct=0, ja_pronta=False)
    continuando = any(e.get("ja_pronta") for e in job["etapas"].values())
    job["inicio_total"] = ((v.get("estudio") or {}).get("inicio_total") if continuando else None) or time.time()
    job["retomando"] = continuando  # a 1ª etapa desta rodada pode já ter andado antes: não entra na média de tempo
    job["min_video"] = (v.get("narracao_duracao") or ((v.get("cenas") or [{}])[-1].get("fim") or 0)) / 60 or op.get("duracao_min") or 10
    job["hist"] = dict(storage.load()["settings"].get("tempos_etapas") or {})
    job["log"] = list((v.get("estudio") or {}).get("log") or [])[-60:]
    job["resultado"] = dict((v.get("estudio") or {}).get("resultado") or {})
    _log(job, "▶ Iniciando o Estúdio 1 clique" + (" (continuando de onde parou)" if any(e.get("ja_pronta") for e in job["etapas"].values()) else ""))
    threading.Thread(target=_rodar, args=(job,), daemon=True).start()
    return job


def pausar(vid):
    j = JOBS.get(vid)
    if j and j["rodando"]:
        j["pausado"] = True


def continuar(vid):
    j = JOBS.get(vid)
    if j and j["rodando"]:
        j["pausado"] = False
        return
    iniciar(vid)


def parar(vid):
    j = JOBS.get(vid)
    if j and j["rodando"]:
        j["parar"] = True
        j["pausado"] = False


def _rodar(job):
    vid = job["vid"]
    render.CHECAR[vid] = lambda: _checar(job)
    try:
        for k, nome, _ in ETAPAS:
            e = job["etapas"][k]
            if e["status"] == "ok":
                continue
            _checar(job)
            job["atual"] = k
            job["sub"] = {"checar": lambda: _checar(job)}
            e.update(status="rodando", pct=0, msg="", inicio=time.time())
            _log(job, f"— {nome}")
            _persistir(job)
            try:
                res = ETAPA_FN[k](job)
            except Parado:
                e.update(status="pendente", msg="Parado aqui")
                raise
            except Exception as ex:
                e.update(status="erro", msg=str(ex)[:300])
                job["erro"] = f"{nome}: {ex}"
                _log(job, f"✖ {nome}: {ex}", "erro")
                _persistir(job)
                return
            for err in (job["sub"].get("erros") or [])[:6]:
                _log(job, f"  aviso: {err}", "aviso")
            e.update(status="pulada" if res == "pulada" else "ok", pct=100, fim=time.time(), msg=(res if isinstance(res, str) and res != "pulada" else e["msg"]))
            if e["status"] == "pulada":
                e["status"] = "ok"
                e["msg"] = e["msg"] or "Já estava pronto"
            _log(job, f"✔ {nome}" + (f" — {e['msg']}" if e["msg"] else "") + f" ({_fmt(e['fim'] - e['inicio'])})", "ok")
            if not job.pop("retomando", False) and e["msg"] != "Já estava pronto":
                _aprender_tempo(job, k, e["fim"] - e["inicio"])
            job["retomando"] = False
            _persistir(job)
            threading.Thread(target=_sincronizar_etapa_dp, args=(vid, k), daemon=True).start()
        job["atual"] = ""
        _log(job, f"🎉 Vídeo pronto em {_fmt(time.time() - job['inicio'] - job['pausado_total'])}. Abra a pasta de entrega.", "ok")
    except Parado:
        _log(job, "■ Parado. Clique em Continuar para seguir de onde parou.", "aviso")
    except Exception as ex:  # segurança
        job["erro"] = str(ex)
        _log(job, f"✖ Erro inesperado: {ex}", "erro")
    finally:
        job["rodando"] = False
        job["pausado"] = False
        render.CHECAR.pop(vid, None)
        _persistir(job)


def _fmt(s):
    s = int(s or 0)
    return f"{s // 3600}h{s % 3600 // 60:02d}min" if s >= 3600 else (f"{s // 60}min{s % 60:02d}s" if s >= 60 else f"{s}s")


def _perfil(job, ch):
    """Perfil visual do vídeo: o escolhido no Estúdio ou, se nenhum, o do canal."""
    return (job.get("opcoes") or {}).get("estilo_edicao") or (ch or {}).get("perfil") or "padrao"


_PALAVRAS = {
    "en": set("the and of to was were is are in that her his she he it with for had have on as but by from they what who this which would there their been not".split()),
    "pt": set("o os as do da dos das de e na no ao à é são que em um uma não para com foi ela ele seu sua mas pelo pela isso então também quando ainda mais nos nas estava eram".split()),
    "es": set("el los las del de y al que en un una no para con fue ella él su pero por lo como cuando también pues entonces muy estaba eran".split()),
    "fr": set("le la les des dans avec pour une sur est sont mais plus cette aux pas par tout tous comme sans nous vous ils elles était".split()),
}
CTA_TEXTO = {"pt": "INSCREVA-SE", "en": "SUBSCRIBE", "es": "SUSCRÍBETE", "fr": "ABONNEZ-VOUS"}


def detectar_idioma(texto):
    """pt / en / es / fr pelo jeito do texto (palavras mais comuns de cada língua); None se não der para saber."""
    pal = re.findall(r"[a-záàéèíóúâêîôûãõçñüïëù]+", (texto or "").lower())
    if len(pal) < 8:
        return None
    cont = {k: sum(1 for p in pal if p in s) for k, s in _PALAVRAS.items()}
    melhor = max(cont, key=cont.get)
    return melhor if cont[melhor] >= max(3, len(pal) * 0.04) else None


def idioma_video(v, ch=None):
    """O idioma do vídeo é o da NARRAÇÃO (um canal em português pode ter um vídeo em inglês)."""
    texto = (v or {}).get("roteiro") or " ".join(c.get("texto", "") for c in ((v or {}).get("cenas") or [])[:80])
    return detectar_idioma(texto[:8000]) or (ch or {}).get("idioma") or "pt"


def _video(vid):
    db = storage.load()
    v = storage.find(db["videos"], vid)
    ch = storage.find(db["channels"], v["channel_id"]) or {}
    ch = dict(ch, idioma=idioma_video(v, ch))  # todos os prompts e textos da tela seguem a língua da narração
    return db, v, ch


# ---------------------------------------------------------------- áudio e legenda próprios
def _legenda(v):
    """Legenda do vídeo: a .srt que o usuário mandou (tempos exatos) ou a gerada pelas cenas."""
    srt = HELPERS["abs"](v["id"], v.get("srt_proprio"))
    if srt and os.path.exists(srt):
        texto = open(srt, encoding="utf-8-sig", errors="replace").read()
        v["srt"] = texto
        with open(os.path.join(storage.video_dir(v["id"]), "legendas.srt"), "w", encoding="utf-8") as f:
            f.write(texto)
        return
    HELPERS["gravar_srt"](v)


def _transcrever(vid, audio):
    """Transcreve a narração com o Gemini (áudio comprimido para caber num pedido só)."""
    import base64

    leve = os.path.join(storage.video_dir(vid), "_transcricao.mp3")
    render._run([render.ffmpeg_bin(), "-y", "-i", audio, "-ac", "1", "-ar", "16000", "-b:a", "24k", leve])
    dados = open(leve, "rb").read()
    parts = [{"inline_data": {"mime_type": "audio/mp3", "data": base64.b64encode(dados).decode()}},
             {"text": "Transcreva esta narração palavra por palavra, no idioma original, com pontuação correta. "
                      "Responda só com o texto transcrito, em parágrafos, sem comentários e sem marcações de tempo."}]
    j, _ = gemini.chamar(parts, vid, max_tokens=32768, temperatura=0.0)
    return gemini._texto(j).strip()


def _cenas_da_srt(entradas, seg, dur_audio):
    """Agrupa as falas da legenda em cenas de ~seg segundos, com os tempos reais do áudio."""
    grupos, atual = [], []
    for e in entradas:
        atual.append(e)
        tam = atual[-1][1] - atual[0][0]
        fim_frase = re.search(r"[\.\!\?…]$", e[2].strip())
        if tam >= seg * 1.4 or (tam >= seg * 0.7 and fim_frase):
            grupos.append(atual)
            atual = []
    if atual:
        if grupos and atual[-1][1] - atual[0][0] < seg * 0.35:
            grupos[-1] += atual
        else:
            grupos.append(atual)
    cenas = []
    for i, g in enumerate(grupos):
        texto = " ".join(x[2] for x in g).strip()
        cenas.append({"n": i + 1, "texto": texto, "palavras": scenes.contar_palavras(texto), "inicio": 0.0 if i == 0 else round(g[0][0], 3),
                      "fim": 0.0, "tipo": "", "pessoa_real": "", "termos_busca": [], "descricao_visual": "", "prompt_ia": "",
                      "midia": None, "candidatos": [], "status": "pendente"})
    for i, c in enumerate(cenas):  # cenas encostadas umas nas outras: a linha do tempo bate com o áudio
        c["fim"] = cenas[i + 1]["inicio"] if i + 1 < len(cenas) else round(max(grupos[-1][-1][1], dur_audio or 0), 3)
    return cenas


# ---------------------------------------------------------------- 1. roteiro
def _sincronizar_etapa_dp(vid, etapa):
    """Espelha automaticamente cada avanço do Estúdio 1 clique no DarkPlanner Web."""
    try:
        from core import darkplanner_sync
        db = storage.load()
        v = storage.find(db["videos"], vid)
        if not v:
            return
        if etapa == "roteiro" and v.get("roteiro"):
            darkplanner_sync.salvar_roteiro_dp(v.get("channel_id"), vid, v["roteiro"])
        elif etapa == "narracao":
            darkplanner_sync.atualizar_video_dp(vid, {"checklist_audio": "Pronto"})
        elif etapa == "render":
            darkplanner_sync.atualizar_video_dp(vid, {"checklist_pronto": "Pronto"})
        elif etapa == "seo":
            darkplanner_sync.atualizar_video_dp(vid, {"checklist_thumbnail": "Pronto"})
    except Exception:
        pass


def e_roteiro(job):
    av = lambda m: _log(job, "  " + m, "aviso")
    db, v, ch = _video(job["vid"])
    if len((v.get("roteiro") or "").split()) < 30:
        try:
            from core import darkplanner_sync
            rot_dp = darkplanner_sync.buscar_roteiro_dp(v["id"])
            if len((rot_dp or "").split()) >= 30:
                with Tx() as db2:
                    v2 = storage.find(db2["videos"], v["id"])
                    v2["roteiro"] = rot_dp
                    v2["etapas"]["roteiro"] = True
                return f"Roteiro sincronizado do DarkPlanner ({len(rot_dp.split())} palavras)"
        except Exception:
            pass
    if len((v.get("roteiro") or "").split()) >= 30:
        return "Usando o roteiro que já estava no vídeo"
    audio = HELPERS["abs"](v["id"], v.get("narracao"))
    if v.get("narracao_origem") == "upload" and audio and os.path.exists(audio):
        if not reallab.tem_gemini():
            raise RuntimeError("Para tirar o texto do seu áudio é preciso uma chave do Gemini (ou envie a legenda .srt junto).")
        job["sub"]["etapa"] = "Transcrevendo o seu áudio"
        texto = _transcrever(v["id"], audio)
        if len(texto.split()) < 20:
            raise RuntimeError("Não consegui transcrever o áudio. Envie a legenda .srt ou cole o roteiro.")
        with Tx() as db2:
            v2 = storage.find(db2["videos"], v["id"])
            v2["roteiro"] = texto
            v2["etapas"]["roteiro"] = True
        return f"Texto tirado do seu áudio ({len(texto.split())} palavras)"
    if job["opcoes"].get("modo") == "noticia":
        from core import noticias

        horas = int(job["opcoes"].get("noticia_horas") or 48)
        job["sub"]["etapa"] = f"Apurando o que saiu nas últimas {horas} horas"
        ref, fontes = noticias.apurar(v["titulo"] + (" " + v["briefing"].get("contexto", "") if v["briefing"].get("contexto") else ""), horas, v["id"],
                                      lambda m: _log(job, "  " + m, "aviso"))
        if len(ref) < 300:
            raise RuntimeError("Não achei notícias recentes sobre esse tema. Tente outras palavras no título ou aumente as horas.")
        with Tx() as db2:
            v2 = storage.find(db2["videos"], v["id"])
            v2["briefing"]["referencias"] = ref
            v2["briefing"]["contexto"] = (v2["briefing"].get("contexto", "") + "\nVÍDEO DE NOTÍCIA: conte o que aconteceu nas últimas horas, "
                                          "com datas e horários, citando de onde veio cada informação. Só use os fatos do material de referência.").strip()
            v2["noticia"] = {"horas": horas, "apurado_em": storage.now(), "fontes": fontes[:40]}
        _log(job, f"  {len(fontes)} fontes de notícia encontradas", "ok")
        db, v, ch = _video(job["vid"])
    if not claude.tem_ia():
        raise RuntimeError("Sem roteiro e sem chave do Gemini/Claude. Cole o roteiro ou coloque uma chave em Conexões.")
    ppm = db["settings"].get("palavras_por_minuto", 150)
    tom = perfis.get(_perfil(job, ch)).get("tom")
    dp_prompts = ((ch or {}).get("dp") or {}).get("prompts") or []
    prompt_mestre_txt = ""
    if dp_prompts:
        pm_id = (job.get("opcoes") or {}).get("prompt_mestre_id")
        pm = next((p for p in dp_prompts if p.get("id") == pm_id), dp_prompts[0])
        if pm and pm.get("conteudo"):
            prompt_mestre_txt = f"\nPROMPT MESTRE DO CANAL ({pm.get('nome','DarkPlanner')}):\n{pm['conteudo'][:3000]}"
    ctx_extra = "\n".join(x for x in [
        v["briefing"].get("contexto", ""),
        ("ESTILO DE NARRAÇÃO: " + tom) if tom else "",
        prompt_mestre_txt,
    ] if x).strip()
    if ctx_extra:
        v = dict(v, briefing=dict(v["briefing"], contexto=ctx_extra))
    job["sub"]["etapa"] = "Escrevendo o roteiro"
    dur = float(v["briefing"].get("duracao_min") or 10)
    if dur > 14:
        # roteiro longo: estrutura + partes, para não cortar no meio
        partes = max(2, round(dur / 8))
        estrutura = claude.texto_pref("roteiro", prompts.roteiro_estrutura(ch, v, partes, ppm), v["id"], av)
        textos = []
        for k in range(1, partes + 1):
            _checar(job)
            job["sub"].update(etapa=f"Escrevendo parte {k}/{partes}", feito=k - 1, total=partes)
            textos.append(re.sub(r"^```\w*|```$", "", claude.texto_pref("roteiro", prompts.roteiro_parte(ch, v, k, partes, estrutura, textos[-1][-1200:] if textos else "", ppm), v["id"], av).strip()).strip())
        texto = "\n\n".join(textos)
    else:
        texto = re.sub(r"^```\w*|```$", "", claude.texto_pref("roteiro", prompts.roteiro(ch, v, ppm), v["id"], av).strip()).strip()
    if len(texto.split()) < 30:
        raise RuntimeError("O Gemini devolveu um roteiro curto demais. Tente de novo.")
    with Tx() as db2:
        v2 = storage.find(db2["videos"], v["id"])
        v2["roteiro"] = texto
        v2["etapas"]["roteiro"] = True
        v2["cenas"] = []
        v2["blocos_voz"] = []
        v2["narracao"] = ""
    extra = ""
    if job["opcoes"].get("revisar_roteiro", True):
        extra = _revisar_roteiro(job)
    return f"{len(texto.split())} palavras" + extra


def _revisar_roteiro(job):
    """Oficina automática: dá nota ao roteiro e, se ficar abaixo de 80, melhora uma vez."""
    from core import oficina

    db, v, ch = _video(job["vid"])
    ch = dict(ch, perfil=_perfil(job, ch))
    try:
        job["sub"]["etapa"] = "Avaliando o roteiro (humano, qualidade, políticas, estrutura)"
        a = oficina.avaliar(v, ch)
        _log(job, "  notas do roteiro: " + ", ".join(f"{oficina.CRITERIOS_N[k]} {n}" for k, n in a["notas"].items()), "ok")
        if a["geral"] >= 80:
            with Tx() as db2:
                storage.find(db2["videos"], v["id"]).setdefault("oficina", {})["avaliacao"] = dict(a, quando=storage.now())
            return f" · nota {a['geral']}"
        _checar(job)
        novo = oficina.melhorar(v, ch, a, progresso=lambda k, n: job["sub"].update(etapa=f"Melhorando o roteiro ({k + 1}/{n})", feito=k, total=n))
        with Tx() as db2:
            v2 = storage.find(db2["videos"], v["id"])
            of = v2.setdefault("oficina", {})
            of.setdefault("versoes", []).append({"quando": storage.now(), "motivo": "antes da melhoria automática", "texto": v2["roteiro"]})
            of["avaliacao_antes"] = a
            v2["roteiro"] = novo
        return f" · nota {a['geral']} → melhorado automaticamente"
    except Parado:
        raise
    except Exception as ex:
        _log(job, f"  revisão do roteiro: {str(ex)[:150]}", "aviso")
        return ""


# ---------------------------------------------------------------- 2. cenas
def e_cenas(job):
    db, v, ch = _video(job["vid"])
    if v.get("cenas"):
        return f"{len(v['cenas'])} cenas (já divididas)"
    s = db["settings"]
    seg = float(job["opcoes"].get("segundos_por_cena") or perfis.get(_perfil(job, ch)).get("segundos_cena") or s.get("segundos_por_cena", 8))
    srt = HELPERS["abs"](v["id"], v.get("srt_proprio"))
    if srt and os.path.exists(srt):
        entradas = render._ler_srt(srt)
        if entradas:
            with Tx() as db2:
                v2 = storage.find(db2["videos"], v["id"])
                v2["cenas"] = _cenas_da_srt(entradas, seg, v2.get("narracao_duracao"))
                n = len(v2["cenas"])
            return f"{n} cenas nos tempos da sua legenda"
    with Tx() as db2:
        v2 = storage.find(db2["videos"], v["id"])
        v2["cenas"] = scenes.dividir_cenas(v2["roteiro"], seg, s.get("palavras_por_minuto", 150))
        scenes.aplicar_tempos(v2["cenas"], None, s.get("palavras_por_minuto", 150))
        n = len(v2["cenas"])
    return f"{n} cenas"


# ---------------------------------------------------------------- 3. pesquisa profunda
PESQUISA_EXEMPLO = [{
    "n": 1,
    "pessoa_real": "nome completo ou vazio",
    "lugar": "lugar exato ou vazio",
    "epoca": "ano/década ou vazio",
    "descricao_visual": "o que deve aparecer na tela, em português",
    "termos_busca": ["6 buscas em INGLÊS, da mais exata à mais geral, ex.: 'Apollo 11 launch footage 1969', 'Saturn V rocket launch', 'rocket launch'"],
    "broll": ["3 buscas curtas em INGLÊS para vídeo de apoio/ambiente, ex.: 'night sky stars timelapse'"],
    "prompt_ia": "prompt em inglês para gerar a imagem por IA se nada real servir (sem rostos reais, sem texto)",
    "layout": "um dos efeitos da lista (ou midia)",
    "layout_texto": "o texto do efeito, no formato pedido na lista; vazio para midia/pessoa/colagem/sequencia",
    "pessoas": ["nome completo de cada pessoa mostrada (pessoa, duas_pessoas, quadro)"],
    "layout_fonte": "citacao/documento: de onde é a frase (ex.: Decisão do STF, 26/10/2026)",
    "layout_destaque": "documento: a palavra-chave que fica marcada",
    "coordenadas": "mapa: [latitude, longitude]",
    "zoom": "mapa: 5 a 16",
}]


def _prompt_pesquisa(ch, v, lote, noticia=False, perfil="padrao"):
    linhas = "\n".join(f"{c['n']}. {c['texto']}" for c in lote)
    contexto = "\n".join(f"{c['n']}. {c['texto'][:90]}" for c in v["cenas"][:: max(1, len(v["cenas"]) // 25)])
    return f"""Você é pesquisador de imagens de arquivo para documentários do YouTube. Seu trabalho é achar FILMAGEM REAL
(vídeo de arquivo, cinejornal, footage) e fotos reais para cada cena — pense como um pesquisador profissional:
qual evento, pessoa, lugar e época exatos aparecem, e como esse material estaria catalogado em acervos
(Wikimedia Commons, Internet Archive, NASA, Pexels, Pixabay, YouTube Creative Commons).

TÍTULO: {v.get('titulo','')}
RESUMO DO VÍDEO (para manter a coerência de época e lugar):
{contexto}

REGRAS
- "termos_busca": 6 buscas em INGLÊS, curtas (2 a 6 palavras). As 2 primeiras bem exatas (nome + evento + ano, e "footage"/"newsreel" quando fizer sentido);
  as do meio, variações (outro nome do evento, o lugar, o objeto); as últimas, gerais mas ainda do mesmo assunto.
{"- VÍDEO DE NOTÍCIA RECENTE: das 6 buscas, as 3 primeiras em PORTUGUÊS (como a imprensa brasileira escreveria a manchete) e as outras em inglês." + chr(10) if noticia else ""}- "broll": 3 buscas de vídeo de ambiente que combinam com a cena se não houver filmagem do fato (paisagem, cidade, objetos, clima da época).
- Se a cena cita uma pessoa real, o nome completo vai em "pessoa_real" e no primeiro termo.
- Nunca invente fatos; se a cena é abstrata (emoção, reflexão), use termos visuais que representem a ideia.
- IDIOMA DA TELA: a narração está em {prompts.IDIOMAS.get(ch.get("idioma", "pt"), "português do Brasil")}. Todo texto que APARECE NO VÍDEO
  ("layout_texto", "layout_fonte", "layout_destaque") deve estar nesse idioma, com datas e números no formato dele.
- Efeito "frase": o "layout_texto" é UMA FRASE INTEIRA da narração (do começo da frase até o ponto final), nunca um pedaço cortado no meio.
- Nunca escolha imagem com logo de marca, nem foto de pessoa real que a narração não cita (ex.: políticos numa sessão qualquer).

EFEITO DA CENA ("layout") — deixa o vídeo com cara de documentário profissional:
{perfis.regras_efeitos(perfil, len(v["cenas"]))}

CENAS
{linhas}

Responda SOMENTE JSON: uma lista, um objeto por cena, neste formato:
{json.dumps(PESQUISA_EXEMPLO, ensure_ascii=False)}"""


def e_pesquisa(job):
    av = lambda m: _log(job, "  " + m, "aviso")
    db, v, ch = _video(job["vid"])
    faltam = [c for c in v["cenas"] if not c.get("pesquisa_ok")]
    if not faltam:
        return "pulada"
    if not claude.tem_ia():
        return "Sem Gemini/Claude: usando palavras do próprio texto"
    lote_n = 20
    fila = [faltam[i: i + lote_n] for i in range(0, len(faltam), lote_n)]
    total = len(faltam)
    feitos = 0
    tentativas = {}
    while fila:
        _checar(job)
        lote = fila.pop(0)
        job["sub"].update(etapa=f"Pesquisando cenas {lote[0]['n']}–{lote[-1]['n']}", feito=total - sum(len(x) for x in fila) - len(lote), total=total)
        try:
            res = claude.json_pref("pesquisa", _prompt_pesquisa(ch, v, lote, job["opcoes"].get("modo") == "noticia", _perfil(job, ch)), v["id"], av)
        except Exception as ex:
            msg = str(ex)
            if "indisponível" in msg or "limite" in msg.lower():
                _log(job, f"  pesquisa parou nas cenas {lote[0]['n']}–{lote[-1]['n']}: {msg[:150]}", "aviso")
                break
            chave_l = (lote[0]["n"], lote[-1]["n"])
            tentativas[chave_l] = tentativas.get(chave_l, 0) + 1
            if len(lote) > 5:
                # resposta veio quebrada (JSON incompleto): tenta de novo em pedaços menores
                meio = len(lote) // 2
                fila[:0] = [lote[:meio], lote[meio:]]
                _log(job, f"  resposta das cenas {lote[0]['n']}–{lote[-1]['n']} veio quebrada — refazendo em 2 partes", "aviso")
            elif tentativas[chave_l] < 2:
                fila.insert(0, lote)
                _log(job, f"  refazendo a pesquisa das cenas {lote[0]['n']}–{lote[-1]['n']}", "aviso")
            else:
                _log(job, f"  cenas {lote[0]['n']}–{lote[-1]['n']} ficaram com a busca simples ({msg[:100]})", "aviso")
            continue
        if isinstance(res, dict):
            res = res.get("cenas") or next((x for x in res.values() if isinstance(x, list)), [])
        por_n = {}
        for x in res if isinstance(res, list) else []:
            try:
                por_n[int(x.get("n"))] = x
            except (TypeError, ValueError, AttributeError):
                pass
        with Tx() as db2:
            v2 = storage.find(db2["videos"], v["id"])
            v2["chamadas_ia"] = v2.get("chamadas_ia", 0) + 1
            for c in v2["cenas"]:
                x = por_n.get(c["n"])
                if not x:
                    continue
                tb = x.get("termos_busca") or []
                tb = [tb] if isinstance(tb, str) else [str(t).strip() for t in tb if str(t).strip()]
                br = x.get("broll") or []
                br = [br] if isinstance(br, str) else [str(t).strip() for t in br if str(t).strip()]
                if tb:
                    c["termos_busca"] = tb[:6]
                c["broll"] = br[:3]
                for k in ("pessoa_real", "descricao_visual", "prompt_ia", "lugar", "epoca", "layout_texto", "layout_fonte", "layout_destaque"):
                    if x.get(k):
                        c[k] = str(x[k])
                lay = str(x.get("layout") or "midia").strip()
                c["layout"] = lay if lay in layouts.LAYOUTS else "midia"
                if isinstance(x.get("pessoas"), list):
                    c["pessoas"] = [str(p) for p in x["pessoas"] if p][:4]
                if isinstance(x.get("coordenadas"), list) and len(x["coordenadas"]) == 2:
                    c["coordenadas"] = x["coordenadas"]
                if x.get("zoom"):
                    c["zoom"] = x["zoom"]
                if c["layout"] in layouts.PRECISA_TEXTO and not c.get("layout_texto"):
                    c["layout"] = "midia"
                c["pesquisa_ok"] = True
                feitos += 1
    _espalhar_efeitos(v["id"])
    return f"{feitos} cenas pesquisadas"


def _espalhar_efeitos(vid):
    """Evita efeito igual em cenas seguidas e excesso de capítulos (os lotes da pesquisa não se enxergam)."""
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        ant, ult_cap = "midia", -99
        for k, c in enumerate(v2["cenas"]):
            lay = c.get("layout") or "midia"
            if lay != "midia" and lay == ant and lay not in ("pessoa",):
                c["layout"] = lay = "midia"
            if lay == "capitulo":
                if k - ult_cap < 20 or k == 0:
                    c["layout"] = lay = "midia"
                else:
                    ult_cap = k
            ant = lay


# ---------------------------------------------------------------- 4. narração
def e_narracao(job):
    vid = job["vid"]
    db, v, ch = _video(vid)
    absn = HELPERS["abs"](vid, v.get("narracao"))
    if absn and os.path.exists(absn) and v.get("narracao_duracao"):
        _ajustar_tempos(vid)
        return "Usando o seu áudio" if v.get("narracao_origem") == "upload" else "Usando a narração que já existe"
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        if not v2.get("blocos_voz"):
            v2["blocos_voz"] = voz.dividir_blocos(v2["roteiro"], 900)
        cfg = HELPERS["voz_cfg"](db2, v2, ch)
        cfg.update({k: val for k, val in (job["opcoes"].get("voz") or {}).items() if val})
        v2["voz"] = cfg
        blocos = [dict(b) for b in v2["blocos_voz"]]
    pasta = storage.video_dir(vid)
    if cfg.get("motor") == "darkplanner":
        return _narracao_darkplanner(job, v, cfg, pasta)
    alvo = [b for b in blocos if b.get("status") != "pronto" or not os.path.exists(HELPERS["abs"](vid, b.get("arquivo")))]
    job["sub"]["total"] = len(blocos)
    for k, b in enumerate(blocos):
        job["sub"]["feito"] = k
        if b not in alvo:
            continue
        _checar(job)
        job["sub"]["etapa"] = f"Narrando bloco {b['i']}/{len(blocos)} ({cfg.get('motor')})"
        ultimo = None
        res = None
        for tentativa in range(3):
            try:
                path = voz.gerar_bloco(b, db["settings"], pasta, cfg)
                res = {"status": "pronto", "erro": "", "arquivo": os.path.relpath(path, pasta), "duracao": render.duracao_midia(path) or 0}
                break
            except Exception as ex:
                ultimo = ex
                time.sleep(2 + tentativa * 3)
        if not res:
            raise RuntimeError(f"Bloco {b['i']} da narração falhou: {ultimo}")
        with Tx() as db3:
            v3 = storage.find(db3["videos"], vid)
            b3 = next((x for x in v3["blocos_voz"] if x["i"] == b["i"]), None)
            if b3:
                b3.update(res)
    job["sub"].update(etapa="Juntando os blocos", feito=len(blocos))
    db, v, ch = _video(vid)
    saida = os.path.join(pasta, "narracao_vozlab.mp3")
    voz.juntar([HELPERS["abs"](vid, b["arquivo"]) for b in v["blocos_voz"]], saida, render.ffmpeg_bin(), 0.35)
    dur = render.duracao_midia(saida)
    with Tx() as db4:
        v4 = storage.find(db4["videos"], vid)
        v4["narracao"] = os.path.relpath(saida, pasta)
        v4["narracao_duracao"] = dur
        v4["narracao_origem"] = "vozlab"
        v4["etapas"]["narracao"] = True
    _ajustar_tempos(vid)
    return f"{_fmt(dur)} de narração"


def _partes_texto(texto, maximo):
    """Divide o roteiro em pedaços de até `maximo` caracteres, sempre no fim de um parágrafo ou frase."""
    if len(texto) <= maximo:
        return [texto]
    partes, atual = [], ""
    for frase in re.split(r"(?<=[.!?…])\s+|\n+", texto):
        if atual and len(atual) + len(frase) + 1 > maximo:
            partes.append(atual.strip())
            atual = ""
        atual += frase + " "
    if atual.strip():
        partes.append(atual.strip())
    return partes


def _narracao_darkplanner(job, v, cfg, pasta):
    """A narração inteira num pedido só (ou poucos, se passar do limite de caracteres) + a legenda com o tempo de cada fala."""
    from core import chaves

    vid = job["vid"]
    contas = [c for c in chaves.lista(storage.load(), "darkplanner") if c.get("status") != "invalida"]
    if not contas:
        raise RuntimeError("Conecte sua chave da DarkPlanner em Conexões e chaves.")
    if not cfg.get("voz_darkplanner"):
        raise RuntimeError("Escolha a voz da DarkPlanner (VozLab ou Estúdio).")
    ultimo = None
    for conta in contas:
        try:
            maximo = 200000
            try:
                maximo = int(voz.darkplanner_uso(conta["key"]).get("max_characters_per_audio") or maximo)
            except Exception:
                pass
            partes = _partes_texto(v["roteiro"], max(1000, maximo - 200))
            mp3s, entradas, offset = [], [], 0.0
            for k, texto in enumerate(partes):
                aviso = lambda m, k=k: job["sub"].update(etapa=m + (f" — parte {k + 1}/{len(partes)}" if len(partes) > 1 else ""))
                mp3, srt = voz.darkplanner_gerar(texto, cfg["voz_darkplanner"], os.path.join(pasta, f"narracao_darkplanner_{k + 1}"), conta["key"],
                                                 cfg.get("velocidade", "+0%"), checar=lambda: _checar(job), aviso=aviso)
                for a, b, t in (render._ler_srt(srt) if srt else []):
                    entradas.append((a + offset, b + offset, t))
                offset += render.duracao_midia(mp3) or 0
                mp3s.append(mp3)
            chaves.consumo_add("tts", "darkplanner", caracteres=len(v["roteiro"]), bytes=len(v["roteiro"].encode("utf-8")))
            break
        except Parado:
            raise
        except Exception as ex:
            ultimo = ex
            if any(x in str(ex).lower() for x in ("401", "403", "429", "limite")):
                continue  # próxima chave
            raise
    else:
        raise RuntimeError(str(ultimo))
    saida = mp3s[0] if len(mp3s) == 1 else voz.juntar(mp3s, os.path.join(pasta, "narracao_darkplanner.mp3"), render.ffmpeg_bin(), 0.0)
    srt_final = None
    if entradas:
        srt_final = os.path.join(pasta, "narracao_darkplanner.srt")
        fmt = lambda s: f"{int(s // 3600):02d}:{int(s % 3600 // 60):02d}:{int(s % 60):02d},{int(round((s % 1) * 1000)) % 1000:03d}"
        with open(srt_final, "w", encoding="utf-8") as f:
            for i, (a, b, t) in enumerate(entradas, 1):
                f.write(f"{i}\n{fmt(a)} --> {fmt(b)}\n{t}\n\n")
    dur = render.duracao_midia(saida)
    with Tx() as db4:
        v4 = storage.find(db4["videos"], vid)
        v4["narracao"] = os.path.relpath(saida, pasta)
        v4["narracao_duracao"] = dur
        v4["narracao_origem"] = "darkplanner"
        if srt_final:
            v4["srt_narracao"] = os.path.relpath(srt_final, pasta)
        v4["etapas"]["narracao"] = True
    _ajustar_tempos(vid)
    return f"{_fmt(dur)} de narração (DarkPlanner)" + (" com os tempos da legenda" if srt_final else "")


def _tempos_pela_srt(cenas, entradas, dur):
    """Cada cena começa no instante em que a narração fala a 1ª palavra dela (pela legenda da DarkPlanner)."""
    marcas = []
    for a, b, t in entradas:
        ws = t.split()
        for k in range(len(ws)):
            marcas.append(a + (b - a) * k / max(1, len(ws)))
    total = sum(len((c.get("texto") or "").split()) for c in cenas)
    if not marcas or not total:
        return False
    escala = len(marcas) / total
    idx = 0
    for i, c in enumerate(cenas):
        t = 0.0 if i == 0 else marcas[min(len(marcas) - 1, int(round(idx * escala)))]
        c["inicio"] = round(max(t, cenas[i - 1]["inicio"] + 0.5 if i else 0.0), 3)
        idx += len((c.get("texto") or "").split())
    fim = max(dur or 0, entradas[-1][1])
    for i, c in enumerate(cenas):
        c["fim"] = cenas[i + 1]["inicio"] if i + 1 < len(cenas) else round(fim, 3)
    return True


def _ajustar_tempos(vid):
    with Tx() as db:
        v = storage.find(db["videos"], vid)
        if v.get("cenas"):
            if not v.get("srt_proprio"):  # com a legenda própria, os tempos já vêm certos dela
                srt = HELPERS["abs"](vid, v.get("srt_narracao")) if v.get("srt_narracao") else None
                if not (srt and os.path.exists(srt) and _tempos_pela_srt(v["cenas"], render._ler_srt(srt), v.get("narracao_duracao"))):
                    HELPERS["tempos"](v, v.get("narracao_duracao"), db["settings"].get("palavras_por_minuto", 150))
            _legenda(v)


# ---------------------------------------------------------------- 5. mídia
def e_midia(job):
    vid = job["vid"]
    db, v, ch = _video(vid)
    # cenas já buscadas que não acharam nada (status "ia" com candidatos) não são buscadas de novo ao continuar
    pend = [c for c in v["cenas"] if c.get("status") not in ("escolhida", "manual") and not (c.get("status") == "ia" and c.get("candidatos"))]
    if not pend:
        return "pulada"
    sub = job["sub"]
    rapido = job["opcoes"].get("velocidade", "caprichado") == "rapido"
    from core import chaves

    n_chaves = max(1, len([k for k in chaves.ordem("gemini") if k.get("tipo") != "paga"]))
    sub["settings_extra"] = {"preferencia_midia": job["opcoes"].get("preferencia_midia", "videos"), "termos_por_cena": 4 if rapido else 6, "max_repeticao": 1,
                             "modo_rapido": rapido, "cenas_paralelo": min(6, 2 + n_chaves) if rapido else min(4, 1 + n_chaves),
                             "conferencias_por_cena": 3 if rapido else 4}
    _log(job, f"  {'Modo rápido' if rapido else 'Modo caprichado'}: {sub['settings_extra']['cenas_paralelo']} cenas ao mesmo tempo, {n_chaves} chave(s) do Gemini em rodízio")
    sub["sem_ia_auto"] = True
    if job["opcoes"].get("modo") == "noticia" and not v.get("pool_noticias"):
        from core import noticias

        sub["etapa"] = "Buscando fotos e vídeos das últimas horas"
        pool = noticias.pool_imagens(v["titulo"], int(job["opcoes"].get("noticia_horas") or 48), bool(job["opcoes"].get("noticia_canais")),
                                     lambda m: _log(job, "  " + m, "aviso"))
        with Tx() as dbp:
            storage.find(dbp["videos"], vid)["pool_noticias"] = pool[:80]
        _log(job, f"  {len(pool)} fotos/vídeos recentes encontrados (Agência Brasil e YouTube)", "ok")
    if len(pend) == len([c for c in v["cenas"] if c.get("status") not in ("escolhida", "manual")]):
        reallab.job_midia(vid, sub, so_pendentes=True)
    else:
        reallab.job_midia(vid, sub, so_ns=[c["n"] for c in pend])
    db, v, ch = _video(vid)
    vids = sum(1 for c in v["cenas"] if (c.get("midia") or {}).get("tipo") == "video")
    fotos = sum(1 for c in v["cenas"] if c.get("midia") and (c.get("midia") or {}).get("tipo") != "video")
    sem = sum(1 for c in v["cenas"] if not c.get("midia"))
    job["resultado"]["midia"] = {"videos": vids, "fotos": fotos, "sem": sem}
    return f"{vids} vídeos, {fotos} fotos, {sem} sem mídia"


# ---------------------------------------------------------------- 6. cenas sem mídia
def _tapar_buracos(vid, job, motivo):
    """Cena sem nada: usa o próximo candidato ainda não usado; em último caso repete a mídia vizinha."""
    tapadas = 0
    with Tx() as db:
        v = storage.find(db["videos"], vid)
        usados = {(c.get("midia") or {}).get("download") for c in v["cenas"] if c.get("midia")}
        for i, c in enumerate(v["cenas"]):
            if c.get("midia"):
                continue
            cand = next((x for x in (c.get("candidatos") or []) if x.get("download") not in usados), None)
            if cand:
                c["midia"] = dict(cand, origem="auto", reserva=True)
                usados.add(cand.get("download"))
            else:
                viz = next((v["cenas"][j]["midia"] for j in (i - 1, i + 1, i - 2, i + 2) if 0 <= j < len(v["cenas"]) and v["cenas"][j].get("midia")), None)
                if not viz:
                    continue
                c["midia"] = dict(viz, origem="auto", repetida=True)
            c["status"] = "escolhida"
            c.setdefault("avisos", []).append(f"Sem mídia boa ({motivo}) — usei a melhor alternativa")
            tapadas += 1
    return tapadas


def e_ia(job):
    vid = job["vid"]
    db, v, ch = _video(vid)
    sem = [c for c in v["cenas"] if not c.get("midia")]
    if not sem:
        return "Nenhuma cena ficou sem mídia"
    feitas = 0
    if job["opcoes"].get("permitir_ia") and job["opcoes"].get("ia_motor", "pollinations") != "manual":
        sub = job["sub"]
        sub["settings_extra"] = {"ia_motor": job["opcoes"].get("ia_motor", "pollinations")}
        reallab.job_ia(vid, sub, so_ns=[c["n"] for c in sem])
        db, v, ch = _video(vid)
        feitas = len(sem) - sum(1 for c in v["cenas"] if not c.get("midia"))
    tapadas = _tapar_buracos(vid, job, "IA desligada" if not job["opcoes"].get("permitir_ia") else "IA não gerou")
    return f"{feitas} por IA, {tapadas} com alternativa"


# ---------------------------------------------------------------- 7. download
def e_download(job):
    vid = job["vid"]
    for rodada in range(3):
        sub = job["sub"]
        sub["falhas"] = []
        HELPERS["baixar"](vid, sub)
        falhas = list(sub.get("falhas") or [])
        if not falhas:
            break
        _log(job, f"  {len(falhas)} download(s) falharam — trocando pelo próximo candidato", "aviso")
        with Tx() as db:
            v = storage.find(db["videos"], vid)
            usados = {(c.get("midia") or {}).get("download") for c in v["cenas"] if c.get("midia")}
            for c in v["cenas"]:
                if c["n"] not in falhas:
                    continue
                ruins = set(c.get("falhou_download") or []) | {(c.get("midia") or {}).get("download")}
                c["falhou_download"] = list(ruins)
                prox = next((x for x in (c.get("candidatos") or []) if x.get("download") not in ruins and x.get("download") not in usados and x.get("nota", 0) >= 3), None)
                c["midia"] = dict(prox, origem="auto") if prox else None
                if not prox:
                    c["status"] = "ia"
        if rodada == 2:
            break
    n = _tapar_buracos(vid, job, "download falhou")
    if n:
        HELPERS["baixar"](vid, job["sub"])
    if job["opcoes"].get("montagens", True):
        try:
            _preparar_layouts(vid, job)
        except Parado:
            raise
        except Exception as ex:
            _log(job, f"  montagens: {str(ex)[:150]}", "aviso")
    db, v, ch = _video(vid)
    falta = [c["n"] for c in v["cenas"] if not (c.get("midia") and c["midia"].get("arquivo") and os.path.exists(HELPERS["abs"](vid, c["midia"]["arquivo"])))]
    if len(falta) > max(2, len(v["cenas"]) * 0.15):
        raise RuntimeError(f"{len(falta)} cenas ficaram sem arquivo (cenas {', '.join(map(str, falta[:12]))}). Verifique a internet e clique em Continuar.")
    return f"Tudo baixado" + (f" ({len(falta)} cena(s) vão repetir a vizinha)" if falta else "")


def _foto_pessoa(nome, destino, s, vid):
    """Rosto da pessoa certa: candidatos do Wikimedia com o nome no arquivo, em pé, conferidos pelo Gemini (nota 7+)."""
    res = [x for x in media.buscar_wikimedia(nome, 12, bool(s.get("aceitar_cc_by_sa"))) if x["tipo"] == "foto"
           and (x.get("altura") or 1) >= (x.get("largura") or 1) * 0.75]
    res = [x for x in res if media.pontuar(nome, x.get("texto_match", ""), 0, nome)[0] >= 5]
    res.sort(key=lambda x: media.pontuar(nome, x.get("texto_match", ""), 0, nome)[0], reverse=True)
    res = res[:4]
    if not res:
        return None
    escolhida = None
    if reallab.tem_gemini():
        itens, base = [], []
        for x in res:
            try:
                dados, mime = reallab._bytes_preview(x.get("preview") or x["download"])
                itens.append((dados, mime, f"Wikimedia: {x.get('titulo', '')[:80]}", False))
                base.append(x)
            except Exception:
                continue
        if itens:
            d = gemini.conferir_lote(itens, {"texto": f"Retrato de {nome}", "descricao_visual": f"foto ou retrato falado do rosto de {nome}",
                                            "pessoa_real": nome}, vid)
            ok = [(float(r.get("nota") or 0), r["i"]) for r in d["resultados"] if r.get("serve") and float(r.get("nota") or 0) >= 7]
            if ok:
                escolhida = base[max(ok)[1] - 1]
    elif media.pontuar(nome, res[0].get("texto_match", ""), 0, nome)[0] >= 10:
        escolhida = res[0]  # sem Gemini: só aceita o nome completo exato
    if not escolhida:
        return None
    return media.baixar(escolhida["download"], destino, "foto", escolhida)


def _preparar_layouts(vid, job):
    """Baixa as fotos que as montagens precisam: rosto de cada pessoa (cartões) e 4 fotos para a colagem."""
    db, v, ch = _video(vid)
    pasta = storage.video_dir(vid)
    _preparar_mapas(vid, job)
    db, v, ch = _video(vid)
    alvo = [c for c in v["cenas"] if c.get("layout") in ("pessoa", "duas_pessoas", "colagem", "quadro", "sequencia", "ficha") and not c.get("layout_imgs")]
    if not alvo:
        return
    job["sub"].update(total=len(alvo), feito=0)
    s = db["settings"]
    novos = {}
    nomes_cena = {}
    for k, c in enumerate(alvo):
        _checar(job)
        job["sub"].update(feito=k, etapa=f"Montagem da cena {c['n']}: buscando fotos")
        imgs = []
        destino = os.path.join(pasta, "midia", f"lay_{c['n']:03d}")
        m = c.get("midia") or {}
        arq_m = HELPERS["abs"](vid, m.get("arquivo"))
        if c["layout"] in ("pessoa", "duas_pessoas", "quadro", "ficha"):
            nomes = c.get("pessoas") or ([c["pessoa_real"]] if c.get("pessoa_real") else [])
            nomes_ok = []
            for j, nome in enumerate(nomes[:1] if c["layout"] == "ficha" else nomes[:3] if c["layout"] == "quadro" else nomes[:2]):
                try:
                    p = _foto_pessoa(nome, f"{destino}_p{j}", s, vid)
                    if p:
                        imgs.append(os.path.relpath(p, pasta))
                        nomes_ok.append(nome)
                    else:
                        _log(job, f"  sem foto confiável de {nome} — a cena fica sem o rosto (melhor que pessoa errada)", "aviso")
                except Exception as ex:
                    _log(job, f"  foto de {nome}: {str(ex)[:100]}", "aviso")
            nomes_cena[c["n"]] = nomes_ok
            if c["layout"] == "quadro":  # completa o quadro com a foto da cena (o quadro funciona até com 1 foto)
                if m.get("tipo") == "foto" and arq_m and os.path.exists(arq_m) and len(imgs) < 4:
                    imgs.append(os.path.relpath(arq_m, pasta))
                novos[c["n"]] = ("quadro", imgs)
                continue
            if c["layout"] == "ficha":
                novos[c["n"]] = ("ficha", imgs)
                continue
            if not imgs or (c["layout"] == "duas_pessoas" and len(imgs) < 2):
                novos[c["n"]] = ("pessoa" if imgs else "midia", imgs)
                continue
        else:  # colagem / sequência
            if m.get("tipo") == "foto" and arq_m and os.path.exists(arq_m):
                imgs.append(os.path.relpath(arq_m, pasta))
            usados = {m.get("download")}
            for cand in c.get("candidatos") or []:
                if len(imgs) >= 4:
                    break
                if cand.get("tipo") != "foto" or cand.get("download") in usados or cand.get("nota", 0) < 6:
                    continue
                try:
                    p = media.baixar(cand.get("preview") or cand["download"], f"{destino}_c{len(imgs)}", "foto", cand)
                    imgs.append(os.path.relpath(p, pasta))
                    usados.add(cand.get("download"))
                except Exception:
                    continue
            if len(imgs) < (2 if c["layout"] == "sequencia" else 3):
                novos[c["n"]] = ("midia", [])
                continue
        novos[c["n"]] = (c["layout"], imgs)
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        for c in v2["cenas"]:
            if c["n"] in novos:
                c["layout"], c["layout_imgs"] = novos[c["n"]]
                c["layout_nomes"] = nomes_cena.get(c["n"], [])
    feitos = sum(1 for lay, _ in novos.values() if lay != "midia")
    _log(job, f"  {feitos} montagem(ns) com fotos prontas (cartões, quadros, fichas, colagens)", "ok")


def _preparar_mapas(vid, job):
    """Zoom de satélite: acha o lugar e baixa o mapa em vários níveis. Se não achar, vira plaquinha de local."""
    from core import satelite

    db, v, ch = _video(vid)
    alvo = [c for c in v["cenas"] if c.get("layout") == "mapa" and not c.get("layout_mapa")]
    if not alvo:
        return
    pasta = storage.video_dir(vid)
    res = {}
    for c in alvo:
        _checar(job)
        lugar = c.get("layout_texto") or c.get("lugar") or ""
        job["sub"].update(etapa=f"Mapa de satélite: {lugar[:40]}")
        destino = os.path.join(pasta, "midia", f"mapa_{c['n']:03d}")
        try:
            ok = lugar and satelite.preparar(lugar, destino, c.get("coordenadas"), c.get("zoom"), lambda m: _log(job, "  " + m, "aviso"))
        except Exception as ex:
            ok = False
            _log(job, f"  mapa da cena {c['n']}: {str(ex)[:120]}", "aviso")
        res[c["n"]] = os.path.relpath(destino, pasta) if ok else None
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        for c in v2["cenas"]:
            if c["n"] in res:
                if res[c["n"]]:
                    c["layout_mapa"] = res[c["n"]]
                else:
                    c["layout"] = "local" if (c.get("layout_texto") or c.get("lugar")) else "midia"
                    c["layout_texto"] = c.get("layout_texto") or c.get("lugar") or ""
    _log(job, f"  {sum(1 for x in res.values() if x)} mapa(s) de satélite prontos", "ok")


# ---------------------------------------------------------------- 8. legendas + impacto
def e_impacto(job):
    av = lambda m: _log(job, "  " + m, "aviso")
    vid = job["vid"]
    op = job["opcoes"]
    db, v, ch = _video(vid)
    total = v["cenas"][-1]["fim"] if v["cenas"] else 0
    textos = []
    if op.get("textos_impacto") and claude.tem_ia():
        n = max(3, min(12, int(total / 90)))
        # só cenas sem efeito grande (número, frase, quadro…): o texto de impacto não pode cobrir outro efeito
        lista = "\n".join(f"{c['n']}. {c['texto'][:220]}" for c in v["cenas"] if (c.get("layout") or "midia") in ("midia", "local", "ano"))
        job["sub"]["etapa"] = "Escolhendo os momentos de impacto"
        try:
            res = claude.json_pref("impacto", f"""Você edita vídeos documentais para o YouTube. Escolha os {n} momentos mais fortes da narração
(revelação, número chocante, virada, data marcante) para mostrar um TEXTO GRANDE na tela.
Para cada um: a cena e um texto curtíssimo (2 a 5 palavras, sem aspas, sem emoji), escrito em {prompts.IDIOMAS.get(ch.get("idioma", "pt"), "português do Brasil")} (a língua da narração).
Espalhe ao longo do vídeo; não use a cena 1.
CENAS:
{lista}
Responda SOMENTE JSON: {{"momentos": [{{"n": 5, "texto": "..."}}]}}""", vid, av)
            itens = res.get("momentos", []) if isinstance(res, dict) else res
            por_n = {c["n"]: c for c in v["cenas"]}
            for x in itens:
                c = por_n.get(int(x.get("n", 0) or 0))
                t = str(x.get("texto", "")).strip()[:40]
                if c and t:
                    textos.append({"texto": t, "inicio": round(c["inicio"] + 0.4, 2), "duracao": round(min(3.2, max(1.5, c["fim"] - c["inicio"] - 0.6)), 2), "cena": c["n"]})
        except Exception as ex:
            _log(job, f"  textos de impacto: {str(ex)[:150]}", "aviso")
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        ed = v2.setdefault("editor", {})
        pf_id = _perfil(job, ch)
        pf = perfis.get(pf_id)
        ed["estilo_edicao"] = pf_id
        ed["perfil"] = pf_id
        if op.get("template"):
            ed["template"] = op["template"]
        for k in ("filtro", "transicao"):
            ed[k] = op[k] if op.get(k) and op[k] != "auto" else pf[k]
        ed["montagens"] = bool(op.get("montagens", True))
        ed["sfx"] = bool(op.get("efeitos_sonoros", True))
        leg = ed.setdefault("legenda", {"ativa": True, "tamanho": 15, "posicao": "baixo", "caixa": False})
        leg["estilo"] = op["legenda_estilo"] if op.get("legenda_estilo") not in (None, "", "auto") else pf["legenda"].get("estilo", "")
        if pf["legenda"].get("cor"):
            leg.setdefault("cor", pf["legenda"]["cor"])
        ed["textos"] = textos
        if op.get("cta") and not ed.get("ctas") and total > 40:
            ed["ctas"] = [{"texto": CTA_TEXTO.get(ch.get("idioma", "pt"), "INSCREVA-SE"), "inicio": round(min(60, total * 0.12), 1), "duracao": 5}]
        ed.setdefault("legenda", {"ativa": True, "tamanho": 15, "cor": "#FFFFFF", "posicao": "baixo", "caixa": False})
        v2["musica_volume"] = op.get("musica_volume", v2.get("musica_volume", 0.12))
        _legenda(v2)
    return f"{len(textos)} textos de impacto" + (", CTA de inscrição" if op.get("cta") else "")


# ---------------------------------------------------------------- 9. render
def _frase_inteira(trecho, narracao, max_pal=22):
    """Cartela de frase nunca começa nem termina no meio: completa pela narração ou fica só com as frases inteiras."""
    t = re.sub(r"\s+", " ", str(trecho or "")).strip()
    if not t or (t[0].isupper() and t[-1] in '.!?…"”'):
        return t
    n = re.sub(r"\s+", " ", narracao or "").strip()
    tt = t.rstrip(".!?…,;: ")
    i = n.lower().find(tt.lower())
    if i >= 0:
        ini = max(n.rfind(". ", 0, i + 1), n.rfind("! ", 0, i + 1), n.rfind("? ", 0, i + 1))
        ini = 0 if ini < 0 else ini + 2
        if ini > i:
            ini = i
        fins = [p for p in (n.find(".", i + len(tt)), n.find("!", i + len(tt)), n.find("?", i + len(tt))) if p >= 0]
        fim = (min(fins) + 1) if fins else len(n)
        s = n[ini:fim].strip()
        if s and len(s.split()) <= max_pal:
            return s[0].upper() + s[1:]
    inteiras = [p.strip() for p in re.findall(r"[^.!?…]*[.!?…]", t) if p.strip() and p.strip()[0].isupper()]
    return max(inteiras, key=len) if inteiras else t


def _conferir_idioma(job):
    """Antes de montar: todo texto da tela (efeitos, textos de impacto, botão de inscrição, descrição) na língua da narração."""
    vid = job["vid"]
    db, v, ch = _video(vid)
    alvo = ch.get("idioma", "pt")
    nome = prompts.IDIOMAS.get(alvo, alvo)
    mudou = 0
    ed = v.get("editor") or {}
    itens = []
    for c in v.get("cenas") or []:
        for k in ("layout_texto", "layout_fonte", "layout_destaque", "titulo_tela", "nome_tela"):
            if str(c.get(k) or "").strip():
                itens.append({"id": f"c{c['n']}:{k}", "t": c[k]})
    for i, tx in enumerate(ed.get("textos") or []):
        if str(tx.get("texto") or "").strip():
            itens.append({"id": f"t{i}", "t": tx["texto"]})
    novos = {}
    if itens and claude.tem_ia():
        job["sub"]["etapa"] = f"Conferindo se os textos da tela estão em {nome}"
        try:
            res = claude.json_pref("impacto", f"""A narração deste vídeo está em {nome}. Abaixo estão os textos que aparecem NA TELA.
Devolva cada um escrito em {nome}: se já estiver nesse idioma, devolva EXATAMENTE igual; se estiver em outro idioma, traduza
mantendo o sentido, o tamanho (mais ou menos o mesmo número de palavras), maiúsculas/minúsculas, números, nomes próprios e o separador " | ".
Datas e números no formato de {nome}. Não invente nada.
TEXTOS:
{json.dumps(itens, ensure_ascii=False)}
Responda SOMENTE JSON: {{"textos": [{{"id": "...", "t": "..."}}]}}""", vid, lambda m: _log(job, "  " + m, "aviso"))
            lista = res.get("textos", []) if isinstance(res, dict) else res
            orig = {x["id"]: x["t"] for x in itens}
            for x in lista or []:
                if isinstance(x, dict) and x.get("id") in orig and str(x.get("t") or "").strip() and x["t"] != orig[x["id"]]:
                    novos[x["id"]] = str(x["t"])
        except Exception as ex:
            _log(job, f"  conferência do idioma: {str(ex)[:150]}", "aviso")
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        por_n = {c["n"]: c for c in v2.get("cenas") or []}
        ed2 = v2.setdefault("editor", {})
        for id_, t in novos.items():
            if id_.startswith("c"):
                n, k = id_[1:].split(":")
                if int(n) in por_n:
                    por_n[int(n)][k] = t
                    mudou += 1
            elif id_.startswith("t"):
                i = int(id_[1:])
                if i < len(ed2.get("textos") or []):
                    ed2["textos"][i]["texto"] = t
                    mudou += 1
        for cta in ed2.get("ctas") or []:
            if cta.get("texto") in CTA_TEXTO.values() and cta["texto"] != CTA_TEXTO.get(alvo, cta["texto"]):
                cta["texto"] = CTA_TEXTO[alvo]
                mudou += 1
        narr = v2.get("roteiro") or " ".join(c.get("texto", "") for c in v2.get("cenas") or [])
        for c in v2.get("cenas") or []:
            if c.get("layout") == "frase" and c.get("layout_texto"):
                novo = _frase_inteira(c["layout_texto"], narr)
                if novo != c["layout_texto"]:
                    c["layout_texto"] = novo
                    mudou += 1
        d = v2.get("descricao") or {}
        amostra = " ".join([str(d.get("descricao") or "")] + [str(x) for x in (d.get("titulos") or [])])
        if d and detectar_idioma(amostra) not in (None, alvo):
            v2.pop("descricao", None)  # a etapa de descrição escreve de novo, na língua certa
            mudou += 1
    if mudou:
        _log(job, f"  {mudou} texto(s) da tela passaram para {nome} (a língua da narração)", "ok")


def e_render(job):
    vid = job["vid"]
    _conferir_idioma(job)
    render.JOBS[vid] = {"log": [], "pct": 0, "rodando": True, "etapa": "Preparando"}
    res = HELPERS["montar"](vid, job["sub"])
    if job["parar"]:
        raise Parado()
    if res.get("erro") or not res.get("saida"):
        raise RuntimeError(res.get("erro") or "A montagem não gerou o final.mp4")
    if res.get("aviso"):
        _log(job, "  " + res["aviso"], "aviso")
    return "final.mp4 montado"


# ---------------------------------------------------------------- 10. QA
def _frame_stats(ff, video, t, saida):
    render._run([ff, "-y", "-ss", f"{max(0, t):.2f}", "-i", video, "-frames:v", "1", "-vf", "scale=320:-2", saida])
    from PIL import Image, ImageStat

    with Image.open(saida) as im:
        st = ImageStat.Stat(im.convert("L"))
        return st.mean[0], st.stddev[0]


def _info_final(ff, path):
    import subprocess

    p = subprocess.run([ff, "-hide_banner", "-i", path], capture_output=True, text=True, errors="ignore")
    txt = p.stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", txt)
    dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0
    r = re.search(r"Video:.*?(\d{3,5})x(\d{3,5})", txt)
    return {"duracao": dur, "audio": "Audio:" in txt, "resolucao": f"{r.group(1)}x{r.group(2)}" if r else "?"}


def _relevancia(vid, cenas, qa_dir, job):
    """Gemini olha o quadro do MEIO de cada cena já montada e diz se combina com a narração (0–10)."""
    import base64

    if not reallab.tem_gemini():
        return {}
    titulo = (storage.find(storage.load()["videos"], vid) or {}).get("titulo", "")
    notas = {}
    alvo = [c for c in cenas if c.get("layout") not in ("citacao", "documento", "quadro", "mapa", "capitulo", "sequencia", "colagem") and os.path.exists(os.path.join(qa_dir, f"cena_{c['n']:03d}.jpg"))]
    for k in range(0, len(alvo), 8):
        _checar(job)
        lote = alvo[k:k + 8]
        job["sub"].update(etapa=f"Revisando se as imagens combinam com a narração (cenas {lote[0]['n']}–{lote[-1]['n']})")
        parts = []
        for c in lote:
            parts.append({"text": f"CENA {c['n']} — narração: {c['texto'][:300]}"})
            parts.append({"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(open(os.path.join(qa_dir, f"cena_{c['n']:03d}.jpg"), "rb").read()).decode()}})
        parts.append({"text": f"""Você revisa um vídeo pronto sobre: {titulo}. Para cada cena acima, dê uma nota de 0 a 10 para o quanto a IMAGEM combina com a narração
dela e com o assunto (ignore legendas e textos desenhados por cima). Nota baixa (0–4) para: imagem sem relação com o assunto (animais, pessoas
aleatórias, objetos soltos), pessoa ou lugar errado, tela escura/vazia/borrada. Seja exigente como um editor de TV.
Nota 0–2 também para: logotipo de marca ou empresa em destaque (PayPal, bancos, apps, redes sociais) se a narração não fala dessa marca
(texto_gravado); placa de nome, crachá ou legenda que identifica uma pessoa real que a narração NÃO cita — ex.: políticos numa sessão qualquer
(entidade_errada); apresentador ou vídeo institucional falando outro idioma; tela de código de programação ou interface de
software genérica; infográfico vazio, tela quase toda branca ou estourada; mapa-múndi ou continente inteiro quando
a cena fala de um lugar específico.
Responda SOMENTE JSON: {{"cenas": [{{"n": 1, "nota": 0, "motivo": "frase curta"}}]}}"""})
        try:
            j_, _ = gemini.chamar(parts, vid, json_out=True, max_tokens=2000, temperatura=0.1)
            d = prompts.parse_json(gemini._texto(j_))
            for x in (d.get("cenas") if isinstance(d, dict) else d) or []:
                try:
                    notas[int(x.get("n"))] = (float(x.get("nota") or 0), str(x.get("motivo", ""))[:100])
                except (TypeError, ValueError, AttributeError):
                    pass
        except Exception as ex:
            _log(job, f"  revisão de relevância: {str(ex)[:120]}", "aviso")
            break
    return notas


EFEITOS_RESGATE = ("frase", "ficha", "documento", "linha_tempo", "numero", "data", "mapa", "citacao")


def _resgatar(job, ns):
    """Cenas sem imagem real boa: viram efeito de documentário (se a narração der o conteúdo) ou imagem de IA feita para a frase."""
    vid = job["vid"]
    db, v, ch = _video(vid)
    pf_id = _perfil(job, ch)
    por_n = {c["n"]: c for c in v["cenas"]}
    ns = [n for n in sorted(ns) if n in por_n]
    if not ns:
        return 0, 0
    decisoes = {}
    estilo_ia = {"true_crime": "dark cinematic documentary still, muted colors, film grain, moody lighting",
                 "historia": "vintage sepia archival photograph, period-accurate, film grain",
                 "horror": "dark cold cinematic still, fog, low light, eerie atmosphere",
                 "jornal": "realistic news photo, natural light", "natureza": "vivid nature documentary photo, golden light"}.get(pf_id, "cinematic documentary still")
    for k in range(0, len(ns), 30):
        _checar(job)
        lote = ns[k:k + 30]
        job["sub"].update(etapa=f"Resolvendo cenas sem imagem boa ({lote[0]}–{lote[-1]})")
        linhas = []
        for n in lote:
            c = por_n[n]
            viz = f"{(por_n.get(n - 1) or {}).get('layout') or 'midia'}/{(por_n.get(n + 1) or {}).get('layout') or 'midia'}"
            linhas.append(f"{n}. [vizinhas: {viz}] {c.get('texto', '')[:260]}")
        regras = "\n".join(f'- "{e}": {perfis.EFEITOS_DESC[e]}' for e in EFEITOS_RESGATE)
        p = f"""Você edita um documentário de histórias reais para o YouTube: {v.get('titulo', '')}.
Estas cenas NÃO têm imagem real boa (só imagem genérica). Para cada uma, escolha a melhor saída:
A) um EFEITO de documentário, se a narração da cena der o conteúdo (data, lugar, número, frase forte, pessoa, documento, sequência de fatos);
B) "ia": uma imagem gerada por IA feita para a frase — descreva em "prompt_ia" (INGLÊS) a cena exata: lugar, época, objetos, clima.
   Nunca rosto de pessoa real identificável (use silhuetas, mãos, de costas, objetos, lugares). Estilo: {estilo_ia}.
Prefira efeito quando a narração tiver conteúdo concreto; use "ia" para cenas de ambiente/ação. Nunca o mesmo efeito da cena vizinha
(vizinhas entre colchetes) e não repita o mesmo efeito em mais de 1 a cada 4 cenas deste lote. Nunca invente fatos, números ou frases.
EFEITOS:
{regras}

CENAS
{chr(10).join(linhas)}

Responda SOMENTE JSON: [{{"n": 1, "layout": "frase|...|ia", "layout_texto": "", "layout_destaque": "", "layout_fonte": "", "coordenadas": [0, 0], "zoom": 10, "prompt_ia": ""}}]"""
        try:
            res = claude.json_pref("pesquisa", p, vid, lambda m: _log(job, "  " + m, "aviso"))
            if isinstance(res, dict):
                res = res.get("cenas") or next((x for x in res.values() if isinstance(x, list)), [])
            for x in res or []:
                try:
                    decisoes[int(x.get("n"))] = x
                except (TypeError, ValueError, AttributeError):
                    pass
        except Exception as ex:
            _log(job, f"  resgate das cenas {lote[0]}–{lote[-1]}: {str(ex)[:120]}", "aviso")
    efeitos, ias = [], []
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        for c in v2["cenas"]:
            if c["n"] not in ns:
                continue
            x = decisoes.get(c["n"]) or {}
            lay = str(x.get("layout") or "ia").strip()
            c["resgatada"] = True
            if lay in EFEITOS_RESGATE and (lay not in layouts.PRECISA_TEXTO or str(x.get("layout_texto") or "").strip()):
                c["layout"] = lay
                for k_ in ("layout_texto", "layout_destaque", "layout_fonte"):
                    c[k_] = str(x.get(k_) or "")
                if lay == "mapa":
                    c.pop("layout_mapa", None)
                    if isinstance(x.get("coordenadas"), list) and len(x["coordenadas"]) == 2:
                        c["coordenadas"] = x["coordenadas"]
                    if x.get("zoom"):
                        c["zoom"] = x["zoom"]
                c["layout_imgs"] = []
                c["fundo_neutro"] = lay not in ("mapa", "documento", "quadro", "citacao")
                efeitos.append(c["n"])
            else:
                c["prompt_ia"] = str(x.get("prompt_ia") or c.get("prompt_ia") or c.get("descricao_visual") or c.get("texto", ""))[:600]
                c["layout"] = "midia"
                ias.append(c["n"])
    _preparar_mapas(vid, job)  # mapas novos (se algum lugar não for achado, vira plaquinha de local)
    feitas_ia = 0
    if ias:
        if job["opcoes"].get("permitir_ia", True) and job["opcoes"].get("ia_motor", "pollinations") != "manual":
            sub = job["sub"]
            sub["settings_extra"] = {"ia_motor": job["opcoes"].get("ia_motor", "pollinations")}
            antes = {c["n"]: c.get("midia") for c in _video(vid)[1]["cenas"] if c["n"] in ias}
            reallab.job_ia(vid, sub, so_ns=ias)
            db3, v3, _ = _video(vid)
            falharam = [c["n"] for c in v3["cenas"] if c["n"] in ias and (c.get("midia") or {}).get("origem") != "ia"]
            feitas_ia = len(ias) - len(falharam)
        else:
            falharam = list(ias)
        if falharam:  # sem IA: a cena vira a frase dela em destaque, sobre fundo neutro
            with Tx() as db4:
                v4 = storage.find(db4["videos"], vid)
                for c in v4["cenas"]:
                    if c["n"] in falharam:
                        palavras = (c.get("texto") or "").split()
                        c["layout"], c["layout_texto"], c["fundo_neutro"] = "frase", " ".join(palavras[:12]), True
            efeitos += falharam
    return len(efeitos), feitas_ia


def e_qa(job):
    vid = job["vid"]
    ff = render.ffmpeg_bin()
    pasta = storage.video_dir(vid)
    final = os.path.join(pasta, "final.mp4")
    qa_dir = os.path.join(pasta, "qa")
    os.makedirs(qa_dir, exist_ok=True)
    problemas = []
    rodadas = 3 if job["opcoes"].get("qa_refazer", True) else 1
    revisar = None  # na 1ª rodada revisa todas; depois, só as trocadas
    boas = {}
    inicio = 0
    pend = (_video(vid)[1].get("qa_pendente") or {})
    if pend:  # o app foi fechado no meio da revisão: termina a remontagem e continua de onde parou
        _log(job, f"  continuando a revisão (rodada {pend.get('rodada', 0) + 2}) — remontando as {len(pend.get('revisar') or [])} cena(s) trocadas", "info")
        HELPERS["baixar"](vid, job["sub"])
        res = HELPERS["montar"](vid, job["sub"])
        if job["parar"]:
            raise Parado()
        if res.get("erro") or not res.get("saida"):
            raise RuntimeError(res.get("erro") or "A remontagem falhou")
        revisar = set(pend.get("revisar") or [])
        boas = {int(k): v_ for k, v_ in (pend.get("boas") or {}).items()}
        inicio = min(rodadas - 1, int(pend.get("rodada", 0)) + 1)
    for rodada in range(inicio, rodadas):
        db, v, ch = _video(vid)
        ruins = []
        job["sub"]["total"] = len(v["cenas"])
        for i, c in enumerate(v["cenas"]):
            _checar(job)
            job["sub"].update(feito=i, etapa=f"Conferindo cena {c['n']}/{len(v['cenas'])}")
            meio = (c["inicio"] + c["fim"]) / 2
            try:
                media_l, desvio = _frame_stats(ff, final, meio, os.path.join(qa_dir, f"cena_{c['n']:03d}.jpg"))
            except Exception:
                ruins.append((c["n"], "não consegui ler o quadro"))
                continue
            if media_l < 14 and desvio < 8:
                ruins.append((c["n"], "tela preta"))
            elif desvio < 3:
                ruins.append((c["n"], "imagem lisa/quebrada"))
        # revisão de conteúdo: a imagem combina com o que está sendo dito?
        cenas_rev = [c for c in v["cenas"] if (revisar is None or c["n"] in revisar) and not c.get("resgatada")]
        notas = _relevancia(vid, cenas_rev, qa_dir, job)
        for n, (nota, motivo) in notas.items():
            if nota >= 7:
                boas[n] = nota
            elif nota < (5 if job["opcoes"].get("velocidade") == "rapido" else 6) and n not in {x for x, _ in ruins}:
                ruins.append((n, f"não combina com a narração ({motivo})"))
        if not ruins:
            break
        problemas = ruins
        _log(job, f"  revisão encontrou {len(ruins)} cena(s) para trocar: " + "; ".join(f"cena {n}: {m}" for n, m in ruins[:8]), "aviso")
        if rodada == rodadas - 1:
            break
        # troca: 1ª rodada tenta o próximo candidato bom; o que não tiver vira efeito ou imagem de IA (resgate)
        trocadas = set()
        resgate = set()
        with Tx() as db2:
            v2 = storage.find(db2["videos"], vid)
            usados = {(x.get("midia") or {}).get("download") for x in v2["cenas"] if x.get("midia")}
            por_n = {x["n"]: x for x in v2["cenas"]}
            for n, _m in ruins:
                c = por_n.get(n)
                if not c:
                    continue
                ja = set(c.get("rejeitadas_qa") or []) | {(c.get("midia") or {}).get("download")}
                c["rejeitadas_qa"] = list(ja)
                prox = None
                if rodada == 0 and not c.get("resgatada"):
                    prox = next((x for x in (c.get("candidatos") or []) if x.get("download") not in usados and x.get("download") not in ja
                                 and x.get("nota", 0) >= 6 and x.get("conferida", True) is not False
                                 and not media.TERMOS_RUINS.search(str(x.get("titulo", "")))), None)
                if prox:
                    c["midia"] = dict(prox, origem="auto", trocada_qa=True)
                    c["layout"] = "midia" if c.get("layout") in ("pessoa", "duas_pessoas", "colagem") else c.get("layout")
                    usados.add(prox.get("download"))
                    trocadas.add(n)
                elif not c.get("resgatada"):
                    resgate.add(n)
        if resgate:
            n_ef, n_ia = _resgatar(job, resgate)
            _log(job, f"  {len(resgate)} cena(s) sem imagem real boa: {n_ef} viraram efeito de documentário e {n_ia} imagem de IA", "ok")
            trocadas |= resgate
        if not trocadas:
            break
        revisar = trocadas
        with Tx() as dbq:  # guarda onde parou: se fechar o app, continua daqui
            storage.find(dbq["videos"], vid)["qa_pendente"] = {"rodada": rodada, "revisar": sorted(trocadas), "boas": {str(k): v_ for k, v_ in boas.items()}}
        _log(job, f"  trocando {len(trocadas)} cena(s) e remontando", "aviso")
        HELPERS["baixar"](vid, job["sub"])
        job["sub"]["etapa"] = "Remontando as cenas trocadas"
        res = HELPERS["montar"](vid, job["sub"])
        if job["parar"]:
            raise Parado()
        if res.get("erro") or not res.get("saida"):
            raise RuntimeError(res.get("erro") or "A remontagem falhou")
        problemas = []
    with Tx() as dbq:
        storage.find(dbq["videos"], vid).pop("qa_pendente", None)
    db, v, ch = _video(vid)
    info = _info_final(ff, final)
    esperado = v["cenas"][-1]["fim"] if v["cenas"] else 0
    checks = []
    if not info["audio"]:
        checks.append("vídeo sem áudio")
    if esperado and abs(info["duracao"] - esperado) > 3:
        checks.append(f"duração {info['duracao']:.0f}s (esperado {esperado:.0f}s)")
    job["resultado"]["qa"] = {"problemas": [f"cena {n}: {m}" for n, m in problemas], "final": info, "checks": checks}
    if checks:
        _log(job, "  conferência do arquivo final: " + "; ".join(checks), "aviso")
    return ("Tudo certo" if not problemas and not checks else f"{len(problemas) + len(checks)} aviso(s)") + f" · {info['resolucao']} · {_fmt(info['duracao'])}"


# ---------------------------------------------------------------- 11. SEO + thumb
def e_seo(job):
    av = lambda m: _log(job, "  " + m, "aviso")
    vid = job["vid"]
    db, v, ch = _video(vid)
    pasta = storage.video_dir(vid)
    if not v.get("descricao") and claude.tem_ia():
        job["sub"]["etapa"] = "Gemini escrevendo título, descrição, tags e capítulos"
        try:
            d = claude.json_pref("seo", prompts.descricao(ch, v, scenes.capitulos_aprox(v.get("cenas", []))), vid, av)
            with Tx() as db2:
                v2 = storage.find(db2["videos"], vid)
                v2["descricao"] = d if isinstance(d, dict) else {"descricao": str(d)}
                v2["etapas"]["descricao"] = True
        except Exception as ex:
            _log(job, f"  descrição: {str(ex)[:150]}", "aviso")
    db, v, ch = _video(vid)
    desc = v.get("descricao") or {}
    texto = ((desc.get("thumb_textos") or [None])[0] or v["titulo"])[:40]
    # fundo: quadro da cena mais forte (pessoa real / maior nota), tirado do vídeo final
    fundo = os.path.join(pasta, "thumb_fundo_auto.jpg")
    try:
        fundo = _fundo_thumb_seguro(vid, v, pasta, job) or fundo
        os.makedirs(os.path.join(pasta, "thumbs"), exist_ok=True)
        nome = f"thumb_auto_{int(time.time()) % 10**8}.png"
        thumb.gerar(fundo, texto, "", job["opcoes"].get("thumb_estilo", "impacto"), "esquerda", os.path.join(pasta, "thumbs", nome))
        with Tx() as db3:
            v3 = storage.find(db3["videos"], vid)
            v3["thumbs"] = ([{"arquivo": nome, "estilo": job["opcoes"].get("thumb_estilo", "impacto"), "texto": texto}] + (v3.get("thumbs") or []))[:16]
            v3["etapas"]["thumb"] = True
        job["resultado"]["thumb"] = nome
    except Exception as ex:
        _log(job, f"  thumbnail: {str(ex)[:150]}", "aviso")
    return ("descrição + " if desc else "") + ("thumbnail" if job["resultado"].get("thumb") else "sem thumbnail")


def _fundo_thumb_seguro(vid, v, pasta, job):
    """Escolhe o fundo da thumbnail entre as melhores cenas, mas só um que passe na checagem: nada de pessoa real que o vídeo
    não cita (ex.: políticos com placa de nome), logo de marca ou imagem que dê a entender algo que o vídeo não diz."""
    import base64
    import io

    from PIL import Image

    ff = render.ffmpeg_bin()
    cands = sorted(v["cenas"][1:] or v["cenas"], key=lambda c: (bool(c.get("pessoa_real")), (c.get("midia") or {}).get("nota", 0)), reverse=True)
    resumo = (v.get("roteiro") or " ".join(c.get("texto", "") for c in v["cenas"]))[:1500]
    for k, c in enumerate(cands[:6]):
        m = c.get("midia") or {}
        arq = HELPERS["abs"](vid, m.get("arquivo"))
        if not (arq and os.path.exists(arq)):
            continue
        destino = os.path.join(pasta, f"thumb_fundo_{k}.jpg")
        try:
            if m.get("tipo") == "video" and os.path.splitext(arq)[1].lower() not in render.EXT_IMAGEM:
                render._run([ff, "-y", "-ss", "1", "-i", arq, "-frames:v", "1", "-q:v", "2", destino])
            else:
                Image.open(arq).convert("RGB").save(destino, quality=92)
        except Exception:
            continue
        if not reallab.tem_gemini():
            return destino
        try:
            im = Image.open(destino).convert("RGB")
            im.thumbnail((768, 768))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=85)
            job["sub"]["etapa"] = "Conferindo se o fundo da thumbnail é seguro"
            j_, _ = gemini.chamar([{"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(buf.getvalue()).decode()}},
                                   {"text": f"""Esta imagem vai ser o FUNDO DA THUMBNAIL de um vídeo do YouTube, com o número/frase do vídeo escrito em cima.
TÍTULO: {v.get('titulo', '')}
RESUMO DO QUE O VÍDEO DIZ: {resumo}
Pode usar? Responda NÃO se: aparece pessoa real identificável que o vídeo não cita ou não acusa (ex.: políticos, autoridades ou pessoas comuns
com rosto visível, placa de nome ou crachá) — ligar o rosto dela ao assunto pode ser difamação; tem logo de marca ou empresa; tem texto grande,
marca d'água ou logo de outro canal; é escura, borrada ou de baixa qualidade. Responda SIM para lugares, objetos, documentos, dinheiro,
viaturas, paisagens do assunto e pessoas sem rosto identificável.
Responda SOMENTE JSON: {{"usar": true, "motivo": "frase curta"}}"""}], vid, json_out=True, max_tokens=200, temperatura=0.1)
            d = prompts.parse_json(gemini._texto(j_))
            if isinstance(d, dict) and d.get("usar"):
                return destino
            _log(job, f"  thumbnail: não usei a cena {c['n']} ({str((d or {}).get('motivo', ''))[:80]})", "aviso")
        except Exception as ex:
            _log(job, f"  thumbnail: checagem falhou ({str(ex)[:80]})", "aviso")
    # nenhuma passou: fundo neutro tirado de uma cena de efeito (número, data, frase), sem pessoa real
    efeito = next((c for c in v["cenas"] if c.get("layout") in ("numero", "data", "frase", "documento", "mapa")), None)
    if efeito:
        destino = os.path.join(pasta, "thumb_fundo_efeito.jpg")
        render._run([ff, "-y", "-ss", f"{(efeito['inicio'] + efeito['fim']) / 2:.2f}", "-i", os.path.join(pasta, "final.mp4"), "-frames:v", "1", "-q:v", "2", destino])
        return destino
    return None


# ---------------------------------------------------------------- 12. entrega
def _texto_descricao(v):
    d = v.get("descricao") or {}
    partes = []
    if d.get("titulos"):
        partes.append("TÍTULOS SUGERIDOS\n" + "\n".join(f"- {t}" for t in d["titulos"]))
    if d.get("descricao"):
        partes.append("DESCRIÇÃO\n" + d["descricao"])
    if d.get("capitulos"):
        partes.append("CAPÍTULOS\n" + "\n".join(f"{x.get('tempo','')} {x.get('titulo','')}" for x in d["capitulos"] if isinstance(x, dict)))
    if d.get("tags"):
        partes.append("TAGS\n" + ", ".join(d["tags"]))
    if d.get("hashtags"):
        partes.append("HASHTAGS\n" + " ".join(d["hashtags"]))
    fontes = (v.get("noticia") or {}).get("fontes") or []
    if fontes:
        partes.append("FONTES (apuração das últimas horas)\n" + "\n".join(f"- {f.get('veiculo') or f.get('titulo')}: {f.get('link')}" for f in fontes[:15]))
    return "\n\n".join(partes) or v.get("titulo", "")


def e_entrega(job):
    vid = job["vid"]
    db, v, ch = _video(vid)
    pasta = storage.video_dir(vid)
    ent = os.path.join(pasta, "entrega")
    os.makedirs(ent, exist_ok=True)
    nome = re.sub(r"[^\w\- ]", "", v["titulo"])[:70].strip() or vid
    shutil.copy2(os.path.join(pasta, "final.mp4"), os.path.join(ent, f"{nome}.mp4"))
    if os.path.exists(os.path.join(pasta, "legendas.srt")):
        shutil.copy2(os.path.join(pasta, "legendas.srt"), os.path.join(ent, "legendas.srt"))
    with open(os.path.join(ent, "descricao-youtube.txt"), "w", encoding="utf-8") as f:
        f.write(_texto_descricao(v))
    with open(os.path.join(ent, "creditos.txt"), "w", encoding="utf-8") as f:
        f.write(media.creditos(v["cenas"]))
    with open(os.path.join(ent, "roteiro.txt"), "w", encoding="utf-8") as f:
        f.write(v.get("roteiro", ""))
    if v.get("thumbs"):
        t = os.path.join(pasta, "thumbs", v["thumbs"][0]["arquivo"])
        if os.path.exists(t):
            shutil.copy2(t, os.path.join(ent, "thumbnail.png"))
    try:
        job["sub"]["etapa"] = "Montando o pacote para CapCut"
        with open(os.path.join(ent, "pacote-capcut.zip"), "wb") as f:
            HELPERS["pacote"](vid, f)
    except Exception as ex:
        _log(job, f"  pacote CapCut: {str(ex)[:150]}", "aviso")
    qa = job["resultado"].get("qa") or {}
    rel = [f"Vídeo: {v['titulo']}", f"Gerado em: {storage.now()}", f"Cenas: {len(v['cenas'])}"]
    m = job["resultado"].get("midia") or {}
    if m:
        rel.append(f"Mídia: {m.get('videos', 0)} vídeos, {m.get('fotos', 0)} fotos")
    fin = qa.get("final") or {}
    if fin:
        rel.append(f"Arquivo final: {fin.get('resolucao')} · {_fmt(fin.get('duracao'))} · áudio: {'sim' if fin.get('audio') else 'NÃO'}")
    if qa.get("problemas") or qa.get("checks"):
        rel.append("Avisos do QA:\n" + "\n".join(f"- {x}" for x in (qa.get("problemas") or []) + (qa.get("checks") or [])))
    else:
        rel.append("QA: nenhuma cena preta ou quebrada.")
    with open(os.path.join(ent, "relatorio.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(rel))
    with Tx() as db2:
        v2 = storage.find(db2["videos"], vid)
        v2["entrega"] = ent
    job["resultado"]["entrega"] = ent
    job["resultado"]["arquivo"] = f"{nome}.mp4"
    return f"{len(os.listdir(ent))} arquivos na pasta entrega"


ETAPA_FN = {
    "roteiro": e_roteiro, "cenas": e_cenas, "pesquisa": e_pesquisa, "narracao": e_narracao, "midia": e_midia, "ia": e_ia,
    "download": e_download, "impacto": e_impacto, "render": e_render, "qa": e_qa, "seo": e_seo, "entrega": e_entrega,
}
