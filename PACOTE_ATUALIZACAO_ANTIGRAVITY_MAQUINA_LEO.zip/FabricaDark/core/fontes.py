"""Fontes extras de mídia real com licença livre: Openverse, Met Museum, Smithsonian, Europeana.
Só passam domínio público, CC0 e CC BY (CC BY-SA opcional). NC (não comercial) e ND (sem obra derivada) ficam sempre de fora.
"""
import re

import requests

UA = "FabricaDark/1.0 (ferramenta pessoal de producao de video)"
T = 20


def licenca_ok(texto, aceitar_sa=False):
    t = (texto or "").lower().replace("_", "-")
    if not t:
        return False
    if any(x in t for x in ("-nc", " nc", "noncommercial", "non-commercial", "-nd", " nd", "noderiv", "no derivatives")):
        return False
    if any(x in t for x in ("public domain", "publicdomain", "pdm", "cc0", "cc-zero", "zero", "no restrictions", "pd-", "domínio público")) or t.strip() in ("pd", "pdm"):
        return True
    if re.search(r"\bby\b|cc[- ]?by|/by/|licenses/by", t):
        if "sa" in re.split(r"[^a-z]+", t) or "by-sa" in t or "/by-sa/" in t:
            return aceitar_sa
        return True
    return False


def _cand(fonte, tipo, preview, download, titulo, texto, licenca, autor, pagina, w=None, h=None):
    return {"fonte": fonte, "tipo": tipo, "preview": preview, "download": download, "titulo": titulo, "texto_match": texto,
            "licenca": licenca, "autor": (autor or "")[:80], "pagina": pagina, "largura": w, "altura": h}


_OV_FORA = {"ate": 0, "falhas": 0}


def openverse(termo, aceitar_sa=False, limite=12):
    import time as _t

    if _OV_FORA["ate"] > _t.time():
        return []  # Openverse lento/fora do ar: pula por um tempo, sem travar a busca
    lic = "pdm,cc0,by" + (",by-sa" if aceitar_sa else "")
    try:
        r = requests.get("https://api.openverse.org/v1/images/", params={"q": termo, "license": lic, "page_size": limite, "mature": "false"},
                         headers={"User-Agent": UA}, timeout=8)
    except requests.RequestException:
        _OV_FORA["falhas"] += 1
        if _OV_FORA["falhas"] >= 2:
            _OV_FORA["ate"], _OV_FORA["falhas"] = _t.time() + 1800, 0
        return []
    _OV_FORA["falhas"] = 0
    if r.status_code == 429:
        raise RuntimeError("Openverse: limite de buscas de hoje atingido")
    r.raise_for_status()
    out = []
    for it in r.json().get("results", []):
        lic_txt = f"{it.get('license','')} {it.get('license_version','')}".strip()
        if not licenca_ok(lic_txt if it.get("license") not in ("pdm", "cc0") else "public domain", aceitar_sa):
            continue
        if (it.get("width") or 1000) < 640:
            continue
        tags = " ".join(t.get("name", "") for t in (it.get("tags") or []))
        out.append(_cand("Openverse", "foto", it.get("thumbnail") or it.get("url"), it.get("url"), it.get("title", ""),
                         f"{it.get('title','')} {tags}", "CC " + lic_txt.upper(), it.get("creator", ""), it.get("foreign_landing_url", ""),
                         it.get("width"), it.get("height")))
    return out


_MET_FORA = {"ate": 0}


def met(termo, limite=6):
    import time as _t

    if _MET_FORA["ate"] > _t.time():
        return []  # o Met recusou há pouco: pula sem gastar tempo
    r = requests.get("https://collectionapi.metmuseum.org/public/collection/v1/search", params={"q": termo, "hasImages": "true"}, headers={"User-Agent": UA}, timeout=T)
    if r.status_code in (403, 404, 410, 429, 503):
        _MET_FORA["ate"] = _t.time() + 3600  # desliga o Met por 1 hora, sem erro na tela
        return []
    r.raise_for_status()
    ids = (r.json().get("objectIDs") or [])[: limite * 2]
    out = []
    for oid in ids:
        if len(out) >= limite:
            break
        o = requests.get(f"https://collectionapi.metmuseum.org/public/collection/v1/objects/{oid}", headers={"User-Agent": UA}, timeout=T)
        if not o.ok:
            continue
        o = o.json()
        if not o.get("isPublicDomain") or not o.get("primaryImage"):
            continue
        tags = " ".join(t.get("term", "") for t in (o.get("tags") or []))
        txt = f"{o.get('title','')} {o.get('objectName','')} {o.get('culture','')} {o.get('objectDate','')} {tags}"
        out.append(_cand("Met Museum", "foto", o.get("primaryImageSmall") or o["primaryImage"], o["primaryImage"], o.get("title", ""), txt,
                         "Domínio público (CC0)", o.get("artistDisplayName", ""), o.get("objectURL", "")))
    return out


def smithsonian(termo, key, limite=10):
    if not key:
        return []
    r = requests.get("https://api.si.edu/openaccess/api/v1.0/search",
                     params={"q": f'{termo} AND online_media_type:"Images"', "rows": limite, "api_key": key}, timeout=T)
    r.raise_for_status()
    out = []
    for row in (r.json().get("response") or {}).get("rows", []):
        c = row.get("content") or {}
        dn = c.get("descriptiveNonRepeating") or {}
        midias = (dn.get("online_media") or {}).get("media") or []
        m = next((x for x in midias if (x.get("usage") or {}).get("access") == "CC0" and x.get("type", "").lower().startswith("images")), None)
        if not m:
            continue
        titulo = row.get("title", "")
        topicos = " ".join(((c.get("indexedStructured") or {}).get("topic") or [])[:10])
        out.append(_cand("Smithsonian", "foto", m.get("thumbnail") or m.get("content"), m.get("content"), titulo, f"{titulo} {topicos}",
                         "CC0", "", dn.get("record_link", "")))
    return out


def europeana(termo, key, aceitar_sa=False, limite=10):
    if not key:
        return []
    r = requests.get("https://api.europeana.eu/record/v2/search.json",
                     params={"wskey": key, "query": termo, "reusability": "open", "media": "true", "qf": "TYPE:IMAGE", "rows": limite, "profile": "rich"}, timeout=T)
    r.raise_for_status()
    out = []
    for it in r.json().get("items", []):
        rights = (it.get("rights") or [""])[0]
        if not licenca_ok(rights, aceitar_sa):
            continue
        full = (it.get("edmIsShownBy") or [None])[0]
        prev = (it.get("edmPreview") or [None])[0]
        if not (full or prev):
            continue
        titulo = (it.get("title") or [""])[0]
        assuntos = " ".join((it.get("dcSubjectLangAware") or {}).get("def", [])[:8]) if isinstance(it.get("dcSubjectLangAware"), dict) else ""
        out.append(_cand("Europeana", "foto", prev or full, full or prev, titulo, f"{titulo} {assuntos} {' '.join(it.get('year') or [])}",
                         rights.split("/licenses/")[-1].split("/publicdomain/")[-1].strip("/") or rights, (it.get("dcCreator") or [""])[0], it.get("guid", "")))
    return out


# ---------------- Internet Archive (filmagens antigas em domínio público / CC) ----------------
def internet_archive(termo, limite=6):
    q = (f'({termo}) AND mediatype:(movies) AND '
         '(licenseurl:(*publicdomain*) OR licenseurl:(*creativecommons.org/licenses/by/*) OR licenseurl:(*creativecommons.org/publicdomain*))')
    r = requests.get("https://archive.org/advancedsearch.php", timeout=T, headers={"User-Agent": UA},
                     params={"q": q, "fl[]": ["identifier", "title", "licenseurl", "subject", "description", "year"], "rows": limite, "output": "json"})
    r.raise_for_status()
    out = []
    for d in (r.json().get("response") or {}).get("docs", []):
        lic = d.get("licenseurl", "")
        if "-nc" in lic or "-nd" in lic or "/by-sa/" in lic:
            continue
        ident = d["identifier"]
        sub = d.get("subject") or []
        sub = " ".join(sub) if isinstance(sub, list) else str(sub)
        desc = d.get("description") or ""
        desc = " ".join(desc) if isinstance(desc, list) else str(desc)
        out.append({"fonte": "Internet Archive", "tipo": "video", "preview": f"https://archive.org/services/img/{ident}",
                    "download": f"archive:{ident}", "titulo": d.get("title", ident) if isinstance(d.get("title"), str) else ident,
                    "texto_match": f"{d.get('title','')} {sub} {desc[:300]} {d.get('year','')}",
                    "licenca": "Domínio público" if "publicdomain" in lic else "CC BY", "autor": "",
                    "pagina": f"https://archive.org/details/{ident}"})
    return out


def archive_arquivo_video(ident):
    """Escolhe o .mp4 mais leve do item do Internet Archive."""
    r = requests.get(f"https://archive.org/metadata/{ident}", timeout=T, headers={"User-Agent": UA})
    r.raise_for_status()
    j = r.json()
    arqs = [f for f in j.get("files", []) if f.get("name", "").lower().endswith((".mp4", ".m4v", ".ogv", ".webm"))]
    if not arqs:
        raise RuntimeError("item sem vídeo")
    arqs.sort(key=lambda f: (0 if f["name"].lower().endswith(".mp4") else 1, int(f.get("size") or 1e12)))
    f = arqs[0]
    dur = 0.0
    try:
        dur = float(f.get("length") or 0)
    except ValueError:
        pass
    return f"https://archive.org/download/{ident}/{requests.utils.quote(f['name'])}", dur


# ---------------- NASA (domínio público) ----------------
def nasa(termo, limite=8):
    r = requests.get("https://images-api.nasa.gov/search", params={"q": termo, "media_type": "image,video", "page_size": limite},
                     timeout=T, headers={"User-Agent": UA})
    r.raise_for_status()
    out = []
    for it in ((r.json().get("collection") or {}).get("items") or [])[:limite]:
        d = (it.get("data") or [{}])[0]
        prev = ((it.get("links") or [{}])[0]).get("href", "")
        tipo = "video" if d.get("media_type") == "video" else "foto"
        out.append({"fonte": "NASA", "tipo": tipo, "preview": prev,
                    "download": f"nasa:{d.get('nasa_id')}" if tipo == "video" else prev.replace("~thumb", "~large"),
                    "titulo": d.get("title", ""), "texto_match": f"{d.get('title','')} {' '.join(d.get('keywords') or [])} {d.get('description','')[:300]}",
                    "licenca": "Domínio público (NASA)", "autor": d.get("center", ""), "pagina": f"https://images.nasa.gov/details/{d.get('nasa_id')}"})
    return out


def nasa_arquivo_video(nasa_id):
    r = requests.get(f"https://images-api.nasa.gov/asset/{nasa_id}", timeout=T, headers={"User-Agent": UA})
    r.raise_for_status()
    hrefs = [i["href"] for i in (r.json().get("collection") or {}).get("items", []) if i.get("href", "").endswith(".mp4")]
    for pref in ("~mobile.mp4", "~small.mp4", "~medium.mp4", "~orig.mp4"):
        for h in hrefs:
            if h.endswith(pref):
                return h.replace("http://", "https://")
    if hrefs:
        return hrefs[0].replace("http://", "https://")
    raise RuntimeError("NASA sem mp4")


# ---------------- Unsplash (fotos, licença Unsplash) ----------------
_UN_FORA = {"ate": 0}


def unsplash(termo, key, limite=10):
    import time as _t

    if not key or _UN_FORA["ate"] > _t.time():
        return []
    r = requests.get("https://api.unsplash.com/search/photos", params={"query": termo, "per_page": limite, "orientation": "landscape"},
                     headers={"Authorization": f"Client-ID {key}", "Accept-Version": "v1"}, timeout=T)
    if r.status_code in (401, 403, 429):
        # limite da hora acabou (chave grátis: 50 buscas/hora) ou chave recusada: descansa 1 hora e avisa uma vez só
        _UN_FORA["ate"] = _t.time() + 3600
        raise RuntimeError("Unsplash: limite de buscas da hora acabou (ou a chave foi recusada) — pausei o Unsplash por 1 hora; as outras fontes seguem")
    r.raise_for_status()
    out = []
    for p in r.json().get("results", []):
        u = p.get("urls") or {}
        out.append({"fonte": "Unsplash", "tipo": "foto", "preview": u.get("small"), "download": u.get("regular") or u.get("full"),
                    "titulo": p.get("alt_description") or p.get("description") or "", "texto_match": f"{p.get('alt_description','')} {p.get('description','')} {' '.join(t.get('title','') for t in (p.get('tags') or []))}",
                    "licenca": "Unsplash License", "autor": (p.get("user") or {}).get("name", ""), "pagina": (p.get("links") or {}).get("html", "")})
    return out
