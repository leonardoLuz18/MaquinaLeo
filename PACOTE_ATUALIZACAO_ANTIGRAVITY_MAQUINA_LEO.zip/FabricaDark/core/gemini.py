"""Gemini (Google AI Studio): texto, JSON, conferência de imagem, geração de imagem.

- Até 4 chaves, uma por vez; quando a de agora bate o limite do dia, passa para a próxima.
- Modelo automático: lê a lista de modelos que a SUA chave tem e escolhe o Flash mais novo
  (nas gratuitas, o Flash-Lite, que tem mais pedidos por dia).
- Custo: só chaves pagas contam; respeita o limite de gasto por vídeo (R$).
"""
import base64
import json
import re
import threading
import time

import requests

from core import chaves, storage
from core.storage import Tx

API = "https://generativelanguage.googleapis.com/v1beta"
MODO_INTELIGENCIA_PADRAO = "rapido"
CADEIA_MODELOS_RAPIDO_GRATUITA = (
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-2.0-flash",
    "gemini-flash-lite-latest",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
    "gemini-3.5-flash",
)
CADEIA_MODELOS_RAPIDO_PAGA = (
    "gemini-2.5-flash",
    "gemini-2.5-pro",
    "gemini-3.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-2.0-flash",
    "gemini-flash-lite-latest",
)
CADEIA_MODELOS_CARBON_HIGH = (
    "gemini-4-carbon",
    "gemini-2.5-pro",
    "gemini-3.1-pro-preview",
    "gemini-2.5-flash",
    "gemini-3.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-flash-lite-latest",
)
MODELOS_DESCONTINUADOS_404 = {
    "gemini-1.5-flash",
    "gemini-1.5-pro",
    "gemini-1.0-pro",
}
_MODELOS = {}  # cache: key -> lista de nomes
_GIRO = [0]  # rodízio: cada pedido começa por uma chave diferente (mesmo tipo)
_GIRO_LOCK = threading.Lock()
_ESFRIANDO = {}  # id da chave -> horário em que pode voltar (bateu o limite por minuto)
_MODELO_SEM_COTA = {}  # (id_chave, nome_modelo) -> horário em que pode tentar de novo após HTTP 429/503
_MODELO_INDISPONIVEL_404 = set(MODELOS_DESCONTINUADOS_404)
ULTIMO_MODELO_USADO = {
    "modelo": "gemini-3.5-flash-lite",
    "modo_inteligencia": MODO_INTELIGENCIA_PADRAO,
    "thinking_high": False,
    "ts": 0.0,
}


def _fila_rodizio(fila, settings):
    """Espalha os pedidos entre as chaves do mesmo tipo da primeira (ex.: todas as gratuitas),
    pulando as que bateram o limite por minuto há pouco."""
    if not fila:
        return fila
    if settings.get("gemini_paralelo", True):
        tipo = fila[0].get("tipo")
        grupo = [k for k in fila if k.get("tipo") == tipo]
        resto = [k for k in fila if k.get("tipo") != tipo]
        with _GIRO_LOCK:
            i = _GIRO[0] % len(grupo)
            _GIRO[0] += 1
        fila = grupo[i:] + grupo[:i] + resto
    agora = time.time()
    livres = [k for k in fila if _ESFRIANDO.get(k["id"], 0) <= agora]
    if not livres:  # todas esfriando: espera a primeira liberar
        espera = min(_ESFRIANDO.get(k["id"], 0) for k in fila) - agora
        time.sleep(max(0.5, min(espera, 15)))
        return fila
    return livres + [k for k in fila if k not in livres]


class LimiteGasto(RuntimeError):
    pass


def listar_modelos(key):
    if key in _MODELOS:
        return _MODELOS[key]
    r = requests.get(f"{API}/models", params={"key": key, "pageSize": 200}, timeout=15)
    if not r.ok:
        raise RuntimeError(_erro(r))
    nomes = [
        m["name"].replace("models/", "")
        for m in r.json().get("models", [])
        if "generateContent" in m.get("supportedGenerationMethods", [])
        and m["name"].replace("models/", "") not in _MODELO_INDISPONIVEL_404
    ]
    _MODELOS[key] = nomes
    return nomes


def _versao(nome):
    m = re.search(r"gemini-(\d+(?:\.\d+)?)", nome)
    return float(m.group(1)) if m else 0.0


def _eh_modo_carbon_high(modo_inteligencia=None, settings=None):
    """Só ativa o raciocínio pesado `Gemini 4 Carbon High` na API REST quando pedido estritamente
    (`carbon_high_estrito` ou `forcar_carbon_high_site=True`), mantendo o site ultra-rápido por padrão."""
    if (settings or {}).get("forcar_carbon_high_site") is True:
        return True
    m = str(modo_inteligencia or "").strip().lower()
    return m in ("carbon_high_estrito", "pro_estrito")


def escolher_modelo(key, tipo="gratuita", uso="texto", modo_inteligencia="rapido"):
    nomes = [n for n in listar_modelos(key) if n not in _MODELO_INDISPONIVEL_404]
    nomes_set = set(nomes)
    if uso == "imagem":
        cands = [n for n in nomes if "image" in n and "gemini" in n]
    elif _eh_modo_carbon_high(modo_inteligencia):
        preferidos = [m for m in CADEIA_MODELOS_CARBON_HIGH if m in nomes_set]
        if preferidos:
            return preferidos[0]
        ruim = ("tts", "image", "audio", "live", "embedding", "native", "computer", "robotics")
        cands = [n for n in nomes if n.startswith("gemini") and not any(b in n for b in ruim)]
    else:
        cadeia_pref = CADEIA_MODELOS_RAPIDO_PAGA if tipo == "paga" else CADEIA_MODELOS_RAPIDO_GRATUITA
        for m_fast in cadeia_pref:
            if m_fast in nomes_set:
                return m_fast
        ruim = ("tts", "image", "audio", "live", "embedding", "exp", "thinking", "native", "computer", "robotics")
        cands = [n for n in nomes if n.startswith("gemini") and "flash" in n and not any(b in n for b in ruim)]
    if not cands:
        cands = [n for n in nomes if n.startswith("gemini")] or nomes
    estaveis = [n for n in cands if "preview" not in n] or cands
    if uso != "imagem" and not _eh_modo_carbon_high(modo_inteligencia):
        lite = [n for n in estaveis if "lite" in n]
        normal = [n for n in estaveis if "lite" not in n]
        grupo = (lite or normal) if tipo != "paga" else (normal or lite)
    else:
        normal = [n for n in estaveis if "lite" not in n]
        lite = [n for n in estaveis if "lite" in n]
        grupo = normal or lite or estaveis
    grupo.sort(key=lambda n: (_versao(n), -len(n)), reverse=True)
    return grupo[0]


def _erro(r):
    try:
        return r.json()["error"]["message"]
    except Exception:
        return r.text[:300]


def _modelo_para(k, settings, uso, modo_inteligencia="rapido"):
    if uso == "imagem":
        return settings.get("gemini_img_modelo") or escolher_modelo(k["key"], k.get("tipo"), "imagem", modo_inteligencia=modo_inteligencia)
    if _eh_modo_carbon_high(modo_inteligencia, settings):
        return escolher_modelo(k["key"], k.get("tipo"), uso, modo_inteligencia="carbon_high_estrito")
    fixo = (settings.get("gemini_modelo_pagas" if k.get("tipo") == "paga" else "gemini_modelo_gratis", "") or "").strip()
    if fixo and fixo not in _MODELO_INDISPONIVEL_404:
        return fixo
    auto_salvo = (k.get("modelo_auto") or "").strip()
    if auto_salvo and auto_salvo not in _MODELO_INDISPONIVEL_404 and "carbon" not in auto_salvo and "pro" not in auto_salvo:
        return auto_salvo
    return escolher_modelo(k["key"], k.get("tipo"), "texto", modo_inteligencia=modo_inteligencia)


def _custo_brl(settings, tin, tout):
    usd = tin / 1e6 * float(settings.get("gemini_preco_in", 0.30)) + tout / 1e6 * float(settings.get("gemini_preco_out", 2.50))
    return usd * float(settings.get("dolar", 5.40))


def _suporta_thinking_high(modelo):
    m = (modelo or "").lower()
    if "lite" in m or "image" in m or "tts" in m:
        return False
    return m.startswith(("gemini-4", "gemini-3"))


def chamar(
    parts,
    video_id=None,
    json_out=False,
    uso="texto",
    max_tokens=16384,
    temperatura=0.7,
    ferramentas=None,
    modo_inteligencia="rapido",
    timeout_s=45,
):
    """Faz a chamada ultra-rápida com rodízio de chaves (Flash-Lite / Flash Turbo por padrão). Retorna (resposta_json, info)."""
    db = storage.load()
    s = db["settings"]
    usar_carbon_high = _eh_modo_carbon_high(modo_inteligencia, s)
    if not chaves.lista(db, "gemini"):
        default_key = s.get("gemini_key") or "AQ.Ab8RN6Ijcws11rfFDVTj-ZQQnQfi5rgpFq_eUXp-XJB73laTYQ"
        if default_key:
            try:
                chaves.adicionar("gemini", default_key, tipo="gratuita")
            except ValueError:
                pass
            db = storage.load()
        else:
            raise RuntimeError("Coloque uma chave do Gemini em Conexões (aistudio.google.com/apikey — é grátis).")
    fila = _fila_rodizio(chaves.ordem("gemini", db), s)
    if not fila:
        for x in chaves.lista(db, "gemini"):
            chaves.registrar("gemini", x["id"], esgotada=False)
        db = storage.load()
        fila = _fila_rodizio(chaves.ordem("gemini", db), s)
    if not fila:
        raise RuntimeError("Todas as chaves do Gemini bateram o limite de hoje (renova às 04:00 de Brasília).")
    limite = float(s.get("limite_gasto_video", 10) or 0)
    gasto = 0.0
    if video_id:
        v = storage.find(db["videos"], video_id) or {}
        gasto = float(v.get("custo_ia_brl", 0))
    ultimo = ""
    agora = time.time()
    for k in fila:
        if k.get("tipo") == "paga" and video_id and limite and gasto >= limite:
            ultimo = f"Limite de gasto do vídeo (R$ {limite:.2f}) atingido — só chaves gratuitas."
            continue
        try:
            modelo_principal = _modelo_para(k, s, uso, modo_inteligencia=modo_inteligencia)
        except Exception as e:
            ultimo = str(e)
            continue

        modelos_disponiveis_key = set(_MODELOS.get(k["key"]) or [])
        modelos_livres = []
        modelos_esfriando = []
        if uso == "imagem":
            modelos_livres = [modelo_principal]
        else:
            cadeia_base = (
                list(CADEIA_MODELOS_CARBON_HIGH) + [modelo_principal]
                if usar_carbon_high
                else [modelo_principal] + list(CADEIA_MODELOS_RAPIDO_PAGA if k.get("tipo") == "paga" else CADEIA_MODELOS_RAPIDO_GRATUITA)
            )
            vistos_m = set()
            for m_cand in cadeia_base:
                if not m_cand or m_cand in vistos_m or m_cand in _MODELO_INDISPONIVEL_404:
                    continue
                if modelos_disponiveis_key and m_cand not in modelos_disponiveis_key and not m_cand.endswith("-latest"):
                    continue
                vistos_m.add(m_cand)
                if _MODELO_SEM_COTA.get((k["id"], m_cand), 0) > agora:
                    modelos_esfriando.append(m_cand)
                else:
                    modelos_livres.append(m_cand)

        modelos_tentar = modelos_livres + modelos_esfriando
        if not modelos_tentar:
            modelos_tentar = [modelo_principal]

        timeout_efetivo = max(15, int(timeout_s or (90 if usar_carbon_high else 40)))
        for modelo in modelos_tentar:
            trocar_modelo = False
            usar_thinking_neste = bool(usar_carbon_high and uso != "imagem" and _suporta_thinking_high(modelo))
            for tentativa in range(2):
                cfg = {
                    "temperature": temperatura,
                    "maxOutputTokens": max(max_tokens, 8192) if usar_thinking_neste else max_tokens,
                }
                if json_out:
                    cfg["responseMimeType"] = "application/json"
                if usar_thinking_neste:
                    cfg["thinkingConfig"] = {"thinkingLevel": "HIGH"}
                if uso == "imagem":
                    cfg = {"responseModalities": ["IMAGE", "TEXT"]}
                body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": cfg}
                if ferramentas:
                    body["tools"] = ferramentas
                try:
                    r = requests.post(
                        f"{API}/models/{modelo}:generateContent",
                        params={"key": k["key"]},
                        json=body,
                        timeout=timeout_efetivo,
                    )
                except requests.RequestException as e_net:
                    ultimo = str(e_net)[:240]
                    _MODELO_SEM_COTA[(k["id"], modelo)] = time.time() + 120
                    trocar_modelo = True
                    break
                if r.status_code == 404:
                    ultimo = _erro(r)
                    _MODELO_INDISPONIVEL_404.add(modelo)
                    _MODELOS.pop(k["key"], None)
                    trocar_modelo = True
                    break
                if r.status_code == 429:
                    msg = _erro(r)
                    ultimo = msg
                    _MODELO_SEM_COTA[(k["id"], modelo)] = time.time() + 600
                    trocar_modelo = True
                    break
                if r.status_code >= 500:
                    ultimo = _erro(r)
                    if r.status_code == 503:
                        _MODELO_SEM_COTA[(k["id"], modelo)] = time.time() + 180
                        trocar_modelo = True
                        break
                    if tentativa < 1:
                        time.sleep(0.8)
                        continue
                    trocar_modelo = True
                    break
                if not r.ok:
                    msg = _erro(r)
                    ultimo = msg
                    if r.status_code in (400, 403) and "api key" in msg.lower():
                        chaves.atualizar("gemini", k["id"], status="invalida")
                        break
                    if r.status_code == 400 and usar_thinking_neste and ("thinking" in msg.lower() or "config" in msg.lower()):
                        usar_thinking_neste = False
                        continue
                    _MODELOS.pop(k["key"], None)
                    trocar_modelo = True
                    break
                j = r.json()
                um = j.get("usageMetadata", {})
                tin, tout = um.get("promptTokenCount", 0), um.get("candidatesTokenCount", 0) + um.get("thoughtsTokenCount", 0)
                custo = _custo_brl(s, tin, tout) if k.get("tipo") == "paga" else 0.0
                chaves.registrar("gemini", k["id"], usos=1)
                chaves.consumo_add("gemini", "geral", chamadas=1, tokens_in=tin, tokens_out=tout, custo_brl=custo)
                if video_id and custo:
                    with Tx() as db2:
                        v2 = storage.find(db2["videos"], video_id)
                        if v2 is not None:
                            v2["custo_ia_brl"] = round(float(v2.get("custo_ia_brl", 0)) + custo, 4)
                modo_label = "gemini_4_carbon_high" if usar_carbon_high else "rapido"
                ULTIMO_MODELO_USADO.update({
                    "modelo": modelo,
                    "modo_inteligencia": modo_label,
                    "thinking_high": usar_thinking_neste,
                    "ts": time.time(),
                })
                return j, {
                    "modelo": modelo,
                    "modo_inteligencia": modo_label,
                    "thinking_high": usar_thinking_neste,
                    "chave": k["id"],
                    "tipo": k.get("tipo"),
                    "custo_brl": custo,
                }
            if not trocar_modelo:
                break
    raise RuntimeError(f"Gemini indisponível: {ultimo}")


def _texto(j):
    try:
        partes = j["candidates"][0]["content"]["parts"]
    except (KeyError, IndexError):
        motivo = (j.get("promptFeedback") or {}).get("blockReason") or (j.get("candidates") or [{}])[0].get("finishReason", "")
        raise RuntimeError(f"O Gemini não respondeu ({motivo or 'resposta vazia'}).")
    txt = "".join(p.get("text", "") for p in partes if not p.get("thought"))
    if not txt:
        txt = "".join(p.get("text", "") for p in partes)
    return txt


def gerar_texto(prompt, video_id=None, modo_inteligencia="rapido", sistema="", temperatura=0.7, temp=None, max_tokens=16384, timeout_s=45, **kwargs):
    prompt_final = f"{sistema}\n\n{prompt}" if sistema else prompt
    temp_val = float(temp if temp is not None else temperatura)
    max_tok_val = int(max_tokens or 16384)
    try:
        j, _ = chamar(
            [{"text": prompt_final}],
            video_id,
            max_tokens=max_tok_val,
            temperatura=temp_val,
            modo_inteligencia=modo_inteligencia,
            timeout_s=timeout_s,
        )
        return _texto(j).strip()
    except Exception as e_gem:
        try:
            from core import antigravity_codex

            txt_fb, _prov_fb = antigravity_codex.gerar_texto_fallback_cascata(
                prompt,
                sistema=sistema,
                max_tokens=max_tok_val,
                temperatura=temp_val,
                json_mode=False,
                timeout=max(120, int(timeout_s or 45) * 3),
            )
            if txt_fb and txt_fb.strip():
                return txt_fb.strip()
        except Exception:
            pass
        raise e_gem


def gerar_json(prompt, video_id=None, modo_inteligencia="rapido", timeout_s=45, sistema="", temperatura=0.35, temp=None, max_tokens=8192, **kwargs):
    from core.prompts import parse_json

    prompt_final = f"{sistema}\n\n{prompt}" if sistema else prompt
    temp_val = float(temp if temp is not None else temperatura)
    max_tok_val = int(max_tokens or 8192)
    try:
        j, _ = chamar(
            [{"text": prompt_final}],
            video_id,
            json_out=True,
            max_tokens=max_tok_val,
            temperatura=temp_val,
            modo_inteligencia=modo_inteligencia,
            timeout_s=timeout_s,
        )
        return parse_json(_texto(j))
    except Exception as e_gem:
        try:
            from core import antigravity_codex

            txt_fb, _prov_fb = antigravity_codex.gerar_texto_fallback_cascata(
                prompt,
                sistema=sistema,
                max_tokens=max_tok_val,
                temperatura=temp_val,
                json_mode=True,
                timeout=max(120, int(timeout_s or 45) * 3),
            )
            if txt_fb and txt_fb.strip():
                return parse_json(txt_fb)
        except Exception:
            pass
        raise e_gem


def conferir_midia(img_bytes, mime, cena, video_id=None, contexto_ok=False, modo_inteligencia="rapido"):
    """Análise visual rápida e rigorosa (Gemini Flash Turbo) para decidir se a foto ou vídeo serve para a cena."""
    canal_ctx = str(cena.get("canal_nome") or "").strip()
    assunto_ctx = str(cena.get("assunto_video") or "").strip()
    eh_gta_gaming = any(k in f"{canal_ctx} {assunto_ctx} {cena.get('texto','')}".lower() for k in ("gta", "grand theft auto", "rockstar", "vice city", "leonida", "liberty city", "los santos"))
    regra_nicho = (
        "\nCONTEXTO GAMER / GTA (GTA à la Une / Grand Theft Auto): Aceite capturas/cenas cinematográficas autênticas do universo GTA / Rockstar Games "
        "(Vice City, Leonida, Liberty City, GTA IV, GTA V, GTA VI) OU filmagens reais urbanas coerentes (Miami/Flórida neon, Nova York/Liberty City, carros esportivos, perseguição noturna) quando servirem de comparação visual. "
        "Reprove imediatamente facecam de streamer/youtuber no canto, HUD poluído de outros jogos (Minecraft, Roblox, Fortnite, RPG medieval) ou thumbnails com letras gigantes de outros canais.\n"
        if eh_gta_gaming
        else ""
    )
    regra_ctx = (
        "\nIMPORTANTE: esta é a miniatura/frame de um VÍDEO de apoio (b-roll). Aceite (serve=true) se for uma imagem de CONTEXTO coerente "
        "com o assunto — mesma região, paisagem, cidade, rio, estrada, época ou atividade — mesmo que não mostre exatamente o fato narrado. "
        "Reprove só se for de outro lugar/época claramente diferente, pessoa falando para a câmera, marca d'água/texto grande na tela ou qualidade ruim.\n"
    ) if contexto_ok else ""
    prompt = f"""Você é o Diretor de Fotografia e Verificação Visual. Analise a imagem/frame real com rigor editorial e decida se ela serve para esta cena.{regra_ctx}{regra_nicho}
CANAL / PROJETO: {canal_ctx or '(documentário)'} — {assunto_ctx}
NARRAÇÃO DA CENA: {cena.get('texto','')}
PLANO DESEJADO: {cena.get('descricao_visual','')}
PESSOA REAL ESPERADA: {cena.get('pessoa_real') or '(nenhuma)'}

Reprove se: mostra a pessoa/lugar/época/jogo errados (entidade_errada); é alguém falando para a câmera, entrevista, streamer ou apresentador (pessoa_falando);
tem texto/legenda/logo/marca d'água grande gravado na imagem (texto_gravado); qualidade muito baixa, borrada ou vertical com barras (baixa_qualidade); não tem relação (sem_relacao).
REPROVE TAMBÉM (nota no máximo 2): logotipo de marca ou empresa em destaque (PayPal, bancos, apps, redes sociais) se a narração não fala dessa marca
(texto_gravado); placa de nome, crachá ou legenda que identifica uma pessoa real que a narração NÃO cita — ex.: políticos numa sessão qualquer
(entidade_errada); apresentador ou vídeo institucional falando outro idioma (pessoa_falando); tela de código de programação ou interface de
software genérica (sem_relacao); infográfico vazio, tela quase toda branca ou estourada (baixa_qualidade); mapa-múndi ou continente inteiro quando
a cena fala de um lugar específico (entidade_errada).
Responda SOMENTE JSON: {{"serve": true, "nota": 0, "na_imagem": "descrição curta e precisa do que aparece", "motivo": "ok|entidade_errada|pessoa_falando|texto_gravado|baixa_qualidade|sem_relacao", "detalhe": "frase curta"}}"""
    parts = [{"inline_data": {"mime_type": mime, "data": base64.b64encode(img_bytes).decode()}}, {"text": prompt}]
    j, info = chamar(parts, video_id, json_out=True, uso="verificacao", max_tokens=800, temperatura=0.1, modo_inteligencia=modo_inteligencia, timeout_s=35)
    from core.prompts import parse_json

    d = parse_json(_texto(j))
    d["serve"] = bool(d.get("serve"))
    d["modelo_ia"] = info.get("modelo")
    d["modo_inteligencia"] = info.get("modo_inteligencia")
    return d


def conferir_lote(itens, cena, video_id=None, modo_inteligencia="rapido"):
    """Confere várias mídias reais numa chamada só com Gemini Flash Turbo.
    itens: [(img_bytes, mime, rotulo, eh_video)].
    Devolve {"resultados": [{"i", "serve", "nota", "na_imagem", "motivo"}], "melhor": i ou 0, "modelo_ia": ...}."""
    parts = []
    for i, (dados, mime, rotulo, eh_video) in enumerate(itens, 1):
        parts.append({"text": f"IMAGEM {i} — {'miniatura/frame de VÍDEO REAL (b-roll)' if eh_video else 'FOTO REAL'} · {rotulo}"})
        parts.append({"inline_data": {"mime_type": mime, "data": base64.b64encode(dados).decode()}})
    assunto = str(cena.get("assunto_video") or "").strip()
    canal_ctx = str(cena.get("canal_nome") or "").strip()
    if video_id and not assunto:
        try:
            assunto = (storage.find(storage.load()["videos"], video_id) or {}).get("titulo", "")
        except Exception:
            pass
    eh_gta_gaming = any(k in f"{canal_ctx} {assunto} {cena.get('texto','')} {cena.get('trecho','')}".lower() for k in ("gta", "grand theft auto", "rockstar", "vice city", "leonida", "liberty city", "los santos"))
    bloco_gta = (
        "\nREGRA ESPECIAL CANAL GTA À LA UNE (100% JOGOS GTA — PADRÃO MANO. / ROCKSTAR MAG' / ROU): "
        "Aprove com nota alta (8 a 10) exclusivamente gameplay, trailers, cutscenes e capturas in-game limpas dos JOGOS Grand Theft Auto "
        "(GTA VI Vice City/Leonida, GTA V Los Santos, GTA IV Liberty City, San Andreas, Vice City, motor RAGE/Euphoria da Rockstar Games). "
        "Reprove (serve=false, nota <= 2) vídeos stock genéricos do mundo real sem relação direta com o jogo GTA, outros jogos (Minecraft, Roblox, Fortnite, Cyberpunk), "
        "facecam de youtubers/streamers falando e miniaturas poluídas com textos gigantes/setas.\n"
        if eh_gta_gaming
        else ""
    )
    parts.append({"text": f"""Você é um Editor-Chefe EXIGENTE de documentários. Acima há {len(itens)} mídias candidatas para UMA cena. Avalie cada uma com rigor.{bloco_gta}
CANAL: {canal_ctx or '(documentário)'}
ASSUNTO DO VÍDEO: {assunto}
NARRAÇÃO DA CENA: {cena.get('texto','') or cena.get('trecho','')}
PLANO DESEJADO: {cena.get('descricao_visual','') or cena.get('o_que_mostrar','')}
PESSOA REAL ESPERADA: {cena.get('pessoa_real') or '(nenhuma)'}

"nota" = o quanto a imagem/vídeo combina com ESTA narração e com o assunto do vídeo (0 a 10). Um espectador precisa olhar e achar 100% coerente e inédito.
Regras: FOTO só serve se mostra o que a cena diz (pessoa/lugar/época/objeto certos).
Miniatura/frame de VÍDEO pode ser CONTEXTO, mas só se for claramente do mesmo tema: ex. política → Congresso, Brasília, urnas, eleitores, autoridades;
economia → dinheiro, bolsa, gráficos, comércio, dólar; história de um estado → paisagens/cidades daquele lugar; GTA/gaming → 100% cenas dos jogos GTA (GTA VI, GTA V, GTA IV, Vice City, Los Santos, Liberty City, motor RAGE) sem facecam.
REPROVE SEMPRE (serve=false): animais soltos sem relação, pessoas comuns em casa, objetos aleatórios, natureza genérica ou qualquer coisa que não tenha ligação
direta com o assunto (sem_relacao); pessoa/lugar/época/jogo errados (entidade_errada); alguém falando para a câmera (pessoa_falando);
texto/logo/marca d'água grande gravado (texto_gravado); imagem escura, borrada ou de baixa qualidade (baixa_qualidade). Na dúvida, reprove.
REPROVE TAMBÉM (nota no máximo 3): youtuber, podcaster, streamer ou comentarista de outro canal falando (pessoa_falando); miniatura/arte de outro canal
com chamada em letras grandes tipo "URGENTE", setas e montagem (texto_gravado); vídeo em pé de celular/shorts com faixas laterais (baixa_qualidade);
estúdio virtual, tela verde ou chroma key vazio (sem_relacao); print de site ou de rede social (texto_gravado).
REPROVE TAMBÉM (nota no máximo 2): logotipo de marca ou empresa em destaque (PayPal, bancos, apps, redes sociais) se a narração não fala dessa marca
(texto_gravado); placa de nome, crachá ou legenda que identifica uma pessoa real que a narração NÃO cita — ex.: políticos numa sessão qualquer
(entidade_errada); apresentador ou vídeo institucional falando outro idioma (pessoa_falando); tela de código de programação ou interface de
software genérica (sem_relacao); infográfico vazio, tela quase toda branca ou estourada (baixa_qualidade); mapa-múndi ou continente inteiro quando
a cena fala de um lugar específico (entidade_errada).
IMAGEM GENÉRICA (nota no máximo 4, sem_relacao): céu, nuvens, paisagem, montanha, lago, corredor, silhueta, pessoas aleatórias andando,
prédio qualquer ou cidade de OUTRO lugar — a menos que a narração fale exatamente disso. Lugar de outro país/cidade é entidade_errada.
Em "melhor" diga o número da que mais combina entre as que servem (prefira vídeo quando empatar); 0 se nenhuma serve.
Responda SOMENTE JSON: {{"resultados": [{{"i": 1, "serve": true, "nota": 0, "na_imagem": "descrição curta", "motivo": "ok|entidade_errada|pessoa_falando|texto_gravado|baixa_qualidade|sem_relacao"}}], "melhor": 1}}"""})
    j, info = chamar(parts, video_id, json_out=True, uso="verificacao", max_tokens=2000, temperatura=0.1, modo_inteligencia=modo_inteligencia, timeout_s=40)
    from core.prompts import parse_json

    d = parse_json(_texto(j))
    if isinstance(d, list):
        d = {"resultados": d, "melhor": 0}
    res = []
    for x in d.get("resultados") or []:
        try:
            res.append(dict(x, i=int(x.get("i")), serve=bool(x.get("serve"))))
        except (TypeError, ValueError):
            pass
    try:
        melhor = int(d.get("melhor") or 0)
    except (TypeError, ValueError):
        melhor = 0
    return {
        "resultados": res,
        "melhor": melhor,
        "modelo_ia": info.get("modelo"),
        "modo_inteligencia": info.get("modo_inteligencia"),
    }


def gerar_imagem(prompt, video_id=None):
    j, info = chamar([{"text": prompt}], video_id, uso="imagem")
    for p in j.get("candidates", [{}])[0].get("content", {}).get("parts", []):
        inl = p.get("inlineData") or p.get("inline_data")
        if inl and inl.get("data"):
            return base64.b64decode(inl["data"]), inl.get("mimeType", "image/png")
    raise RuntimeError("O modelo de imagem do Gemini não devolveu imagem (a chave gratuita pode não ter acesso).")


def testar(kid):
    k = chaves.pegar("gemini", kid)
    try:
        _MODELOS.pop(k["key"], None)
        modelo = escolher_modelo(k["key"], k.get("tipo"), "texto")
        r = requests.post(f"{API}/models/{modelo}:generateContent", params={"key": k["key"]},
                          json={"contents": [{"parts": [{"text": "Responda só: ok"}]}], "generationConfig": {"maxOutputTokens": 20}}, timeout=40)
        if r.status_code == 429:
            chaves.atualizar("gemini", kid, status="ok", modelo_auto=modelo, testada_em=time.strftime("%d/%m/%Y %H:%M"), erro="limite de hoje atingido")
            return True, f"Chave válida ({modelo}), mas bateu o limite agora."
        if not r.ok:
            raise RuntimeError(_erro(r))
        chaves.atualizar("gemini", kid, status="ok", modelo_auto=modelo, testada_em=time.strftime("%d/%m/%Y %H:%M"), erro="")
        return True, modelo
    except Exception as e:
        chaves.atualizar("gemini", kid, status="invalida", testada_em=time.strftime("%d/%m/%Y %H:%M"), erro=str(e)[:200])
        return False, str(e)


def primeira_chave():
    f = chaves.ordem("gemini")
    if f:
        return f[0]["key"]
    s = storage.load()["settings"]
    return s.get("gemini_key", "")


def estimativa(db=None):
    """Quantas buscas de vídeo por dia as chaves gratuitas aguentam."""
    db = db or storage.load()
    gratis = [x for x in chaves.lista(db, "gemini") if x.get("tipo") != "paga"]
    vids = [v for v in db["videos"] if v.get("chamadas_ia")]
    media = (sum(v["chamadas_ia"] for v in vids) / len(vids)) if vids else 200
    por_chave = 500 / max(1, media)
    return {"chamadas_por_video": round(media), "videos_por_dia_por_chave": round(por_chave, 1), "gratuitas": len(gratis), "videos_por_dia": round(por_chave * len(gratis), 1)}
