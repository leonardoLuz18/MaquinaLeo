# -*- coding: utf-8 -*-
"""Motor dedicado do canal `GTA à la Une` (fr-FR):
1. Coleta notícias reais em francês sobre Grand Theft Auto / Rockstar Games (GTA IV & GTA VI Novembro);
2. Extrai vídeos (.mp4) e capturas oficiais diretamente de `https://www.rockstargames.com` (`/fr/VI`, `/VI`, `/fr/newswire`)
   e do canal oficial `@RockstarGames` + gameplays/trailers de GTA IV, GTA V e GTA VI via `yt-dlp`;
3. Aplica blindagem Fair-Use / Anti-Copyright em `ffmpeg` em TODOS os cortes:
   - Micro-cortes transformativos curtos (3.8s a 5.8s, nunca trechos longos contínuos);
   - 0% áudio original (`-an`: remove músicas de rádio/trilha sonora com Content ID);
   - Zoom/enquadramento assimétrico dinâmico + Ken Burns em capturas oficiais;
   - Máscara óptica (vignette + matte cinematográfico + barra neon GTA + grão sutil + color grading + fade in/out).
"""

import concurrent.futures
import hashlib
import html
import os
import re
import subprocess
import tempfile
import threading
import time
import xml.etree.ElementTree as ET

import requests

CANAL_GTA_A_LA_UNE_ID = "a8068857-d56f-4aba-baf3-ea2b7ebda5bb"

_LOCK_GTA_CACHE = threading.Lock()
_CACHE_NOTICIAS_FR = {"ts": 0.0, "itens": []}
_CACHE_ACERVO_ROCKSTAR = {"ts": 0.0, "videos_web": [], "fotos_web": [], "yt_entries": []}
_CACHE_STREAM_YT = {}  # video_id -> {"ts": float, "url": str, "dur": float, "title": str}

HEADERS_PADRAO = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.7,en;q=0.6",
}


def eh_canal_ou_projeto_gta(canal_id="", canal_nome="", titulo=""):
    """Identifica se o canal ou projeto pertence ao canal francês `GTA à la Une`."""
    cid = str(canal_id or "").strip().lower()
    cnome = str(canal_nome or "").strip().lower()
    tit = str(titulo or "").strip().lower()
    if cid == CANAL_GTA_A_LA_UNE_ID:
        return True
    if "gta à la une" in cnome or "gta a la une" in cnome or "@gta" in cnome:
        return True
    if "gta" in cnome and ("une" in cnome or "fr" in cnome or "rockstar" in cnome):
        return True
    # Caso o canal_nome não tenha vindo preenchido mas o título seja claramente GTA em francês
    if not cnome and any(k in tit for k in ("gta vi", "gta 6", "gta iv", "gta 4", "gta 5", "gta v", "rockstar games", "vice city", "liberty city", "los santos")):
        if any(fr_w in tit for fr_w in ("détails", "details", "novembre", "cachés", "joueurs", "sortie", "secret", "pourquoi", "limite", "technologie", "savoir", "était")):
            return True
    return False


# Alias retrocompatível usado pelo pipeline do Studio e do monitor da Etapa 7
eh_canal_gta_a_la_une = eh_canal_ou_projeto_gta

REFERENCIAS_OFICIAIS_GTA_A_LA_UNE = [
    {
        "id": "ref_gta_mano_8gd39qlktyy",
        "canal_id": CANAL_GTA_A_LA_UNE_ID,
        "nome_canal": "Mano. (@mano_gta)",
        "canal": "Mano.",
        "handle": "@mano_gta",
        "video_id": "8GD39QLKtyY",
        "url": "https://www.youtube.com/watch?v=8GD39QLKtyY&t=50s",
        "url_canal": "https://www.youtube.com/watch?v=8GD39QLKtyY&t=50s",
        "foto_url": "https://i.ytimg.com/vi/8GD39QLKtyY/hqdefault.jpg",
        "nicho": "Essai Gaming 100% GTA 6 (FR)",
        "titulo": "Le jeu vidéo a atteint sa limite avec GTA 6",
        "foco": "Ensaio documental gamer em francês sobre o impacto histórico de GTA 6, limites técnicos da Rockstar Games, orçamento, IA e comparativos 100% visuais de GTA.",
        "anotacoes": "Referência Oficial #1 GTA à la Une (https://www.youtube.com/watch?v=8GD39QLKtyY&t=50s): 'Le jeu vidéo a atteint sa limite avec GTA 6' — gancho magnético nos primeiros 50s, análise profunda de impacto e 100% imagens/vídeos dos jogos GTA.",
    },
    {
        "id": "ref_gta_rockstar_mag_dpspfyoef8",
        "canal_id": CANAL_GTA_A_LA_UNE_ID,
        "nome_canal": "Rockstar Mag' (@RockstarmagFr)",
        "canal": "Rockstar Mag'",
        "handle": "@RockstarmagFr",
        "video_id": "dPSpuFYoEF8",
        "url": "https://www.youtube.com/watch?v=dPSpuFYoEF8",
        "url_canal": "https://www.youtube.com/watch?v=dPSpuFYoEF8",
        "foto_url": "https://i.ytimg.com/vi/dPSpuFYoEF8/hqdefault.jpg",
        "nicho": "Dossier 100% Jeux GTA (FR)",
        "titulo": "VOILÀ, C'ÉTAIT GTA V.",
        "foco": "100% focado diretamente nos jogos da franquia Grand Theft Auto (GTA V, GTA VI, GTA IV, San Andreas, Vice City) — gameplay puro, missões, mapa e legado in-game.",
        "anotacoes": "Referência Oficial #2 GTA à la Une (https://www.youtube.com/watch?v=dPSpuFYoEF8): 'VOILÀ, C'ÉTAIT GTA V.' — foco 100% no jogo GTA (gameplay, missões, mapa de Los Santos/Vice City/Liberty City e legado Rockstar).",
    },
    {
        "id": "ref_gta_rou_i_bj61boudo",
        "canal_id": CANAL_GTA_A_LA_UNE_ID,
        "nome_canal": "Rou (@rou.shorts)",
        "canal": "Rou",
        "handle": "@rou.shorts",
        "video_id": "I-bJ61bouDo",
        "url": "https://www.youtube.com/watch?v=I-bJ61bouDo",
        "url_canal": "https://www.youtube.com/watch?v=I-bJ61bouDo",
        "foto_url": "https://i.ytimg.com/vi/I-bJ61bouDo/hqdefault.jpg",
        "nicho": "Technologie Moteur RAGE & GTA 6 (FR)",
        "titulo": "L'incroyable technologie derrière GTA 6",
        "foco": "Análise técnica dinâmica do motor RAGE da Rockstar, +600.000 animações, física Euphoria, iluminação ray-tracing, deformação de terreno e comparativos GTA V vs GTA 6.",
        "anotacoes": "Referência Oficial #3 GTA à la Une (https://www.youtube.com/watch?v=I-bJ61bouDo): 'L'incroyable technologie derrière GTA 6' — breakdown visual do motor RAGE 9, 600.000+ animações, física Euphoria, ray-tracing e comparativos GTA 5 vs GTA 6.",
    },
    {
        "id": "ref_gta_vico_g3adrien_fr",
        "canal_id": CANAL_GTA_A_LA_UNE_ID,
        "nome_canal": "Vico GTA & G3ADRIEN OFF",
        "canal": "Vico GTA & G3ADRIEN OFF",
        "handle": "@VicoGTA / @G3ADRIENOFF",
        "video_id": "",
        "url": "https://www.youtube.com/results?search_query=Vico+GTA+G3ADRIEN+OFF+GTA+6",
        "url_canal": "https://www.youtube.com/results?search_query=Vico+GTA+G3ADRIEN+OFF+GTA+6",
        "foto_url": "",
        "nicho": "Packaging Viral & Comparatifs GTA 5 vs GTA 6 (FR)",
        "titulo": "Tout ce qu'il faut savoir avant de jouer à GTA 6 / GTA 6 vs GTA 5",
        "foco": "Thumbnails vibrantes de altíssimo CTR e títulos diretos em francês focados 100% em segredos, mecânicas inéditas e comparativos GTA 5 vs GTA 6.",
        "anotacoes": "Referência Oficial #4 GTA à la Une: Packaging viral francófono ('GTA 6 sort dans 10 jours : tout ce qu'il faut savoir avant de jouer', 'GTA 6 fait des choses qu'on n'aurait JAMAIS imaginées dans GTA 5 !'). Disco D: e outros bancos somente em último caso para apoio.",
    },
]



def buscar_noticias_gta_frances_ao_vivo(limite=8, usar_cache=True):
    """Busca as últimas notícias reais em francês sobre GTA VI, GTA IV e Rockstar Games
    (Google Actualités FR + Rockstar Games Newswire FR) com cache rápido de 20 minutos."""
    agora = time.time()
    with _LOCK_GTA_CACHE:
        if usar_cache and _CACHE_NOTICIAS_FR["itens"] and (agora - _CACHE_NOTICIAS_FR["ts"] < 1200):
            return list(_CACHE_NOTICIAS_FR["itens"][:limite])

    noticias = []
    vistos = set()

    urls_rss = [
        "https://news.google.com/rss/search?q=Rockstar+Games+GTA+VI+OR+GTA+6+OR+GTA+IV&hl=fr&gl=FR&ceid=FR:fr",
        "https://news.google.com/rss/search?q=%22Grand+Theft+Auto%22+Rockstar&hl=fr&gl=FR&ceid=FR:fr",
    ]
    for u_rss in urls_rss:
        try:
            r = requests.get(u_rss, headers=HEADERS_PADRAO, timeout=5)
            if not r.ok or not r.text:
                continue
            root = ET.fromstring(r.content)
            for item in root.findall(".//item"):
                tit = html.unescape((item.findtext("title") or "").strip())
                pub = (item.findtext("pubDate") or "").strip()
                lnk = (item.findtext("link") or "").strip()
                src_el = item.find("source")
                fonte = (src_el.text if src_el is not None and src_el.text else "Actualités GTA FR").strip()
                if not tit or len(tit) < 15:
                    continue
                ch_t = re.sub(r"\W+", "", tit.lower())[:48]
                if ch_t in vistos:
                    continue
                vistos.add(ch_t)
                noticias.append({
                    "titulo": tit,
                    "fonte": fonte,
                    "data": pub[:25],
                    "url": lnk,
                })
                if len(noticias) >= max(12, limite):
                    break
        except Exception:
            continue

    with _LOCK_GTA_CACHE:
        if noticias:
            _CACHE_NOTICIAS_FR["ts"] = agora
            _CACHE_NOTICIAS_FR["itens"] = noticias
    return noticias[:limite]


def formatar_bloco_noticias_gta_fr_prompt(limite=6):
    """Retorna um resumo enxuto em francês das últimas notícias reais da Rockstar / GTA para enriquecer roteiros."""
    itens = buscar_noticias_gta_frances_ao_vivo(limite=limite, usar_cache=True)
    if not itens:
        return ""
    linhas = [
        "ACTUALITÉS RÉCENTES VÉRIFIÉES (ROCKSTAR GAMES / PRESSE FRANCOPHONE — À UTILISER COMME CONTEXTE FACTUEL SANS COPIER MOT À MOT) :"
    ]
    for i, n in enumerate(itens[:limite], 1):
        linhas.append(f"  {i}. [{n.get('fonte')}] {n.get('titulo')} ({n.get('data')})")
    return "\n".join(linhas)


def _raspar_midias_site_rockstar():
    """Extrai os vídeos oficiais (.mp4 in-engine) e capturas HD (.jpg) diretamente de
    `https://www.rockstargames.com/fr/VI` e `https://www.rockstargames.com/VI`."""
    agora = time.time()
    with _LOCK_GTA_CACHE:
        if _CACHE_ACERVO_ROCKSTAR["videos_web"] and (agora - _CACHE_ACERVO_ROCKSTAR["ts"] < 1800):
            return (
                list(_CACHE_ACERVO_ROCKSTAR["videos_web"]),
                list(_CACHE_ACERVO_ROCKSTAR["fotos_web"]),
            )

    videos_web = []
    fotos_web = []
    vistos_v = set()
    vistos_f = set()

    for url_pag in ("https://www.rockstargames.com/fr/VI", "https://www.rockstargames.com/VI"):
        try:
            r = requests.get(url_pag, headers=HEADERS_PADRAO, timeout=8)
            if not r.ok or not r.text:
                continue
            txt = r.text
            # Prioriza 1920_hvec / 1280_hvec (FFmpeg converte direto para H.264 720p com máscara)
            rels_mp4 = sorted(set(re.findall(r'(/VI/_next/static/media/[^\s"\'<>]+?\.mp4)', txt)))
            # Ordena colocando 1280_hvec e 1920_hvec primeiro
            rels_mp4.sort(key=lambda p: (0 if "1280_hvec" in p else (1 if "1920_hvec" in p else 2), p))
            # Evita pegar a mesma cena duas vezes em resoluções diferentes (usa o hash base após o ponto)
            cenas_base_mp4 = set()
            for rel in rels_mp4:
                m_hash = re.search(r"\.([a-zA-Z0-9_~-]+)\.mp4$", rel)
                base_id = m_hash.group(1)[:8] if m_hash else rel
                # Agrupa 1280_av1 vs 1280_hvec pelo índice sequencial ou evita av1 se já houver hvec
                if "av1." in rel and any("hvec." in x for x in rels_mp4):
                    continue
                if rel in vistos_v or base_id in cenas_base_mp4:
                    continue
                vistos_v.add(rel)
                cenas_base_mp4.add(base_id)
                u_full = "https://www.rockstargames.com" + rel
                videos_web.append({
                    "id_unico": f"rockstar_web_mp4:{os.path.basename(rel)}",
                    "tipo": "video",
                    "fonte": "Rockstar Games Official (rockstargames.com/fr/VI)",
                    "tier": "Tier 1 (Rockstar Games Official Motion)",
                    "banco_id": "youtube",
                    "url": u_full,
                    "download": u_full,
                    "preview": u_full,
                    "gta_oficial": True,
                    "modo_gta": "rockstar_mp4",
                    "titulo": f"Rockstar Games GTA VI Official Scene ({len(videos_web) + 1})",
                    "palavras_chave": ["gta", "vi", "vice", "city", "leonida", "rockstar", "gameplay", "trailer"],
                })

            rels_jpg = sorted(set(re.findall(r'(/VI/_next/static/media/[^\s"\'<>]+?\.(?:jpg|jpeg|png|webp))', txt)))
            for rel_i in rels_jpg:
                bn_l = os.path.basename(rel_i).lower()
                # Ignora capas verticais mobile e logos pequenos
                if any(k in bn_l for k in ("mobile", "fob_", "logo", "rating", "pegi", "esrb", "icon")):
                    continue
                if rel_i in vistos_f:
                    continue
                vistos_f.add(rel_i)
                u_img = "https://www.rockstargames.com" + rel_i
                fotos_web.append({
                    "id_unico": f"rockstar_web_img:{os.path.basename(rel_i)}",
                    "tipo": "video",  # Será convertida em clipe .MP4 5s com Ken Burns + Máscara Anti-Copyright!
                    "fonte": "Rockstar Games Official High-Res Capture (rockstargames.com)",
                    "tier": "Tier 1 (Rockstar Official Capture -> Motion MP4)",
                    "banco_id": "youtube",
                    "url": u_img,
                    "download": u_img,
                    "preview": u_img,
                    "gta_oficial": True,
                    "modo_gta": "rockstar_img_motion",
                    "titulo": f"Rockstar Games GTA Official Capture ({len(fotos_web) + 1})",
                    "palavras_chave": ["gta", "rockstar", "vice", "city", "leonida", "novembre", "capture"],
                })
        except Exception:
            continue

    with _LOCK_GTA_CACHE:
        if videos_web or fotos_web:
            _CACHE_ACERVO_ROCKSTAR["ts"] = agora
            _CACHE_ACERVO_ROCKSTAR["videos_web"] = videos_web
            _CACHE_ACERVO_ROCKSTAR["fotos_web"] = fotos_web

    return videos_web, fotos_web


def _extrair_tags_jogo_gta(texto=""):
    """Classifica a qual jogo/tema da franquia GTA o vídeo ou trecho pertence para casamento contextual 1:1."""
    t = str(texto or "").lower()
    tags = {"gta", "rockstar"}
    if any(k in t for k in ("gta vi", "gta 6", "gtavi", "gta6", "leonida", "lucia", "jason", "extended look")):
        tags.update(("gta6", "vice_city", "leonida"))
    if any(k in t for k in ("gta v", "gta 5", "gtav", "gta5", "los santos", "michael", "trevor", "franklin", "gta online")):
        tags.update(("gta5", "los_santos"))
    if any(k in t for k in ("gta iv", "gta 4", "gtaiv", "gta4", "liberty city", "niko", "bellic", "euphoria")):
        tags.update(("gta4", "liberty_city", "euphoria"))
    if any(k in t for k in ("san andreas", "cj", "carl johnson", "grove street")):
        tags.update(("gtasa", "san_andreas"))
    if "vice city" in t or "tommy vercetti" in t:
        tags.add("vice_city")
    if any(k in t for k in ("rage", "engine", "moteur", "physics", "physique", "animation", "graphics", "graphisme", "comparison", "vs")):
        tags.update(("rage_engine", "tech"))
    if any(k in t for k in ("police", "flic", "wanted", "chase", "poursuite", "cops", "étoiles", "stars")):
        tags.add("police")
    if any(k in t for k in ("car", "voiture", "vehicle", "véhicule", "drift", "driving", "conduite", "traffic", "moto")):
        tags.add("vehicles")
    return sorted(tags)


def pontuar_candidato_gta_para_texto(cand, texto_cena=""):
    """Pontua um candidato 100% GTA em relação ao trecho em francês do SRT (estilo Mano., Rockstar Mag' e Rou)."""
    if not isinstance(cand, dict):
        return 0
    tags_cena = set(_extrair_tags_jogo_gta(texto_cena)) - {"gta", "rockstar"}
    palavras_cand = set(cand.get("palavras_chave") or [])
    score = 10 if cand.get("gta_oficial") else 0
    if cand.get("modo_gta") in ("rockstar_mp4", "yt_section"):
        score += 4  # Prioriza vídeo em movimento sobre imagem estática animada
    if not tags_cena:
        if "gta6" in palavras_cand:
            score += 6
        return score
    inter = tags_cena.intersection(palavras_cand)
    score += len(inter) * 12
    # Se a cena fala especificamente de GTA 5 ou GTA 4, dá bônus forte para clipes daquele exato jogo
    for jogo_esp in ("gta5", "gta4", "gtasa", "rage_engine", "gta6"):
        if jogo_esp in tags_cena and jogo_esp in palavras_cand:
            score += 18
    return score


def _coletar_videos_youtube_gta_rockstar(queries_extras=None, max_por_busca=6):
    """Lista vídeos 100% focados nos jogos Grand Theft Auto:
    - Canal oficial `@RockstarGames` + Trailers oficiais de GTA VI, GTA V e GTA IV;
    - Gameplays 4K/HD puros dos jogos GTA (GTA VI, GTA V Los Santos, GTA IV Liberty City, San Andreas, Vice City) sem facecam;
    - Comparativos técnicos do motor RAGE / física / animações in-game (estilo Mano., Rockstar Mag' e Rou)."""
    try:
        import yt_dlp
    except Exception:
        return []

    agora = time.time()
    base_entries = []
    with _LOCK_GTA_CACHE:
        if _CACHE_ACERVO_ROCKSTAR["yt_entries"] and (agora - _CACHE_ACERVO_ROCKSTAR["ts"] < 1800):
            base_entries = list(_CACHE_ACERVO_ROCKSTAR["yt_entries"])

    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "extract_flat": True,
        "playlistend": 22,
        "nocheckcertificate": True,
        "socket_timeout": 8,
    }

    termos_gta_obrigatorios = (
        "grand theft auto", "gta", "vice city", "los santos", "liberty city",
        "leonida", "san andreas", "rockstar games", "rage engine",
    )
    termos_proibidos = (
        "reaction", "reacts", "facecam", "live stream", "podcast", "shorts",
        "irl", "real life", "vlog", "prank", "tiktok", "webcam", "interview",
    )

    if not base_entries:
        alvos_fixos = [
            ("https://www.youtube.com/@RockstarGames/videos", "Rockstar Games (@RockstarGames)"),
            ("ytsearch8:Grand Theft Auto VI official trailer extended look gameplay Rockstar Games", "GTA VI Official Trailer & Gameplay"),
            ("ytsearch8:GTA 5 PS5 gameplay 4K 60fps no commentary Los Santos", "GTA V 100% Gameplay Los Santos"),
            ("ytsearch6:GTA 6 vs GTA 5 graphics physics animations comparison gameplay", "GTA VI vs GTA V RAGE Comparison"),
            ("ytsearch6:GTA IV Liberty City gameplay 4K 60fps no commentary Niko Bellic", "GTA IV Liberty City Gameplay"),
            ("ytsearch5:GTA San Andreas GTA Vice City Definitive Edition gameplay no commentary", "GTA Classic Gameplay"),
            ("ytsearch5:Rockstar RAGE engine GTA 6 GTA 5 physics details animations footage", "GTA RAGE Engine Technology"),
        ]

        def _fetch_alvo(par):
            alvo_u, rotulo = par
            achados = []
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(alvo_u, download=False) or {}
                for e in (info.get("entries") or []):
                    if not isinstance(e, dict) or not e.get("id"):
                        continue
                    tit_e = str(e.get("title") or "")
                    tit_l = tit_e.lower()
                    # Garante 100% foco exclusivo na franquia Grand Theft Auto (rejeita qualquer outro jogo ou vídeo fora de GTA!)
                    if not any(k in tit_l for k in termos_gta_obrigatorios):
                        continue
                    if any(bad in tit_l for bad in termos_proibidos):
                        continue
                    dur_e = float(e.get("duration") or 0)
                    if dur_e and (dur_e < 18 or dur_e > 4200):
                        continue
                    achados.append({
                        "yt_id": e["id"],
                        "title": tit_e,
                        "duration": dur_e or 90.0,
                        "channel": e.get("channel") or e.get("uploader") or rotulo,
                        "oficial_rockstar": ("rockstar" in str(e.get("channel") or "").lower()) or ("@RockstarGames" in alvo_u),
                        "tags_jogo": _extrair_tags_jogo_gta(f"{tit_e} {rotulo}"),
                    })
            except Exception:
                pass
            return achados

        with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex:
            for lst in ex.map(_fetch_alvo, alvos_fixos):
                base_entries.extend(lst)

        dedup = []
        vistos_ids = set()
        for it in base_entries:
            if it["yt_id"] not in vistos_ids:
                vistos_ids.add(it["yt_id"])
                dedup.append(it)
        base_entries = dedup
        with _LOCK_GTA_CACHE:
            if base_entries:
                _CACHE_ACERVO_ROCKSTAR["yt_entries"] = base_entries

    # Se houver queries específicas das cenas, força sempre contexto de gameplay in-game de GTA
    extras_limpas = []
    for q in (queries_extras or [])[:5]:
        qs = str(q or "").strip()
        if not qs:
            continue
        if "gta" not in qs.lower() and "grand theft auto" not in qs.lower():
            qs = f"GTA 6 GTA 5 gameplay {qs}"
        elif "gameplay" not in qs.lower() and "trailer" not in qs.lower():
            qs = f"{qs} gameplay"
        if qs not in extras_limpas:
            extras_limpas.append(qs)

    if extras_limpas:
        def _fetch_q(q_s):
            out = []
            try:
                opts_q = dict(ydl_opts, playlistend=max_por_busca)
                with yt_dlp.YoutubeDL(opts_q) as ydl:
                    inf = ydl.extract_info(f"ytsearch{max_por_busca}:{q_s} no commentary no facecam", download=False) or {}
                for e in (inf.get("entries") or []):
                    if not isinstance(e, dict) or not e.get("id"):
                        continue
                    dur_e = float(e.get("duration") or 0)
                    if dur_e and (dur_e < 18 or dur_e > 3600):
                        continue
                    tit_e = str(e.get("title") or "")
                    tit_l = tit_e.lower()
                    if not any(k in tit_l for k in termos_gta_obrigatorios):
                        continue
                    if any(b in tit_l for b in termos_proibidos):
                        continue
                    out.append({
                        "yt_id": e["id"],
                        "title": tit_e,
                        "duration": dur_e or 90.0,
                        "channel": e.get("channel") or "GTA Gameplay",
                        "oficial_rockstar": "rockstar" in str(e.get("channel") or "").lower(),
                        "query_origem": q_s,
                        "tags_jogo": _extrair_tags_jogo_gta(f"{tit_e} {q_s}"),
                    })
            except Exception:
                pass
            return out

        vistos_ids = {x["yt_id"] for x in base_entries}
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
            for lst_q in ex.map(_fetch_q, extras_limpas):
                for it in lst_q:
                    if it["yt_id"] not in vistos_ids:
                        vistos_ids.add(it["yt_id"])
                        base_entries.append(it)

    return base_entries


def construir_candidatos_gta_sem_repeticao(total_cenas=160, queries_cenas=None, chaves_bloqueadas=None):
    """Monta um amplo pool 100% focado nos jogos GTA (vídeos e capturas oficiais dos jogos):
    - Prioridade absoluta aos vídeos e imagens dos jogos GTA (GTA VI, GTA V, GTA IV, San Andreas, Vice City, motor RAGE);
    - Cada candidato já carrega sua janela exata de corte Fair-Use (`start_s`, `dur_s` de 4.2s a 5.2s)
      e `id_unico` exclusivo para NUNCA repetir no mesmo vídeo nem em vídeos anteriores do canal `GTA à la Une`."""
    bloqueadas = set(chaves_bloqueadas or set())
    videos_web, fotos_web = _raspar_midias_site_rockstar()
    yt_videos = _coletar_videos_youtube_gta_rockstar(queries_extras=queries_cenas)

    for vw_it in videos_web:
        vw_it["palavras_chave"] = sorted(set((vw_it.get("palavras_chave") or []) + ["gta6", "vice_city", "leonida", "rage_engine"]))
    for fw_it in fotos_web:
        fw_it["palavras_chave"] = sorted(set((fw_it.get("palavras_chave") or []) + ["gta6", "vice_city", "leonida"]))

    # Fatiamento inteligente Fair-Use dos vídeos 100% GTA (pula logos iniciais e telas finais)
    fatias_yt_por_video = []
    for yv in yt_videos:
        vid_id = yv["yt_id"]
        dur_total = float(yv.get("duration") or 90.0)
        ini_util = 8.0 if dur_total > 60 else (5.0 if dur_total > 28 else 2.0)
        fim_util = max(ini_util + 5.0, dur_total - 10.0)
        passo = 8.0 if dur_total <= 180 else (11.5 if dur_total <= 900 else 15.0)
        t_cur = ini_util
        fatias_deste = []
        tags_yv = list(yv.get("tags_jogo") or _extrair_tags_jogo_gta(yv.get("title") or ""))
        palavras_t = [w for w in re.split(r"[^a-zA-Z0-9]+", yv["title"].lower()) if len(w) >= 3]
        while t_cur + 4.5 <= fim_util and len(fatias_deste) < 85:
            janela_idx = int(t_cur // 6)
            id_u = f"rockstar_yt:{vid_id}:w{janela_idx:03d}"
            u_watch = f"https://www.youtube.com/watch?v={vid_id}&t={int(t_cur)}s"
            if id_u not in bloqueadas and u_watch.lower() not in bloqueadas:
                fatias_deste.append({
                    "id_unico": id_u,
                    "tipo": "video",
                    "fonte": f"GTA In-Game / Rockstar ({yv.get('channel') or 'Rockstar Games'})",
                    "tier": "Tier 1 (Rockstar Official GTA Cut)" if yv.get("oficial_rockstar") else "Tier 1 (100% GTA Game Footage Cut)",
                    "banco_id": "youtube",
                    "url": u_watch,
                    "download": u_watch,
                    "preview": f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg",
                    "yt_id": vid_id,
                    "start_s": round(t_cur, 2),
                    "dur_s": 4.8,
                    "gta_oficial": True,
                    "modo_gta": "yt_section",
                    "titulo": f"{yv['title']} [{int(t_cur)}s]",
                    "palavras_chave": sorted(set(palavras_t + tags_yv + ["gta", "rockstar"])),
                })
            t_cur += passo
        if fatias_deste:
            fatias_yt_por_video.append(fatias_deste)

    # Intercala (round-robin) entre:
    # 1) Vídeos oficiais in-engine de rockstargames.com/fr/VI
    # 2) Micro-cortes intercalados de TODOS os trailers e gameplays puros de GTA (GTA VI, GTA V, GTA IV, SA, VC)
    # 3) Capturas oficiais HD dos jogos GTA em rockstargames.com animadas em .mp4 com Ken Burns (1 a cada 2 rodadas para priorizar gameplay em movimento!)
    pool_intercalado = []
    vistos_pool = set(bloqueadas)

    def _add_cand(c):
        cu = c.get("id_unico") or c.get("download") or ""
        if not cu or cu in vistos_pool:
            return False
        vistos_pool.add(cu)
        pool_intercalado.append(c)
        return True

    idx_vw = 0
    idx_fw = 0
    rodada = 0
    alvo_pool = max(int(total_cenas) * 2 + 100, 480)

    while len(pool_intercalado) < alvo_pool:
        adicionou_rodada = False
        if idx_vw < len(videos_web):
            if _add_cand(videos_web[idx_vw]):
                adicionou_rodada = True
            idx_vw += 1

        for lista_f in fatias_yt_por_video:
            if rodada < len(lista_f):
                if _add_cand(lista_f[rodada]):
                    adicionou_rodada = True

        # Intercala capturas oficiais HD da Rockstar com movimento Ken Burns (mantendo ~80%+ gameplay/trailer real em movimento)
        if idx_fw < len(fotos_web) and (rodada % 2 == 0 or rodada >= max((len(x) for x in fatias_yt_por_video), default=0)):
            if _add_cand(fotos_web[idx_fw]):
                adicionou_rodada = True
            idx_fw += 1

        rodada += 1
        if not adicionou_rodada and idx_vw >= len(videos_web) and idx_fw >= len(fotos_web):
            break

    return pool_intercalado


def _resolver_stream_youtube_direto(yt_id):
    """Resolve e faz cache (por 25 min) da URL direta do stream de vídeo H.264/MP4 <= 720p no YouTube
    para que o `ffmpeg -ss` baixe APENAS os 4.8s necessários em ~1.5s."""
    agora = time.time()
    with _LOCK_GTA_CACHE:
        c = _CACHE_STREAM_YT.get(yt_id)
        if c and c.get("url") and (agora - c.get("ts", 0) < 1500):
            return c["url"], float(c.get("dur") or 90.0)

    try:
        import yt_dlp

        ydl_opts = {
            "quiet": True,
            "no_warnings": True,
            "nocheckcertificate": True,
            "socket_timeout": 10,
            "format": "bestvideo[height<=720][ext=mp4]/best[height<=720][ext=mp4]/bestvideo[height<=720]/best[height<=720]",
        }
        if os.path.exists("/usr/local/bin/node") or os.name == "nt":
            ydl_opts["js_runtimes"] = {"node": {}}

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            inf = ydl.extract_info(f"https://www.youtube.com/watch?v={yt_id}", download=False) or {}
        u_stream = inf.get("url") or ""
        if not u_stream and inf.get("requested_formats"):
            u_stream = inf["requested_formats"][0].get("url") or ""
        dur = float(inf.get("duration") or 90.0)
        if u_stream:
            with _LOCK_GTA_CACHE:
                _CACHE_STREAM_YT[yt_id] = {"ts": agora, "url": u_stream, "dur": dur}
            return u_stream, dur
    except Exception:
        pass
    return "", 0.0


def montar_filtro_ffmpeg_anticopyright_gta(idx_cena=1, dur_s=4.8, eh_imagem_estatica=False):
    """Constrói o filtergraph `ffmpeg` Fair-Use / Anti-Copyright para `GTA à la Une`:
    1. Zoom + Enquadramento Assimétrico variável por cena (108%-114% scale + crop 1280x720 deslocado);
    2. Color Grading Editorial Francófono (contraste, saturação sutil e balanço cromático variado);
    3. Máscara Óptica Anti-Content-ID:
       - Vignette cinematográfica nas bordas (`vignette=PI/4.8`);
       - Matte superior/inferior (`16px` `black@0.58`) + linha neon GTA (`3px` alternando Rosa Vice / Ciano / Âmbar Liberty);
       - Textura de filme leve (`noise=alls=3:allf=t`);
    4. Transição suave integrada (`fade in` 0.20s + `fade out` 0.22s) e ajuste fino de cadência (`setpts=0.96*PTS`)."""
    dur_limpa = max(2.8, min(6.0, float(dur_s or 4.8)))
    fade_out_st = round(max(1.5, dur_limpa - 0.24), 2)
    cores_neon = ("0xec4899", "0x06b6d4", "0xf59e0b")
    cor_barra = cores_neon[idx_cena % len(cores_neon)]

    # Deslocamento de crop diferente para cada cena para nunca manter o quadro bruto original 1:1
    off_x = 32 + ((idx_cena * 23) % 96)
    off_y = 18 + ((idx_cena * 13) % 54)
    sat = round(1.10 + ((idx_cena % 4) * 0.02), 2)
    cont = round(1.05 + ((idx_cena % 3) * 0.02), 2)

    if eh_imagem_estatica:
        # Transforma a captura oficial HD da Rockstar em um vídeo .MP4 fluido com movimento lateral/diagonal Ken Burns!
        dir_pan = 1 if (idx_cena % 2 == 0) else -1
        expr_x = f"(iw-1280)*(0.5+{dir_pan}*0.32*(t/{dur_limpa:.2f}-0.5))"
        expr_y = f"(ih-720)*(0.5+0.20*(t/{dur_limpa:.2f}-0.5))"
        base_motion = f"scale=1520:855:force_original_aspect_ratio=increase,crop=1280:720:'{expr_x}':'{expr_y}',fps=30"
    else:
        base_motion = (
            f"scale=1424:801:force_original_aspect_ratio=increase,"
            f"crop=1280:720:{off_x}:{off_y},"
            f"setpts=0.96*PTS,fps=30"
        )

    mascara_e_transicao = (
        f"{base_motion},"
        f"eq=contrast={cont}:saturation={sat}:brightness=-0.015,"
        f"vignette=PI/4.8,"
        f"noise=alls=3:allf=t,"
        f"drawbox=x=0:y=0:w=iw:h=16:color=black@0.58:t=fill,"
        f"drawbox=x=0:y=ih-16:w=iw:h=16:color=black@0.58:t=fill,"
        f"drawbox=x=0:y=ih-3:w=iw:h=3:color={cor_barra}@0.88:t=fill,"
        f"fade=t=in:st=0:d=0.20,"
        f"fade=t=out:st={fade_out_st}:d=0.22"
    )
    return mascara_e_transicao


def baixar_e_mascarar_cena_gta_anticopyright(cand, dest_mp4, idx_cena=1, duracao_cena_srt=4.8):
    """Baixa o trecho oficial da Rockstar Games (`rockstargames.com` ou `@RockstarGames` YouTube) e gera
    imediatamente o arquivo `.mp4` final em `dest_mp4` com:
    - 0% áudio original (`-an`);
    - Corte curto Fair-Use (`3.8s` a `5.6s`);
    - Máscara visual Anti-Copyright + Transições Fade + Color Grading + Enquadramento Dinâmico."""
    if not isinstance(cand, dict):
        return False

    dur_alvo = round(min(5.6, max(3.8, float(duracao_cena_srt or cand.get("dur_s") or 4.8))), 2)
    modo_gta = str(cand.get("modo_gta") or "")
    u_dl = str(cand.get("download") or cand.get("url") or "").strip()
    cflags = 0x08000000 if os.name == "nt" else 0
    tmp_raw = ""
    tmp_out = dest_mp4 + f".gta_mask_{idx_cena}.mp4"

    try:
        if modo_gta == "yt_section" or "youtube.com/watch" in u_dl or cand.get("yt_id"):
            yt_id = cand.get("yt_id") or ""
            if not yt_id:
                m_v = re.search(r"[?&]v=([a-zA-Z0-9_-]{11})", u_dl)
                yt_id = m_v.group(1) if m_v else ""
            if not yt_id:
                return False
            stream_url, dur_real = _resolver_stream_youtube_direto(yt_id)
            if not stream_url:
                return False
            start_s = float(cand.get("start_s") or 6.0)
            if dur_real > 15 and start_s + dur_alvo > dur_real - 3:
                start_s = max(2.0, dur_real - dur_alvo - 4.0)

            vf_str = montar_filtro_ffmpeg_anticopyright_gta(idx_cena=idx_cena, dur_s=dur_alvo, eh_imagem_estatica=False)
            cmd = [
                "ffmpeg", "-y",
                "-ss", f"{start_s:.2f}",
                "-i", stream_url,
                "-t", f"{dur_alvo:.2f}",
                "-vf", vf_str,
                "-an",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-pix_fmt", "yuv420p",
                "-movflags", "+faststart",
                tmp_out,
            ]
            r_ff = subprocess.run(cmd, capture_output=True, timeout=24, creationflags=cflags)
            if r_ff.returncode == 0 and os.path.exists(tmp_out) and os.path.getsize(tmp_out) > 15000:
                os.replace(tmp_out, dest_mp4)
                return True
            return False

        # Download direto de rockstargames.com (.mp4 ou .jpg de alta resolução)
        if not u_dl.startswith("http"):
            return False
        r_http = requests.get(u_dl, headers=HEADERS_PADRAO, timeout=14)
        if not r_http.ok or len(r_http.content or b"") < 8000:
            return False

        eh_img = (modo_gta == "rockstar_img_motion") or u_dl.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
        suf_raw = ".jpg" if eh_img else ".mp4"
        with tempfile.NamedTemporaryFile(suffix=suf_raw, delete=False) as tf:
            tf.write(r_http.content)
            tmp_raw = tf.name

        vf_str = montar_filtro_ffmpeg_anticopyright_gta(idx_cena=idx_cena, dur_s=dur_alvo, eh_imagem_estatica=eh_img)
        if eh_img:
            cmd = [
                "ffmpeg", "-y",
                "-loop", "1",
                "-i", tmp_raw,
                "-t", f"{dur_alvo:.2f}",
                "-vf", vf_str,
                "-an",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "22", "-pix_fmt", "yuv420p",
                "-movflags", "+faststart",
                tmp_out,
            ]
        else:
            # Offset sutil variável para vídeos longos da Rockstar
            cmd = [
                "ffmpeg", "-y",
                "-i", tmp_raw,
                "-t", f"{dur_alvo:.2f}",
                "-vf", vf_str,
                "-an",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-pix_fmt", "yuv420p",
                "-movflags", "+faststart",
                tmp_out,
            ]
        r_ff = subprocess.run(cmd, capture_output=True, timeout=20, creationflags=cflags)
        if r_ff.returncode == 0 and os.path.exists(tmp_out) and os.path.getsize(tmp_out) > 15000:
            os.replace(tmp_out, dest_mp4)
            return True
        return False
    except Exception:
        return False
    finally:
        for p_clean in (tmp_raw, tmp_out):
            if p_clean and os.path.exists(p_clean):
                try:
                    os.remove(p_clean)
                except Exception:
                    pass


def aplicar_mascara_anticopyright_em_arquivo_existente(caminho_mp4, idx_cena=1, duracao_alvo=5.0):
    """Aplica a blindagem Anti-Copyright (0% áudio original + máscara + crop/zoom + fade) em um `.mp4` local já existente."""
    if not caminho_mp4 or not os.path.isfile(caminho_mp4):
        return False
    dur_limpa = round(min(5.8, max(3.8, float(duracao_alvo or 5.0))), 2)
    tmp_out = caminho_mp4 + f".remask_{idx_cena}.mp4"
    vf_str = montar_filtro_ffmpeg_anticopyright_gta(idx_cena=idx_cena, dur_s=dur_limpa, eh_imagem_estatica=False)
    cflags = 0x08000000 if os.name == "nt" else 0
    try:
        r_ff = subprocess.run(
            [
                "ffmpeg", "-y",
                "-i", caminho_mp4,
                "-t", f"{dur_limpa:.2f}",
                "-vf", vf_str,
                "-an",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-pix_fmt", "yuv420p",
                "-movflags", "+faststart",
                tmp_out,
            ],
            capture_output=True,
            timeout=20,
            creationflags=cflags,
        )
        if r_ff.returncode == 0 and os.path.exists(tmp_out) and os.path.getsize(tmp_out) > 12000:
            os.replace(tmp_out, caminho_mp4)
            return True
        return False
    except Exception:
        return False
    finally:
        if os.path.exists(tmp_out):
            try:
                os.remove(tmp_out)
            except Exception:
                pass


PROMPTS_OFICIAIS_GTA_A_LA_UNE_FR = [
    {
        "id": "gta_fr_prompt_mestre_v3",
        "nome": "1. Prompt Mestre — GTA à la Une (100% Jeu GTA · Références Mano., Rockstar Mag' & Rou · fr-FR)",
        "categoria": "roteiro",
        "conteudo": (
            "IDENTITÉ ÉDITORIALE : Chaîne YouTube francophone « GTA à la Une » (100% en français fr-FR, voix Léo - Reassuring and Dynamic).\n"
            "RÉFÉRENCES DIRECTES DU STYLE :\n"
            "- Mano. (https://www.youtube.com/watch?v=8GD39QLKtyY — « Le jeu vidéo a atteint sa limite avec GTA 6 ») : essai gaming profond, accroche choc dès les 50 premières secondes, budget, IA et impact industriel.\n"
            "- Rockstar Mag' (https://www.youtube.com/watch?v=dPSpuFYoEF8 — « VOILÀ, C'ÉTAIT GTA V. ») : 100% centré sur les jeux Grand Theft Auto eux-mêmes (gameplay, cartes, missions, personnages, héritage).\n"
            "- Rou (https://www.youtube.com/watch?v=I-bJ61bouDo — « L'incroyable technologie derrière GTA 6 ») : décryptage visuel du moteur RAGE, +600 000 animations, physique Euphoria, rendu de la lumière et comparatifs GTA IV / GTA V / GTA VI.\n"
            "- Vico GTA & G3ADRIEN OFF : rythme dynamique, guides avant-sortie (« Tout ce qu'il faut savoir avant de jouer à GTA 6 ») et comparatifs chocs GTA 5 vs GTA 6.\n"
            "RÈGLES STRICTES :\n"
            "1. 100% FOCUS JEU GTA : Parler exclusivement des jeux Grand Theft Auto (GTA VI Vice City/Leonida, GTA V Los Santos, GTA IV Liberty City, San Andreas, Vice City) et de la technologie Rockstar Games.\n"
            "2. 100% EN FRANÇAIS : Titre, structure, narration parlée, SRT, textes à l'écran et description SEO uniquement en français naturel de France.\n"
            "3. CTA FINAL EN FRANÇAIS : « Abonnez-vous à GTA à la Une et activez la cloche pour ne rien manquer sur GTA ! »"
        ),
    },
    {
        "id": "gta_fr_style_anticopyright_v3",
        "nome": "2. Estilo Visual — 100% Vídeos & Imagens dos Jogos GTA (Disco D & Outros Bancos só em Último Caso)",
        "categoria": "estilo",
        "conteudo": (
            "STYLE_DNA : \"100% authentic Grand Theft Auto in-game gameplay & official Rockstar Games trailers/screenshots (GTA VI Vice City/Leonida, GTA V Los Santos, "
            "GTA IV Liberty City, RAGE engine comparisons) sourced from rockstargames.com and pure GTA gameplay/trailers, protected with Fair-Use Anti-Copyright mask "
            "(3.8s-5.5s micro-cuts, 0% original audio -an, 110% asymmetric framing, neon Vice/Liberty grading, vignette + cinema matte + fade transitions, 0% repetition on channel). "
            "Local drive D:\\BANCO DE DADOS and external stock databases are strictly LAST RESORT support only.\""
        ),
    },
    {
        "id": "gta_fr_studio_edicao_v3",
        "nome": "3. Edição DarkPlanner Studio — 100% Gameplay/Cenas GTA, Máscara Anti-Copyright & Ritmo Mano./Rou",
        "categoria": "edicao",
        "conteudo": (
            "STUDIO_EDIT_BLOCK :\n"
            "- Faixa V1 (Prioridade 100% Jogo GTA) : Exclusivamente vídeos .MP4 e capturas HD dos jogos GTA (Rockstar Games + Gameplay GTA VI / GTA V / GTA IV sem facecam) com máscara anti-copyright aplicada. Usar D:\\BANCO DE DADOS ou bancos externos SOMENTE em último caso absoluto para apoio.\n"
            "- Ritmo & Transições (Estilo Mano. / Rockstar Mag' / Rou) : Micro-cortes dinâmicos de 2-4s nos primeiros 60 blocos e 4-6s nos demais, zoom dinâmico, Ken Burns nas capturas oficiais HD dos jogos GTA e 0% áudio original nos clipes.\n"
            "- Destaques & Templates : Predefinição `sys_tudo` / `dinamico` com lower-thirds em francês (fr-FR), legendas sincronizadas 1:1 com a voz Léo e trilha synthwave discreta (-18dB)."
        ),
    },
]

