"""Montagens animadas por cena (estilo documentário profissional).

Cada cena pode ter um "layout" escolhido pela IA na pesquisa:
  pessoa        foto da pessoa em cartão (estilo anuário) entrando, com o nome embaixo
  duas_pessoas  dois cartões lado a lado
  data          data escrita letra por letra no meio da tela
  local         plaquinha com o nome do lugar, entrando pela esquerda
  ano           selo grande com o ano (filmagem de arquivo)
  citacao       "a frase real": texto do documento aparecendo letra por letra, etiqueta vermelha
  colagem       grade com 4 fotos
  midia         só a mídia (padrão)

Tudo é desenhado com Pillow (imagens com transparência) e animado no FFmpeg por cima do trecho já montado.
Estilos: "padrao", "true_crime" (cartões sépia, brilho de lente), "jornal" (etiquetas vermelhas, faixa amarela).
"""
import math
import os
import random

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageOps

from core.templates import MONO, SANS, fonte

LAYOUTS = ("midia", "pessoa", "duas_pessoas", "data", "local", "ano", "citacao", "colagem",
           "quadro", "linha_tempo", "ficha", "numero", "escala", "documento", "capitulo", "mapa", "frase", "nome", "sequencia")
PRECISA_TEXTO = ("data", "local", "ano", "citacao", "linha_tempo", "ficha", "numero", "escala", "documento", "capitulo", "frase", "nome")
PRECISA_FOTOS = ("pessoa", "duas_pessoas", "colagem", "sequencia")

SERIF = [r"C:\Windows\Fonts\georgiab.ttf", r"C:\Windows\Fonts\timesbd.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"]
IMPACTO = [r"C:\Windows\Fonts\impact.ttf", r"C:\Windows\Fonts\arialbd.ttf", "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
           "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]
MAO = [r"C:\Windows\Fonts\segoeprb.ttf", r"C:\Windows\Fonts\segoepr.ttf", r"C:\Windows\Fonts\comicbd.ttf",
       "/usr/share/fonts/truetype/google-fonts/Poppins-Medium.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
LEVE = [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\segoeui.ttf", "/usr/share/fonts/truetype/google-fonts/Poppins-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]

# cores e fontes de cada perfil de canal
TEMAS = {
    "padrao": dict(acc=(249, 115, 22), txt=(245, 245, 245), papel=(236, 228, 212), tinta=(30, 28, 24), fundo=(14, 14, 16),
                   quadro=(58, 41, 27), titulo=SANS, foto="cor"),
    "true_crime": dict(acc=(200, 16, 46), txt=(240, 232, 214), papel=(232, 222, 198), tinta=(35, 28, 20), fundo=(22, 18, 14),
                       quadro=(52, 37, 24), titulo=SERIF, foto="sepia"),
    "jornal": dict(acc=(200, 16, 46), txt=(255, 255, 255), papel=(240, 238, 232), tinta=(20, 20, 20), fundo=(12, 14, 20),
                   quadro=(40, 44, 52), titulo=SANS, foto="cor"),
    "historia": dict(acc=(201, 162, 90), txt=(244, 234, 210), papel=(226, 212, 180), tinta=(48, 36, 22), fundo=(26, 20, 14),
                     quadro=(66, 48, 30), titulo=SERIF, foto="sepia"),
    "horror": dict(acc=(178, 18, 28), txt=(226, 226, 230), papel=(205, 200, 190), tinta=(20, 20, 22), fundo=(6, 6, 9),
                   quadro=(20, 18, 18), titulo=SERIF, foto="frio"),
    "natureza": dict(acc=(132, 204, 96), txt=(246, 248, 240), papel=(232, 230, 214), tinta=(28, 36, 24), fundo=(10, 20, 14),
                     quadro=(44, 52, 36), titulo=SANS, foto="cor"),
}
ROTULOS = {
    "pt": {"frase": "A FRASE REAL", "parte": "PARTE", "arquivo": "ARQUIVO", "confidencial": "CONFIDENCIAL", "sat": "Imagens de satélite: Esri, Maxar"},
    "en": {"frase": "THE ACTUAL PHRASE", "parte": "PART", "arquivo": "FILE", "confidencial": "CONFIDENTIAL", "sat": "Satellite imagery: Esri, Maxar"},
    "es": {"frase": "LA FRASE REAL", "parte": "PARTE", "arquivo": "ARCHIVO", "confidencial": "CONFIDENCIAL", "sat": "Imágenes satelitales: Esri, Maxar"},
    "fr": {"frase": "LA VRAIE PHRASE", "parte": "PARTIE", "arquivo": "DOSSIER", "confidencial": "CONFIDENTIEL", "sat": "Imagerie satellite : Esri, Maxar"},
}


def tema(estilo):
    return {**TEMAS["padrao"], **TEMAS.get(estilo or "padrao", {})}


def _tratar_foto(im, t):
    if t["foto"] == "sepia":
        return ImageOps.colorize(ImageOps.grayscale(im), (25, 20, 15), (245, 232, 205))
    if t["foto"] == "frio":
        return ImageOps.colorize(ImageOps.grayscale(im), (8, 10, 14), (215, 222, 230))
    return im
ETIQUETA = {"pt": "A FRASE REAL", "en": "THE ACTUAL PHRASE", "es": "LA FRASE REAL", "fr": "LA VRAIE PHRASE"}


# ------------------------------------------------------------------ peças desenhadas
def _sombra(im, raio=18, opac=150):
    w, h = im.size
    pad = raio * 2
    sh = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rectangle([pad, pad + raio // 2, pad + w, pad + h + raio // 2], fill=(0, 0, 0, opac))
    sh = sh.filter(ImageFilter.GaussianBlur(raio))
    sh.alpha_composite(im, (pad, pad))
    return sh


def cartao(foto, nome, H, estilo="padrao", angulo=0.0):
    """Cartão de foto (3:4) com borda e nome embaixo. Retorna imagem RGBA."""
    alt = int(H * 0.5)
    larg = int(alt * 0.78)
    try:
        im = Image.open(foto).convert("RGB")
    except Exception:
        im = Image.new("RGB", (larg, alt), (60, 60, 60))
    im = ImageOps.fit(im, (larg, alt), Image.LANCZOS, centering=(0.5, 0.35))
    im = _tratar_foto(im, tema(estilo))
    borda = max(6, H // 90)
    card = Image.new("RGBA", (larg + borda * 2, alt + borda * 2), (240, 236, 226, 255))
    card.paste(im, (borda, borda))
    out = _sombra(card)
    if nome:
        tam = max(18, H // 22)
        f = fonte(SANS, tam)
        d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
        tw = int(d.textlength(nome, font=f))
        canvas = Image.new("RGBA", (max(out.width, tw + 40), out.height + int(tam * 1.6)), (0, 0, 0, 0))
        canvas.alpha_composite(out, ((canvas.width - out.width) // 2, 0))
        dc = ImageDraw.Draw(canvas)
        x = (canvas.width - tw) // 2
        y = out.height - int(tam * 0.4)
        dc.text((x, y), nome, font=f, fill=(255, 255, 255, 255), stroke_width=max(2, tam // 12), stroke_fill=(0, 0, 0, 220))
        out = canvas
    if angulo:
        out = out.rotate(angulo, resample=Image.BICUBIC, expand=True)
    return out


def placa_local(texto, W, H, estilo="padrao"):
    tam = max(18, H // 24)
    f = fonte(SANS, tam)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    linhas = _quebrar(texto, f, W * 0.32, d)
    tw = max(d.textlength(l, font=f) for l in linhas)
    pad = int(tam * 0.6)
    w, h = int(tw + pad * 2), int(len(linhas) * tam * 1.25 + pad * 1.6)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dc = ImageDraw.Draw(im)
    fundo = (200, 16, 46, 235) if estilo == "jornal" else (20, 20, 20, 200)
    dc.rectangle([0, 0, w, h], fill=fundo)
    if estilo != "jornal":
        dc.rectangle([0, 0, max(4, tam // 7), h], fill=tema(estilo)["acc"] + (255,))
    for k, l in enumerate(linhas):
        dc.text((pad, pad * 0.8 + k * tam * 1.25), l, font=f, fill=(245, 245, 245, 255))
    return im


def selo_ano(texto, H):
    tam = max(28, H // 11)
    f = fonte(SANS, tam)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = d.textlength(texto, font=f)
    pad = int(tam * 0.35)
    im = Image.new("RGBA", (int(tw + pad * 2), int(tam * 1.35)), (0, 0, 0, 0))
    dc = ImageDraw.Draw(im)
    dc.rounded_rectangle([0, 0, im.width - 1, im.height - 1], radius=tam // 6, fill=(250, 250, 245, 240), outline=(20, 20, 20, 255), width=max(2, tam // 18))
    dc.text((pad, int(tam * 0.08)), texto, font=f, fill=(15, 15, 15, 255))
    return _sombra(im, 10, 120)


def etiqueta(texto, H, cor=(200, 16, 46)):
    tam = max(16, H // 26)
    f = fonte(SANS, tam)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = d.textlength(texto, font=f)
    im = Image.new("RGBA", (int(tw + tam * 1.2), int(tam * 1.7)), (0, 0, 0, 0))
    dc = ImageDraw.Draw(im)
    dc.rectangle([0, 0, im.width, im.height], fill=cor + (255,))
    dc.text((tam * 0.6, tam * 0.3), texto, font=f, fill=(255, 255, 255, 255))
    return im.rotate(2, resample=Image.BICUBIC, expand=True)


def credito(texto, H):
    tam = max(12, H // 46)
    f = fonte(SANS, tam)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = d.textlength(texto, font=f)
    im = Image.new("RGBA", (int(tw + tam), int(tam * 1.6)), (0, 0, 0, 120))
    ImageDraw.Draw(im).text((tam // 2, tam * 0.25), texto, font=f, fill=(255, 255, 255, 230))
    return im


def fundo_documento(W, H):
    random.seed(11)
    im = Image.new("RGB", (W, H), (22, 21, 19))
    ruido = Image.effect_noise((W // 3, H // 3), 30).resize((W, H)).convert("L")
    textura = Image.merge("RGB", [ruido.point(lambda p: 18 + p // 9)] * 3)
    im = Image.blend(im, textura, 0.55)
    vin = Image.new("L", (W, H), 0)
    ImageDraw.Draw(vin).ellipse([-W * 0.2, -H * 0.3, W * 1.2, H * 1.3], fill=255)
    vin = vin.filter(ImageFilter.GaussianBlur(W // 10))
    return Image.composite(im, Image.new("RGB", (W, H), (6, 6, 6)), vin)


def brilho_lente(W, H, lado="esq"):
    """Vazamento de luz quente (light leak) para o estilo true crime."""
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    g = Image.new("L", (W, H), 0)
    cx = int(W * (0.12 if lado == "esq" else 0.88))
    ImageDraw.Draw(g).ellipse([cx - W * 0.3, -H * 0.2, cx + W * 0.3, H * 1.2], fill=95)
    g = g.filter(ImageFilter.GaussianBlur(W // 9))
    cor = Image.new("RGBA", (W, H), (255, 140, 40, 255))
    im = Image.composite(cor, im, g)
    return im


def colagem(fotos, W, H, estilo="padrao"):
    fotos = [f for f in fotos if f and os.path.exists(f)][:4]
    bg = Image.new("RGB", (W, H), (14, 14, 14) if estilo != "true_crime" else (24, 20, 16))
    if not fotos:
        return bg
    n = len(fotos)
    gap = max(6, W // 160)
    if n == 1:
        caixas = [(0, 0, W, H)]
    elif n == 2:
        caixas = [(0, 0, W // 2 - gap // 2, H), (W // 2 + gap // 2, 0, W, H)]
    elif n == 3:
        caixas = [(0, 0, W // 2 - gap // 2, H), (W // 2 + gap // 2, 0, W, H // 2 - gap // 2), (W // 2 + gap // 2, H // 2 + gap // 2, W, H)]
    else:
        caixas = [(0, 0, W // 2 - gap // 2, H // 2 - gap // 2), (W // 2 + gap // 2, 0, W, H // 2 - gap // 2),
                  (0, H // 2 + gap // 2, W // 2 - gap // 2, H), (W // 2 + gap // 2, H // 2 + gap // 2, W, H)]
    for f, (x0, y0, x1, y1) in zip(fotos, caixas):
        try:
            im = ImageOps.fit(Image.open(f).convert("RGB"), (x1 - x0, y1 - y0), Image.LANCZOS)
        except Exception:
            continue
        if estilo in ("true_crime", "historia", "horror"):
            im = _tratar_foto(im, tema(estilo))
        bg.paste(im, (x0, y0))
    return bg


def _quebrar(texto, f, largura, d):
    palavras, linhas, atual = (texto or "").split(), [], ""
    for w in palavras:
        t = (atual + " " + w).strip()
        if d.textlength(t, font=f) > largura and atual:
            linhas.append(atual)
            atual = w
        else:
            atual = t
    if atual:
        linhas.append(atual)
    return linhas or [""]


# ------------------------------------------------------------------ texto letra por letra
def frames_digitando(texto, W, H, pasta, nome, fps_txt=20, fonte_lista=None, tam=None, largura=0.8, pos="centro",
                     cor=(255, 255, 255, 255), contorno=True, max_seg=2.2, brilho=None, y0=None):
    """Gera a sequência de PNGs (só a camada do texto) com o texto aparecendo letra por letra."""
    os.makedirs(pasta, exist_ok=True)
    tam = tam or max(24, H // 14)
    f = fonte(fonte_lista or SANS, tam)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    linhas = _quebrar(texto, f, W * largura, d)
    alt = int(tam * 1.3)
    total = sum(len(l) for l in linhas) or 1
    n = max(2, min(int(max_seg * fps_txt), total))
    caminhos = []
    for k in range(1, n + 1):
        vis = math.ceil(total * k / n)
        im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        dc = ImageDraw.Draw(im)
        y = y0 if y0 is not None else ((H - alt * len(linhas)) // 2 if pos == "centro" else int(H * 0.16))
        resta = vis
        for l in linhas:
            parte = l[:max(0, resta)]
            resta -= len(l)
            x = (W - d.textlength(l, font=f)) / 2 if pos == "centro" else W * 0.1
            if parte:
                if contorno:
                    dc.text((x, y), parte, font=f, fill=cor, stroke_width=max(2, tam // 14), stroke_fill=(0, 0, 0, 230))
                else:
                    dc.text((x, y), parte, font=f, fill=cor)
            y += alt
        if brilho:
            im = _brilho(im, brilho, max(6, tam // 4))
        p = os.path.join(pasta, f"{nome}_{k:03d}.png")
        im.save(p, compress_level=1)
        caminhos.append(p)
    return os.path.join(pasta, f"{nome}_%03d.png"), n, fps_txt, y


# ------------------------------------------------------------------ peças novas (efeitos de documentário)
def _brilho(im, cor, raio=14, forca=1.6):
    """Brilho (glow) colorido em volta do que estiver desenhado na camada."""
    a = im.getchannel("A").filter(ImageFilter.GaussianBlur(raio)).point(lambda p: min(255, int(p * forca)))
    g = Image.new("RGBA", im.size, tuple(cor[:3]) + (0,))
    g.putalpha(a)
    g.alpha_composite(im)
    return g


def _medir(f, s):
    d = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    b = d.textbbox((0, 0), s, font=f)
    return b[2] - b[0], b[3] - b[1]


def _itens(txt, maximo=5):
    return [p.strip() for p in (txt or "").replace("\n", "|").split("|") if p.strip()][:maximo]


def _par(item):
    """'1969: chegada à Lua' -> ('1969', 'chegada à Lua')."""
    if ":" in item:
        a, b = item.split(":", 1)
        return a.strip(), b.strip()
    if " - " in item:
        a, b = item.split(" - ", 1)
        return a.strip(), b.strip()
    return item.strip(), ""


def _numero(s):
    """Acha o primeiro número do texto. Retorna (prefixo, valor, casas, sufixo, separador_decimal) ou None."""
    import re
    m = re.search(r"\d[\d.,]*", s or "")
    if not m:
        return None
    bruto = m.group(0).rstrip(".,")
    dec = ","
    if "," in bruto and "." in bruto:
        dec = "," if bruto.rfind(",") > bruto.rfind(".") else "."
    elif "," in bruto:
        dec = "," if len(bruto.split(",")[-1]) != 3 else "_"
    elif "." in bruto:
        dec = "." if len(bruto.split(".")[-1]) != 3 else "_"
    milhar = "." if dec == "," else ","
    limpo = bruto.replace(milhar, "") if dec != "_" else bruto.replace(".", "").replace(",", "")
    casas = 0
    if dec in (",", ".") and dec in limpo:
        casas = len(limpo.split(dec)[1])
        limpo = limpo.replace(dec, ".")
    try:
        val = float(limpo)
    except ValueError:
        return None
    return s[:m.start()], val, casas, s[m.start() + len(bruto):], ("," if dec in (",", "_") else ".")


def _fmt_num(v, casas, dec):
    milhar = "." if dec == "," else ","
    s = f"{v:,.{casas}f}"
    return s.replace(",", "§").replace(".", dec).replace("§", milhar)


def fundo_quadro(W, H, t):
    """Quadro de cortiça escuro (quadro de investigação)."""
    base = Image.new("RGB", (W, H), t["quadro"])
    ruido = Image.effect_noise((W // 2, H // 2), 60).resize((W, H)).convert("L")
    tex = Image.merge("RGB", [ruido.point(lambda p, c=c: max(0, min(255, c - 22 + p // 6))) for c in t["quadro"]])
    im = Image.blend(base, tex, 0.6)
    vin = Image.new("L", (W, H), 0)
    ImageDraw.Draw(vin).ellipse([-W * 0.25, -H * 0.35, W * 1.25, H * 1.35], fill=255)
    vin = vin.filter(ImageFilter.GaussianBlur(W // 8))
    return Image.composite(im, Image.new("RGB", (W, H), (5, 4, 3)), vin)


def polaroid(foto, larg, t):
    m = max(8, larg // 18)
    alt = int(larg * 0.82)
    try:
        im = ImageOps.fit(Image.open(foto).convert("RGB"), (larg - 2 * m, alt), Image.LANCZOS, centering=(0.5, 0.35))
    except Exception:
        im = Image.new("RGB", (larg - 2 * m, alt), (70, 70, 70))
    im = _tratar_foto(im, t)
    card = Image.new("RGBA", (larg, alt + m + int(larg * 0.16)), (238, 234, 224, 255))
    card.paste(im, (m, m))
    return card


def _alfinete(dc, x, y, r, cor):
    dc.ellipse([x - r + 2, y - r + 4, x + r + 2, y + r + 4], fill=(0, 0, 0, 120))
    dc.ellipse([x - r, y - r, x + r, y + r], fill=cor + (255,))
    dc.ellipse([x - r * 0.45, y - r * 0.55, x - r * 0.05, y - r * 0.15], fill=(255, 255, 255, 170))


def postit(texto, lado, t, angulo):
    im = Image.new("RGBA", (lado, lado), (0, 0, 0, 0))
    cor = (246, 222, 98) if t["foto"] != "frio" else (226, 222, 196)
    dc = ImageDraw.Draw(im)
    dc.rectangle([0, 0, lado, lado], fill=cor + (255,))
    dc.rectangle([0, 0, lado, lado // 9], fill=tuple(max(0, c - 22) for c in cor) + (255,))
    tam = max(14, lado // 8)
    f = fonte(MAO, tam)
    linhas = _quebrar(texto, f, lado * 0.82, dc)
    while len(linhas) * tam * 1.25 > lado * 0.78 and tam > 12:
        tam -= 2
        f = fonte(MAO, tam)
        linhas = _quebrar(texto, f, lado * 0.82, dc)
    y = (lado - len(linhas) * tam * 1.25) / 2 + lado * 0.04
    for l in linhas:
        dc.text(((lado - dc.textlength(l, font=f)) / 2, y), l, font=f, fill=(30, 30, 40, 255))
        y += tam * 1.25
    return _sombra(im.rotate(angulo, resample=Image.BICUBIC, expand=True), 10, 110)


def _canvas(W, H):
    return Image.new("RGBA", (W, H), (0, 0, 0, 0))


def camadas_quadro(fotos, notas, W, H, t, nomes=()):
    """Quadro de investigação: fotos presas com alfinete, fio vermelho ligando tudo e bilhetes. Retorna lista de camadas (W×H)."""
    rnd = random.Random(len(fotos) * 7 + len(notas))
    slots = {1: [(0.5, 0.3)], 2: [(0.3, 0.28), (0.7, 0.31)], 3: [(0.2, 0.3), (0.5, 0.25), (0.8, 0.32)],
             4: [(0.16, 0.3), (0.4, 0.24), (0.63, 0.33), (0.85, 0.24)]}[max(1, min(4, len(fotos)))]
    larg = int(W * (0.22 if len(fotos) <= 2 else 0.19))
    camadas, pinos = [], []
    for k, (f, (fx, fy)) in enumerate(zip(fotos, slots)):
        p = polaroid(f, larg, t)
        if k < len(nomes) and nomes[k]:
            dc = ImageDraw.Draw(p)
            ft = fonte(MAO, max(14, larg // 13))
            nm = nomes[k][:28]
            dc.text(((p.width - dc.textlength(nm, font=ft)) / 2, p.height - larg * 0.14), nm, font=ft, fill=(30, 30, 40, 255))
        ang = rnd.uniform(-5, 5)
        pr = _sombra(p.rotate(ang, resample=Image.BICUBIC, expand=True), 14, 140)
        cv = _canvas(W, H)
        x, y = int(W * fx - pr.width / 2), int(H * fy - pr.height / 2)
        cv.alpha_composite(pr, (max(0, x), max(0, y)))
        px, py = int(W * fx), int(max(0, y) + pr.height * 0.12)
        _alfinete(ImageDraw.Draw(cv), px, py, max(7, W // 150), t["acc"])
        pinos.append((px, py))
        camadas.append(cv)
    pos_notas = [(0.36, 0.66), (0.64, 0.68), (0.12, 0.66)]
    lado = int(W * 0.12)
    notas_cv = []
    for k, (n, (fx, fy)) in enumerate(zip(notas, pos_notas)):
        pi = postit(n, lado, t, rnd.uniform(-6, 6))
        cv = _canvas(W, H)
        x, y = int(W * fx - pi.width / 2), int(H * fy - pi.height / 2)
        cv.alpha_composite(pi, (x, y))
        _alfinete(ImageDraw.Draw(cv), int(W * fx), int(y + pi.height * 0.14), max(6, W // 170), t["acc"])
        pinos.append((int(W * fx), int(y + pi.height * 0.14)))
        notas_cv.append(cv)
    fio = None
    if len(pinos) >= 2:
        fio = _canvas(W, H)
        dc = ImageDraw.Draw(fio)
        ordem = pinos[:len(fotos)] + pinos[len(fotos):]
        for (x0, y0), (x1, y1) in zip(ordem, ordem[1:] + ([ordem[0]] if len(ordem) > 2 else [])):
            pts = []
            for s in range(21):
                u = s / 20
                sag = math.sin(u * math.pi) * H * 0.025
                pts.append((x0 + (x1 - x0) * u, y0 + (y1 - y0) * u + sag))
            dc.line(pts, fill=(150, 14, 22, 255), width=max(2, W // 640))
        for x, y in pinos:  # alfinete por cima do fio
            _alfinete(dc, x, y, max(6, W // 160), t["acc"])
    return camadas, fio, notas_cv


def camadas_linha_tempo(itens, W, H, t):
    """Linha do tempo horizontal: linha + um marco por item (o último em destaque)."""
    n = len(itens)
    y = int(H * 0.40)
    x0, x1 = int(W * 0.08), int(W * 0.92)
    base = _canvas(W, H)
    dc = ImageDraw.Draw(base)
    dc.line([(x0, y), (x1, y)], fill=t["txt"] + (200,), width=max(3, H // 270))
    marcos = []
    fa = fonte(t["titulo"], max(26, H // 16))
    fb = fonte(LEVE, max(18, H // 30))
    larg_txt = min(W * 0.3, (x1 - x0) / max(1, n) * 0.9)
    margem = (W * 0.84 - larg_txt) / 2  # o texto do primeiro/último marco não sai da tela
    for k, it in enumerate(itens):
        quando, oque = _par(it)
        x = int(W / 2) if n == 1 else int(W * 0.5 - margem + 2 * margem * k / (n - 1))
        cv = _canvas(W, H)
        d2 = ImageDraw.Draw(cv)
        ult = k == n - 1
        cor = t["acc"] if ult else t["txt"]
        r = max(8, H // 70) if ult else max(6, H // 100)
        d2.ellipse([x - r, y - r, x + r, y + r], fill=cor + (255,), outline=(0, 0, 0, 200), width=2)
        tw, th = _medir(fa, quando)
        d2.text((x - tw / 2, y - th - H * 0.05), quando, font=fa, fill=cor + (255,), stroke_width=2, stroke_fill=(0, 0, 0, 200))
        yy = y + H * 0.035
        for l in _quebrar(oque, fb, larg_txt, d2)[:4]:
            lw, _ = _medir(fb, l)
            d2.text((x - lw / 2, yy), l, font=fb, fill=(235, 235, 235, 255), stroke_width=2, stroke_fill=(0, 0, 0, 220))
            yy += fb.size * 1.25
        marcos.append(_brilho(cv, cor, 10, 0.9) if ult else cv)
    return base, marcos


def camadas_ficha(itens, titulo, foto, W, H, t, rotulo="ARQUIVO", centro=False):
    """Ficha/arquivo com nome e dados. Retorna (painel, [camada de cada linha]) — painel posicionado em (px, py)."""
    pw, ph = int(W * 0.56), int(H * 0.58)
    px, py = (int((W - pw) / 2), int(H * 0.12)) if centro else (int(W * 0.40), int(H * 0.08))
    painel = Image.new("RGBA", (pw, ph), (12, 12, 12, 215))
    dc = ImageDraw.Draw(painel)
    cab = int(ph * 0.13)
    dc.rectangle([0, 0, pw, cab], fill=t["acc"] + (255,))
    fr = fonte(SANS, int(cab * 0.42))
    dc.text((pw * 0.04, cab * 0.27), f"{rotulo}  ·  {titulo.upper()}"[:48], font=fr, fill=(255, 255, 255, 255))
    xt = int(pw * 0.05)
    if foto:
        fw, fh = int(pw * 0.3), int(ph * 0.62)
        try:
            im = ImageOps.fit(Image.open(foto).convert("RGB"), (fw, fh), Image.LANCZOS, centering=(0.5, 0.3))
            im = _tratar_foto(im, t)
            painel.paste(im, (int(pw * 0.04), cab + int(ph * 0.06)))
            dc.rectangle([int(pw * 0.04), cab + int(ph * 0.06), int(pw * 0.04) + fw, cab + int(ph * 0.06) + fh], outline=(230, 230, 230, 255), width=3)
            xt = int(pw * 0.38)
        except Exception:
            pass
    linhas = []
    fc = fonte(LEVE, max(14, H // 44))
    fv = fonte(SANS, max(18, H // 32))
    y = cab + int(ph * 0.07)
    larg = pw - xt - pw * 0.05
    for it in itens[:6]:
        campo, valor = _par(it)
        if not valor:
            campo, valor = "", campo
        cv = _canvas(W, H)
        d2 = ImageDraw.Draw(cv)
        if campo:
            d2.text((px + xt, py + y), campo.upper(), font=fc, fill=t["acc"] + (255,))
            y += fc.size * 1.35
        for l in _quebrar(valor, fv, larg, d2)[:2]:
            d2.text((px + xt, py + y), l, font=fv, fill=(245, 245, 245, 255))
            y += fv.size * 1.25
        y += H * 0.012
        linhas.append(cv)
        if y > ph * 0.95:
            break
    return _sombra(painel, 16, 150), (px, py), linhas


def quadros_numero(texto, rotulo, W, H, t, pasta, fps=20, seg=1.3):
    """Número grande contando até o valor (com brilho). Retorna (padrão_seq, n_quadros, fps)."""
    os.makedirs(pasta, exist_ok=True)
    num = _numero(texto)
    tam = max(60, H // 4)
    f = fonte(IMPACTO, tam)
    while _medir(f, texto)[0] > W * 0.86 and tam > 30:
        tam -= 8
        f = fonte(IMPACTO, tam)
    n = max(2, int(seg * fps)) if num else 1
    for k in range(1, n + 1):
        if num:
            pre, val, casas, suf, dec = num
            u = k / n
            e = 1 - pow(1 - u, 3)
            s = pre + _fmt_num(val * e if k < n else val, casas, dec) + suf
        else:
            s = texto
        cam = _canvas(W, H)
        dc = ImageDraw.Draw(cam)
        dc.text((W / 2, H * 0.44), s, font=f, anchor="ms", fill=t["txt"] + (255,), stroke_width=max(2, tam // 40), stroke_fill=(0, 0, 0, 200))
        cam = _brilho(cam, t["acc"], max(10, tam // 7), 1.3)
        cam.save(os.path.join(pasta, f"num_{k:03d}.png"), compress_level=1)
    rot = None
    if rotulo:
        rot = _canvas(W, H)
        fr = fonte(SANS, max(22, H // 20))
        dc = ImageDraw.Draw(rot)
        rw, _ = _medir(fr, rotulo.upper())
        dc.rectangle([(W - rw) / 2 - H * 0.02, H * 0.49, (W + rw) / 2 + H * 0.02, H * 0.49 + fr.size * 1.45], fill=t["acc"] + (235,))
        dc.text(((W - rw) / 2, H * 0.49 + fr.size * 0.12), rotulo.upper(), font=fr, fill=(255, 255, 255, 255))
    return os.path.join(pasta, "num_%03d.png"), n, fps, rot


def quadros_escala(itens, W, H, t, pasta, fps=20, seg=1.4):
    """Comparação de escala: barras crescendo até o valor de cada item."""
    os.makedirs(pasta, exist_ok=True)
    dados = []
    for it in itens[:5]:
        nome, val = _par(it)
        num = _numero(val) or _numero(nome)
        if num:
            dados.append((nome if val else "", val or nome, num))
    if len(dados) < 2:
        return None
    mx = max(d[2][1] for d in dados) or 1
    n_b = len(dados)
    base_y = int(H * 0.70)
    alt_max = H * 0.48
    bw = int(min(W * 0.13, W * 0.7 / n_b * 0.6))
    passo = W * 0.76 / n_b
    fn = fonte(SANS, max(16, H // 34))
    fv = fonte(IMPACTO, max(22, H // 20))
    n = max(2, int(seg * fps))
    for k in range(1, n + 1):
        e = 1 - pow(1 - k / n, 3)
        cam = _canvas(W, H)
        dc = ImageDraw.Draw(cam)
        dc.line([(W * 0.08, base_y), (W * 0.92, base_y)], fill=t["txt"] + (200,), width=3)
        for j, (nome, val, num) in enumerate(dados):
            cx = int(W * 0.12 + passo * (j + 0.5))
            h = max(4, alt_max * (num[1] / mx) * e)
            maior = num[1] == mx
            cor = t["acc"] if maior else tuple(int(c * 0.75) for c in t["txt"])
            dc.rectangle([cx - bw / 2, base_y - h, cx + bw / 2, base_y], fill=cor + (255,))
            vs = val if k == n else num[0] + _fmt_num(num[1] * e, num[2], num[4]) + num[3]
            vw, vh = _medir(fv, vs)
            dc.text((cx - vw / 2, base_y - h - vh - H * 0.025), vs, font=fv, fill=(255, 255, 255, 255), stroke_width=2, stroke_fill=(0, 0, 0, 220))
            yy = base_y + H * 0.02
            for l in _quebrar(nome, fn, passo * 0.95, dc)[:2]:
                lw, _ = _medir(fn, l)
                dc.text((cx - lw / 2, yy), l, font=fn, fill=(240, 240, 240, 255), stroke_width=2, stroke_fill=(0, 0, 0, 220))
                yy += fn.size * 1.25
        cam.save(os.path.join(pasta, f"esc_{k:03d}.png"), compress_level=1)
    return os.path.join(pasta, "esc_%03d.png"), n, fps


def quadros_documento(frase, destaque, fonte_txt, W, H, t, pasta, rotulo="CONFIDENCIAL", fps=20, seg=2.0):
    """Documento com tarjas pretas: as tarjas da frase saem e a palavra-chave é marcada. Retorna (seq, n, fps, x, y)."""
    os.makedirs(pasta, exist_ok=True)
    rnd = random.Random(len(frase))
    pw, ph = int(W * 0.6), int(H * 0.9)
    tam = max(16, H // 30)
    f = fonte(MONO, tam)
    d = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    mx = int(pw * 0.09)
    larg = pw - 2 * mx
    linhas_f = _quebrar(frase, f, larg, d)[:6]
    passo = int(tam * 1.7)
    topo = int(ph * 0.2)
    # linhas de enchimento (tarjadas) antes e depois da frase
    antes = rnd.randint(2, 3)
    total_l = int((ph * 0.9 - topo) / passo)
    depois = max(0, min(4, total_l - antes - len(linhas_f)))
    dest = (destaque or "").strip().lower()
    n = max(2, int(seg * fps))
    caminhos = []
    for k in range(1, n + 1):
        u = k / n
        pg = Image.new("RGBA", (pw, ph), t["papel"] + (255,))
        dc = ImageDraw.Draw(pg)
        ruido = Image.effect_noise((pw // 4, ph // 4), 25).resize((pw, ph)).convert("L").point(lambda p: p // 10)
        pg = Image.composite(Image.new("RGBA", (pw, ph), tuple(max(0, c - 18) for c in t["papel"]) + (255,)), pg, ruido)
        dc = ImageDraw.Draw(pg)
        fc = fonte(SANS, max(14, H // 40))
        dc.text((mx, ph * 0.06), (fonte_txt or "DOCUMENTO").upper()[:50], font=fc, fill=t["tinta"] + (255,))
        dc.line([(mx, ph * 0.06 + fc.size * 1.6), (pw - mx, ph * 0.06 + fc.size * 1.6)], fill=t["tinta"] + (255,), width=2)
        # carimbo
        fs = fonte(SANS, max(18, H // 26))
        sw, sh = _medir(fs, rotulo)
        car = Image.new("RGBA", (sw + 30, sh + 26), (0, 0, 0, 0))
        dcar = ImageDraw.Draw(car)
        dcar.rectangle([2, 2, car.width - 3, car.height - 3], outline=t["acc"] + (210,), width=4)
        dcar.text((15, 6), rotulo, font=fs, fill=t["acc"] + (210,))
        car = car.rotate(-12, resample=Image.BICUBIC, expand=True)
        pg.alpha_composite(car, (int(pw * 0.62), int(ph * 0.025)))
        y = topo
        for _ in range(antes):
            dc.rectangle([mx, y, mx + larg * (0.6 + 0.4 * ((y * 37) % 100) / 100), y + tam * 1.1], fill=(14, 14, 14, 255))
            y += passo
        fase_tarja = min(1, max(0, (u - 0.25) / 0.45))  # 25%..70%: tarjas saem
        fase_marca = min(1, max(0, (u - 0.72) / 0.25))  # 72%..97%: marca-texto
        for j, l in enumerate(linhas_f):
            x = mx
            for pal in l.split(" "):
                pw_, _ = _medir(f, pal + " ")
                limpo = pal.strip(".,;:!?\"“”'").lower()
                if dest and limpo and (limpo == dest or (len(dest.split()) > 1 and limpo in dest.split())) and fase_marca > 0:
                    ww, _ = _medir(f, pal)
                    dc.rectangle([x - 3, y - 2, x + (ww + 6) * fase_marca - 3, y + tam * 1.15], fill=(255, 226, 60, 255))
                x += pw_
            dc.text((mx, y), l, font=f, fill=t["tinta"] + (255,))
            # tarja desta linha saindo para a direita (uma linha depois da outra)
            lf = min(1, max(0, fase_tarja * len(linhas_f) - j))
            lw, _ = _medir(f, l)
            if lf < 1:
                dc.rectangle([mx + lw * lf, y - 2, mx + lw + 4, y + tam * 1.15], fill=(14, 14, 14, 255))
            y += passo
        for q in range(depois):
            dc.rectangle([mx, y, mx + larg * (0.5 + 0.5 * ((q * 53 + 17) % 100) / 100), y + tam * 1.1], fill=(14, 14, 14, 255))
            y += passo
        pg = _sombra(pg.rotate(-1.5, resample=Image.BICUBIC, expand=True), 18, 160)
        p = os.path.join(pasta, f"doc_{k:03d}.png")
        pg.save(p, compress_level=1)
        caminhos.append(p)
    w0, h0 = Image.open(caminhos[-1]).size
    return os.path.join(pasta, "doc_%03d.png"), n, fps, (W - w0) // 2, (H - h0) // 2


def camadas_capitulo(numero, titulo, W, H, t, rotulo="PARTE"):
    romano = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]
    parte = f"{rotulo} {romano[numero - 1] if 0 < numero <= len(romano) else numero}"
    c1 = _canvas(W, H)
    dc = ImageDraw.Draw(c1)
    fp = fonte(SANS, max(22, H // 19))
    pw_, ph_ = _medir(fp, parte)
    y = H * 0.36
    dc.text(((W - pw_) / 2, y), parte, font=fp, fill=t["acc"] + (255,))
    dc.line([(W / 2 - pw_ / 2 - W * 0.12, y + ph_ * 0.6), (W / 2 - pw_ / 2 - W * 0.02, y + ph_ * 0.6)], fill=t["acc"] + (255,), width=3)
    dc.line([(W / 2 + pw_ / 2 + W * 0.02, y + ph_ * 0.6), (W / 2 + pw_ / 2 + W * 0.12, y + ph_ * 0.6)], fill=t["acc"] + (255,), width=3)
    c2 = _canvas(W, H)
    dc = ImageDraw.Draw(c2)
    tam = max(34, H // 10)
    ft = fonte(t["titulo"], tam)
    linhas = _quebrar(titulo, ft, W * 0.8, dc)
    while len(linhas) > 2 and tam > 24:
        tam -= 6
        ft = fonte(t["titulo"], tam)
        linhas = _quebrar(titulo, ft, W * 0.8, dc)
    yy = H * 0.45
    for l in linhas[:3]:
        lw, _ = _medir(ft, l)
        dc.text(((W - lw) / 2, yy), l, font=ft, fill=t["txt"] + (255,))
        yy += tam * 1.2
    return _brilho(c1, t["acc"], 8, 0.8), _brilho(c2, (0, 0, 0), 14, 1.4)


def camadas_frase(frase, W, H, t, pasta, fps=20):
    """Frase de impacto entre cantoneiras, com brilho, aparecendo letra por letra."""
    tam = max(30, H // 12)
    f = fonte(t["titulo"], tam)
    d = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    linhas = _quebrar(frase, f, W * 0.66, d)
    while len(linhas) > 3 and tam > 22:
        tam -= 4
        f = fonte(t["titulo"], tam)
        linhas = _quebrar(frase, f, W * 0.66, d)
    alt = int(tam * 1.3) * len(linhas)
    larg = max(d.textlength(l, font=f) for l in linhas)
    y0 = (H - alt) // 2 - int(H * 0.04)
    x0, x1 = (W - larg) / 2 - H * 0.06, (W + larg) / 2 + H * 0.06
    yt, yb = y0 - H * 0.05, y0 + alt + H * 0.04
    cant = _canvas(W, H)
    dc = ImageDraw.Draw(cant)
    L, e = H * 0.06, max(4, H // 180)
    for (cx, cy, sx, sy) in ((x0, yt, 1, 1), (x1, yt, -1, 1), (x0, yb, 1, -1), (x1, yb, -1, -1)):
        dc.line([(cx, cy + sy * L), (cx, cy), (cx + sx * L, cy)], fill=t["acc"] + (255,), width=e, joint="curve")
    cant = _brilho(cant, t["acc"], 10, 1.2)
    seq, n, fpt, _ = frames_digitando(frase, W, H, pasta, "frase", fps_txt=fps, fonte_lista=t["titulo"], tam=tam, largura=0.66,
                                      cor=t["txt"] + (255,), contorno=False, max_seg=1.6, brilho=t["acc"], y0=y0)
    return cant, (seq, n, fpt)


def tarja_nome(nome, funcao, W, H, t):
    fn = fonte(SANS, max(24, H // 20))
    ff_ = fonte(LEVE, max(16, H // 34))
    nw, nh = _medir(fn, nome)
    fw, fh = _medir(ff_, funcao or "")
    pad = int(H * 0.022)
    w = int(max(nw, fw) + pad * 3)
    h = int(nh + (fh + pad * 0.6 if funcao else 0) + pad * 2.2)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dc = ImageDraw.Draw(im)
    dc.rectangle([0, 0, w, h], fill=(10, 10, 12, 215))
    dc.rectangle([0, 0, max(5, H // 140), h], fill=t["acc"] + (255,))
    dc.text((pad * 1.6, pad * 0.7), nome, font=fn, fill=(255, 255, 255, 255))
    if funcao:
        dc.text((pad * 1.6, pad * 0.7 + nh + pad * 0.8), funcao, font=ff_, fill=t["acc"] + (255,) if t["acc"] != (200, 16, 46) else (230, 230, 230, 255))
    return _sombra(im, 10, 120)


def quadros_sequencia(fotos, W, H, dur, fps, t, pasta):
    """Match cut: fotos em sequência rápida, com zoom lento e um flash branco no corte. Grava JPGs."""
    os.makedirs(pasta, exist_ok=True)
    fotos = [f for f in fotos if f and os.path.exists(f)][:5]
    ims = []
    for f in fotos:
        try:
            im = ImageOps.fit(Image.open(f).convert("RGB"), (int(W * 1.08), int(H * 1.08)), Image.LANCZOS)
            ims.append(_tratar_foto(im, t) if t["foto"] != "cor" else im)
        except Exception:
            continue
    if len(ims) < 2:
        return None
    total = max(2, int(round(dur * fps)))
    cada = total / len(ims)
    branco = Image.new("RGB", (W, H), (255, 255, 255))
    for k in range(total):
        j = min(len(ims) - 1, int(k / cada))
        u = (k - j * cada) / cada
        z = 1.0 + 0.07 * u
        im = ims[j]
        cw, ch = int(im.width / z / 1.08 * 1.0), int(im.height / z / 1.08)
        x0, y0 = (im.width - cw) // 2, (im.height - ch) // 2
        fr = im.crop((x0, y0, x0 + cw, y0 + ch)).resize((W, H), Image.BILINEAR)
        dk = k - int(j * cada)
        if j > 0 and dk < 3:
            fr = Image.blend(fr, branco, [0.75, 0.4, 0.15][dk])
        fr.save(os.path.join(pasta, f"seq_{k + 1:04d}.jpg"), quality=90)
    return os.path.join(pasta, "seq_%04d.jpg")


def camada_alvo(W, H, t, nome):
    """Alfinete do mapa no centro + plaquinha com o nome do lugar."""
    cv = _canvas(W, H)
    dc = ImageDraw.Draw(cv)
    cx, cy = W // 2, H // 2
    r = max(12, H // 45)
    dc.ellipse([cx - r * 2.4, cy - r * 0.8, cx + r * 2.4, cy + r * 0.8], outline=t["acc"] + (200,), width=3)
    dc.polygon([(cx, cy), (cx - r, cy - r * 1.6), (cx + r, cy - r * 1.6)], fill=t["acc"] + (255,))
    dc.ellipse([cx - r * 1.15, cy - r * 3.1, cx + r * 1.15, cy - r * 0.9], fill=t["acc"] + (255,))
    dc.ellipse([cx - r * 0.45, cy - r * 2.45, cx + r * 0.45, cy - r * 1.55], fill=(255, 255, 255, 255))
    cv = _brilho(cv, (0, 0, 0), 8, 1.2)
    placa = None
    if nome:
        fn = fonte(SANS, max(22, H // 24))
        nw, nh = _medir(fn, nome.upper())
        placa = Image.new("RGBA", (int(nw + H * 0.05), int(nh + H * 0.04)), (10, 10, 12, 220))
        d2 = ImageDraw.Draw(placa)
        d2.rectangle([0, placa.height - max(4, H // 200), placa.width, placa.height], fill=t["acc"] + (255,))
        d2.text((H * 0.025, H * 0.012), nome.upper(), font=fn, fill=(255, 255, 255, 255))
        placa = _sombra(placa, 10, 140)
    return cv, placa


def _quadro_do_trecho(ff, rodar, trecho, saida, seg=0.5):
    try:
        rodar([ff, "-y", "-ss", f"{seg:.2f}", "-i", trecho, "-frames:v", "1", "-q:v", "3", saida])
        return saida if os.path.exists(saida) else None
    except Exception:
        return None


# ------------------------------------------------------------------ montagem no FFmpeg
def _anim_xy(x_final, y_final, de, t0, dur=0.55, W=1920, H=1080):
    """Expressões de posição (entra deslizando com desaceleração)."""
    p = f"min(1,max(0,(t-{t0:.2f})/{dur}))"
    e = f"(1-pow(1-{p},3))"
    if de == "baixo":
        return f"{x_final}", f"{y_final}+({H}*0.35)*(1-{e})"
    if de == "esq":
        return f"{x_final}-({W}*0.45)*(1-{e})", f"{y_final}"
    if de == "dir":
        return f"{x_final}+({W}*0.45)*(1-{e})", f"{y_final}"
    if de == "cai":  # cai um pouquinho (foto sendo presa no quadro)
        return f"{x_final}", f"{y_final}-({H}*0.05)*(1-{e})"
    if de == "sobe":
        return f"{x_final}", f"{y_final}+({H}*0.04)*(1-{e})"
    return f"{x_final}", f"{y_final}"


def aplicar(i, cena, dur, trecho, W, H, fps, estilo, pasta_tmp, ff, rodar, idioma="pt"):
    """Recebe o trecho já montado (mídia com movimento) e grava por cima a montagem da cena. Substitui o arquivo."""
    lay = cena.get("layout") or "midia"
    txt = (cena.get("layout_texto") or "").strip()
    imgs = [p for p in (cena.get("layout_imgs_abs") or []) if p and os.path.exists(p)]
    t = tema(estilo)
    rot = ROTULOS.get(idioma, ROTULOS["pt"])
    tmp = os.path.join(pasta_tmp, f"lay_{i}")
    os.makedirs(tmp, exist_ok=True)
    entradas = []  # (fonte, x, y, t0, de)
    fundo_filtro = None
    fundo_img = None
    fundo_seq = None  # (padrão, fps)
    escurecer = "boxblur=6:1,eq=brightness=-0.32:saturation=0.55"

    def png(im, nome):
        p = os.path.join(tmp, nome)
        im.save(p, compress_level=1)
        return p

    def seq(padrao, fps_s, n, t0=0.2, x="0", y="0"):
        entradas.append(({"seq": padrao, "fps": fps_s, "n": n, "x": x, "y": y}, x, y, t0, None))

    if lay in ("pessoa", "duas_pessoas") and imgs:
        nomes = cena.get("layout_nomes") or cena.get("pessoas") or ([cena.get("pessoa_real")] if cena.get("pessoa_real") else [])
        fundo_filtro = "boxblur=12:2,eq=brightness=-0.18:saturation=0.75"
        qtd = 2 if lay == "duas_pessoas" and len(imgs) >= 2 else 1
        for k in range(qtd):
            nm = nomes[k] if k < len(nomes) else ""
            c = cartao(imgs[k], nm.upper() if estilo == "jornal" else nm, H, estilo,
                       angulo=(-2.5 if k == 0 else 3) if estilo in ("true_crime", "historia", "horror") else 0)
            p = png(c, f"card{k}.png")
            if qtd == 1:  # cartões na parte de cima: o nome fica acima da legenda
                x, y = f"(W-{c.width})/2", "H*0.03"
            else:
                x = f"W*0.27-{c.width}/2" if k == 0 else f"W*0.73-{c.width}/2"
                y = "H*0.02" if k == 0 else "H*0.07"
            entradas.append((p, x, y, 0.15 + k * 0.7, "baixo"))
    elif lay == "data" and txt:
        fundo_filtro = "eq=brightness=-0.1"
        s_, n, fpt, _ = frames_digitando(txt, W, H, tmp, "data", tam=max(28, H // 11), max_seg=1.4, fonte_lista=t["titulo"])
        seq(s_, fpt, n)
    elif lay == "local" and txt:
        p = png(placa_local(txt, W, H, estilo), "local.png")
        entradas.append((p, "W*0.06", "H*0.70", 0.3, "esq"))
    elif lay == "ano" and txt:
        p = png(selo_ano(txt[:10], H), "ano.png")
        entradas.append((p, "W*0.05", "H*0.07", 0.2, None))
    elif lay == "citacao" and txt:
        fundo_img = png(fundo_documento(W, H), "doc.png")
        s_, n, fpt, y_fim = frames_digitando("“" + txt.strip("\"“”") + "”", W, H, tmp, "cit", fonte_lista=MONO, tam=max(22, H // 19),
                                            largura=0.8, pos="topo", cor=(232, 228, 216, 255), contorno=False,
                                            max_seg=min(max(1.5, dur * 0.6), 6))
        seq(s_, fpt, n)
        et = png(etiqueta(rot["frase"], H, t["acc"]), "etq.png")
        entradas.append((et, "W*0.1", f"{min(int(y_fim + H * 0.03), int(H * 0.82))}", 0.6, "esq"))
        if cena.get("layout_fonte"):
            cr = png(credito(cena["layout_fonte"], H), "fonte.png")
            entradas.append((cr, "W*0.1", f"{min(int(y_fim + H * 0.11), int(H * 0.9))}", 1.0, None))
    elif lay == "colagem" and len(imgs) >= 2:
        fundo_img = png(colagem(imgs, W, H, estilo), "colagem.png")
    elif lay == "quadro":
        fotos = imgs[:4] or [x for x in [_quadro_do_trecho(ff, rodar, trecho, os.path.join(tmp, "q0.jpg"), min(0.5, dur / 2))] if x]
        if fotos:
            fundo_img = png(fundo_quadro(W, H, t), "cortica.png")
            nomes = cena.get("layout_nomes") or []  # nome só na foto que é mesmo daquela pessoa
            fotos_c, fio, notas = camadas_quadro(fotos, _itens(txt, 3), W, H, t, nomes)
            passo = min(0.45, max(0.2, (dur - 1.2) / max(1, len(fotos_c) + len(notas) + 1)))
            tt = 0.1
            for k, c in enumerate(fotos_c):
                entradas.append((png(c, f"q{k}.png"), "0", "0", tt, "cai"))
                tt += passo
            for k, c in enumerate(notas):
                entradas.append((png(c, f"n{k}.png"), "0", "0", tt, "cai"))
                tt += passo
            if fio:  # o fio vermelho entra por último, ligando o que já está no quadro
                entradas.append((png(fio, "fio.png"), "0", "0", tt, None))
    elif lay == "linha_tempo" and _itens(txt):
        fundo_filtro = escurecer
        base, marcos = camadas_linha_tempo(_itens(txt, 5), W, H, t)
        entradas.append((png(base, "lt.png"), "0", "0", 0.1, None))
        passo = min(0.7, max(0.3, (dur - 1) / max(1, len(marcos))))
        for k, c in enumerate(marcos):
            entradas.append((png(c, f"lt{k}.png"), "0", "0", 0.35 + k * passo, "sobe"))
    elif lay == "ficha" and _itens(txt):
        fundo_filtro = "boxblur=8:1,eq=brightness=-0.22:saturation=0.6"
        titulo = cena.get("pessoa_real") or (cena.get("pessoas") or [""])[0] or ""
        painel, (px, py), linhas = camadas_ficha(_itens(txt, 6), titulo, imgs[0] if imgs else None, W, H, t, rot["arquivo"],
                                                 centro=bool(cena.get("fundo_neutro")))
        entradas.append((png(painel, "ficha.png"), str(px - 16 * 2), str(py - 16 * 2), 0.1, "dir"))
        for k, c in enumerate(linhas):
            entradas.append((png(c, f"fl{k}.png"), "0", "0", 0.6 + k * 0.32, None))
    elif lay == "numero" and txt:
        fundo_filtro = escurecer
        valor, rotulo = (_itens(txt, 2) + [""])[:2]
        s_, n, fpt, rot_cam = quadros_numero(valor, rotulo, W, H, t, os.path.join(tmp, "num"))
        seq(s_, fpt, n, 0.15)
        if rot_cam:
            entradas.append((png(rot_cam, "rot.png"), "0", "0", 0.15 + n / fpt * 0.7, "sobe"))
    elif lay == "escala" and len(_itens(txt)) >= 2:
        r_ = quadros_escala(_itens(txt, 5), W, H, t, os.path.join(tmp, "esc"))
        if r_:
            fundo_filtro = escurecer
            seq(r_[0], r_[2], r_[1], 0.15)
    elif lay == "documento" and txt:
        fundo_img = png(fundo_documento(W, H), "mesa.png")
        s_, n, fpt, x, y = quadros_documento(txt.strip("\"“”"), cena.get("layout_destaque") or "", cena.get("layout_fonte") or "",
                                             W, H, t, os.path.join(tmp, "doc"), rot["confidencial"], seg=min(2.4, max(1.4, dur * 0.55)))
        seq(s_, fpt, n, 0.0, str(x), str(y))
    elif lay == "capitulo" and txt:
        fundo_filtro = "boxblur=18:2,eq=brightness=-0.28:saturation=0.4"
        c1, c2 = camadas_capitulo(int(cena.get("capitulo_num") or 1), txt, W, H, t, rot["parte"])
        entradas.append((png(c1, "cap1.png"), "0", "0", 0.15, "sobe"))
        entradas.append((png(c2, "cap2.png"), "0", "0", 0.55, "sobe"))
    elif lay == "frase" and txt:
        fundo_filtro = "boxblur=5:1,eq=brightness=-0.2:saturation=0.6"
        cant, (s_, n, fpt) = camadas_frase(txt.strip("\"“”"), W, H, t, os.path.join(tmp, "fr"))
        entradas.append((png(cant, "cant.png"), "0", "0", 0.05, None))
        seq(s_, fpt, n, 0.3)
    elif lay == "nome" and txt:
        nome, funcao = (_itens(txt, 2) + [""])[:2]
        p = png(tarja_nome(nome, funcao, W, H, t), "nome.png")
        entradas.append((p, "W*0.045", "H*0.60", 0.25, "esq"))
    elif lay == "sequencia" and len(imgs) >= 2:
        s_ = quadros_sequencia(imgs, W, H, dur, fps, t, os.path.join(tmp, "sq"))
        if s_:
            fundo_seq = (s_, fps)
    elif lay == "mapa" and cena.get("layout_mapa_abs"):
        from core import satelite

        s_ = satelite.quadros_zoom(cena["layout_mapa_abs"], W, H, dur, fps, os.path.join(tmp, "mp"))
        if s_:
            fundo_seq = (s_, fps)
            alvo, placa = camada_alvo(W, H, t, txt or cena.get("lugar") or "")
            t_pin = max(0.3, dur * 0.72)
            entradas.append((png(alvo, "pin.png"), "0", "0", t_pin, "cai"))
            if placa:
                entradas.append((png(placa, "placa.png"), f"(W-{placa.width})/2", f"H/2+{int(H * 0.04)}", t_pin + 0.25, "sobe"))
            entradas.append((png(credito(rot["sat"], H), "sat.png"), "W-w-W*0.02", "H*0.03", 0, None))

    # cena resgatada (a imagem original não combinava): o efeito vai sobre um fundo escuro com textura, sem a imagem ruim
    if cena.get("fundo_neutro") and not fundo_img and not fundo_seq and (entradas or lay != "midia"):
        fundo_img = png(fundo_documento(W, H), "neutro.png")
    # brilho de lente nos estilos quentes (algumas cenas, para não cansar)
    if estilo in ("true_crime", "historia") and i % 6 == 3 and not fundo_seq and lay == "midia":
        entradas.append((png(brilho_lente(W, H, "esq" if i % 2 else "dir"), "leak.png"), "0", "0", 0, "leak"))
    # crédito de imagens de canais de notícia
    m = cena.get("midia") or {}
    if m.get("fonte") == "YouTube (notícia)" and m.get("autor") and lay != "mapa":
        entradas.append((png(credito(f"Imagens: {m['autor']}", H), "cred.png"), "W-w-W*0.02", "H*0.03", 0, None))

    if not entradas and not fundo_img and not fundo_seq:
        return False

    args = [ff, "-y"]
    frames = max(1, int(round(dur * fps)))
    if fundo_seq:
        args += ["-framerate", str(fundo_seq[1]), "-i", fundo_seq[0]]
        cadeia = [f"[0:v]scale={W}:{H},setsar=1,format=yuv420p,tpad=stop_mode=clone:stop_duration={dur + 1:.2f}[b0]"]
    elif fundo_img:
        # fundo desenhado (documento/colagem/quadro) com zoom lento
        args += ["-loop", "1", "-framerate", str(fps), "-t", f"{dur:.3f}", "-i", fundo_img]
        cadeia = [f"[0:v]scale={int(W * 1.08)}:{int(H * 1.08)},zoompan=z='min(1+0.05*on/{frames},1.05)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'"
                  f":d=1:s={W}x{H}:fps={fps},setsar=1,format=yuv420p[b0]"]
    else:
        args += ["-i", trecho]
        cadeia = [f"[0:v]{fundo_filtro or 'null'},format=yuv420p[b0]"]
    atual = "b0"
    for n_, (src, x, y, t0, de) in enumerate(entradas):
        idx = n_ + 1
        if isinstance(src, dict):  # sequência de quadros: segura o último quadro até o fim
            args += ["-framerate", str(src["fps"]), "-i", src["seq"]]
            cadeia.append(f"[{idx}:v]format=rgba,setpts=PTS+{t0:.2f}/TB,tpad=stop_mode=clone:stop_duration={dur + 1:.2f}[l{n_}]")
            cadeia.append(f"[{atual}][l{n_}]overlay={src.get('x', '0')}:{src.get('y', '0')}:eof_action=repeat[s{n_}]")
        elif de == "leak":
            args += ["-loop", "1", "-framerate", str(fps), "-t", f"{dur:.3f}", "-i", src]
            cadeia.append(f"[{idx}:v]format=rgba,fade=t=in:st=0:d=0.35:alpha=1,fade=t=out:st=0.55:d=0.6:alpha=1[l{n_}]")
            cadeia.append(f"[{atual}][l{n_}]overlay=0:0[s{n_}]")
        else:
            args += ["-loop", "1", "-framerate", str(fps), "-t", f"{dur:.3f}", "-i", src]
            ex, ey = _anim_xy(x, y, de, t0, W=W, H=H)
            cadeia.append(f"[{idx}:v]format=rgba,fade=t=in:st={t0:.2f}:d=0.4:alpha=1[l{n_}]")
            cadeia.append(f"[{atual}][l{n_}]overlay=x='{ex}':y='{ey}':eval=frame[s{n_}]")
        atual = f"s{n_}"
    saida = os.path.join(tmp, "saida.mp4")
    args += ["-filter_complex", ";".join(cadeia), "-map", f"[{atual}]", "-t", f"{dur:.3f}", "-r", str(fps),
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-an", saida]
    rodar(args)
    os.replace(saida, trecho)
    return True
