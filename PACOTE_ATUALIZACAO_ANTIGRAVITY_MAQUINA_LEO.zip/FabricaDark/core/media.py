"""Busca de mídia real por cena (Wikimedia Commons, Pixabay, Pexels), nota de aderência e download."""
import os
import re
import unicodedata

import requests

UA = "FabricaDark/1.0 (ferramenta pessoal de producao de video; contato local)"
TIMEOUT = 20

STOP = set(
    "a an the of in on at to for and or with from by is are was were be as into over under this that "
    "de da do das dos e o os as um uma em no na nos nas com por para".split()
)


def _norm(t):
    t = unicodedata.normalize("NFKD", (t or "").lower())
    t = "".join(ch for ch in t if not unicodedata.combining(ch))
    return re.findall(r"[a-z0-9]+", t)


def _tokens(t):
    return [w for w in _norm(t) if w not in STOP and len(w) > 1]


def pontuar(termo, texto_candidato, termo_idx=0, pessoa=""):
    q = _tokens(termo)
    if not q:
        return 0, "generica"
    cand = set(_tokens(texto_candidato))
    # aceita plural simples
    def has(w):
        return w in cand or (w.endswith("s") and w[:-1] in cand) or (w + "s") in cand

    frac = sum(1 for w in q if has(w)) / len(q)
    nota = frac * 10 - termo_idx * 1.2
    if pessoa:
        p = _tokens(pessoa)
        if p and all(has(w) for w in p):
            nota += 2
        elif p:
            nota -= 3
    nota = max(0, min(10, round(nota, 1)))
    if nota >= 8:
        match = "exata"
    elif nota >= 4:
        match = "parecida"
    else:
        match = "generica"
    return nota, match


# ---------------- provedores ----------------

import threading as _threading
import time as _time

_WIKI_LOCK = _threading.Lock()
_WIKI_ULTIMO = [0.0]


def _wiki_api(params):
    """Uma consulta por vez ao Wikimedia, com intervalo, e espera/tenta de novo se ele pedir calma (429)."""
    for tentativa in range(5):
        with _WIKI_LOCK:
            espera = 1.0 - (_time.time() - _WIKI_ULTIMO[0])
            if espera > 0:
                _time.sleep(espera)
            r = requests.get("https://commons.wikimedia.org/w/api.php", params=dict(params, maxlag=5),
                             headers={"User-Agent": UA}, timeout=TIMEOUT)
            _WIKI_ULTIMO[0] = _time.time()
        if r.status_code == 429 or (r.ok and (r.json().get("error") or {}).get("code") == "maxlag"):
            _time.sleep(float(r.headers.get("Retry-After") or 0) or 5 * (tentativa + 1))
            continue
        r.raise_for_status()
        return r.json()
    r.raise_for_status()
    return r.json()


def buscar_wikimedia(termo, limite=12, aceitar_sa=False):
    params = {
        "action": "query",
        "format": "json",
        "generator": "search",
        "gsrsearch": f"{termo} filetype:bitmap",
        "gsrnamespace": 6,
        "gsrlimit": limite,
        "prop": "imageinfo",
        "iiprop": "url|size|extmetadata|mime",
        "iiurlwidth": 1920,
    }
    pages = (_wiki_api(params).get("query") or {}).get("pages") or {}
    out = []
    for p in sorted(pages.values(), key=lambda x: x.get("index", 0)):
        ii = (p.get("imageinfo") or [{}])[0]
        if not ii or ii.get("width", 0) < 640:
            continue
        meta = ii.get("extmetadata") or {}
        desc = re.sub(r"<[^>]+>", " ", (meta.get("ImageDescription") or {}).get("value", ""))
        cats = (meta.get("Categories") or {}).get("value", "").replace("|", " ")
        titulo = p.get("title", "").replace("File:", "")
        lic = re.sub(r"<[^>]+>", "", (meta.get("LicenseShortName") or {}).get("value", ""))
        from core.fontes import licenca_ok

        if not licenca_ok(lic, aceitar_sa):
            continue
        thumb = ii.get("thumburl") or ii.get("url")
        out.append(
            {
                "fonte": "Wikimedia Commons",
                "tipo": "foto",
                "preview": thumb.replace("/1920px-", "/500px-") if "/1920px-" in thumb else thumb,
                "download": thumb,
                "titulo": titulo,
                "texto_match": f"{titulo} {desc} {cats}",
                "licenca": re.sub(r"<[^>]+>", "", (meta.get("LicenseShortName") or {}).get("value", "")),
                "autor": re.sub(r"<[^>]+>", "", (meta.get("Artist") or {}).get("value", ""))[:80],
                "pagina": ii.get("descriptionurl", ""),
                "largura": ii.get("width"),
                "altura": ii.get("height"),
            }
        )
    return out


def buscar_wikimedia_video(termo, limite=8, aceitar_sa=False):
    """Vídeos (webm) do Wikimedia Commons com licença livre."""
    from core.fontes import licenca_ok

    params = {"action": "query", "format": "json", "generator": "search", "gsrsearch": f"{termo} filetype:video",
              "gsrnamespace": 6, "gsrlimit": limite, "prop": "imageinfo", "iiprop": "url|size|extmetadata|mime", "iiurlwidth": 500}
    out = []
    for p in sorted(((_wiki_api(params).get("query") or {}).get("pages") or {}).values(), key=lambda x: x.get("index", 0)):
        ii = (p.get("imageinfo") or [{}])[0]
        if not ii or not ii.get("url") or (ii.get("size") or 0) > 150_000_000:
            continue
        meta = ii.get("extmetadata") or {}
        lic = re.sub(r"<[^>]+>", "", (meta.get("LicenseShortName") or {}).get("value", ""))
        if not licenca_ok(lic, aceitar_sa):
            continue
        titulo = p.get("title", "").replace("File:", "")
        desc = re.sub(r"<[^>]+>", " ", (meta.get("ImageDescription") or {}).get("value", ""))
        cats = (meta.get("Categories") or {}).get("value", "").replace("|", " ")
        out.append({"fonte": "Wikimedia Commons", "tipo": "video", "preview": ii.get("thumburl") or "", "download": ii["url"],
                    "titulo": titulo, "texto_match": f"{titulo} {desc} {cats}", "licenca": lic,
                    "autor": re.sub(r"<[^>]+>", "", (meta.get("Artist") or {}).get("value", ""))[:80],
                    "pagina": ii.get("descriptionurl", ""), "largura": ii.get("width"), "altura": ii.get("height")})
    return out


def bonus_video(c, cena, settings):
    """Quanto um vídeo 'vale a mais' que uma foto, conforme a preferência do vídeo."""
    pref = settings.get("preferencia_midia", "equilibrado")
    if c.get("tipo") != "video":
        return 0.0
    if pref == "videos":
        return 1.5 if cena.get("pessoa_real") else 3.0
    if pref == "fotos":
        return -1.0
    return 0.6 if cena.get("tipo") in ("lugar", "conceito", "objeto", "evento_historico") else 0.2


def buscar_pixabay(termo, key, limite=10, videos=True):
    if not key:
        return []
    out = []
    r = requests.get(
        "https://pixabay.com/api/",
        params={"key": key, "q": termo[:100], "image_type": "photo", "per_page": limite, "safesearch": "true"},
        timeout=TIMEOUT,
    )
    if r.ok:
        for h in r.json().get("hits", []):
            out.append(
                {
                    "fonte": "Pixabay",
                    "tipo": "foto",
                    "preview": h.get("webformatURL"),
                    "download": h.get("largeImageURL") or h.get("webformatURL"),
                    "titulo": h.get("tags", ""),
                    "texto_match": h.get("tags", ""),
                    "licenca": "Pixabay License",
                    "autor": h.get("user", ""),
                    "pagina": h.get("pageURL", ""),
                    "largura": h.get("imageWidth"),
                    "altura": h.get("imageHeight"),
                }
            )
    if videos:
        r = requests.get(
            "https://pixabay.com/api/videos/",
            params={"key": key, "q": termo[:100], "per_page": max(3, limite // 2), "safesearch": "true"},
            timeout=TIMEOUT,
        )
        if r.ok:
            for h in r.json().get("hits", []):
                vs = h.get("videos") or {}
                best = next((vs[q] for q in ("medium", "large", "small") if (vs.get(q) or {}).get("url")), {})  # 1920: leve e suficiente
                if not best.get("url"):
                    continue
                thumb = best.get("thumbnail") or (vs.get("medium") or {}).get("thumbnail") or (vs.get("small") or {}).get("thumbnail") or ""
                if not thumb and h.get("picture_id"):
                    thumb = f"https://i.vimeocdn.com/video/{h['picture_id']}_640x360.jpg"  # API antiga do Pixabay
                out.append(
                    {
                        "fonte": "Pixabay",
                        "tipo": "video",
                        "preview": thumb,
                        "download": best.get("url"),
                        "titulo": h.get("tags", ""),
                        "texto_match": h.get("tags", ""),
                        "licenca": "Pixabay License",
                        "autor": h.get("user", ""),
                        "pagina": h.get("pageURL", ""),
                        "largura": best.get("width"),
                        "altura": best.get("height"),
                        "duracao": h.get("duration"),
                    }
                )
    return out


def buscar_pexels(termo, key, limite=10, videos=True):
    if not key:
        return []
    out = []
    hdr = {"Authorization": key}
    r = requests.get("https://api.pexels.com/v1/search", params={"query": termo, "per_page": limite}, headers=hdr, timeout=TIMEOUT)
    if r.ok:
        for p in r.json().get("photos", []):
            slug = " ".join(_norm(p.get("url", "").rstrip("/").split("/")[-1]))
            txt = f"{p.get('alt','')} {slug}"
            src = p.get("src") or {}
            out.append(
                {
                    "fonte": "Pexels",
                    "tipo": "foto",
                    "preview": src.get("medium") or src.get("large"),
                    "download": src.get("large2x") or src.get("original"),
                    "titulo": p.get("alt") or slug,
                    "texto_match": txt,
                    "licenca": "Pexels License",
                    "autor": p.get("photographer", ""),
                    "pagina": p.get("url", ""),
                    "largura": p.get("width"),
                    "altura": p.get("height"),
                }
            )
    if videos:
        r = requests.get(
            "https://api.pexels.com/videos/search", params={"query": termo, "per_page": max(3, limite // 2)}, headers=hdr, timeout=TIMEOUT
        )
        if r.ok:
            for v in r.json().get("videos", []):
                files = [f for f in v.get("video_files", []) if f.get("file_type") == "video/mp4" and f.get("width")]
                if not files:
                    continue
                files.sort(key=lambda f: abs((f.get("width") or 0) - 1920))
                f = files[0]
                slug = " ".join(_norm(v.get("url", "").rstrip("/").split("/")[-1]))
                out.append(
                    {
                        "fonte": "Pexels",
                        "tipo": "video",
                        "preview": v.get("image"),
                        "download": f.get("link"),
                        "titulo": slug,
                        "texto_match": slug,
                        "licenca": "Pexels License",
                        "autor": (v.get("user") or {}).get("name", ""),
                        "pagina": v.get("url", ""),
                        "largura": f.get("width"),
                        "altura": f.get("height"),
                        "duracao": v.get("duration"),
                    }
                )
    return out


def buscar_todos(termo, settings, termo_idx=0, pessoa=""):
    from concurrent.futures import ThreadPoolExecutor

    from core import fontes

    ativas = settings.get("fontes_ativas") or {}
    sa = bool(settings.get("aceitar_cc_by_sa"))
    provedores = [
        ("Wikimedia", lambda: buscar_wikimedia(termo, aceitar_sa=sa)),
        ("Wikimedia vídeo", lambda: buscar_wikimedia_video(termo, aceitar_sa=sa) if settings.get("preferencia_midia", "equilibrado") != "fotos" else []),
        ("Pixabay", lambda: buscar_pixabay(termo, settings.get("pixabay_key"))),
        ("Pexels", lambda: buscar_pexels(termo, settings.get("pexels_key"))),
        ("Openverse", lambda: fontes.openverse(termo, sa)),
        ("Met", lambda: fontes.met(termo)),
        ("Smithsonian", lambda: fontes.smithsonian(termo, settings.get("smithsonian_key"))),
        ("Europeana", lambda: fontes.europeana(termo, settings.get("europeana_key"), sa)),
        ("Internet Archive", lambda: fontes.internet_archive(termo) if settings.get("preferencia_midia", "equilibrado") != "fotos" else []),
        ("NASA", lambda: fontes.nasa(termo)),
        ("Unsplash", lambda: fontes.unsplash(termo, settings.get("unsplash_key"))),
    ]
    provedores = [p for p in provedores if ativas.get(p[0].replace(" vídeo", ""), True)]
    resultados, erros = [], []
    with ThreadPoolExecutor(max_workers=len(provedores) or 1) as ex:
        futs = [(nome, ex.submit(fn)) for nome, fn in provedores]
        for nome, f in futs:
            try:
                resultados.extend(f.result())
            except Exception as e:  # rede, chave errada etc.
                erros.append(f"{nome}: {str(e)[:120]}")
    for c in resultados:
        c["nota"], c["match"] = pontuar(termo, c.get("texto_match", ""), termo_idx, pessoa)
        c["termo"] = termo
    return resultados, erros


def candidatos_cena(cena, settings, termos=None):
    termos = termos or cena.get("termos_busca") or []
    if not termos:
        termos = [" ".join(_tokens(cena.get("texto", ""))[:4])]
    todos, erros, vistos = [], [], set()
    for i, t in enumerate(termos[: int(settings.get("termos_por_cena", 4) or 4)]):
        res, err = buscar_todos(t, settings, i, cena.get("pessoa_real", ""))
        erros += err
        for c in res:
            if c["download"] in vistos:
                continue
            vistos.add(c["download"])
            todos.append(c)
        # se já achou algo bom, não precisa gastar mais buscas (no modo vídeos, só para quando achar VÍDEO bom)
        if settings.get("preferencia_midia") == "videos":
            if any(c["nota"] >= 6 and c["tipo"] == "video" for c in todos):
                break
        elif any(c["nota"] >= 8 for c in todos):
            break
    # modo vídeos e nenhum vídeo bom: tenta o termo mais genérico só nos bancos de vídeo
    if settings.get("preferencia_midia") == "videos" and not any(c["tipo"] == "video" and c["nota"] >= 4 for c in todos) and termos:
        for geral in (cena.get("broll") or [])[:3] + [termos[-1]]:
            if any(c["tipo"] == "video" and c["nota"] >= 4 for c in todos):
                break
            _video_contexto(geral, settings, todos, vistos, erros)
    def chave(c):
        bonus = bonus_video(c, cena, settings)
        if cena.get("pessoa_real") and c["fonte"] == "Wikimedia Commons" and c["tipo"] == "foto":
            bonus += 0.5
        return c["nota"] + bonus

    todos.sort(key=chave, reverse=True)
    return todos[:30], erros


def _video_contexto(geral, settings, todos, vistos, erros):
    """Vídeo de contexto (b-roll) para dar movimento quando não há vídeo do fato exato."""
    if True:
        for fn in (lambda: buscar_pixabay(geral, settings.get("pixabay_key")), lambda: buscar_pexels(geral, settings.get("pexels_key"))):
            try:
                for c in fn():
                    if c["tipo"] == "video" and c["download"] not in vistos:
                        c["nota"], c["match"] = pontuar(geral, c.get("texto_match", ""), 1, "")
                        if c["nota"] < 2:  # nada a ver com o termo (ex.: ioga numa cena de estrada): nem tenta
                            continue
                        c["nota"] = max(c["nota"], 4.0)  # vídeo de contexto (genérico) para dar movimento
                        c["termo"] = geral
                        vistos.add(c["download"])
                        todos.append(c)
            except Exception as e:
                erros.append(str(e)[:100])


def escolher_auto(cenas, settings):
    _escolher(cenas)
    # limite de cenas por IA: se passar do máximo, preenche as que faltam com a melhor mídia genérica disponível
    pct = float(settings.get("max_cenas_ia_pct", 30) or 0)
    sem = [c for c in cenas if c.get("status") == "ia" and not c.get("forcar_ia")]
    limite = int(len(cenas) * pct / 100)
    if len(sem) > limite:
        # as cenas com candidato menos ruim saem da IA; as piores continuam para IA
        sem.sort(key=lambda c: (c.get("candidatos") or [{"nota": -1}])[0]["nota"], reverse=True)
        for c in sem[: len(sem) - limite]:
            cands = c.get("candidatos") or []
            if cands:
                c["midia"] = dict(cands[0], origem="auto")
                c["status"] = "escolhida"
    return cenas


def _escolher(cenas):
    """Escolhe a melhor mídia de cada cena evitando repetir a mesma mídia."""
    usados = set()
    anterior = None
    for cena in cenas:
        if cena.get("midia") and cena["midia"].get("origem") == "manual":
            usados.add(cena["midia"].get("download"))
            anterior = cena["midia"].get("download")
            continue
        if cena.get("forcar_ia"):
            cena["midia"] = None
            cena["status"] = "ia"
            anterior = None
            continue
        escolha = None
        for c in cena.get("candidatos", []):
            if c["download"] not in usados and c["nota"] >= 4:
                escolha = c
                break
        if escolha is None:
            # sem opção inédita: aceita repetir uma mídia muito boa, desde que não seja a da cena anterior
            for c in cena.get("candidatos", []):
                if c["nota"] >= 7 and c["download"] != anterior:
                    escolha = c
                    break
        anterior = escolha["download"] if escolha else None
        if escolha and escolha["nota"] >= 4:
            escolha = dict(escolha, origem="auto")
            cena["midia"] = escolha
            cena["status"] = "escolhida"
            usados.add(escolha["download"])
        else:
            cena["midia"] = None
            cena["status"] = "ia"
    return cenas


def baixar_youtube(url, destino_sem_ext, duracao_total=0, trecho=15):
    """Baixa só um trecho (sem áudio) de um vídeo Creative Commons do YouTube usando yt-dlp."""
    import glob
    import subprocess
    import sys

    from core.render import ffmpeg_bin

    ini = int(max(0, (duracao_total or 60) * 0.2))
    fim = ini + int(trecho)
    args = [sys.executable, "-m", "yt_dlp", "--no-playlist", "-f", "bv*[height<=1080][ext=mp4]/bv*[ext=mp4]/b[ext=mp4]/b",
            "--download-sections", f"*{ini}-{fim}", "--force-keyframes-at-cuts", "--ffmpeg-location", ffmpeg_bin(),
            "-o", destino_sem_ext + ".%(ext)s", url]
    flags = 0x08000000 if os.name == "nt" else 0
    args[3:3] = ["--socket-timeout", "20", "--retries", "2"] + _js_runtime()
    p = rodar_limite(args, 100)
    achados = [f for f in glob.glob(destino_sem_ext + ".*") if not f.endswith((".part", ".ytdl"))]
    for f in glob.glob(destino_sem_ext + ".*.part") + glob.glob(destino_sem_ext + ".*.ytdl"):
        try:
            os.remove(f)
        except OSError:
            pass
    if p.returncode == 0 and achados and video_ok(achados[0]):
        return achados[0]
    for f in achados:  # veio vazio/quebrado: apaga e tenta cortar direto do link do vídeo
        try:
            os.remove(f)
        except OSError:
            pass
    try:
        return baixar_trecho(_youtube_link_direto(url), destino_sem_ext, duracao_total, trecho, limite=90)
    except Exception as e:
        raise RuntimeError("YouTube: não consegui baixar o trecho (" + str(e)[:200] + ")")


def rodar_limite(args, limite):
    """Roda um programa com tempo-limite DE VERDADE: se passar, mata ele e os filhos (yt-dlp abre um ffmpeg).
    A saída vai para um arquivo temporário (com pipe, o Windows fica esperando o filho morto para sempre)."""
    import subprocess
    import tempfile

    flags = 0x08000000 if os.name == "nt" else 0
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace") as saida:
        p = subprocess.Popen(args, stdout=saida, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, creationflags=flags)
        try:
            p.wait(timeout=limite)
            codigo = p.returncode
        except subprocess.TimeoutExpired:
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True, creationflags=flags)
            else:
                p.kill()
            try:
                p.wait(timeout=10)
            except Exception:
                pass
            codigo = -9
        saida.seek(0)
        texto = saida.read()[-3000:]
    if codigo == -9:
        texto += f"\n(desisti depois de {limite}s)"
    return subprocess.CompletedProcess(args, codigo, texto, texto)


def video_ok(path):
    """Confere se o arquivo de vídeo abre e tem imagem (yt-dlp às vezes cria um .mp4 vazio)."""
    import subprocess

    from core.render import ffmpeg_bin

    if not path or not os.path.exists(path) or os.path.getsize(path) < 20000:
        return False
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        p = subprocess.run([ffmpeg_bin(), "-v", "error", "-i", path, "-frames:v", "1", "-f", "null", "-"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=60, creationflags=flags)
        return p.returncode == 0
    except Exception:
        return False


def _js_runtime():
    """O YouTube agora exige um 'motor de JavaScript' para o yt-dlp; usa o deno instalado junto, se existir."""
    import shutil
    import sys

    pasta = os.path.dirname(sys.executable)
    for p in (os.path.join(pasta, "deno.exe"), os.path.join(pasta, "Scripts", "deno.exe"), os.path.join(pasta, "deno"), shutil.which("deno") or ""):
        if p and os.path.exists(p):
            return ["--js-runtimes", f"deno:{p}"]
    return []


def _youtube_link_direto(url):
    import subprocess
    import sys

    flags = 0x08000000 if os.name == "nt" else 0
    p = rodar_limite([sys.executable, "-m", "yt_dlp", "--no-playlist", "--socket-timeout", "20", *_js_runtime(), "-g", "-f", "bv*[height<=1080][ext=mp4]/bv*[height<=1080]/b", url], 90)
    linhas = [x for x in (p.stdout or "").splitlines() if x.startswith("http")]
    if not linhas:
        raise RuntimeError("yt-dlp não deu o link: " + (p.stderr or "")[-200:])
    return linhas[0]


def wikimedia_original(url):
    """.../commons/thumb/a/ab/Arquivo.jpg/1920px-Arquivo.jpg  ->  .../commons/a/ab/Arquivo.jpg"""
    if "upload.wikimedia.org" in url and "/thumb/" in url:
        return url.replace("/thumb/", "/").rsplit("/", 1)[0]
    return url


def baixar_trecho(url_video, destino_sem_ext, duracao_total=0, trecho=20, limite=180):
    """Baixa só um pedaço de um vídeo longo direto da internet (sem baixar o arquivo inteiro)."""
    import subprocess

    from core.render import ffmpeg_bin

    ini = int(max(0, (duracao_total or 120) * 0.25)) if (duracao_total or 0) > trecho * 2 else 0
    out = destino_sem_ext + ".mp4"
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        p = rodar_limite([ffmpeg_bin(), "-y", "-rw_timeout", "20000000", "-ss", str(ini), "-user_agent", UA, "-i", url_video, "-t", str(trecho), "-an",
                          "-vf", "scale='min(1920,iw)':-2", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", out], limite)
    except subprocess.TimeoutExpired:
        p = subprocess.CompletedProcess([], 1, "", "a internet travou ao baixar o trecho (mais de 3 min)")
    if p.returncode != 0 or not video_ok(out):
        try:
            os.remove(out)
        except OSError:
            pass
        raise RuntimeError("trecho: " + p.stderr[-300:])
    return out


class MidiaRuim(RuntimeError):
    """A mídia baixou certinho, mas não serve para o vídeo (tela verde, vídeo vertical). Não é culpa da fonte."""


def defeito_visual(path, tipo="video"):
    """Olha um quadro do meio: 'vertical' (vídeo de celular/shorts) ou 'tela_verde' (chroma key / estúdio virtual). None se estiver ok."""
    import io as _io
    import subprocess

    from PIL import Image, ImageStat

    from core.render import ffmpeg_bin

    try:
        if tipo == "video":
            flags = 0x08000000 if os.name == "nt" else 0
            ims = []
            for seg in ("1", "4"):
                p = subprocess.run([ffmpeg_bin(), "-v", "error", "-ss", seg, "-i", path, "-frames:v", "1", "-vf", "scale=160:-2",
                                    "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True, timeout=60, creationflags=flags)
                if p.stdout:
                    ims.append(Image.open(_io.BytesIO(p.stdout)).convert("RGB"))
        else:
            im = Image.open(path).convert("RGB")
            im.thumbnail((160, 160))
            ims = [im]
    except Exception:
        return None
    for im in ims:
        w, h = im.size
        if tipo == "video" and h > w * 1.05:
            return "vertical"
        verdes = [g for r, g, b in im.convert("RGB").getdata() if g > 150 and r < g * 0.42 and b < g * 0.48]
        if len(verdes) > w * h * 0.1:
            media_g = sum(verdes) / len(verdes)
            desvio = (sum((g - media_g) ** 2 for g in verdes) / len(verdes)) ** 0.5
            if desvio < 28:  # verde liso e uniforme = tela de chroma (mata e grama têm textura)
                return "tela_verde"
    return None


TERMOS_RUINS = re.compile(r"green ?screen|chroma|virtual (studio|set)|news studio background|tela verde|fundo verde|#shorts?\b", re.I)


def baixar(url, destino_sem_ext, tipo, midia=None):
    path = _baixar_bruto(url, destino_sem_ext, tipo, midia)
    if tipo == "video":
        d = defeito_visual(path, "video")
        if d:
            try:
                os.remove(path)
            except OSError:
                pass
            raise MidiaRuim("vídeo vertical (de celular)" if d == "vertical" else "tela verde / estúdio virtual")
    return path


def _baixar_bruto(url, destino_sem_ext, tipo, midia=None):
    if "youtube.com/watch" in url:
        return baixar_youtube(url, destino_sem_ext, (midia or {}).get("duracao") or 0)
    if url.startswith("archive:"):
        from core import fontes

        link, dur = fontes.archive_arquivo_video(url[8:])
        return baixar_trecho(link, destino_sem_ext, dur)
    if url.startswith("nasa:"):
        from core import fontes

        return baixar_trecho(fontes.nasa_arquivo_video(url[5:]), destino_sem_ext, 0, 15)
    if tipo == "video" and "upload.wikimedia.org" in url:
        return baixar_trecho(url, destino_sem_ext, 0, 20)  # vídeos do Commons podem ser longos
    import time as _t

    r = None
    for tentativa in range(4):
        r = requests.get(url, headers={"User-Agent": UA}, timeout=60, stream=True)
        if r.status_code != 429:
            break
        _t.sleep(3 * (tentativa + 1))  # pediu rápido demais: espera e tenta de novo
    if r.status_code in (400, 404, 429) and wikimedia_original(url) != url:
        # Wikimedia recusou o tamanho da miniatura: baixa o arquivo original
        r = requests.get(wikimedia_original(url), headers={"User-Agent": UA}, timeout=120, stream=True)
    r.raise_for_status()
    ct = r.headers.get("content-type", "")
    ext = ".mp4" if tipo == "video" else ".jpg"
    if "png" in ct:
        ext = ".png"
    elif "webp" in ct:
        ext = ".webp"
    elif "webm" in ct:
        ext = ".webm"
    path = destino_sem_ext + ext
    inicio_dl, total = _time.time(), 0
    with open(path, "wb") as f:
        for chunk in r.iter_content(1 << 16):
            f.write(chunk)
            total += len(chunk)
            if _time.time() - inicio_dl > 150 or total > 400 * 1024 * 1024:  # download travado ou gigante: desiste e usa outra mídia
                r.close()
                f.close()
                os.remove(path)
                raise RuntimeError("download lento demais (passou de 2,5 min) — usando outra mídia")
    if tipo == "video" and not video_ok(path):
        os.remove(path)
        raise RuntimeError("o vídeo baixado veio quebrado")
    return path


def creditos(cenas):
    linhas = []
    for c in cenas:
        m = c.get("midia") or {}
        if m.get("fonte") in ("Wikimedia Commons", "Agência Brasil", "YouTube CC", "YouTube (notícia)", "Internet Archive", "NASA") and m.get("pagina"):
            linhas.append(f"Cena {c['n']}: {m.get('titulo','')} — {m.get('autor','')} — {m.get('licenca','')} — {m.get('pagina')}")
    return "\n".join(linhas)
