"""Notícia de agora: apura o que saiu nas últimas horas e junta material de imagem recente.

Fontes:
- Gemini com busca no Google (fatos atualizados, com fontes) — se houver chave
- Google Notícias (RSS) — manchetes recentes e veículos
- Agência Brasil (EBC) — fotos e textos de uso liberado com crédito (CC BY 3.0 BR)
- YouTube (vídeos publicados nas últimas horas): Creative Commons por padrão;
  canais de notícia em geral só se o usuário ligar a opção (direitos autorais por conta dele).
"""
import datetime as dt
import html
import re
import urllib.parse
import xml.etree.ElementTree as ET

import requests

from core import radar

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FabricaDark/1.0"
AB_RSS = "https://agenciabrasil.ebc.com.br/rss/ultimasnoticias/feed.xml"


def _limpo(t):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", t or ""))).strip()


def _tokens(t):
    return [w for w in re.findall(r"\w+", (t or "").lower()) if len(w) > 3]


def _data_rss(s):
    for fmt in ("%a, %d %b %Y %H:%M:%S %Z", "%a, %d %b %Y %H:%M:%S %z"):
        try:
            d = dt.datetime.strptime(s.strip(), fmt)
            return d.replace(tzinfo=None) if d.tzinfo is None else d.astimezone(dt.timezone.utc).replace(tzinfo=None)
        except Exception:
            continue
    return None


def google_noticias(tema, horas=48, limite=15):
    q = f"{tema} when:{max(1, int(horas))}h"
    url = "https://news.google.com/rss/search?" + urllib.parse.urlencode({"q": q, "hl": "pt-BR", "gl": "BR", "ceid": "BR:pt-419"})
    r = requests.get(url, headers={"User-Agent": UA}, timeout=20)
    r.raise_for_status()
    out = []
    for it in ET.fromstring(r.content).iter("item"):
        src = it.find("source")
        out.append({"titulo": _limpo(it.findtext("title")), "link": it.findtext("link") or "", "veiculo": (src.text if src is not None else ""),
                    "quando": it.findtext("pubDate") or "", "resumo": _limpo(it.findtext("description"))[:300]})
        if len(out) >= limite:
            break
    return out


def _og(html_txt, prop):
    m = re.search(rf'<meta[^>]+property=["\']{prop}["\'][^>]+content=["\']([^"\']+)', html_txt) or \
        re.search(rf'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']{prop}["\']', html_txt)
    return html.unescape(m.group(1)) if m else ""


def agencia_brasil(tema, horas=48, limite=8):
    """Matérias recentes da Agência Brasil sobre o tema: texto + foto principal (uso livre com crédito)."""
    r = requests.get(AB_RSS, headers={"User-Agent": UA}, timeout=20)
    r.raise_for_status()
    toks = set(_tokens(tema))
    limite_t = dt.datetime.utcnow() - dt.timedelta(hours=horas)
    achados = []
    for it in ET.fromstring(r.content).iter("item"):
        tit, desc = _limpo(it.findtext("title")), _limpo(it.findtext("description"))
        quando = _data_rss(it.findtext("pubDate") or "")
        if quando and quando < limite_t:
            continue
        casa = len(toks & set(_tokens(tit + " " + desc)))
        if toks and casa == 0:
            continue
        achados.append((casa, {"titulo": tit, "link": it.findtext("link") or "", "resumo": desc[:400], "quando": it.findtext("pubDate") or ""}))
    achados.sort(key=lambda x: -x[0])
    out = []
    for _, a in achados[:limite]:
        try:
            p = requests.get(a["link"], headers={"User-Agent": UA}, timeout=20).text
            a["foto"] = _og(p, "og:image")
            corpo = re.findall(r"<p[^>]*>(.*?)</p>", p, flags=re.S)
            a["texto"] = _limpo(" ".join(corpo))[:3000]
        except Exception:
            a["foto"], a["texto"] = "", ""
        out.append(a)
    return out


def youtube_recentes(tema, horas=48, so_cc=True, limite=15):
    depois = (dt.datetime.utcnow() - dt.timedelta(hours=horas)).strftime("%Y-%m-%dT%H:%M:%SZ")
    params = dict(part="snippet", type="video", q=tema, order="relevance", publishedAfter=depois, maxResults=limite,
                  relevanceLanguage="pt", regionCode="BR", videoEmbeddable="true")
    if so_cc:
        params["videoLicense"] = "creativeCommon"
    data = radar._get("search", None, **params)
    ids = [it["id"]["videoId"] for it in data.get("items", []) if it.get("id", {}).get("videoId")]
    if not ids:
        return []
    det = {v["id"]: v for v in radar._get("videos", None, part="contentDetails,snippet,status", id=",".join(ids)).get("items", [])}
    out = []
    for i in ids:
        v = det.get(i)
        if not v:
            continue
        cc = (v.get("status") or {}).get("license") == "creativeCommon"
        if so_cc and not cc:
            continue
        sn = v["snippet"]
        dur = radar._iso_dur(v["contentDetails"].get("duration"))
        if dur and dur > 4 * 3600:  # transmissões enormes: pula
            continue
        out.append({
            "fonte": "YouTube CC" if cc else "YouTube (notícia)", "tipo": "video", "noticia": True,
            "preview": (sn.get("thumbnails", {}).get("medium") or {}).get("url", ""),
            "download": f"https://www.youtube.com/watch?v={i}", "titulo": sn["title"],
            "texto_match": f"{sn['title']} {sn.get('description', '')[:300]} {' '.join(sn.get('tags', [])[:15])}",
            "licenca": "Creative Commons (CC BY)" if cc else "Direitos do canal (uso por sua conta)",
            "autor": sn.get("channelTitle", ""), "pagina": f"https://www.youtube.com/watch?v={i}", "duracao": dur,
            "publicado": sn.get("publishedAt", ""),
        })
    return out


def pool_imagens(tema, horas, incluir_canais, log=print):
    """Material de imagem recente para as cenas (vai para o 'pool' da busca de mídia)."""
    pool = []
    try:
        for a in agencia_brasil(tema, horas, 10):
            if a.get("foto"):
                pool.append({"fonte": "Agência Brasil", "tipo": "foto", "noticia": True, "preview": a["foto"], "download": a["foto"],
                             "titulo": a["titulo"], "texto_match": f"{a['titulo']} {a['resumo']}", "licenca": "CC BY 3.0 BR",
                             "autor": "Agência Brasil", "pagina": a["link"]})
    except Exception as e:
        log(f"Agência Brasil: {str(e)[:120]}")
    for so_cc in ([True, False] if incluir_canais else [True]):
        try:
            pool += youtube_recentes(tema, horas, so_cc, 15)
        except Exception as e:
            log(f"YouTube recentes: {str(e)[:120]}")
            break
    vistos, uniq = set(), []
    for x in pool:
        if x["download"] not in vistos:
            vistos.add(x["download"])
            uniq.append(x)
    return uniq


def apurar(tema, horas, video_id=None, log=print):
    """Junta os fatos das últimas horas. Retorna (texto_de_referencia, fontes)."""
    from core import gemini, reallab

    agora = dt.datetime.now().strftime("%d/%m/%Y %H:%M")
    fontes, partes = [], []
    try:
        gn = google_noticias(tema, horas, 15)
        fontes += [{"titulo": g["titulo"], "veiculo": g["veiculo"], "quando": g["quando"], "link": g["link"]} for g in gn]
        partes.append("MANCHETES RECENTES:\n" + "\n".join(f"- [{g['quando']}] {g['titulo']} ({g['veiculo']}) {g['resumo'][:200]}" for g in gn))
    except Exception as e:
        log(f"Google Notícias: {str(e)[:120]}")
    try:
        ab = agencia_brasil(tema, horas, 5)
        fontes += [{"titulo": a["titulo"], "veiculo": "Agência Brasil", "quando": a["quando"], "link": a["link"]} for a in ab]
        partes.append("MATÉRIAS DA AGÊNCIA BRASIL:\n" + "\n\n".join(f"{a['titulo']} ({a['quando']})\n{a.get('texto', '')[:1800]}" for a in ab))
    except Exception as e:
        log(f"Agência Brasil: {str(e)[:120]}")
    if reallab.tem_gemini():
        try:
            j, _ = gemini.chamar([{"text": f"""Hoje é {agora} (horário de Brasília). Pesquise no Google o que aconteceu nas ÚLTIMAS {horas} HORAS sobre: {tema}.
Liste os fatos em ordem cronológica, com data/hora, nomes, números e declarações exatas entre aspas quando houver, e de qual veículo veio cada informação.
Separe o que está confirmado do que ainda é incerto. Não invente nada."""}], video_id, max_tokens=6000, temperatura=0.2,
                                 ferramentas=[{"google_search": {}}])
            partes.insert(0, "APURAÇÃO COM BUSCA NO GOOGLE:\n" + gemini._texto(j))
            for g in ((j.get("candidates") or [{}])[0].get("groundingMetadata") or {}).get("groundingChunks", [])[:12]:
                w = g.get("web") or {}
                if w.get("uri"):
                    fontes.append({"titulo": w.get("title", ""), "veiculo": w.get("title", ""), "quando": "", "link": w["uri"]})
        except Exception as e:
            log(f"Busca no Google (Gemini): {str(e)[:150]}")
    texto = f"(apurado em {agora}, últimas {horas} horas)\n\n" + "\n\n".join(p for p in partes if p.strip())
    return texto[:14000], fontes
