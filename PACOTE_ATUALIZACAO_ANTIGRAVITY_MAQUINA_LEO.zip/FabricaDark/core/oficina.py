"""Oficina do roteiro: nota em 4 critérios, "Melhorar" e conversa com o roteirista.

- avaliar: Humano (soa natural, não parece IA), Qualidade (informação, ritmo, ganchos),
  Políticas do YouTube (conteúdo seguro para monetizar) e Estrutura (abertura, desenvolvimento, fechamento).
- melhorar: reescreve em blocos (serve para roteiros longos), mantendo fatos e tamanho.
- conversar: o roteirista responde e, se for o caso, devolve alterações pontuais (trecho antigo → trecho novo).
"""
import re

from core import claude, perfis

CRITERIOS = [
    ("humano", "Humano", "soa como uma pessoa contando, não como texto de IA: sem clichês ('mergulhe', 'jornada', 'em suma', 'vale ressaltar'), sem listas faladas, frases variadas, emoção na medida"),
    ("qualidade", "Qualidade", "informação concreta (nomes, datas, números), ritmo, ganchos que seguram até o fim, nada de enrolação ou repetição"),
    ("politicas", "Políticas do YouTube", "seguro para monetizar: sem violência gráfica descrita em detalhe, sem ódio, sem desinformação, sem promessa enganosa no gancho, respeito a vítimas"),
    ("estrutura", "Estrutura", "abertura forte nos primeiros 30 segundos, desenvolvimento em fases claras, clímax, fechamento com CTA natural"),
]


def _ctx(ch, v):
    pf = perfis.get((ch or {}).get("perfil"))
    return (f"CANAL: {(ch or {}).get('nome', '')} — nicho: {(ch or {}).get('nicho', '')}; público: {(ch or {}).get('publico', '')}\n"
            f"ESTILO DO CANAL: {pf['nome']}. {pf.get('tom', '')}\nTÍTULO DO VÍDEO: {v.get('titulo', '')}")


def avaliar(v, ch):
    crit = "\n".join(f"- {k} ({n}): {d}" for k, n, d in CRITERIOS)
    p = f"""Você é editor-chefe de roteiros de canais dark do YouTube. Avalie o roteiro abaixo com rigor (nota 0 a 100 em cada critério).
{_ctx(ch, v)}

CRITÉRIOS
{crit}

Para cada critério: nota e um comentário curto (1 frase). Depois liste até 8 trechos com problema, copiando o TRECHO EXATO do roteiro
(até 25 palavras), o problema e uma sugestão de como reescrever. Seja específico; não elogie à toa.

ROTEIRO
{v.get('roteiro', '')}

Responda SOMENTE JSON:
{{"notas": {{"humano": 0, "qualidade": 0, "politicas": 0, "estrutura": 0}}, "comentarios": {{"humano": "", "qualidade": "", "politicas": "", "estrutura": ""}},
"resumo": "uma frase", "problemas": [{{"trecho": "", "criterio": "humano|qualidade|politicas|estrutura", "problema": "", "sugestao": ""}}]}}"""
    r = claude.json_pref("roteiro", p, v.get("id"))
    if not isinstance(r, dict) or "notas" not in r:
        raise RuntimeError("A IA não devolveu a avaliação no formato certo. Tente de novo.")
    notas = {k: max(0, min(100, int(float((r.get("notas") or {}).get(k) or 0)))) for k, _, _ in CRITERIOS}
    r["notas"] = notas
    r["geral"] = round(sum(notas.values()) / len(notas))
    r["problemas"] = [x for x in (r.get("problemas") or []) if isinstance(x, dict)][:8]
    return r


def _blocos(texto, palavras=900):
    pars = [p for p in re.split(r"\n\s*\n", texto.strip()) if p.strip()]
    blocos, atual = [], []
    for p in pars:
        if atual and len(" ".join(atual).split()) + len(p.split()) > palavras:
            blocos.append("\n\n".join(atual))
            atual = []
        atual.append(p)
    if atual:
        blocos.append("\n\n".join(atual))
    return blocos or [texto]


def melhorar(v, ch, avaliacao=None, pedido="", progresso=None):
    """Reescreve o roteiro inteiro (em blocos), corrigindo o que a avaliação apontou."""
    texto = v.get("roteiro", "")
    guia = ""
    if avaliacao:
        guia = "PONTOS A CORRIGIR (da avaliação):\n" + "\n".join(
            f"- [{CRITERIOS_N.get(k, k)}: {n}] {avaliacao.get('comentarios', {}).get(k, '')}" for k, n in avaliacao.get("notas", {}).items() if n < 90)
        guia += "\n" + "\n".join(f"- \"{x.get('trecho', '')}\" → {x.get('problema', '')}. {x.get('sugestao', '')}" for x in avaliacao.get("problemas", []))
    if pedido:
        guia += f"\nPEDIDO DO AUTOR: {pedido}"
    blocos = _blocos(texto)
    novos = []
    for k, b in enumerate(blocos):
        if progresso:
            progresso(k, len(blocos))
        p = f"""Você é roteirista profissional de canais dark do YouTube. Reescreva o TRECHO {k + 1} de {len(blocos)} do roteiro para ficar melhor:
mais humano (sem clichês de IA), mais concreto, com ritmo e ganchos, seguro para as políticas do YouTube.
{_ctx(ch, v)}
{guia}

REGRAS
- Mantenha TODOS os fatos, nomes, datas e números (não invente nada novo).
- Mantenha o tamanho (mais ou menos {len(b.split())} palavras) e a ordem dos acontecimentos.
- Texto corrido para narração: sem títulos, sem marcações, sem emojis, sem comentários seus.
{"- É o começo do vídeo: os primeiros 30 segundos precisam prender (gancho forte)." if k == 0 else ""}
{"- É o fim do vídeo: feche com força e um convite natural para se inscrever." if k == len(blocos) - 1 else ""}
{f"FINAL DO TRECHO ANTERIOR (para continuar sem emenda): ...{novos[-1][-400:]}" if novos else ""}

TRECHO
{b}

Devolva SOMENTE o trecho reescrito."""
        t = claude.texto_pref("roteiro", p, v.get("id")).strip()
        t = re.sub(r"^```\w*|```$", "", t).strip()
        novos.append(t if len(t.split()) >= len(b.split()) * 0.6 else b)
    return "\n\n".join(novos)


CRITERIOS_N = {k: n for k, n, _ in CRITERIOS}


def conversar(v, ch, mensagem, historico=None):
    """Retorna {"resposta": str, "alteracoes": [{"antes","depois"}]} — as alterações já validadas contra o texto."""
    hist = "\n".join(f"{'AUTOR' if h.get('de') == 'eu' else 'ROTEIRISTA'}: {h.get('texto', '')[:600]}" for h in (historico or [])[-8:])
    p = f"""Você é o roteirista do canal e está conversando com o autor sobre o roteiro abaixo.
{_ctx(ch, v)}

ROTEIRO ATUAL
{v.get('roteiro', '')}

CONVERSA ATÉ AGORA
{hist or '(início)'}

AUTOR: {mensagem}

Se o autor pedir mudança no texto, faça as alterações como trocas pontuais: "antes" = trecho COPIADO EXATAMENTE do roteiro atual
(frase ou parágrafo inteiro), "depois" = o novo texto. Para mudanças grandes, troque parágrafos inteiros. Não invente fatos.
Se for só pergunta ou opinião, responda sem alterações. Responda em português, curto e direto.
Responda SOMENTE JSON: {{"resposta": "o que você fez ou respondeu", "alteracoes": [{{"antes": "", "depois": ""}}]}}"""
    r = claude.json_pref("roteiro", p, v.get("id"))
    if not isinstance(r, dict):
        raise RuntimeError("Resposta fora do formato. Tente de novo.")
    texto = v.get("roteiro", "")
    ok = []
    for a in r.get("alteracoes") or []:
        antes, depois = str((a or {}).get("antes") or "").strip(), str((a or {}).get("depois") or "").strip()
        if antes and antes in texto and antes != depois:
            ok.append({"antes": antes, "depois": depois})
    return {"resposta": str(r.get("resposta") or "").strip(), "alteracoes": ok, "pedidas": len(r.get("alteracoes") or [])}


def aplicar(texto, alteracoes):
    for a in alteracoes:
        texto = texto.replace(a["antes"], a["depois"], 1)
    return texto
