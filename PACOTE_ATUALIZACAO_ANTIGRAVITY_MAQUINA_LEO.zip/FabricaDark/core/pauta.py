"""Sugestão do Dia V9 — DNA Editorial Profundo de Cada Canal + Inteligência de Nichos Virais (https://app.darkplanner.com.br/nichos-virais).

Em vez de olhar apenas para metadados superficiais (ex.: 'Business / AUSTRALIA'),
este motor analisa:
1. O DNA Editorial real e os Prompts Mestres de cada um dos 7 canais;
2. A Diretriz Oficial do Gerador de Sugestões de cada canal (o que priorizar, o que evitar, formato narrativo, público e contexto);
3. Os canais e vídeos que estão EXPLODINDO AGORA em https://app.darkplanner.com.br/nichos-virais + Radar YouTube,
   extraindo a EMOÇÃO HUMANA e o GATILHO VIRAL e traduzindo-os para o formato exato do canal.
"""
import datetime as dt
import re

from core import claude, darkplanner_sync, radar

NOMES_IDIOMA = {
    "pt": "português do Brasil",
    "en": "inglês (respeitando a variante do canal: australiano en-AU ou americano en-US)",
    "es": "espanhol neutro",
    "fr": "francês (fr-FR)",
}


# ==============================================================================
# PERFIS EDITORIAIS PROFUNDOS DOS 7 CANAIS (ANÁLISE INDIVIDUALIZADA)
# ==============================================================================
PERFIS_EDITORIAIS_CANAIS = {
    "capitto recomeco": {
        "canal_nome": "Capitto Recomeço",
        "idioma_exato": "Inglês Australiano (en-AU)",
        "formato_real": (
            "Entretenimento com histórias animadas 'What If' (ficção especulativa, poderes impossíveis, testes físicos crescentes, "
            "Falas de Destaque curtas dos Avatares com lip-sync + Quadros 2D Explicativos em azul-marinho #0E1738, base Iflord / FKezpSvDtw4)."
        ),
        "contexto_e_publico": "Jovens adultos (até 35 anos) na Austrália. A Austrália é o palco visual e o contexto cultural do público (ruas de Melbourne e Sydney, bondes/trams, subúrbios, supermercados locais, costa e outback) — isso NÃO exige transformar os vídeos em notícias sobre o país ou imigração.",
        "diretriz_gerador": (
            "Sugira temas para o Capitto Recomeço, um canal de entretenimento com histórias animadas “What If” em inglês australiano (baseado na estrutura dinâmica do canal Iflord — 'What If You Were Indestructible?'), "
            "voltado a jovens adultos na Austrália. Priorize uma premissa impossível fácil de entender, benefícios iniciais divertidos, testes físicos em escalada com quadros comparativos ('Normal vs You'), "
            "Falas de Destaque curtas entre o protagonista (moletom amarelo-âmbar) e o melhor amigo (moletom azul-royal), limites claros, consequências crescentes e um dilema humano. Use situações australianas naturalmente. "
            "Evite notícias, aconselhamento migratório e afirmações políticas como proposta principal."
        ),
        "o_que_priorizar": [
            "Premissa impossível imediata e fácil de visualizar começando com 'What If...' (E se...) no estilo Iflord",
            "Benefícios iniciais empolgantes e testes físicos crescentes (Nível 1 a 3) intercalados com Falas de Destaque curtas dos avatares",
            "Regras físicas/biológicas claras que rendem quadros comparativos 2D ('NORMAL' vs 'YOU') em fundo azul-marinho (#0E1738)",
            "Consequências crescentes e inesperadas que fogem do controle do protagonista + Dilema humano profundo (amizade, solidão, identidade, recomeço)",
            "Cenários australianos integrados naturalmente à animação (ruas de Melbourne e Sydney, trams, subúrbios, supermercados, costa e outback)",
        ],
        "o_que_evitar": [
            "Notícias factuais ou especulações sobre política migratória ('Why Australia Is Closing Its Doors')",
            "Generalizações políticas ou sociais sobre imigrantes ('3 Reasons Australia Stopped Wanting Immigrants')",
            "Guias de imigração ou alertas para quem quer mudar de país ('Stop Moving to Australia Before Knowing This')",
            "Relatos factuais genéricos sobre custo de vida ou morar na Austrália ('The Brutal Truth About Living in Australia Today')",
        ],
        "termos_proibidos_titulo": [
            "immigrant", "immigrants", "immigration", "visa", "visas", "closing its doors",
            "moving to australia", "move to australia", "deport", "border policy", "cost of living crisis",
        ],
        "como_aproveitar_virais": (
            "Aproveite a EMOÇÃO dos temas em alta — medo de perder espaço, necessidade de recomeçar, pertencimento, solidão e insegurança sobre o futuro — "
            "e transforme-a em histórias hipotéticas 'What If' com regras claras e alto potencial visual para animação."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "Why Australia Is Closing Its Doors in 2026",
                "status": "descartado",
                "avaliacao": "Muda a proposta para política migratória e apresenta uma conclusão ampla que precisa de comprovação.",
            },
            {
                "tema": "3 Reasons Australia Stopped Wanting Immigrants",
                "status": "descartado",
                "avaliacao": "Generaliza a posição de um país inteiro. Descartar essa formulação.",
            },
            {
                "tema": "Is Starting Over in Australia Still Possible?",
                "status": "adaptar",
                "avaliacao": "Tem uma emoção compatível com a marca (recomeço e insegurança), mas funciona melhor adaptado ao formato 'What If' (ex.: What If You Could Restart Your Life at 18?).",
            },
            {
                "tema": "The Brutal Truth About Living in Australia Today",
                "status": "descartado",
                "avaliacao": "Muito amplo; promete um relato factual sobre morar no país em vez de entretenimento animado.",
            },
            {
                "tema": "Stop Moving to Australia Before Knowing This",
                "status": "descartado",
                "avaliacao": "Direcionado principalmente a quem pretende imigrar, um público diferente daquele que buscamos com entretenimento.",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "What If You Were the Last Person in Australia?",
                "traducao": "E Se Você Fosse a Última Pessoa na Austrália?",
                "potencial_narrativo": "Liberdade inicial, exploração e solidão. O restante do mundo continua existindo. Mudança visual forte: ruas vazias de Melbourne, transportes parados, supermercados silenciosos e tentativas de contactar pessoas no exterior.",
                "gancho": "You wake up in Melbourne at 8 AM. The trams are frozen on the tracks, the supermarkets are wide open, and twenty-six million people have vanished overnight—yet the rest of the world outside Australia is still alive, watching, and refusing to come near the island.",
            },
            {
                "prioridade": 2,
                "titulo": "What If You Could Restart Your Life at 18?",
                "traducao": "E Se Você Pudesse Recomeçar Sua Vida aos 18 Anos?",
                "potencial_narrativo": "Recomeço, escolhas e consequências que suas memórias não conseguem prever: cada decisão alterada apaga pessoas que você amava no presente.",
                "gancho": "Imagine going to sleep in your tiny Sydney apartment at thirty-two, exhausted by every wrong turn you ever made—and waking up in your childhood bedroom at eighteen, with all your future memories intact.",
            },
            {
                "prioridade": 3,
                "titulo": "What If Everyone Forgot You Every 24 Hours?",
                "traducao": "E Se Todo Mundo Esquecesse Você a Cada 24 Horas?",
                "potencial_narrativo": "Um poder aparentemente conveniente (zero consequências sociais no início) que rapidamente destrói vínculos, carreira e confiança.",
                "gancho": "At midnight every single day, every person in Australia—your boss, your flatmate, the person you love—wipes every memory that you ever existed.",
            },
            {
                "prioridade": 4,
                "titulo": "What If AI Could Do Your Job Better Than You?",
                "traducao": "E Se uma IA Pudesse Fazer o Seu Trabalho Melhor que Você (Com um Clone Seu)?",
                "potencial_narrativo": "Competição, identidade e descoberta do próprio valor em um cenário hipotético onde uma versão sintética assume sua rotina profissional e social.",
                "gancho": "What if your company offered you full pay to stay home in Brisbane forever, as long as a digital version of you took over your desk, your meetings, and eventually your reputation?",
            },
            {
                "prioridade": 5,
                "titulo": "What If You Could Undo One Decision Every Day?",
                "traducao": "E Se Você Pudesse Desfazer Uma Decisão Todos os Dias?",
                "potencial_narrativo": "Pequenas correções cotidianas que criam efeitos colaterais maiores e um dilema emocional irreversível.",
                "gancho": "Every day you get a single 24-hour rewind button for one decision—until the day you have to choose between undoing your biggest mistake or saving someone you love.",
            },
        ],
        "queries_radar": [
            "what if you were indestructible iflord",
            "what if you were the last person on earth animated",
            "what if you could superpower consequences",
            "what happens if hypothetical animated story",
        ],
        "categorias_nichos_virais": ["Explainers / Fatos e Mistérios Visuais", "Ciência / Divulgação Científica"],
        "canais_benchmark": ["Iflord", "Awaken", "Ifinite", "AFTER THE DOOR", "Stickman What Happens", "E Se?", "The Paint Explainer", "The Stickman Scientist"],
    },

    "cappito vital": {
        "canal_nome": "Cappito Vital",
        "idioma_exato": "Português do Brasil (pt-BR)",
        "formato_real": "Storytelling animado 2D Cartoon Estilizado vibrante (fórmula idêntica ao CapittoFin: 70% Vídeo [flow][iv][16:9] + 30% Imagem [flow][i][16:9] no Google Flow) sobre saúde, vitalidade, sinais silenciosos do corpo e longevidade prática após os 40 anos, conduzido pelo apresentador Miguel e protagonistas de 40 a 65 anos.",
        "contexto_e_publico": "Adultos brasileiros 40+ que sentem mudanças na energia, sono, metabolismo, memória ou força muscular e buscam entender o que o corpo está sinalizando através de histórias visuais claras.",
        "diretriz_gerador": (
            "Sugira temas para o Cappito Vital (fórmula visual idêntica ao CapittoFin: 70% Vídeo + 30% Imagem em animação cartoon 2D vibrante), um canal brasileiro de entretenimento educativo e histórias animadas 2D sobre saúde, "
            "vitalidade e sinais do corpo após os 40 anos (com o narrador Miguel). Priorize sinais silenciosos que o corpo dá antes de um "
            "problema maior, o que acontece fisiologicamente quando mudamos ou negligenciamos um hábito diário (sono, inflamação oculta, "
            "perda muscular, cansaço matinal, fígado e cérebro), e dilemas reais da rotina adulta no Brasil. Evite promessas de curas "
            "milagrosas, terrorismo médico ou aulas acadêmicas frias sem narrativa humana."
        ),
        "o_que_priorizar": [
            "Sinais silenciosos do corpo após os 40 anos que a maioria das pessoas acha que é 'só cansaço normal'",
            "Experimentos de causa e efeito fisiológico ('O que acontece no seu corpo quando...') com explicação visual 2D",
            "História de um personagem brasileiro identificável acompanhado pelo apresentador Miguel",
            "Conexão entre hábitos cotidianos (horário do jantar, café, sono picado, sedentarismo oculto) e vitalidade",
        ],
        "o_que_evitar": [
            "Promessas de curas milagrosas ou chás mágicos que substituem tratamento médico",
            "Aulas acadêmicas secas de faculdade sem história ou personagem",
            "Temas voltados para adolescentes ou estética maromba de academia jovem",
        ],
        "termos_proibidos_titulo": ["cura definitiva", "milagroso", "emagreça 10kg em 3 dias"],
        "como_aproveitar_virais": (
            "Pegue os vídeos virais de saúde e hábitos ('What happens if...', 'Sinais que o corpo dá') e traduza para a realidade de quem passou dos 40 anos no Brasil, com o narrador Miguel guiando a jornada."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "Chá Caseiro Que Cura o Fígado Gordo em 3 Dias",
                "status": "descartado",
                "avaliacao": "Promete cura milagrosa inverificável e prejudica a credibilidade do canal.",
            },
            {
                "tema": "Fisiopatologia da Resistência Insulínica em Adultos",
                "status": "descartado",
                "avaliacao": "Tom de aula universitária fria; afasta o público que busca storytelling visual.",
            },
            {
                "tema": "Por Que Você Acorda Cansado Mesmo Dormindo 8 Horas Depois dos 40?",
                "status": "aprovado",
                "avaliacao": "Conecta-se imediatamente a uma dor real do público 40+ e permite excelente visualização 2D do sono e metabolismo.",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "O Que Acontece no Seu Corpo Quando Você Acorda Cansado Todos os Dias Após os 40?",
                "traducao": "",
                "potencial_narrativo": "Dor universal do público 40+; Miguel mostra visualmente a diferença entre descanso muscular e fadiga celular silenciosa.",
                "gancho": "Você dorme sete ou oito horas, mas quando o despertador toca às seis da manhã, parece que um caminhão passou por cima do seu corpo. Depois dos 40, isso raramente é falta de sono.",
            },
            {
                "prioridade": 2,
                "titulo": "7 Sinais Silenciosos de Que Seus Músculos Estão Envelhecendo Mais Rápido Que Você",
                "traducao": "",
                "potencial_narrativo": "Alerta preventivo altamente visual sobre perda de força, metabolismo lento e como reverter a tempo.",
                "gancho": "O envelhecimento real não começa nas rugas do rosto — ele começa silenciosamente nas fibras das suas pernas dez anos antes de você notar.",
            },
            {
                "prioridade": 3,
                "titulo": "O Que Acontece com Seu Cérebro e Seu Fígado Quando Você Janta Tarde por 30 Dias?",
                "traducao": "",
                "potencial_narrativo": "Hábito extremamente comum na rotina brasileira com consequências visuais claras no sono, glicose e memória.",
                "gancho": "Comer às nove e meia da noite parece inofensivo depois de um dia cheio, mas para o seu fígado e para a limpeza noturna do seu cérebro, uma reação em cadeia está apenas começando.",
            },
            {
                "prioridade": 4,
                "titulo": "Por Que a Barriga Depois dos 40 Não É Só Gordura (O Sinal Que Quase Todo Mundo Ignora)",
                "traducao": "",
                "potencial_narrativo": "Desmistifica a estética e foca na saúde metabólica e inflamação visceral de forma educativa.",
                "gancho": "E se aquela barriga resistente que apareceu depois dos 40 não for excesso de comida, mas um mecanismo de defesa de um corpo inflamado?",
            },
            {
                "prioridade": 5,
                "titulo": "O Hábito Matinal Brasileiro Que Sabota Sua Energia Antes das 10h da Manhã",
                "traducao": "",
                "potencial_narrativo": "Contraste direto entre o café da manhã tradicional e o pico/queda de energia no meio da manhã.",
                "gancho": "Logo nos primeiros trinta minutos do dia, milhões de brasileiros fazem uma escolha automática na cozinha que desliga a energia do cérebro exatamente às dez da manhã.",
            },
        ],
        "queries_radar": [
            "sinais silenciosos do corpo depois dos 40 saude",
            "o que acontece no seu corpo quando habito saude",
            "cansaco constante figado musculos longevidade",
        ],
        "categorias_nichos_virais": ["Physical Health", "Saúde", "Fitness", "Self-Improvement", "Education"],
        "canais_benchmark": ["Dr Fernando Manochi", "Pulmão em Foco", "Stickman What Happens", "Centro de Huesos y Músculos"],
    },

    "longevidad real": {
        "canal_nome": "Longevidad Real",
        "idioma_exato": "Espanhol Neutro (es)",
        "formato_real": "Cartoon editorial médico 2D (Clinical Clarity Linework) em espanhol, com educador médico de jaleco branco e protagonistas de 65 a 75 anos.",
        "contexto_e_publico": "Adultos hispanofalantes de 60+ anos preocupados em manter a força nas pernas, evitar a sarcopenia (perda muscular), acertar na alimentação diária e preservar a independência física.",
        "diretriz_gerador": (
            "Sugira temas em espanhol neutro para o Longevidad Real, um canal de educação médica visual 2D voltado a adultos de 60+ anos. "
            "Priorize preservação e recuperação de massa muscular nas pernas e braços (combate à sarcopenia), alimentos reais e porções que "
            "fortalecem ou enfraquecem os músculos após os 60, erros comuns no café da manhã e jantar do idoso que aceleram a fraqueza física, "
            "e ajustes práticos para preservar a autonomia e evitar quedas. Use contrastes claros (erro comum vs. escolha fisiológica correta) "
            "e metáforas visuais anatômicas. Evite estética de fisiculturismo jovem ou promessas farmacológicas."
        ),
        "o_que_priorizar": [
            "Preservação de massa muscular e força nas pernas após os 60 e 70 anos (sarcopenia)",
            "Nutrição geriátrica prática: absorção de proteínas, alimentos anti-inflamatórios e erros comuns nas refeições",
            "Comparações visuais diretas ('INCORRECTO' vs 'CORRECTO') na alimentação e postura/movimento",
            "Autonomia física: subir escadas, levantar da cadeira sem dor, equilíbrio e prevenção de quedas",
        ],
        "o_que_evitar": [
            "Rotinas de academia pesada ou fisiculturismo para jovens de 20 anos",
            "Temas sem relação com longevidade e saúde 60+",
            "Promessas de rejuvenescimento mágico sem base fisiológica",
        ],
        "termos_proibidos_titulo": ["culturismo", "adolescentes", "cripto"],
        "como_aproveitar_virais": (
            "Adapte os temas virais de nutrição, músculos, ossos e sinais do corpo para a fisiologia específica de quem tem mais de 60 anos, destacando alimentos acessíveis e autonomia."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "Rutina de Hipertrofia Extrema en el Gimnasio",
                "status": "descartado",
                "avaliacao": "Voltado ao público jovem de academia; desconectado da realidade e segurança articular do público 60+.",
            },
            {
                "tema": "El Error en el Desayuno Después de los 60 Que Acelera la Pérdida Muscular",
                "status": "aprovado",
                "avaliacao": "Foco cirúrgico no público 60+, une nutrição diária, sarcopenia e comparação visual clara (erro vs. acerto).",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "Por Qué Tus Piernas Pierden Fuerza Después de los 60 (Y los 4 Alimentos Que Frenan la Sarcopenia)",
                "traducao": "Por Que Suas Pernas Perdem Força Depois dos 60 (E os 4 Alimentos Que Freiam a Sarcopenia)",
                "potencial_narrativo": "Une o sintoma mais sentido aos 60+ (pernas fracas ao subir degraus) com solução nutricional prática e visual.",
                "gancho": "Subir un tramo de escaleras o levantarse de un sillón bajo no debería sentirse como escalar una montaña a los 65 años. Cuando las piernas pierden fuerza, el problema casi nunca es solo la edad.",
            },
            {
                "prioridade": 2,
                "titulo": "El Error en el Desayuno Después de los 60 Que Destruye Tu Masa Muscular Sin Que Lo Notes",
                "traducao": "O Erro no Café da Manhã Depois dos 60 Que Destrói Sua Massa Muscular Sem Você Notar",
                "potencial_narrativo": "Contraste visual perfeito entre o desjejum pobre em leucina/proteína e a síntese muscular matinal após os 60.",
                "gancho": "Un café con pan tostado parece el desayuno más ligero y saludable a los 65 años, pero durante esas primeras cuatro horas de la mañana, tus músculos están pagando un precio silencioso.",
            },
            {
                "prioridade": 3,
                "titulo": "5 Señales Silenciosas de Que Tu Cuerpo No Está Absorbiendo la Proteína Que Comes a los 65 Años",
                "traducao": "5 Sinais Silenciosos de Que Seu Corpo Não Está Absorvendo a Proteína Que Você Come aos 65 Anos",
                "potencial_narrativo": "Explica a resistência anabólica da maturidade com metáforas visuais médicas fáceis de entender.",
                "gancho": "Puedes estar comiendo carne, huevos o legumbres todos los días y, aun así, tus músculos pueden estar pasando hambre después de los 60 años.",
            },
            {
                "prioridade": 4,
                "titulo": "Qué le Pasa a Tus Músculos y Articulaciones Cuando Caminas 20 Minutos Después de Comer",
                "traducao": "O Que Acontece com Seus Músculos e Articulações Quando Você Caminha 20 Minutos Após Comer",
                "potencial_narrativo": "Hábito simples e seguro para 60+ com impacto imediato na glicemia e lubrificação articular.",
                "gancho": "Quedarse sentado en el sofá justo después del almuerzo es una costumbre casi sagrada, pero cambiar solo veinte minutos cambia por completo lo que ocurre dentro de tus arterias y rodillas.",
            },
            {
                "prioridade": 5,
                "titulo": "3 Movimientos en Silla Que Devuelven la Estabilidad a las Rodillas y Evitan Caídas Después de los 60",
                "traducao": "3 Movimentos na Cadeira Que Devolvem a Estabilidade aos Joelhos e Evitam Quedas Depois dos 60",
                "potencial_narrativo": "Altíssima utilidade prática e retenção visual com demonstração anatômica 2D.",
                "gancho": "El equilibrio no desaparece de la noche a la mañana: se apaga músculo por músculo cuando dejamos de activar tres pequeños estabilizadores de la cadera y la rodilla.",
            },
        ],
        "queries_radar": [
            "masa muscular despues de los 60 sarcopenia alimentos",
            "fuerza en las piernas adultos mayores salud",
            "huevos musculos articulaciones despues de los 60",
        ],
        "categorias_nichos_virais": ["Saúde", "Physical Health", "Senior Health", "Fitness"],
        "canais_benchmark": ["Centro de Huesos y Músculos", "Dr. Michael Kent | Senior Health", "Dr Fernando Manochi"],
    },

    "the catch-up chapter": {
        "canal_nome": "The Catch-Up Chapter",
        "idioma_exato": "Inglês Americano (en-US)",
        "formato_real": "Cartoon editorial adulto 2D (100% STILL IMAGES [flow][i][16:9] animadas no Studio com o protagonista Arthur) sobre finanças pessoais, matemática oculta da riqueza, alavancagem vs. trabalho linear e recuperação financeira ('Catch-Up') entre os 35 e 65 anos.",
        "contexto_e_publico": "Adultos nos EUA (35 a 65 anos) que trabalham duro, sentem que a classe média está espremida e buscam estratégias racionais, comportamentais e matemáticas para conquistar liberdade financeira e recuperar o tempo perdido.",
        "diretriz_gerador": (
            "Sugira temas em inglês americano para o The Catch-Up Chapter, um canal de educação financeira, psicologia do dinheiro e "
            "estratégia patrimonial em cartoon editorial 2D voltado a adultos nos EUA (35 a 65 anos). Priorize paradoxos financeiros "
            "contraintuitivos (ex.: alavancagem vs. renda linear, o custo invisível do estilo de vida suburbano), estratégias reais para "
            "quem precisa acelerar a aposentadoria depois dos 40/50 anos ('Catch-Up'), e decisões que compram tempo e liberdade. "
            "Evite day-trade, criptomoedas especulativas, notícias passageiras da bolsa ou promessas de dinheiro fácil."
        ),
        "o_que_priorizar": [
            "Paradoxos matemáticos da riqueza (por que trabalhar mais horas em renda linear não gera riqueza real)",
            "Estratégias de 'Catch-Up' (como acelerar 20 anos de patrimônio em 7 a 10 anos após os 40/50 anos)",
            "Armadilhas silenciosas da classe média americana (carros financiados, upgrade de casa, impostos invisíveis, inflação de estilo de vida)",
            "Histórias visuais com o protagonista Arthur comparando dois caminhos financeiros ao longo do tempo",
        ],
        "o_que_evitar": [
            "Dicas de day-trade, meme coins ou apostas especulativas",
            "Notícias políticas partidárias ou manchetes efêmeras do dia em Wall Street",
            "Conteúdo infantilizado para adolescentes fazendo bicos na internet",
        ],
        "termos_proibidos_titulo": ["meme coin", "crypto pump", "day trading", "get rich overnight"],
        "como_aproveitar_virais": (
            "Transforme a ansiedade econômica atual (IA no trabalho, inflação, medo de não conseguir se aposentar) em teses financeiras contraintuitivas e visuais estreladas pelo Arthur."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "Top 5 Penny Stocks to Buy This Week",
                "status": "descartado",
                "avaliacao": "Especulação de curto prazo; foge completamente do formato de sabedoria patrimonial e psicologia financeira do canal.",
            },
            {
                "tema": "Why Working Half as Much Makes You Richer (The Math They Hide)",
                "status": "aprovado",
                "avaliacao": "Paradoxo contraintuitivo perfeito: contrasta renda linear vs. alavancagem e prende o público adulto do início ao fim.",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "Why Working Half as Much Makes You Richer (The Math They Hide)",
                "traducao": "Por Que Trabalhar Metade do Tempo Te Deixa Mais Rico (A Matemática Que Eles Escondem)",
                "potencial_narrativo": "Contrasta a armadilha das horas extras lineares com a construção de ativos e alavancagem através da história visual de Arthur.",
                "gancho": "Look at your bank account right now. Now multiply that number by two. What if doubling your income by working twice as hard actually leaves you poorer in the only currency that truly matters?",
            },
            {
                "prioridade": 2,
                "titulo": "The $100,000 Middle-Class Trap That Keeps Smart People Broke After 45",
                "traducao": "A Armadilha de US$ 100.000 da Classe Média Que Mantém Pessoas Inteligentes Quebradas Após os 45",
                "potencial_narrativo": "Explica como o salário de 6 dígitos é drenado por obrigações fixas invisíveis e como destravar a taxa de poupança tardia.",
                "gancho": "Crossing a hundred thousand dollars a year used to be the finish line of the American Dream—today, for millions of adults over forty-five, it is the most expensive trap they ever walked into.",
            },
            {
                "prioridade": 3,
                "titulo": "Why Catching Up on Retirement at 50 Is Faster Than Starting at 25 (If You Break One Rule)",
                "traducao": "Por Que Recuperar a Aposentadoria aos 50 É Mais Rápido Que Começar aos 25 (Se Você Quebrar Uma Regra)",
                "potencial_narrativo": "Toca diretamente na tese central do canal ('The Catch-Up Chapter') com esperança realista e matemática clara.",
                "gancho": "Every financial textbook says if you didn't start investing at twenty-five, you missed the compounding train. They leave out the one unfair advantage you only have at fifty.",
            },
            {
                "prioridade": 4,
                "titulo": "What Happens When You Downsize Your Ego for 36 Months After 40",
                "traducao": "O Que Acontece Quando Você Reduz o Seu Ego por 36 Meses Depois dos 40",
                "potencial_narrativo": "Experimento mental e financeiro mostrando o efeito bola de neve de cortar custos de status por 3 anos.",
                "gancho": "What if just thirty-six months of living beneath your neighbor's expectations could buy back the next twenty years of your life?",
            },
            {
                "prioridade": 5,
                "titulo": "The Silent Wealth Transfer Happening Inside Every Suburban Driveway",
                "traducao": "A Transferência Silenciosa de Riqueza Que Acontece na Garagem de Cada Subúrbio",
                "potencial_narrativo": "Visualização forte de como depreciação + juros compostos reversos transferem anos de trabalho para bancos.",
                "gancho": "Parked in almost every quiet suburban driveway is a machine silently transferring seven hundred thousand dollars of future retirement wealth straight to the bank.",
            },
        ],
        "queries_radar": [
            "catch up retirement after 45 50 personal finance",
            "middle class trap wealth psychology animated",
            "munger method Charlie Munger wealth habits",
        ],
        "categorias_nichos_virais": ["Finanças (Documentário)", "Psicologia Comportamental Visual", "Business", "Finance"],
        "canais_benchmark": ["The Munger Method", "Economy Rewind", "HistoFund", "Revers Hub"],
    },

    "stormscope report": {
        "canal_nome": "StormScope Report",
        "idioma_exato": "Inglês Americano (en-US)",
        "formato_real": "Documentário investigativo de alta retenção com 100% de filmagens e fotografias reais (0% IA, thumbnails fotográficas sem letras na frente), seguindo os canais de referência oficiais USA Severe Weather (https://www.youtube.com/@USASevereWeather) e Weather Field Report (https://www.youtube.com/@WeatherFieldReport).",
        "contexto_e_publico": "Público global em inglês fascinado por eventos climáticos extremos reais, bombas meteorológicas (microbursts, haboobs, flash floods, supercélulas), colapsos geológicos (sinkholes) e engenharia vs. fúria da natureza.",
        "diretriz_gerador": (
            "Sugira temas em inglês americano para o StormScope Report, um canal documental de eventos climáticos extremos e desastres "
            "reais com 100% de filmagens autênticas (0% IA), modelado nos canais de referência USA Severe Weather (@USASevereWeather) e "
            "Weather Field Report (@WeatherFieldReport). Priorize fenômenos meteorológicos, geológicos e hidrológicos reais, datados "
            "e amplamente registrados em câmera (microbursts, haboobs, enchentes relâmpago, sinkholes urbanos, derechos, supertornados e "
            "colapsos de infraestrutura) onde uma cidade ou rodovia comum vira um cenário de sobrevivência em minutos. Destaque a física "
            "atmosférica, dados reais de sensores e o impacto humano. Evite ficção científica, profecias sem base ou eventos sem imagens reais."
        ),
        "o_que_priorizar": [
            "Eventos climáticos e geológicos 100% REAIS (padrão @USASevereWeather e @WeatherFieldReport), com local, data, números de sensores (mph, pés, milímetros) e farto arquivo em vídeo",
            "Contraste imediato nos primeiros 60s entre uma rotina urbana normal (rodovia, aeroporto, bairro) e o impacto súbito",
            "Termos técnicos altamente visuais (microburst, haboob, derecho, flash flood, karst sinkhole, storm surge, limnic eruption)",
            "Explicação clara da física por trás do desastre + cronologia minuto a minuto",
        ],
        "o_que_evitar": [
            "Histórias fictícias ou cenários imaginários que dependam de imagens geradas por IA ou avatares animados",
            "Teorias da conspiração climáticas ou profecias apocalípticas sem comprovação científica",
            "Eventos antigos do século XVIII/XIX que não possuam fotografias ou vídeos reais",
        ],
        "termos_proibidos_titulo": ["prophecy", "alien", "biblical sign", "fictional"],
        "como_aproveitar_virais": (
            "Analise os vídeos virais de USA Severe Weather (@USASevereWeather), Weather Field Report (@WeatherFieldReport) e desastres climáticos e selecione eventos reais documentados em câmera onde a física da natureza superou a infraestrutura humana em segundos."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "What If the Sun Exploded Tomorrow?",
                "status": "descartado",
                "avaliacao": "Ficção especulativa que exigiria 100% de imagens de IA/CGI; incompatível com a regra de 100% filmagens reais do StormScope Report.",
            },
            {
                "tema": "Why This 80mph Phoenix Microburst Trapped Hundreds in Zero Visibility",
                "status": "aprovado",
                "avaliacao": "Evento real, amplamente filmado, combina física atmosférica fascinante com tensão imediata na rodovia.",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "When a 1,000-Year Flash Flood Turned Ellicott City's Main Street Into a Raging Canyon",
                "traducao": "Quando uma Enchente Relâmpago de 1.000 Anos Transformou a Rua Principal de Ellicott City em um Cânion Furioso",
                "potencial_narrativo": "Evento real com dezenas de vídeos dramáticos de rua mostrando a água subindo 3 metros em minutos e carros sendo arrastados.",
                "gancho": "At six-thirty on a Saturday evening, families were dining along historic Main Street in Ellicott City, Maryland—completely unaware that six inches of rain had just turned the surrounding hills into a funnel aimed straight at downtown.",
            },
            {
                "prioridade": 2,
                "titulo": "The 140mph Inland Hurricane That Flattened the Midwest Without Warning (2020 Derecho)",
                "traducao": "O Furacão Terrestre de 225 km/h Que Devastou o Meio-Oeste Sem Aviso (Derecho de 2020)",
                "potencial_narrativo": "Fenômeno meteorológico real impressionante (Derecho) com ventos de furacão Categoria 4 no meio do continente.",
                "gancho": "Hurricanes are supposed to die the moment they hit land. Yet on August 10th, a wall of thunderstorms over Iowa locked together and accelerated to one hundred and forty miles per hour across seven hundred miles of heartland.",
            },
            {
                "prioridade": 3,
                "titulo": "The Day a 200-Foot Crater Swallowed a Three-Story Factory in Seconds (Guatemala City)",
                "traducao": "O Dia em Que uma Cratera de 60 Metros Engoliu uma Fábrica de Três Andares em Segundos",
                "potencial_narrativo": "Combina tempestade tropical (Agatha), falha de drenagem subterrânea e solo vulcânico em imagens reais chocantes.",
                "gancho": "Beneath the wet asphalt of Zone 2 in Guatemala City, torrential rain from Tropical Storm Agatha was silently carving a cathedral-sized void in volcanic pumice—until an entire intersection vanished.",
            },
            {
                "prioridade": 4,
                "titulo": "Trapped Inside the Joplin EF5 Monster: How a Rain-Wrapped Tornado Hid in Plain Sight",
                "traducao": "Presos Dentro do Monstro EF5 de Joplin: Como um Tornado Envolto em Chuva Se Escondeu à Vista de Todos",
                "potencial_narrativo": "Explica o perigo mortal dos tornados 'rain-wrapped' (invisíveis atrás da cortina de chuva) com registros reais.",
                "gancho": "The sirens in Joplin, Missouri had sounded so many times that spring that shoppers barely looked up—until the dark curtain of rain in front of them revealed a mile-wide vortex moving at two hundred miles per hour.",
            },
            {
                "prioridade": 5,
                "titulo": "When Lituya Bay's 1,720-Foot Mega-Tsunami Stripped an Entire Mountain Bare",
                "traducao": "Quando o Mega-Tsunami de 524 Metros de Lituya Bay Arrancou a Floresta de uma Montanha Inteira",
                "potencial_narrativo": "A maior onda já registrada na história moderna, com fotos aéreas reais da cicatriz na montanha e relatos de sobreviventes.",
                "gancho": "In a narrow Alaskan fjord, forty million cubic yards of rock sheared off a cliff into deep water, sending a wave taller than the Empire State Building racing across the bay at over one hundred miles per hour.",
            },
        ],
        "queries_radar": [
            "USA Severe Weather Weather Field Report extreme storm flood tornado",
            "microburst haboob flash flood caught on camera documentary",
            "disaster breakdown severe weather usa extreme storm",
            "sinkhole collapse flood engineering disaster",
        ],
        "categorias_nichos_virais": ["Documentary", "Science", "History", "Geopolitics"],
        "canais_benchmark": ["USA Severe Weather", "Weather Field Report", "Hindcast", "Disaster Breakdown", "Fascinating Horror"],
    },

    "o estrategista oculto": {
        "canal_nome": "O Estrategista Oculto",
        "idioma_exato": "Português do Brasil (pt-BR)",
        "formato_real": "Documentário de Crônica Histórica Ilustrada 2D (100% IMAGENS ESTÁTICAS [flow][i][16:9] animadas no Studio com Ken Burns) sobre a história oculta, batalhas esquecidas, fundação sangrenta de cidades e segredos geopolíticos dos estados do Brasil.",
        "contexto_e_publico": "Brasileiros apaixonados por história profunda, geopolítica histórica, origens reais dos estados e cidades do Brasil, conflitos coloniais/indígenas e segredos que os livros escolares resumem em duas linhas.",
        "diretriz_gerador": (
            "Sugira temas em português para O Estrategista Oculto, um canal documental de Crônica Histórica Ilustrada 2D sobre a história "
            "oculta do Brasil e de seus estados. Priorize episódios históricos reais, dramáticos e pouco contados em detalhes: guerras de "
            "fundação de capitais brasileiras, alianças e batalhas entre impérios europeus e nações indígenas, revoltas regionais brutais, "
            "cidades engolidas pela floresta ou pelo mar e segredos estratégicos que desenharam as fronteiras do Brasil. Evite política "
            "partidária contemporânea ou resumos escolares frios."
        ),
        "o_que_priorizar": [
            "Fundações dramáticas e sangrentas de capitais e estados brasileiros (Pará, Amazonas, Bahia, Pernambuco, Minas, Rio Grande do Sul, etc.)",
            "Batalhas esquecidas, cercos militares, fortificações e resistência indígena/quilombola estratégica",
            "Disputas entre Portugal, França, Holanda e Espanha pelo controle de rios, ouro e costas brasileiras",
            "Conexão entre o evento histórico oculto e a arquitetura/cultura atual daquela cidade ou estado",
        ],
        "o_que_evitar": [
            "Debates político-partidários ou eleitorais contemporâneos",
            "Resumos didáticos de livro escolar sem tensão narrativa ou mistério histórico",
            "Ficção sem base documental na história do Brasil",
        ],
        "termos_proibidos_titulo": ["eleições 2026", "criptomoeda", "fofoca"],
        "como_aproveitar_virais": (
            "Observe o sucesso de canais como TheLanguageMap, HistoryWhy e Codigo da Natureza Selvagem ('Por que ninguém mora em...', 'A guerra esquecida que mudou o mapa') e aplique à geografia e história profunda dos estados brasileiros."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "Resumo da História do Brasil Colônia para o ENEM",
                "status": "descartado",
                "avaliacao": "Tom escolar burocrático; zero mistério ou retenção documental.",
            },
            {
                "tema": "A Guerra Sangrenta nos Mangues de Belém Que Quase Expulsou Portugal da Amazônia",
                "status": "aprovado",
                "avaliacao": "Tensão épica, cenário visual rico para Crônica Ilustrada 2D e revela a origem real de uma grande capital brasileira.",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "O Império Indígena Militarizado Que Humilhou Tropas Europeias no Coração do Brasil (Guerra dos Bárbaros)",
                "traducao": "",
                "potencial_narrativo": "Mais de 50 anos de guerra no sertão nordestino onde confederações indígenas dominaram táticas de guerrilha e cavalaria contra a Coroa.",
                "gancho": "Durante mais de meio século no sertão do Nordeste, uma aliança militar indígena tão letal colocou o Império Português de joelhos que Lisboa chegou a temer perder todo o interior do Brasil.",
            },
            {
                "prioridade": 2,
                "titulo": "Por Que o Brasil Quase Falou Tupi em Vez de Português? O Decreto Secreto Que Mudou Nossa Língua",
                "traducao": "",
                "potencial_narrativo": "Inspirado nos maiores virais de história linguística: até o século XVIII a Língua Geral dominava São Paulo e a Amazônia até a intervenção brutal de Pombal.",
                "gancho": "Se você viajasse para São Paulo ou para o Maranhão no ano de 1740, falar português nas ruas faria você parecer um estrangeiro — até que uma ordem real decidiu apagar o idioma dominante do Brasil.",
            },
            {
                "prioridade": 3,
                "titulo": "A Cidade Mais Rica de Minas Que Foi Queimada Viva pelo Próprio Governador (Revolta de Filipe dos Santos)",
                "traducao": "",
                "potencial_narrativo": "O Morro da Queimada em Ouro Preto: ruínas reais de uma cidade inteira incendiada durante a noite para dar exemplo aos mineradores.",
                "gancho": "No alto das montanhas de Ouro Preto ainda existem as ruínas de pedra de um bairro inteiro que o governador mandou incendiar com famílias lá dentro para calar a primeira revolta do ouro.",
            },
            {
                "prioridade": 4,
                "titulo": "França Equinocial: Os 3 Anos em Que São Luís do Maranhão Foi a Capital de um Império Francês nos Trópicos",
                "traducao": "",
                "potencial_narrativo": "Única capital brasileira fundada por franceses; batalhas navais, alianças tupinambás e o cerco de Jerônimo de Albuquerque.",
                "gancho": "Antes de pertencer a Portugal, uma ilha estratégica no norte do Brasil foi escolhida pela corte de Paris para ser o coração de uma nova França tropical na América do Sul.",
            },
            {
                "prioridade": 5,
                "titulo": "O Segredo Subterrâneo do Forte Príncipe da Beira: A Fortaleza Colossal no Fim da Amazônia",
                "traducao": "",
                "potencial_narrativo": "Como Portugal ergueu a maior fortaleza militar da selva em Rondônia para barrar o avanço espanhol pelo rio Guaporé.",
                "gancho": "No meio da selva fechada de Rondônia, a milhares de quilômetros do litoral, ergue-se uma muralha de pedra digna da Europa medieval — construída a um custo humano que a história oficial tentou esquecer.",
            },
        ],
        "queries_radar": [
            "historia oculta do brasil batalhas esquecidas",
            "por que o brasil historia estados cidades documentario",
            "guerras coloniais indigenas brasil documentario",
        ],
        "categorias_nichos_virais": ["História Visual / Documentários Históricos Imersivos", "História Narrada / História Militar", "History", "Documentary"],
        "canais_benchmark": ["TheLanguageMap", "Codigo da natureza Selvagem", "HistoryWhy", "Past Compass", "Majestic Studios"],
    },

    "capittofin": {
        "canal_nome": "CapittoFin",
        "idioma_exato": "Português do Brasil (pt-BR)",
        "formato_real": "Storytelling financeiro animado 2D (Cartoon Stylized ambientado no Brasil real — arquitetura, casas, carros e rotina brasileira) sobre psicologia do dinheiro, dilemas familiares e armadilhas patrimoniais.",
        "contexto_e_publico": "Adultos brasileiros (25 a 55 anos) que querem entender por que o dinheiro escapa mesmo quando a renda sobe, como escapar das armadilhas de status e juros no Brasil e como construir patrimônio real.",
        "diretriz_gerador": (
            "Sugira temas em português para o CapittoFin, um canal brasileiro de histórias animadas 2D sobre educação financeira, "
            "psicologia do dinheiro e dilemas patrimoniais no Brasil real. Priorize histórias humanas e contrastes de escolhas financeiras "
            "(ex.: o preço invisível de financiar aparências na classe média brasileira, conflitos familiares por dinheiro ou herança, "
            "por que quem ganha mais muitas vezes empobrece mais rápido no Brasil, e estratégias de liberdade financeira). Use cenários "
            "autenticamente brasileiros. Evite relatórios técnicos da bolsa, recomendações de tickers ou jargões distantes do cotidiano."
        ),
        "o_que_priorizar": [
            "Psicologia do dinheiro no Brasil: o custo invisível de aparentar riqueza (carro zero financiado, condomínio caro, parcelamento infinito)",
            "Dilemas familiares e patrimoniais (emprestar dinheiro para parentes, herança mal planejada, padrão de vida incompatível)",
            "Contrastes narrativos entre dois personagens brasileiros com a mesma renda e destinos financeiros opostos",
            "Matemática real dos juros compostos no Brasil (a favor de quem investe vs. contra quem financia status)",
        ],
        "o_que_evitar": [
            "Análise técnica de gráfico de day-trade ou recomendação de compra de ações específicas da B3",
            "Noticiário político-econômico diário sem história humana",
            "Promessas de renda fácil com apostas ou esquemas duvidosos",
        ],
        "termos_proibidos_titulo": ["day trade", "opções binárias", "aposta garantida"],
        "como_aproveitar_virais": (
            "Pegue o impacto de canais como Luxo Afundado, A Psique e Historias que Dejan Lección (dramas patrimoniais, ilusão de status, psicologia financeira) e traga para o formato animado brasileiro do CapittoFin."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "3 Ações Dividendos para Comprar Hoje na B3",
                "status": "descartado",
                "avaliacao": "Conteúdo datado de corretora; perde o poder de storytelling animado atemporal do CapittoFin.",
            },
            {
                "tema": "Por Que Ganhar R$ 15 Mil no Brasil Muitas Vezes Te Deixa Mais Endividado Que Ganhar R$ 5 Mil",
                "status": "aprovado",
                "avaliacao": "Toca na ferida real da inflação de estilo de vida no Brasil com altíssimo potencial de identificação e animação 2D.",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "Por Que Ganhar R$ 15 Mil no Brasil Muitas Vezes Te Deixa Mais Preso do Que Ganhar R$ 5 Mil",
                "traducao": "",
                "potencial_narrativo": "Mostra passo a passo como o 'upgrade de classe média' no Brasil engole todo o aumento salarial em custos fixos e financiamentos.",
                "gancho": "Quando o salário dobra no Brasil, a maioria das pessoas acha que finalmente chegou à liberdade — sem perceber que acabou de assinar um contrato invisível para precisar trabalhar até os setenta anos.",
            },
            {
                "prioridade": 2,
                "titulo": "A Armadilha do Carro de R$ 150 Mil na Garagem Que Rouba 15 Anos da Sua Aposentadoria",
                "traducao": "",
                "potencial_narrativo": "Visualização brutal do custo real (IPVA, seguro, depreciação + custo de oportunidade na renda fixa brasileira) de trocar de carro por status.",
                "gancho": "Estacionado na garagem de milhões de famílias brasileiras está um símbolo de conquista que, silenciosamente, drena o equivalente a um apartamento inteiro a cada década.",
            },
            {
                "prioridade": 3,
                "titulo": "O Erro Silencioso Que Faz Famílias Brasileiras Perderem Tudo Entre a Primeira e a Segunda Geração",
                "traducao": "",
                "potencial_narrativo": "Storytelling emocional sobre construção de patrimônio familiar, educação financeira dos filhos e conflitos de herança.",
                "gancho": "O pai construiu tudo do zero trabalhando quatorze horas por dia; vinte anos depois, não sobrou nem a casa da família. E o erro não começou quando o dinheiro acabou — começou quando ele sobrou.",
            },
            {
                "prioridade": 4,
                "titulo": "Por Que o Milionário Silencioso do Seu Bairro Vive Como Classe Média (A Regra que Ninguém Vê)",
                "traducao": "",
                "potencial_narrativo": "Contraste visual fascinante entre o 'falso rico' endividado e o investidor silencioso em uma cidade brasileira.",
                "gancho": "Na mesma rua, um vizinho dirige uma caminhonete financiada e não dorme por causa das faturas; o outro anda num carro simples quitado e recebe todo mês mais do que gasta.",
            },
            {
                "prioridade": 5,
                "titulo": "O Custo Oculto de Não Saber Dizer 'Não' para a Própria Família Quando Sua Renda Sobe",
                "traducao": "",
                "potencial_narrativo": "Dilema emocional profundamente brasileiro: culpa familiar, empréstimos que nunca voltam e como ajudar sem se destruir.",
                "gancho": "No Brasil, muitas vezes o maior imposto sobre quem começa a prosperar não vem do governo — vem da mesa de domingo e do medo de parecer egoísta para quem você ama.",
            },
        ],
        "queries_radar": [
            "psicologia do dinheiro classe media brasil",
            "armadilha financeira carro financiado patrimonio",
            "historias financeiras riqueza silenciosa",
        ],
        "categorias_nichos_virais": ["Finanças (Documentário)", "Psicologia Comportamental Visual", "Documentary", "Histórias que Dejan Lección"],
        "canais_benchmark": ["Luxo Afundado", "A Psique", "Economy Rewind", "The Munger Method"],
    },

    "gta a la une": {
        "canal_nome": "GTA à la Une",
        "idioma_exato": "Francês (fr-FR)",
        "formato_real": (
            "Ensaio Documental & Análise Técnica Gaming 100% em Francês (fr-FR) focado EXCLUSIVAMENTE nos jogos Grand Theft Auto (Rockstar Games), "
            "seguindo exatamente o padrão dos vídeos oficiais de referência: "
            "Mano. ('Le jeu vidéo a atteint sa limite avec GTA 6' — https://www.youtube.com/watch?v=8GD39QLKtyY&t=50s), "
            "Rockstar Mag' ('VOILÀ, C'ÉTAIT GTA V.' — https://www.youtube.com/watch?v=dPSpuFYoEF8), "
            "Rou ('L'incroyable technologie derrière GTA 6' — https://www.youtube.com/watch?v=I-bJ61bouDo), "
            "Vico GTA ('GTA 6 sort dans 10 jours : tout ce qu'il faut savoir avant de jouer') e "
            "G3ADRIEN OFF ('GTA 6 fait des choses qu'on n'aurait JAMAIS imaginées dans GTA 5 !'). "
            "100% de imagens e vídeos reais dos JOGOS GTA (GTA VI, GTA V, GTA IV, San Andreas, Vice City); disco local D: e outros bancos externos apenas em último caso para apoio."
        ),
        "contexto_e_publico": (
            "Comunidade francófona (França, Bélgica, Suíça, Canadá/Québec e África Francófona) apaixonada exclusivamente pelo universo dos jogos Grand Theft Auto — "
            "GTA VI (Leonida & Vice City, Lucia & Jason), GTA V (Los Santos), GTA IV (Liberty City & Niko Bellic), San Andreas, Vice City e motor RAGE 9 da Rockstar Games."
        ),
        "diretriz_gerador": (
            "Sugira temas 100% em francês (fr-FR) para o canal GTA à la Une, focado 100% SOMENTE NOS JOGOS GTA no estilo exato de "
            "Mano. (ensaios de impacto sobre os limites da indústria com GTA 6), Rockstar Mag' (retrospectivas e dossiês 100% dentro dos jogos GTA V / GTA IV / GTA VI), "
            "Rou (análise da tecnologia absurda do motor RAGE 9, 600.000+ animações, física Euphoria, ray tracing, IA de PNJ) e "
            "Vico GTA / G3ADRIEN OFF ('Tout ce qu'il faut savoir avant de jouer à GTA 6', 'GTA 6 fait des choses qu'on n'aurait JAMAIS imaginées dans GTA 5 !'). "
            "Títulos curtos, magnéticos e virais em francês (48–74 caracteres), 100% ilustrados com gameplay, trailers e capturas dos jogos GTA."
        ),
        "o_que_priorizar": [
            "Ensaios profundos sobre os limites técnicos e orçamentários de GTA 6 (estilo Mano. — 'Le jeu vidéo a atteint sa limite avec GTA 6')",
            "Análise tecnológica do motor RAGE 9, 600.000+ animações, física da água/lama, danos procedurais e IA patenteada dos PNJ (estilo Rou — 'L'incroyable technologie derrière GTA 6')",
            "Dossiês 100% focados nos jogos da franquia: GTA V, GTA IV (Liberty City / saída de novembro), San Andreas, Vice City e GTA VI (estilo Rockstar Mag' — 'VOILÀ, C'ÉTAIT GTA V.')",
            "Comparativos diretos e guias essenciais de alto CTR francófono (estilo Vico GTA & G3ADRIEN OFF — 'GTA 6 fait des choses qu'on n'aurait JAMAIS imaginées dans GTA 5 !')",
            "100% de imagens e vídeos retirados dos próprios jogos GTA (0% repetição entre vídeos; disco local D: e outros bancos apenas em último caso extremo de apoio)",
        ],
        "o_que_evitar": [
            "Assuntos fora dos jogos Grand Theft Auto / Rockstar Games",
            "Usar vídeos genéricos de bancos stock reais quando há gameplay, trailers e capturas dos jogos GTA disponíveis",
            "Clickbait falso prometendo download pirata, cracks ou hacks",
            "Repetir sempre as mesmas imagens ou vídeos já usados nos vídeos anteriores do canal",
            "Gameplay cru sem roteiro analítico, sem gancho nos primeiros 50s ou sem storytelling documental em francês",
        ],
        "termos_proibidos_titulo": ["crack gratuit", "télécharger gta gratuit", "hack argent illimité"],
        "como_aproveitar_virais": (
            "Combine a embalagem viral francófona de Vico GTA / G3ADRIEN OFF / Mano. com a profundidade técnica e histórica de Rou e Rockstar Mag', "
            "transformando cada mecânica do motor RAGE, comparação GTA 5 vs GTA 6 ou segredo de Liberty City / Vice City em um vídeo 100% focado no jogo GTA."
        ),
        "avaliacao_temas_exemplo": [
            {
                "tema": "Gameplay aléatoire sur GTA Online sans commentaire ni analyse",
                "status": "descartado",
                "avaliacao": "Sem tese documental, sem gancho estruturado nos primeiros 50s e fora do padrão Mano. / Rou / Rockstar Mag'.",
            },
            {
                "tema": "GTA 6 a Atteint une Limite Que Même l'Industrie du Jeu Vidéo Redoute",
                "status": "aprovado",
                "avaliacao": "Segue diretamente a fórmula viral de Mano. (8GD39QLKtyY) com altíssimo CTR francófono e 100% visual dos jogos GTA.",
            },
            {
                "tema": "L'Incroyable Technologie Derrière GTA 6 Qui Écrase Définitivement GTA 5",
                "status": "aprovado",
                "avaliacao": "Combina a análise técnica RAGE de Rou (I-bJ61bouDo) com o comparativo direto GTA 5 vs GTA 6 de G3ADRIEN OFF.",
            },
        ],
        "temas_prioritarios_aprovados": [
            {
                "prioridade": 1,
                "titulo": "Pourquoi le Jeu Vidéo a Atteint Sa Vraie Limite Avec GTA 6",
                "traducao": "Por Que o Videogame Atingiu Seu Verdadeiro Limite Com GTA 6",
                "potencial_narrativo": "Ensaio documental no estilo Mano. (8GD39QLKtyY): orçamento bilionário, escala inédita de Leonida/Vice City, anos de captura de movimento e por que nenhum outro estúdio consegue repetir o que a Rockstar fez.",
                "gancho": "Deux milliards de dollars, plus d'une décennie de développement secret et une ville virtuelle plus vivante que la réalité : avec GTA 6, Rockstar ne sort pas simplement un nouveau jeu, le studio pousse toute l'industrie face à sa propre limite.",
            },
            {
                "prioridade": 2,
                "titulo": "L'Incroyable Technologie Cachée Derrière GTA 6 (Moteur RAGE 9)",
                "traducao": "A Incrível Tecnologia Oculta Por Trás de GTA 6 (Motor RAGE 9)",
                "potencial_narrativo": "Breakdown técnico e visual no estilo Rou (I-bJ61bouDo): as patentes reais de animação procedural, física da água em tempo real, iluminação global ray-traced e memória dos PNJ em Vice City.",
                "gancho": "Derrière chaque reflet sur une carrosserie mouillée de Vice City et chaque réaction imprévisible d'un passant se cache une prouesse technologique brevetée par Rockstar que la plupart des joueurs n'imaginent même pas.",
            },
            {
                "prioridade": 3,
                "titulo": "GTA 6 Fait des Choses Qu'on N'Aurait JAMAIS Imaginées Dans GTA 5 !",
                "traducao": "GTA 6 Faz Coisas Que JAMAIS Teríamos Imaginado em GTA 5!",
                "potencial_narrativo": "Comparativo visual 100% in-game lado a lado (estilo G3ADRIEN OFF & Rockstar Mag') mostrando interiores exploráveis, inventário realista de armas no porta-malas, polícia tática, clima extremo e densidade de Leonida vs Los Santos.",
                "gancho": "Pendant plus de dix ans, Los Santos nous a paru indépassable. Pourtant, lorsqu'on compare scène par scène GTA 5 et les nouvelles mécaniques de GTA 6, l'écart générationnel devient tout simplement vertigineux.",
            },
            {
                "prioridade": 4,
                "titulo": "Voilà Ce Qu'Était Vraiment GTA V (Et Pourquoi GTA 6 Change Tout)",
                "traducao": "Eis o Que Realmente Foi GTA V (E Por Que GTA 6 Muda Tudo)",
                "potencial_narrativo": "Retrospectiva épica 100% focada no jogo (estilo Rockstar Mag' — dPSpuFYoEF8): Michael, Franklin e Trevor, a construção de Los Santos, os segredos de Mount Chiliad e a passagem de bastão para Lucia e Jason.",
                "gancho": "Trois braqueurs, une métropole californienne satirique et douze années qui ont redéfini la pop culture mondiale : avant de plonger dans Leonida, voici ce qu'était réellement l'aventure GTA V.",
            },
            {
                "prioridade": 5,
                "titulo": "Tout Ce Qu'il Faut Savoir Avant de Jouer à GTA 6 et au Retour de GTA IV",
                "traducao": "Tudo o Que Você Precisa Saber Antes de Jogar GTA 6 e o Retorno de GTA IV",
                "potencial_narrativo": "Guia completo e magnético (estilo Vico GTA) conectando todas as confirmações oficiais da Rockstar sobre Leonida/Vice City, conexões do universo HD com Liberty City (GTA IV) e mecânicas confirmadas.",
                "gancho": "Carte complète de Leonida, connexions secrètes avec Liberty City et nouvelles règles de survie à Vice City : voici absolument tout ce que vous devez savoir avant de lancer le prochain chef-d'œuvre de Rockstar.",
            },
        ],
        "queries_radar": [
            "GTA 6 analyse francais Mano Rou Rockstar Mag",
            "GTA 6 technologie moteur RAGE details francais",
            "GTA 6 vs GTA 5 comparaison francais Vico GTA",
            "Grand Theft Auto Vice City Los Santos Liberty City VF",
        ],
        "categorias_nichos_virais": ["Gaming", "Documentary", "Entertainment"],
        "canais_benchmark": ["Mano.", "Rockstar Mag'", "Rou", "Vico GTA", "G3ADRIEN OFF", "Rockstar Actu"],
    },
}


# ==============================================================================
# CATÁLOGO DE BENCHMARKS REAIS COM LINKS DIRETOS CLICÁVEIS POR CANAL
# ==============================================================================
BENCHMARKS_REAIS_POR_CANAL = {
    "capitto recomeco": [
        {
            "canal": "Iflord",
            "categoria": "What If · 3D/2D Animated Storytelling (Benchmark Oficial)",
            "idioma": "en",
            "views_totais": 14800000,
            "inscritos": 285000,
            "url": "https://www.youtube.com/@Iflord",
            "destaque": "Benchmark #1 do Canal",
            "top_videos": [
                {"titulo": "What If You Were Indestructible?", "views": 2450000, "video_id": "FKezpSvDtw4", "url": "https://www.youtube.com/watch?v=FKezpSvDtw4"},
                {"titulo": "What If You Stopped Aging at 25?", "views": 1180000, "video_id": "", "url": "https://www.youtube.com/results?search_query=Iflord+What+If+You+Were+Indestructible"},
            ],
        },
        {
            "canal": "Awaken",
            "categoria": "Education · Animated What If Scenarios",
            "idioma": "en-us",
            "views_totais": 4885449,
            "inscritos": 14800,
            "url": "https://www.youtube.com/channel/UCAGRnC0u-hiBa7eUvrFtFow",
            "destaque": "Explodindo Agora (330x Views/Sub)",
            "top_videos": [
                {"titulo": "Can 2 People Really Restart Humanity?", "views": 4295380, "video_id": "6oZ9fdM0n50", "url": "https://www.youtube.com/watch?v=6oZ9fdM0n50"},
                {"titulo": "What if You’re The Last Guy on Earth?", "views": 436647, "video_id": "XbXiFizyGko", "url": "https://www.youtube.com/watch?v=XbXiFizyGko"},
                {"titulo": "What if You Were The Last Girl On Earth?", "views": 258243, "video_id": "fFziW8Hgf84", "url": "https://www.youtube.com/watch?v=fFziW8Hgf84"},
            ],
        },
        {
            "canal": "After The Door",
            "categoria": "Hypothetical Scenarios · Animated Dilemmas",
            "idioma": "en",
            "views_totais": 3250000,
            "inscritos": 42000,
            "url": "https://www.youtube.com/results?search_query=After+The+Door+What+If",
            "destaque": "Em Ascensão no Nicho",
            "top_videos": [
                {"titulo": "What If Time Froze for 24 Hours Only for You?", "views": 890000, "video_id": "", "url": "https://www.youtube.com/results?search_query=What+If+Time+Froze+for+24+Hours+Animated"},
            ],
        },
        {
            "canal": "What If Show",
            "categoria": "Science & Speculative What If",
            "idioma": "en",
            "views_totais": 980000000,
            "inscritos": 7900000,
            "url": "https://www.youtube.com/@WhatIfScienceShow",
            "destaque": "Referência Global",
            "top_videos": [
                {"titulo": "What If You Were the Last Person on Earth?", "views": 6400000, "video_id": "", "url": "https://www.youtube.com/results?search_query=What+If+You+Were+the+Last+Person+on+Earth"},
            ],
        },
    ],
    "stormscope report": [
        {
            "canal": "USA Severe Weather",
            "categoria": "Extreme Weather Documentary · Real Footage",
            "idioma": "en",
            "views_totais": 18500000,
            "inscritos": 145000,
            "url": "https://www.youtube.com/@USASevereWeather",
            "destaque": "Benchmark Oficial #1",
            "top_videos": [
                {"titulo": "When A Category 5 Monster Slammed Into The Coast Caught On Camera", "views": 1420000, "video_id": "", "url": "https://www.youtube.com/@USASevereWeather/videos"},
                {"titulo": "Rare EF5 Tornado Trapped Drivers On The Highway", "views": 980000, "video_id": "", "url": "https://www.youtube.com/results?search_query=USA+Severe+Weather+tornado+flood"},
            ],
        },
        {
            "canal": "Weather Field Report",
            "categoria": "Field Broadcast · Severe Storm Investigations",
            "idioma": "en",
            "views_totais": 9400000,
            "inscritos": 82000,
            "url": "https://www.youtube.com/@WeatherFieldReport",
            "destaque": "Benchmark Oficial #2",
            "top_videos": [
                {"titulo": "How A 100-Foot Sinkhole Swallowed An Entire Intersection In Seconds", "views": 860000, "video_id": "", "url": "https://www.youtube.com/@WeatherFieldReport/videos"},
            ],
        },
        {
            "canal": "Disaster Breakdown",
            "categoria": "Engineering & Weather Disasters · Documentary",
            "idioma": "en",
            "views_totais": 62000000,
            "inscritos": 490000,
            "url": "https://www.youtube.com/@DisasterBreakdown",
            "destaque": "Ouro · Alta Retenção",
            "top_videos": [
                {"titulo": "The Microburst That Changed Aviation Forever (Delta Flight 191)", "views": 3100000, "video_id": "", "url": "https://www.youtube.com/results?search_query=Disaster+Breakdown+Microburst"},
            ],
        },
        {
            "canal": "Fascinating Horror",
            "categoria": "Historical Disasters & Floods · Documentary",
            "idioma": "en",
            "views_totais": 195000000,
            "inscritos": 1350000,
            "url": "https://www.youtube.com/@FascinatingHorror",
            "destaque": "Referência Narrativa",
            "top_videos": [
                {"titulo": "The Lake Peigneur Disaster: When a Salt Mine Drained a Lake", "views": 2700000, "video_id": "", "url": "https://www.youtube.com/results?search_query=Fascinating+Horror+Lake+Peigneur"},
            ],
        },
    ],
    "cappito vital": [
        {
            "canal": "Dr. Fernando Lemos - Planeta Intestino",
            "categoria": "Saúde 40+/60+ · Prevenção e Longevidade",
            "idioma": "pt",
            "views_totais": 420000000,
            "inscritos": 6500000,
            "url": "https://www.youtube.com/@PlanetaIntestino",
            "destaque": "Referência Saúde BR",
            "top_videos": [
                {"titulo": "Sinais nos Pés e Panturrilhas de Má Circulação Após os 50", "views": 1950000, "video_id": "", "url": "https://www.youtube.com/results?search_query=sinais+nos+pes+panturrilhas+circulacao+50+anos"},
            ],
        },
        {
            "canal": "Cardio DF — Dr. Rodrigo",
            "categoria": "Saúde Cardiovascular & Vitalidade Madura",
            "idioma": "pt",
            "views_totais": 85000000,
            "inscritos": 1400000,
            "url": "https://www.youtube.com/@CardioDF",
            "destaque": "Em Ascensão 60+",
            "top_videos": [
                {"titulo": "O Hábito Matinal Que Protege Seu Coração e Sua Pressão Depois dos 50", "views": 1120000, "video_id": "", "url": "https://www.youtube.com/results?search_query=habito+matinal+coracao+pressao+depois+dos+50"},
            ],
        },
        {
            "canal": "Dr. Dayan Siebra",
            "categoria": "Vitalidade, Músculos e Longevidade",
            "idioma": "pt",
            "views_totais": 690000000,
            "inscritos": 7800000,
            "url": "https://www.youtube.com/@DayanSiebra",
            "destaque": "Alto CTR Saúde",
            "top_videos": [
                {"titulo": "Como Evitar a Perda de Massa Muscular (Sarcopenia) Após os 50 Anos", "views": 1640000, "video_id": "", "url": "https://www.youtube.com/results?search_query=como+evitar+sarcopenia+apos+50+anos"},
            ],
        },
    ],
    "longevidad real": [
        {
            "canal": "Fisioterapia a tu alcance",
            "categoria": "Salud 60+ · Movilidad, Rodillas y Longevidad",
            "idioma": "es",
            "views_totais": 380000000,
            "inscritos": 5200000,
            "url": "https://www.youtube.com/@Fisioterapiaatualcance",
            "destaque": "Benchmark Salud ES",
            "top_videos": [
                {"titulo": "Por Qué Duelen Las Piernas y Rodillas Después de los 60 Años", "views": 2300000, "video_id": "", "url": "https://www.youtube.com/results?search_query=por+que+duelen+las+piernas+despues+de+los+60"},
            ],
        },
        {
            "canal": "Dr. Carlos Jaramillo",
            "categoria": "Medicina Funcional · Nutrición y Músculo 60+",
            "idioma": "es",
            "views_totais": 290000000,
            "inscritos": 4900000,
            "url": "https://www.youtube.com/@DrCarlosJaramillo",
            "destaque": "Referencia Médica ES",
            "top_videos": [
                {"titulo": "El Error en la Cena Que Consume Tu Músculo Después de los 60", "views": 1850000, "video_id": "", "url": "https://www.youtube.com/results?search_query=Dr+Carlos+Jaramillo+sarcopenia+cena"},
            ],
        },
    ],
    "the catch-up chapter": [
        {
            "canal": "Hypothetica",
            "categoria": "2D Financial Editorial Cartoon · Retirement",
            "idioma": "en",
            "views_totais": 12400000,
            "inscritos": 165000,
            "url": "https://www.youtube.com/@Hypothetica101",
            "destaque": "Benchmark Visual #1",
            "top_videos": [
                {"titulo": "Why Retiring With $500K At 55 Feels Completely Different Than You Think", "views": 740000, "video_id": "", "url": "https://www.youtube.com/@Hypothetica101/videos"},
            ],
        },
        {
            "canal": "Azul",
            "categoria": "Retirement Planning · Catch-Up After 50",
            "idioma": "en",
            "views_totais": 48000000,
            "inscritos": 540000,
            "url": "https://www.youtube.com/@AzulWells",
            "destaque": "Ouro · Público 50+",
            "top_videos": [
                {"titulo": "Why Paying Off Your Mortgage Early Can Hurt Your Retirement", "views": 1150000, "video_id": "", "url": "https://www.youtube.com/results?search_query=Azul+Wells+paying+off+mortgage+early+retirement"},
            ],
        },
    ],
    "o estrategista oculto": [
        {
            "canal": "TheLanguageMap",
            "categoria": "Geopolítica Histórica & Mapas Ilustrados",
            "idioma": "en",
            "views_totais": 21000000,
            "inscritos": 190000,
            "url": "https://www.youtube.com/@TheLanguageMap",
            "destaque": "Benchmark Visual 2D",
            "top_videos": [
                {"titulo": "Why Brazil Almost Spoke Tupi Instead of Portuguese", "views": 920000, "video_id": "", "url": "https://www.youtube.com/results?search_query=Why+Brazil+Almost+Spoke+Tupi+Instead+of+Portuguese"},
            ],
        },
        {
            "canal": "Impérios AD",
            "categoria": "História Militar & Fronteiras do Brasil",
            "idioma": "pt",
            "views_totais": 95000000,
            "inscritos": 910000,
            "url": "https://www.youtube.com/@ImperiosAD",
            "destaque": "Referência História BR",
            "top_videos": [
                {"titulo": "As Guerras Esquecidas Que Desenharam o Mapa do Brasil", "views": 1350000, "video_id": "", "url": "https://www.youtube.com/results?search_query=Imperios+AD+guerras+mapa+do+Brasil"},
            ],
        },
    ],
    "capittofin": [
        {
            "canal": "Joca Investe",
            "categoria": "Storytelling Financeiro Animado 2D (Brasil)",
            "idioma": "pt",
            "views_totais": 16500000,
            "inscritos": 240000,
            "url": "https://www.youtube.com/@jocainvesteOFICIAL",
            "destaque": "Benchmark Visual #1",
            "top_videos": [
                {"titulo": "A Armadilha do Carro Financiado na Classe Média Brasileira", "views": 880000, "video_id": "", "url": "https://www.youtube.com/@jocainvesteOFICIAL/videos"},
            ],
        },
        {
            "canal": "Luxo Afundado",
            "categoria": "Psicologia do Dinheiro & Ilusão de Status",
            "idioma": "pt",
            "views_totais": 9800000,
            "inscritos": 135000,
            "url": "https://www.youtube.com/results?search_query=Luxo+Afundado+financas",
            "destaque": "Em Ascensão Finanças BR",
            "top_videos": [
                {"titulo": "Por Que Ganhar R$ 15 Mil no Brasil Muitas Vezes Te Deixa Mais Endividado", "views": 640000, "video_id": "", "url": "https://www.youtube.com/results?search_query=por+que+classe+media+ganha+bem+e+vive+endividada"},
            ],
        },
    ],
    "gta a la une": [
        {
            "canal": "Mano.",
            "categoria": "Essai Documentaire 100% GTA 6 & Limites de l'Industrie (FR)",
            "idioma": "fr",
            "views_totais": 14500000,
            "inscritos": 185000,
            "url": "https://www.youtube.com/watch?v=8GD39QLKtyY&t=50s",
            "destaque": "Référence Officielle #1 (GTA à la Une)",
            "top_videos": [
                {
                    "titulo": "Le jeu vidéo a atteint sa limite avec GTA 6",
                    "views": 1120000,
                    "video_id": "8GD39QLKtyY",
                    "url": "https://www.youtube.com/watch?v=8GD39QLKtyY&t=50s",
                },
            ],
        },
        {
            "canal": "Rockstar Mag'",
            "categoria": "Dossiers & Rétrospectives 100% Jeux GTA (FR)",
            "idioma": "fr",
            "views_totais": 48000000,
            "inscritos": 320000,
            "url": "https://www.youtube.com/watch?v=dPSpuFYoEF8",
            "destaque": "Référence Officielle #2 (100% Jeu GTA)",
            "top_videos": [
                {
                    "titulo": "VOILÀ, C'ÉTAIT GTA V.",
                    "views": 890000,
                    "video_id": "dPSpuFYoEF8",
                    "url": "https://www.youtube.com/watch?v=dPSpuFYoEF8",
                },
            ],
        },
        {
            "canal": "Rou",
            "categoria": "Analyse Technologique Moteur RAGE & Physique GTA 6 (FR)",
            "idioma": "fr",
            "views_totais": 36000000,
            "inscritos": 290000,
            "url": "https://www.youtube.com/watch?v=I-bJ61bouDo",
            "destaque": "Référence Officielle #3 (Tech & RAGE 9)",
            "top_videos": [
                {
                    "titulo": "L'incroyable technologie derrière GTA 6",
                    "views": 960000,
                    "video_id": "I-bJ61bouDo",
                    "url": "https://www.youtube.com/watch?v=I-bJ61bouDo",
                },
            ],
        },
        {
            "canal": "Vico GTA & G3ADRIEN OFF",
            "categoria": "Packaging Viral, Guides & Comparatifs GTA 5 vs GTA 6 (FR)",
            "idioma": "fr",
            "views_totais": 29000000,
            "inscritos": 240000,
            "url": "https://www.youtube.com/results?search_query=Vico+GTA+G3ADRIEN+OFF+GTA+6",
            "destaque": "Référence Packaging & CTR Viral FR",
            "top_videos": [
                {
                    "titulo": "GTA 6 fait des choses qu'on n'aurait JAMAIS imaginées dans GTA 5 !",
                    "views": 540000,
                    "video_id": "",
                    "url": "https://www.youtube.com/results?search_query=GTA+6+fait+des+choses+qu%27on+n%27aurait+JAMAIS+imagin%C3%A9es+dans+GTA+5",
                },
                {
                    "titulo": "Tout ce que tu DOIS savoir avant de jouer à GTA 6",
                    "views": 480000,
                    "video_id": "",
                    "url": "https://www.youtube.com/results?search_query=Tout+ce+que+tu+DOIS+savoir+avant+de+jouer+%C3%A0+GTA+6",
                },
            ],
        },
    ],
}


def _normalizar_chave_canal(nome=""):
    import unicodedata
    s = unicodedata.normalize("NFKD", str(nome or "")).encode("ascii", "ignore").decode("ascii").lower().strip()
    s = re.sub(r"\s+", " ", s)
    return s


def _garantir_urls_clicaveis_canais_virais(lista_canais, ch_key=""):
    """Garante que todo canal benchmark e todo vídeo dentro de `top_videos` tenha URL clicável real do YouTube."""
    import urllib.parse
    out = []
    vistos = set()

    # 1. Começa com os benchmarks oficiais do canal específico (garantindo relevância 100% ao nicho do canal)
    for k_b, cands_b in BENCHMARKS_REAIS_POR_CANAL.items():
        if k_b in ch_key or (ch_key and ch_key in k_b):
            for cb in cands_b:
                nm = (cb.get("canal") or "").strip()
                if nm and nm.lower() not in vistos:
                    vistos.add(nm.lower())
                    out.append(dict(cb))
            break

    # 2. Adiciona os canais dinâmicos vindos do radar/nichos-virais (filtrando canais fora do nicho como Roblox em canais de clima)
    for c in (lista_canais or []):
        if not isinstance(c, dict):
            continue
        nm = claude.corrigir_mojibake_ptbr((c.get("canal") or "").strip())
        if not nm or nm.lower() in vistos:
            continue
        # Evita misturar canais infantis/Roblox em canais documentais de clima, saúde ou finanças
        txt_c_low = f"{nm} {c.get('categoria','')} {' '.join((v.get('titulo') or '') for v in (c.get('top_videos') or []))}".lower()
        if "stormscope" in ch_key and any(w in txt_c_low for w in ("roblox", "minecraft", "stickman", "girl on earth", "last guy on earth")):
            continue
        if ("vital" in ch_key or "longevidad" in ch_key or "fin" in ch_key or "catch" in ch_key) and any(w in txt_c_low for w in ("roblox", "minecraft")):
            continue
        vistos.add(nm.lower())
        c_copy = dict(c)
        c_copy["canal"] = nm
        url_c = (c_copy.get("url") or c_copy.get("canal_url") or "").strip()
        if not url_c or not url_c.startswith("http"):
            url_c = f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(nm)}"
        c_copy["url"] = url_c
        vids_limpos = []
        for tv in (c_copy.get("top_videos") or []):
            if not isinstance(tv, dict):
                continue
            vt = claude.corrigir_mojibake_ptbr((tv.get("titulo") or "").strip())
            if not vt:
                continue
            vid_id = (tv.get("video_id") or tv.get("videoId") or "").strip()
            v_url = (tv.get("url") or "").strip()
            if not v_url or not v_url.startswith("http"):
                v_url = f"https://www.youtube.com/watch?v={vid_id}" if vid_id else f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(nm + ' ' + vt)}"
            vids_limpos.append({
                "titulo": vt,
                "views": int(tv.get("views") or 0),
                "video_id": vid_id,
                "url": v_url,
            })
        c_copy["top_videos"] = vids_limpos
        out.append(c_copy)
    return out[:8]


def _montar_em_alta_detalhado(canais_virais, em_alta_textos=None):
    """Constrói lista estruturada e 100% clicável de vídeos em alta no nicho (com `url_video` e `url_canal`)."""
    import urllib.parse
    detalhados = []
    vistos = set()
    for cv in (canais_virais or []):
        if not isinstance(cv, dict):
            continue
        nm_c = (cv.get("canal") or "").strip()
        url_c = (cv.get("url") or "").strip() or f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(nm_c)}"
        for tv in (cv.get("top_videos") or []):
            vt = (tv.get("titulo") or "").strip()
            if not vt or vt.lower() in vistos:
                continue
            vistos.add(vt.lower())
            vid_id = (tv.get("video_id") or "").strip()
            url_v = (tv.get("url") or "").strip() or (
                f"https://www.youtube.com/watch?v={vid_id}" if vid_id else f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(nm_c + ' ' + vt)}"
            )
            detalhados.append({
                "titulo": vt,
                "canal": nm_c,
                "views": int(tv.get("views") or 0),
                "video_id": vid_id,
                "url_video": url_v,
                "url_canal": url_c,
                "destaque": cv.get("destaque") or "Em Alta",
            })
    for txt in (em_alta_textos or []):
        s = claude.corrigir_mojibake_ptbr(str(txt or "").strip())
        if not s:
            continue
        m = re.match(r"^\[([^\]]+)\]\s*(.+?)(?:\s*\(([\d\.,]+)\s*views\))?$", s, re.I)
        if m:
            nm_c, vt, vw_s = m.group(1).strip(), m.group(2).strip(), (m.group(3) or "0")
            if vt.lower() in vistos:
                continue
            vistos.add(vt.lower())
            vw = int(re.sub(r"\D+", "", vw_s) or 0)
            detalhados.append({
                "titulo": vt,
                "canal": nm_c,
                "views": vw,
                "video_id": "",
                "url_video": f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(nm_c + ' ' + vt)}",
                "url_canal": f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(nm_c)}",
                "destaque": "Radar do Nicho",
            })
    return detalhados[:12]


def obter_perfil_editorial_canal(ch):
    """Retorna o Perfil Editorial Profundo do canal (combinando o mapeamento especialista dos 8 canais
    + prompts mestres sincronizados do DarkPlanner + diretrizes customizadas salvas pelo usuário)."""
    ch = ch or {}
    chave = _normalizar_chave_canal(ch.get("nome") or "")
    base = None
    for k, v in PERFIS_EDITORIAIS_CANAIS.items():
        if k in chave or chave in k:
            base = dict(v)
            break

    if not base:
        # Fallback inteligente para canais novos: analisa os prompts mestres do canal no DarkPlanner
        dp_prompts = ((ch.get("dp") or {}).get("prompts")) or []
        txt_prompts = "\n".join(f"{p.get('nome', '')}: {p.get('conteudo', '')[:800]}" for p in dp_prompts)
        idioma_c = ch.get("idioma") or "pt"
        base = {
            "canal_nome": ch.get("nome") or "Canal DarkPlanner",
            "idioma_exato": NOMES_IDIOMA.get(idioma_c, idioma_c),
            "formato_real": ch.get("tese") or f"Canal especializado em {ch.get('nicho', '')} / {ch.get('subnicho', '')}",
            "contexto_e_publico": ch.get("publico") or "Público interessado no nicho do canal",
            "diretriz_gerador": (
                ch.get("diretriz_pauta")
                or f"Sugira temas altamente alinhados à proposta editorial do canal {ch.get('nome', '')}, "
                   f"respeitando fielmente os Prompts Mestres do canal e evitando temas genéricos fora do formato."
            ),
            "o_que_priorizar": [ch.get("tese") or "Narrativa de alta retenção fiel ao estilo visual do canal"],
            "o_que_evitar": [ch.get("evitar") or "Temas genéricos fora da proposta central do canal"],
            "termos_proibidos_titulo": [],
            "como_aproveitar_virais": "Extrair a emoção e o gatilho de curiosidade dos vídeos em alta e adaptá-los ao formato do canal.",
            "avaliacao_temas_exemplo": [],
            "temas_prioritarios_aprovados": [],
            "queries_radar": [ch.get("subnicho") or ch.get("nicho") or ch.get("nome") or ""],
            "categorias_nichos_virais": [],
            "canais_benchmark": [],
            "resumo_prompts_dp": txt_prompts[:1200],
        }

    # Se o usuário personalizou a diretriz ou o que evitar no próprio canal, respeita e incorpora
    if (ch.get("diretriz_pauta") or "").strip():
        base["diretriz_gerador"] = ch["diretriz_pauta"].strip()
    if (ch.get("evitar") or "").strip():
        ev_custom = ch["evitar"].strip()
        if ev_custom not in base["o_que_evitar"]:
            base["o_que_evitar"] = [ev_custom] + list(base["o_que_evitar"])
    if (ch.get("publico") or "").strip():
        base["contexto_e_publico"] = ch["publico"].strip()
    if (ch.get("tese") or "").strip():
        base["formato_real"] = ch["tese"].strip()

    return base


_CACHE_NICHOS_VIRAIS = {"ts": 0.0, "dados": None}


def _buscar_inteligencia_nichos_virais(ch, perfil, log=print, rapido=True):
    """Cruza os canais e vídeos explodindo em https://app.darkplanner.com.br/nichos-virais + Radar YouTube
    com o DNA Editorial específico do canal (com cache em memória para resposta instantânea e links 100% clicáveis)."""
    import time as _time
    import urllib.parse
    ch_key = _normalizar_chave_canal((ch or {}).get("nome", ""))
    canais_pareados = []
    videos_inspiracao = []

    try:
        agora = _time.time()
        if _CACHE_NICHOS_VIRAIS["dados"] and (agora - _CACHE_NICHOS_VIRAIS["ts"] < 900):
            dados_nv = _CACHE_NICHOS_VIRAIS["dados"]
        else:
            dados_nv = darkplanner_sync.buscar_nichos_virais_dp()
            if isinstance(dados_nv, dict) and (dados_nv.get("exploding") or dados_nv.get("catalogo")):
                _CACHE_NICHOS_VIRAIS["dados"] = dados_nv
                _CACHE_NICHOS_VIRAIS["ts"] = agora
        exploding = dados_nv.get("exploding") or []
        rising = dados_nv.get("rising_fast") or []
        catalogo = dados_nv.get("catalogo") or {}

        benchmarks_nomes = {b.lower() for b in (perfil.get("canais_benchmark") or [])}
        cats_alvo = {c.lower() for c in (perfil.get("categorias_nichos_virais") or [])}
        idioma_canal = (ch.get("idioma") or "pt").lower()[:2]

        # 1. Busca nos canais Explodindo Agora e Subindo Rápido (/nichos-virais/channels)
        todos_nv = exploding + rising
        for c in todos_nv:
            titulo_c = claude.corrigir_mojibake_ptbr((c.get("title") or c.get("channel_name") or "").strip())
            if not titulo_c:
                continue
            cat_p = claude.corrigir_mojibake_ptbr((c.get("primary_category") or "").strip())
            sub_c = claude.corrigir_mojibake_ptbr((c.get("subcategory") or "").strip())
            lang_c = (c.get("language_detected") or "").lower()
            eh_bench = any(b in titulo_c.lower() for b in benchmarks_nomes)
            eh_cat = (cat_p.lower() in cats_alvo) or any(ct in f"{cat_p} {sub_c}".lower() for ct in cats_alvo)
            # Para Capitto Recomeço, filtra especificamente canais What If / Hipotéticos / Stickman / Animação Narrativa
            if "recomeco" in ch_key:
                top_txt = " ".join((v.get("title") or "") for v in (c.get("top_videos") or [])).lower()
                eh_cat = False
                if (
                    titulo_c.lower().strip() in ("e se?", "e se", "awaken", "ifinite", "after the door", "stickman what happens")
                    or any(k in top_txt or k in titulo_c.lower() for k in ("what if ", "what happens if", "e se você", "e se sua", "e se o seu", "stickman", "ifinite", "after the door"))
                ):
                    eh_bench = True
            elif "stormscope" in ch_key:
                top_txt = " ".join((v.get("title") or "") for v in (c.get("top_videos") or [])).lower()
                eh_cat = any(k in f"{titulo_c} {cat_p} {sub_c} {top_txt}".lower() for k in ("weather", "storm", "tornado", "flood", "hurricane", "disaster", "earth", "nature", "climate", "canyon", "volcano", "tsunami"))
            elif "gta" in ch_key:
                top_txt = " ".join((v.get("title") or "") for v in (c.get("top_videos") or [])).lower()
                eh_cat = any(k in f"{titulo_c} {cat_p} {sub_c} {top_txt}".lower() for k in ("gta", "rockstar", "gaming", "game", "vice city", "open world"))

            if eh_bench or eh_cat:
                top_vids = c.get("top_videos") or []
                vids_fmt = []
                for tv in top_vids[:3]:
                    vt = claude.corrigir_mojibake_ptbr((tv.get("title") or "").strip())
                    vv = int(tv.get("views") or 0)
                    vid_id = (tv.get("videoId") or tv.get("video_id") or "").strip()
                    if vt:
                        url_v = f"https://www.youtube.com/watch?v={vid_id}" if vid_id else f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(titulo_c + ' ' + vt)}"
                        vids_fmt.append({"titulo": vt, "views": vv, "video_id": vid_id, "url": url_v})
                        videos_inspiracao.append(f"[{titulo_c}] {vt} ({vv:,} views)".replace(",", "."))
                url_ch = (c.get("channel_url") or "").strip() or f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(titulo_c)}"
                canais_pareados.append({
                    "canal": titulo_c,
                    "categoria": f"{cat_p}{' · ' + sub_c if sub_c else ''}",
                    "idioma": lang_c or idioma_canal,
                    "views_totais": int(c.get("total_views") or 0),
                    "inscritos": int(c.get("subscribers") or 0),
                    "url": url_ch,
                    "destaque": "Explodindo Agora" if c in exploding else "Subindo Rápido",
                    "top_videos": vids_fmt,
                })

        # 2. Complementa com o Catálogo Curado de Nichos Virais (/nichos-virais)
        for nicho_nome, lista_c in catalogo.items():
            nicho_limpo = claude.corrigir_mojibake_ptbr(nicho_nome)
            if any(ct in nicho_limpo.lower() for ct in cats_alvo) or any(
                any(b in (it.get("canal_nome") or "").lower() for b in benchmarks_nomes) for it in (lista_c or [])
            ):
                for it in (lista_c or [])[:3]:
                    nm_c = claude.corrigir_mojibake_ptbr((it.get("canal_nome") or "").strip())
                    if not nm_c or any(x["canal"].lower() == nm_c.lower() for x in canais_pareados):
                        continue
                    obs = claude.corrigir_mojibake_ptbr((it.get("observacoes") or "").replace("\n", " ").strip()[:160])
                    url_ch = (it.get("canal_url") or "").strip() or f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(nm_c)}"
                    canais_pareados.append({
                        "canal": nm_c,
                        "categoria": nicho_limpo,
                        "idioma": idioma_canal,
                        "views_totais": int(it.get("total_visualizacoes") or 0),
                        "inscritos": int(it.get("total_inscritos") or 0),
                        "url": url_ch,
                        "destaque": "Ouro · Nichos Virais",
                        "observacoes": obs,
                        "top_videos": [],
                    })
                    if obs:
                        videos_inspiracao.append(f"[{nm_c} — {nicho_limpo}] {obs}")
    except Exception as e:
        log(f"Aviso ao consultar nichos-virais: {str(e)[:120]}")

    canais_finais = _garantir_urls_clicaveis_canais_virais(canais_pareados, ch_key=ch_key)
    for cf in canais_finais:
        for tv in (cf.get("top_videos") or []):
            linha_cf = f"[{cf['canal']}] {tv['titulo']} ({int(tv.get('views') or 0):,} views)".replace(",", ".")
            if linha_cf not in videos_inspiracao:
                videos_inspiracao.insert(0, linha_cf)

    # 3. Só consulta a API do YouTube se houver chave oficial ativa (nunca roda yt-dlp lento aqui)
    if not rapido:
        try:
            from core import chaves as _chaves
            if _chaves.ordem("youtube"):
                queries_r = perfil.get("queries_radar") or []
                for q in queries_r[:1]:
                    if not q:
                        continue
                    r = radar._buscar_api(None, q, ch.get("idioma", "pt"), dias=25, min_duracao_s=240, paginas=1)
                    vids = sorted(r.get("videos", []), key=lambda x: -(x.get("views") or 0))[:5]
                    for v in vids:
                        linha = claude.corrigir_mojibake_ptbr(f"[{v.get('canal', 'YouTube')}] {v['titulo']} ({v.get('views', 0):,} views)".replace(",", "."))
                        if linha not in videos_inspiracao:
                            videos_inspiracao.append(linha)
        except Exception:
            pass

    return {
        "canais_pareados": canais_finais[:8],
        "videos_inspiracao": videos_inspiracao[:14],
        "em_alta_detalhado": _montar_em_alta_detalhado(canais_finais[:8], videos_inspiracao[:14]),
    }



def _titulo_viola_perfil(titulo, perfil):
    t_low = str(titulo or "").lower()
    for proibido in (perfil.get("termos_proibidos_titulo") or []):
        if proibido and proibido.lower() in t_low:
            return True
    return False


_STOPWORDS_TEMA = {
    "what", "if", "you", "were", "was", "the", "a", "an", "in", "on", "at", "to", "for", "of", "with", "by",
    "from", "your", "all", "every", "day", "days", "hours", "hour", "year", "years", "australia", "australian",
    "happens", "happen", "happened", "how", "why", "when", "who", "this", "that", "these", "those", "is", "are",
    "como", "por", "que", "o", "os", "as", "um", "uma", "de", "do", "da", "dos", "das", "em", "no", "na",
    "nos", "nas", "para", "com", "sem", "seu", "sua", "seus", "suas", "voce", "você", "se", "mais", "menos",
    "que", "quando", "onde", "qual", "quais", "pelo", "pela", "sobre", "entre", "apos", "após", "anos",
    "el", "la", "los", "las", "un", "una", "del", "al", "por", "para", "con", "sin", "tu", "tus", "su", "sus",
}


def _sem_acentos(texto):
    import unicodedata
    s = unicodedata.normalize("NFD", str(texto or ""))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def _tokens_nucleo_tema(texto):
    limpo = _sem_acentos(str(texto or "").lower())
    palavras = re.findall(r"[a-z0-9]{3,}", limpo)
    return {p for p in palavras if p not in _STOPWORDS_TEMA}


def verificar_tema_ja_feito(titulo_sugerido, db, ch):
    """Verifica se um tema/título recomendado já foi produzido, publicado no YouTube,
    colocado em produção no Kanban/Estúdio ou marcado manualmente como concluído/oculto."""
    t_raw = (titulo_sugerido or "").strip()
    if not t_raw:
        return {"ja_feito": False, "oculto": False, "status_feito": "", "video_id": "", "titulo_encontrado": ""}

    cid = str((ch or {}).get("id") or "")
    t_norm = re.sub(r"\W+", "", _sem_acentos(t_raw.lower()))
    tokens_sug = _tokens_nucleo_tema(t_raw)

    cfg_s = (db or {}).get("settings") or {}
    extra_conc = ((cfg_s.get("temas_concluidos_por_canal") or {}).get(cid) or []) if isinstance(cfg_s, dict) else []
    extra_ocul = ((cfg_s.get("temas_ocultos_por_canal") or {}).get(cid) or []) if isinstance(cfg_s, dict) else []

    ocultos_manuais = {
        re.sub(r"\W+", "", _sem_acentos(x.lower()))
        for x in list((ch or {}).get("temas_ocultos_manual") or []) + list(extra_ocul)
        if x
    }
    concluidos_manuais = {
        re.sub(r"\W+", "", _sem_acentos(x.lower()))
        for x in list((ch or {}).get("temas_concluidos_manual") or []) + list(extra_conc)
        if x
    }

    eh_oculto = t_norm in ocultos_manuais

    if t_norm in concluidos_manuais:
        return {
            "ja_feito": True,
            "oculto": eh_oculto,
            "status_feito": "Concluído (Marcado)",
            "video_id": "",
            "titulo_encontrado": t_raw,
            "views_youtube": 0,
        }

    candidatos = []
    # 1. Vídeos do banco local / DarkPlanner
    for v in db.get("videos", []):
        if str(v.get("channel_id") or "") != cid:
            continue
        vt = (v.get("titulo") or "").strip()
        if not vt:
            continue
        st = "Publicado no YouTube" if v.get("publicado") else ("100% Concluído" if v.get("concluido") else ("Com Roteiro Pronto" if v.get("roteiro") else "Em Produção"))
        candidatos.append({
            "titulo": vt,
            "video_id": str(v.get("id") or ""),
            "status": st,
            "concluido_real": bool(v.get("concluido") or v.get("publicado") or v.get("roteiro")),
            "views": int(v.get("youtube_views") or (v.get("dp_video") or {}).get("youtube_views") or 0),
        })

    # 2. Vídeos sincronizados diretamente do canal do YouTube
    for vyt in (ch.get("youtube_videos_publicados") or []):
        vt = (vyt.get("titulo") or "").strip()
        if not vt:
            continue
        candidatos.append({
            "titulo": vt,
            "video_id": str(vyt.get("yt_id") or ""),
            "status": "Publicado no YouTube",
            "concluido_real": True,
            "views": int(vyt.get("views") or 0),
        })

    # 3. Cartões no Kanban do canal
    for k in db.get("kanban", []):
        if str(k.get("channel_id") or "") != cid:
            continue
        kt = (k.get("titulo") or "").strip()
        if not kt:
            continue
        col = (k.get("coluna") or "planejamento").lower()
        st = "Publicado" if col == "publicado" else ("Finalizado" if col == "finalizado" else "No Kanban (" + col.capitalize() + ")")
        candidatos.append({
            "titulo": kt,
            "video_id": str(k.get("video_id") or k.get("dp_video_id") or k.get("id") or ""),
            "status": st,
            "concluido_real": col in ("publicado", "finalizado", "producao"),
            "views": 0,
        })

    for cand in candidatos:
        ct_norm = re.sub(r"\W+", "", _sem_acentos(cand["titulo"].lower()))
        if not ct_norm:
            continue
        if ct_norm == t_norm or (len(t_norm) >= 18 and (t_norm in ct_norm or ct_norm in t_norm)):
            return {
                "ja_feito": True,
                "oculto": eh_oculto,
                "status_feito": cand["status"],
                "video_id": cand["video_id"],
                "titulo_encontrado": cand["titulo"],
                "views_youtube": cand["views"],
            }
        if tokens_sug and len(tokens_sug) >= 2:
            tokens_cand = _tokens_nucleo_tema(cand["titulo"])
            inter = tokens_sug.intersection(tokens_cand)
            # Se compartilha >= 75% dos tokens-núcleo do tema (ou pelo menos 3 palavras-chave principais idênticas)
            if len(inter) >= max(2, int(len(tokens_sug) * 0.75)) or (len(inter) >= 3 and len(inter) / max(1, min(len(tokens_sug), len(tokens_cand))) >= 0.66):
                return {
                    "ja_feito": True,
                    "oculto": eh_oculto,
                    "status_feito": cand["status"],
                    "video_id": cand["video_id"],
                    "titulo_encontrado": cand["titulo"],
                    "views_youtube": cand["views"],
                }

    return {"ja_feito": False, "oculto": eh_oculto, "status_feito": "", "video_id": "", "titulo_encontrado": "", "views_youtube": 0}


def _analisar_titulo_neural_v8(titulo, ch=None, perfil=None, idx=0, eh_campeao=False):
    """Analisa um título com a metodologia Títulos Neurais V8 (CTR Score, Gatilho Neural e Análise Neural de Clique)."""
    t = (titulo or "").strip()
    tl = t.lower()
    ch_key = _normalizar_chave_canal((ch or {}).get("nome", ""))

    # Detecta o gatilho neural dominante pelo vocabulário e estrutura do título
    if tl.startswith("what if") or "e se " in tl or "y si " in tl:
        if any(w in tl for w in ("last person", "alone", "vanish", "disappear", "nobody", "empty")):
            gatilho = "Premissa Impossível + Isolamento Absoluto (Iflord V8)"
            analise = "Combina curiosidade visual imediata com o dilema humano da solidão extrema (CTR máximo no nicho What If)."
        elif any(w in tl for w in ("stop", "freeze", "time", "rewind", "pause", "never sleep", "1 hour")):
            gatilho = "Controle do Tempo + Escalada de Consequências"
            analise = "Ativa fantasia de poder cotidiano seguida de colapso físico/social progressivo."
        elif any(w in tl for w in ("see", "timer", "number", "score", "lie", "truth", "mind", "hear")):
            gatilho = "Onisciência Social + Paradoxo Psicológico"
            analise = "Transforma interações humanas comuns em tensão imediata e testes sociais em escalada."
        else:
            gatilho = "Curiosidade Hipotética Visual + Escalada Física V8"
            analise = "Premissa fácil de visualizar na thumb 2.5D/3D com progressão clara de testes (Níveis 1 a 3)."
    elif any(w in tl for w in ("never", "nunca", "jamais", "proibido", "erro", "mistake", "pare de", "deje de", "warning", "alerta")):
        gatilho = "Quebra de Crença + Alerta Inevitável"
        analise = "Desafia um hábito considerado seguro pelo público, gerando clique imediato por autoproteção."
    elif any(w in tl for w in ("why", "por que", "por qué", "como", "how", "secret", "segredo", "oculto", "hidden", "ninguém")):
        gatilho = "Lacuna de Curiosidade + Revelação Documental"
        analise = "Abre um mistério específico nos primeiros 5 segundos que só se fecha assistindo à investigação."
    elif any(w in tl for w in ("tornado", "storm", "flood", "hurricane", "wind", "disaster", "trapped", "survive")):
        gatilho = "Tensão de Sobrevivência + Escala de Impacto Real"
        analise = "Choque visual documental com números/escala real que prende a atenção nos primeiros 30 segundos."
    else:
        if "recomeco" in ch_key:
            gatilho = "Fórmula Neural What If (Iflord Benchmark)"
        elif "vital" in ch_key or "longevidad" in ch_key:
            gatilho = "Revelação Biológica + Protocolo Prático 60+"
        elif "fin" in ch_key:
            gatilho = "Assimetria Financeira + Alerta Patrimonial"
        else:
            gatilho = "Alto Contraste Emocional + Lacuna de Curiosidade V8"
        analise = "Título validado pelo motor Títulos Neurais V8 (até 75 caracteres, alto impacto visual na thumbnail)."

    # Calcula score neural de CTR (94 a 99)
    base_score = 99 if eh_campeao or idx == 0 else max(94, 98 - (idx % 5))
    if "?" in t or any(c.isdigit() for c in t):
        base_score = min(99, base_score + 1)
    if eh_campeao:
        base_score = 99

    return {
        "analisado_neural_v8": True,
        "campeao_neural": bool(eh_campeao),
        "ctr_score": int(base_score),
        "gatilho_neural": gatilho,
        "analise_neural": analise,
    }


def enriquecer_pauta_e_diagnostico_canal(db, ch, pauta_obj=None, perfil_canal=None):
    """Cruza em tempo real todos os Temas Recomendados e as Sugestões do Dia com os vídeos já feitos no canal,
    aplica a análise de Títulos Neurais V8 em cada sugestão, marca cada item com `ja_feito` / `status_feito` / `oculto`,
    e gera o Diagnóstico & Alertas Específicos do Canal."""
    import copy

    ch = ch or {}
    cid = str(ch.get("id") or "")
    perfil = copy.deepcopy(perfil_canal or obter_perfil_editorial_canal(ch))
    pauta_out = copy.deepcopy(pauta_obj) if isinstance(pauta_obj, dict) else {}

    # 1. Verifica cada tema em `temas_prioritarios_aprovados` e aplica Análise de Títulos Neurais V8
    prioridades_enriq = []
    primeiro_pendente_marcado = False
    for idx_p, pr in enumerate(perfil.get("temas_prioritarios_aprovados") or []):
        pr_c = dict(pr)
        info_f = verificar_tema_ja_feito(pr_c.get("titulo") or "", db, ch)
        pr_c.update(info_f)
        pr_c["prioridade"] = pr_c.get("prioridade") or (idx_p + 1)
        eh_camp = (not pr_c.get("ja_feito") and not pr_c.get("oculto") and not primeiro_pendente_marcado)
        if eh_camp:
            primeiro_pendente_marcado = True
        neural_info = _analisar_titulo_neural_v8(pr_c.get("titulo") or "", ch, perfil, idx=idx_p, eh_campeao=eh_camp)
        for k_n, v_n in neural_info.items():
            if not pr_c.get(k_n):
                pr_c[k_n] = v_n
        pr_c["campeao_neural"] = eh_camp
        prioridades_enriq.append(pr_c)
    perfil["temas_prioritarios_aprovados"] = prioridades_enriq
    if isinstance(pauta_out.get("perfil_editorial"), dict):
        pauta_out["perfil_editorial"]["temas_prioritarios_aprovados"] = prioridades_enriq

    # 2. Verifica `pauta_out["tema"]` e `pauta_out["novos"]` + aplica Análise de Títulos Neurais V8
    if isinstance(pauta_out.get("tema"), dict):
        assunto_t = (pauta_out["tema"].get("assunto") or "").strip()
        info_tema = verificar_tema_ja_feito(assunto_t, db, ch)
        pauta_out["tema"].update(info_tema)
        neural_tema = _analisar_titulo_neural_v8(assunto_t, ch, perfil, idx=0, eh_campeao=True)
        for k_n, v_n in neural_tema.items():
            if not pauta_out["tema"].get(k_n):
                pauta_out["tema"][k_n] = v_n
        tits_enriq = []
        for idx_tv, tv in enumerate(pauta_out["tema"].get("titulos") or []):
            if isinstance(tv, dict):
                tv_c = dict(tv)
                tv_c.update(verificar_tema_ja_feito(tv_c.get("titulo") or "", db, ch))
                neural_tv = _analisar_titulo_neural_v8(tv_c.get("titulo") or "", ch, perfil, idx=idx_tv, eh_campeao=(idx_tv == 0))
                for k_n, v_n in neural_tv.items():
                    if not tv_c.get(k_n):
                        tv_c[k_n] = v_n
                tv_c["campeao_neural"] = (idx_tv == 0)
                tits_enriq.append(tv_c)
        pauta_out["tema"]["titulos"] = tits_enriq

    novos_enriq = []
    for idx_nv, nv in enumerate(pauta_out.get("novos") or []):
        if isinstance(nv, dict):
            nv_c = dict(nv)
            nv_c.update(verificar_tema_ja_feito(nv_c.get("titulo") or "", db, ch))
            neural_nv = _analisar_titulo_neural_v8(nv_c.get("titulo") or "", ch, perfil, idx=idx_nv, eh_campeao=(idx_nv == 0))
            for k_n, v_n in neural_nv.items():
                if not nv_c.get(k_n):
                    nv_c[k_n] = v_n
            novos_enriq.append(nv_c)
    if pauta_out:
        pauta_out["novos"] = novos_enriq
        # Se o tema principal do dia já foi feito, promove automaticamente a primeira sugestão inédita para o topo se houver!
        if (pauta_out.get("tema") or {}).get("ja_feito"):
            prox_inedito = next((x for x in prioridades_enriq if not x.get("ja_feito") and not x.get("oculto")), None)
            if not prox_inedito:
                prox_inedito = next((x for x in novos_enriq if not x.get("ja_feito") and not x.get("oculto")), None)
            if prox_inedito:
                pauta_out["tema"]["proxima_recomendacao_imediata"] = prox_inedito.get("titulo") or ""

    # 3. Constrói o Diagnóstico Profundo e Alertas de Otimização do Canal
    dp_c = ch.get("dp") or {}
    yt_url = (ch.get("youtube_channel_url") or dp_c.get("youtube_channel_url") or ch.get("canal_url") or "").strip()
    yt_id = (dp_c.get("youtube_channel_id") or "").strip()
    inscritos = int(dp_c.get("youtube_subscribers") or 0)
    views_totais = int(dp_c.get("youtube_views") or 0)
    vids_yt_count = int(dp_c.get("youtube_video_count") or dp_c.get("videos_ja_postados") or 0)
    horarios_post = dp_c.get("horario_postagem") or ["19:00"]
    if isinstance(horarios_post, str):
        horarios_post = [horarios_post]

    vids_canal_db = [v for v in db.get("videos", []) if str(v.get("channel_id") or "") == cid]
    vids_concluidos = [v for v in vids_canal_db if v.get("concluido") or v.get("publicado")]
    vids_em_prod = [v for v in vids_canal_db if not v.get("concluido") and not v.get("publicado")]

    # Top vídeos do canal (combinando youtube_videos_publicados e db["videos"])
    mapa_top = {}
    for vyt in (ch.get("youtube_videos_publicados") or []):
        tit_y = (vyt.get("titulo") or "").strip()
        if tit_y:
            mapa_top[tit_y.lower()] = {
                "titulo": tit_y,
                "views": int(vyt.get("views") or 0),
                "url": vyt.get("url") or "",
                "yt_id": vyt.get("yt_id") or "",
            }
    for vdb in vids_canal_db:
        tit_d = (vdb.get("titulo") or "").strip()
        vw_d = int(vdb.get("youtube_views") or (vdb.get("dp_video") or {}).get("youtube_views") or 0)
        if tit_d and (tit_d.lower() not in mapa_top or vw_d > mapa_top[tit_d.lower()]["views"]):
            mapa_top[tit_d.lower()] = {
                "titulo": tit_d,
                "views": vw_d,
                "url": f"https://www.youtube.com/watch?v={vdb.get('youtube_id')}" if vdb.get("youtube_id") else "",
                "yt_id": vdb.get("youtube_id") or "",
            }
    top_videos_canal = sorted(mapa_top.values(), key=lambda x: -x["views"])[:5]
    media_views = round(views_totais / max(1, vids_yt_count), 1) if vids_yt_count > 0 else 0

    feitos_prio = [x for x in prioridades_enriq if x.get("ja_feito")]
    pendentes_prio = [x for x in prioridades_enriq if not x.get("ja_feito") and not x.get("oculto")]
    prox_tema_ouro = (
        pendentes_prio[0]["titulo"]
        if pendentes_prio
        else next((x.get("titulo") for x in novos_enriq if not x.get("ja_feito") and not x.get("oculto")), (pauta_out.get("tema") or {}).get("assunto") or "")
    )

    alertas = []
    # Alerta 1: Próxima Ação Editorial Específica (baseado no que já foi feito vs pendente)
    if feitos_prio:
        nomes_feitos = ", ".join(f'"{x["titulo"]}"' for x in feitos_prio[:2])
        alertas.append({
            "tipo": "sucesso",
            "icone": "✅",
            "titulo": f"{len(feitos_prio)} de {len(prioridades_enriq)} Temas Prioritários já foram produzidos!",
            "detalhe": f"Já concluídos neste canal: {nomes_feitos}. Seu próximo Título Campeão Neural V8 imediato é: \"{prox_tema_ouro}\".",
            "acao_sugerida": prox_tema_ouro,
        })
    elif prox_tema_ouro:
        alertas.append({
            "tipo": "prioridade",
            "icone": "🎯",
            "titulo": "Próximo Vídeo Campeão Neural V8 Recomendado para Gravar Hoje",
            "detalhe": f"Nenhum dos temas prioritários foi gravado ainda ou todos estão abertos. Comece hoje por \"{prox_tema_ouro}\" — já analisado pelo Títulos Neurais V8 (99% CTR) para o público de {perfil.get('canal_nome')}.",
            "acao_sugerida": prox_tema_ouro,
        })

    # Alerta 2: Análise das Métricas Reais do YouTube do Canal
    if not yt_url:
        alertas.append({
            "tipo": "atencao",
            "icone": "🔗",
            "titulo": "Vincule a URL/Conta do YouTube deste Canal",
            "detalhe": "Conecte o @handle ou link do canal acima para a IA monitorar automaticamente seus inscritos, views por vídeo, vídeos já postados e detectar qual formato mais performa.",
        })
    else:
        top_v = top_videos_canal[0] if top_videos_canal else None
        if top_v and top_v.get("views", 0) > 0:
            alertas.append({
                "tipo": "performance",
                "icone": "📈",
                "titulo": f"Vídeo Campeão do Canal: \"{top_v['titulo']}\" ({top_v['views']:,} views)".replace(",", "."),
                "detalhe": f"O canal soma {views_totais:,} visualizações ({inscritos:,} inscritos · média de {media_views} views/vídeo). Crie uma variação/parte 2 mantendo o mesmo gatilho emocional do seu vídeo campeão!".replace(",", "."),
            })
        else:
            alertas.append({
                "tipo": "performance",
                "icone": "📊",
                "titulo": f"Canal Vinculado ({inscritos} inscritos · {vids_yt_count} vídeos · Horário ideal: {', '.join(horarios_post)})",
                "detalhe": "Clique em 'Sincronizar YouTube Agora' sempre que publicar um vídeo novo para atualizar as visualizações e marcar automaticamente os temas publicados como concluídos.",
            })

    # Alerta 3: Otimização Técnica de Retenção, Roteiro e Thumbnail específica do DNA do canal
    ch_key = _normalizar_chave_canal(ch.get("nome", ""))
    if "recomeco" in ch_key:
        alertas.append({
            "tipo": "otimizacao",
            "icone": "🧠",
            "titulo": "Fórmula Iflord + Títulos Neurais V8 Ativos na Sugestão do Dia",
            "detalhe": "Todos os títulos abaixo já passaram pela análise de Títulos Neurais V8 (94%–99% CTR). Ao clicar em '⚡ Gerar', o Estúdio já recebe o título neural pronto e monta 80% narração em 2ª pessoa ('You...') + 20% Falas de Destaque curtas entre os Avatares [01] e [02].",
        })
    elif "stormscope" in ch_key:
        alertas.append({
            "tipo": "otimizacao",
            "icone": "🌪️",
            "titulo": "Regra de Ouro Documental StormScope (0% IA / 100% Real Footage)",
            "detalhe": "Nos primeiros 3 minutos (00:00–03:00), mostre imagens reais do impacto climático sem repetir nenhum corte .mp4. Na thumbnail, use 2 a 3 palavras em amarelo/vermelho de alerta extremo.",
        })
    elif "vital" in ch_key or "longevidad" in ch_key:
        alertas.append({
            "tipo": "otimizacao",
            "icone": "❤️",
            "titulo": "Otimização de Retenção 60+ (Ritmo Pausado + Quebra de Mito nos Primeiros 30s)",
            "detalhe": "Público sênior retém 40% mais quando o vídeo abre desmontando um hábito cotidiano ('O erro matinal que...') e entrega um protocolo prático numerado nos blocos finais. Duração ideal: 18 a 22 minutos.",
        })
    else:
        alertas.append({
            "tipo": "otimizacao",
            "icone": "🔥",
            "titulo": "Títulos Neurais V8 Já Integrados na Sugestão do Dia",
            "detalhe": "Todos os títulos abaixo já vêm analisados pelo motor Títulos Neurais V8 (Score de CTR + Gatilho Neural). Basta clicar em '⚡ Gerar' para produzir direto no Estúdio e enviar Thumbnail, Tags e Descrição ao DarkPlanner.",
        })

    if vids_em_prod:
        alertas.append({
            "tipo": "fila",
            "icone": "🎬",
            "titulo": f"Você tem {len(vids_em_prod)} vídeo(s) em produção neste canal",
            "detalhe": "Finalize os vídeos em aberto (" + ", ".join(f'"{v.get("titulo")}"' for v in vids_em_prod[:2]) + ") e clique em 'Marcar Concluído' para manter sua fila limpa.",
        })

    diagnostico = {
        "canal_id": cid,
        "canal_nome": ch.get("nome") or perfil.get("canal_nome") or "",
        "youtube_vinculado": bool(yt_url),
        "youtube_url": yt_url,
        "youtube_channel_id": yt_id,
        "youtube_avatar": dp_c.get("youtube_avatar") or "",
        "inscritos": inscritos,
        "views_totais": views_totais,
        "videos_publicados_yt": max(vids_yt_count, len(ch.get("youtube_videos_publicados") or [])),
        "media_views_por_video": media_views,
        "horarios_postagem": horarios_post,
        "ultimo_sync_yt": ch.get("youtube_sincronizado_em") or dp_c.get("youtube_synced_at") or "",
        "total_videos_banco": len(vids_canal_db),
        "total_concluidos": len(vids_concluidos),
        "total_em_producao": len(vids_em_prod),
        "total_recomendados": len(prioridades_enriq),
        "total_recomendados_feitos": len(feitos_prio),
        "total_recomendados_pendentes": len(pendentes_prio),
        "proximo_tema_recomendado": prox_tema_ouro,
        "top_videos_canal": top_videos_canal,
        "alertas_otimizacao": alertas,
    }

    pauta_out = claude.corrigir_mojibake_ptbr(pauta_out)
    perfil = claude.corrigir_mojibake_ptbr(perfil)
    diagnostico = claude.corrigir_mojibake_ptbr(diagnostico)
    return pauta_out, perfil, diagnostico


SUGESTOES_EXTRAS_CANAIS_V8 = {
    "stormscope report": [
        {
            "titulo": "When Zhengzhou’s Subway Turned Into a Flood Trap During Record Rainfall",
            "traducao": "Quando o Metrô de Zhengzhou Virou uma Armadilha de Inundação Durante uma Chuva Histórica",
            "potencial_narrativo": "O caso combina imagens reais amplamente registradas em ambientes urbanos e dentro dos vagões com uma explicação física clara de como a inundação da superfície alcançou um sistema subterrâneo em horário de pico.",
            "gancho": "At five-thirty in the afternoon, Line 5 of the Zhengzhou subway was packed with commuters escaping a historic rainstorm—until a retaining wall gave way and a river poured directly into the underground tunnel.",
            "gatilho_neural": "Refúgio convertido em armadilha",
        },
        {
            "titulo": "Why Phoenix’s 60-Mile Haboob Wall of Dust Swallowed an Entire City in Daylight",
            "traducao": "Por Que a Muralha de Poeira de 100 km em Phoenix Engoliu uma Cidade Inteira em Pleno Dia",
            "potencial_narrativo": "Imagens aéreas e de rodovia mostram uma parede de poeira de 1.500 metros de altura desligando a luz do sol em segundos, explicando o fenômeno de colapso de tempestade (downburst).",
            "gancho": "Drivers on Interstate 10 outside Phoenix had clear blue skies in their mirrors and a five-thousand-foot black wall of desert dust racing toward their windshields at sixty miles per hour.",
            "gatilho_neural": "Escala visual extrema + Escuridão súbita",
        },
        {
            "titulo": "The 90-Second Microburst That Slammed 130mph Winds Down on Dallas Airport",
            "traducao": "O Microburst de 90 Segundos Que Despejou Ventos de 210 km/h Sobre o Aeroporto de Dallas",
            "potencial_narrativo": "Investiga a física da 'bomba de ar frio' invisível que mudou para sempre a aviação comercial e o monitoramento meteorológico nos EUA.",
            "gancho": "A commercial airliner on final approach into Dallas saw a routine afternoon rain shaft ahead—unaware that inside that cloud, a column of sinking air was accelerating downward like an invisible avalanche.",
            "gatilho_neural": "Ameaça invisível + Física atmosférica",
        },
        {
            "titulo": "When a Bayou Salt Mine Punctured Under Lake Peigneur and Reversed a Waterfall",
            "traducao": "Quando uma Mina de Sal Rompeu Sob o Lago Peigneur e Inverteu uma Cachoeira Inteira",
            "potencial_narrativo": "Registros reais mostram um lago inteiro na Louisiana sendo sugado para uma caverna subterrânea, engolindo barcaças, árvores e criando um redemoinho gigante.",
            "gancho": "In a quiet Louisiana bayou, a fourteen-inch drill bit accidentally pierced the roof of a salt mine beneath Lake Peigneur—turning a shallow freshwater lake into a giant whirlpool that swallowed eleven barges.",
            "gatilho_neural": "Colapso de engenharia + Redemoinho real",
        },
    ],
    "capitto recomeco": [
        {
            "titulo": "What If You Stopped Ageing at 25 While Everyone Else Kept Growing Older?",
            "traducao": "E Se Você Parasse de Envelhecer aos 25 Enquanto Todo Mundo Continuasse Envelhecendo?",
            "potencial_narrativo": "Começa como o sonho perfeito em Melbourne, mas década após década obriga o protagonista a esconder sua identidade e ver amigos e amores envelhecerem.",
            "gancho": "At twenty-five, freezing your age feels like winning the biological lottery in Melbourne—until ten years pass, your best mate looks thirty-five, and the government notices your face hasn't changed a single millimetre.",
            "gatilho_neural": "Desejo universal + Consequência emocional",
        },
        {
            "titulo": "What If You Could See Everyone's Exact Trust Score Floating Above Their Head?",
            "traducao": "E Se Você Pudesse Ver o Nível Exato de Confiança de Cada Pessoa Flutuando Sobre a Cabeça Dela?",
            "potencial_narrativo": "Rende quadros visuais 2D incríveis ('NORMAL vs YOU') e reviravoltas dramáticas quando a pessoa que você mais confia aparece com um número baixo.",
            "gancho": "You step onto a crowded Sydney train and suddenly every passenger has a glowing percentage floating above their head—and your closest friend is sitting right next to you with a twelve percent.",
            "gatilho_neural": "Onisciência social + Choque de revelação",
        },
        {
            "titulo": "What If Gravity Reversed for Just 10 Seconds Across Australia?",
            "traducao": "E Se a Gravidade se Invertesse por Apenas 10 Segundos em Toda a Austrália?",
            "potencial_narrativo": "Escalada física imediata minuto a minuto, mostrando a diferença entre estar dentro de casa em Melbourne vs. ao ar livre no Outback.",
            "gancho": "Ten seconds doesn't sound like enough time to end your normal life—unless for those ten seconds, the sky above Australia becomes the floor.",
            "gatilho_neural": "Escalada física imediata + Sobrevivência",
        },
    ],
    "cappito vital": [
        {
            "titulo": "O Que Acontece no Seu Corpo Quando Você Fica 14 Horas Sem Comer Depois dos 40?",
            "traducao": "",
            "potencial_narrativo": "Miguel explica hora a hora a limpeza celular, a queima de gordura visceral e os cuidados essenciais para não perder massa muscular após os 40.",
            "gancho": "Durante as primeiras oito horas sem comer, seu corpo ainda funciona no automático. Mas a partir da décima segunda hora, uma chave metabólica silenciosa vira dentro das suas células.",
            "gatilho_neural": "Linha do tempo fisiológica + Curiosidade biológica",
        },
        {
            "titulo": "5 Sinais nos Seus Pés e Panturrilhas Que Revelam Como Está Sua Circulação Após os 40",
            "traducao": "",
            "potencial_narrativo": "Pés frios, inchaço no fim da tarde e cãibras noturnas explicados de forma visual e clara como termômetro cardiovascular.",
            "gancho": "Suas panturrilhas funcionam como um segundo coração bombeando o sangue de volta para cima — e quando elas começam a falhar depois dos 40, os primeiros avisos aparecem nos seus pés.",
            "gatilho_neural": "Alerta preventivo + Autodiagnóstico visual",
        },
    ],
    "longevidad real": [
        {
            "titulo": "Por Qué Comer Poco en la Cena Después de los 60 Puede Debilitar Tus Piernas",
            "traducao": "Por Que Comer Pouco no Jantar Depois dos 60 Pode Enfraquecer Suas Pernas",
            "potencial_narrativo": "Quebra a crença comum de que 'jantar só um chá com biscoito' é saudável aos 65 anos, mostrando o catabolismo muscular noturno.",
            "gancho": "Muchos adultos mayores creen que cenar solo una taza de té con galletas es la mejor decisión para su salud, sin saber que durante la noche su cuerpo empieza a consumir el músculo de sus propias piernas.",
            "gatilho_neural": "Quebra de crença + Proteção muscular 60+",
        },
        {
            "titulo": "El Hábito de 3 Minutos al Despertar Que Protege Tu Equilibrio y Tus Rodillas a los 65",
            "traducao": "O Hábito de 3 Minutos ao Acordar Que Protege Seu Equilíbrio e Seus Joelhos aos 65",
            "potencial_narrativo": "Explica a queda de pressão postural e a rigidez articular matinal, ensinando a ativação segura antes de levantar da cama.",
            "gancho": "La mayoría de los tropiezos y mareos después de los 65 años ocurren en los primeros noventa segundos después de levantarse de la cama, y casi todos se pueden evitar antes de poner los pies en el suelo.",
            "gatilho_neural": "Protocolo prático matinal + Segurança articular",
        },
    ],
    "the catch-up chapter": [
        {
            "titulo": "Why Paying Off Your House Early After 45 Can Quietly Delay Your Retirement",
            "traducao": "Por Que Quitar Sua Casa Antecipadamente Após os 45 Pode Atrasar Silenciosamente Sua Aposentadoria",
            "potencial_narrativo": "Paradoxo financeiro clássico de liquidez vs. patrimônio imobilizado na fase de recuperação ('Catch-Up').",
            "gancho": "Being debt-free feels like the ultimate financial victory at fifty—until you realize you just locked your last ten years of compounding liquidity inside drywall and bricks.",
            "gatilho_neural": "Paradoxo patrimonial + Liquidez vs. Imóvel",
        },
        {
            "titulo": "The 7-Year Catch-Up Blueprint for Adults Starting Late With Under $50,000",
            "traducao": "O Plano de Recuperação de 7 Anos Para Adultos Começando Tarde com Menos de US$ 50.000",
            "potencial_narrativo": "Mostra com matemática clara como usar a fase de maior renda e menores despesas com filhos para comprimir 20 anos em 7.",
            "gancho": "If you are forty-eight with less than fifty thousand dollars saved, conventional retirement advice wasn't written for you—you need a completely different mathematical playbook.",
            "gatilho_neural": "Esperança matemática + Plano de 7 anos",
        },
    ],
    "o estrategista oculto": [
        {
            "titulo": "A Muralha Submersa de Recife e o Cerco Que Mudou o Mapa do Nordeste para Sempre",
            "traducao": "",
            "potencial_narrativo": "Investiga a engenharia militar holandesa e portuguesa nos arrecifes de Pernambuco e a batalha decisiva pelos portos do açúcar.",
            "gancho": "Debaixo das águas e pontes do Recife antigo esconde-se o traçado de uma cidade-fortaleza que desafiou a maior potência naval do século XVII.",
            "gatilho_neural": "Geopolítica histórica + Mistério arquitetônico",
        },
        {
            "titulo": "A Estrada Proibida da Coroa: Por Que Portugal Fechou o Caminho Mais Curto Entre Minas e o Mar",
            "traducao": "",
            "potencial_narrativo": "Revela a paranoia geopolítica do ouro no século XVIII, caminhos clandestinos na Serra do Mar e cidades vigiadas por dragões reais.",
            "gancho": "Abrir uma simples trilha na mata entre as minas de ouro e o litoral brasileiro dava pena de confisco total e degredo — porque Lisboa sabia que aquela estrada podia partir o império ao meio.",
            "gatilho_neural": "Segredo de Estado + História oculta do Brasil",
        },
    ],
    "capittofin": [
        {
            "titulo": "A Ilusão do Apartamento Financiado em 35 Anos Que Faz a Classe Média Pagar Três Imóveis",
            "traducao": "",
            "potencial_narrativo": "Mostra através de dois personagens brasileiros a diferença real entre financiar no impulso vs. usar a renda fixa brasileira para comprar com desconto.",
            "gancho": "Na hora de assinar as chaves no estande decorado, ninguém faz a conta do que acontece nos primeiros cento e vinte boletos — onde quase tudo o que você paga vai para o banco e quase nada reduz a sua dívida.",
            "gatilho_neural": "Matemática oculta + Dilema da classe média",
        },
        {
            "titulo": "Por Que Quem Herda Dinheiro no Brasil Quase Sempre Perde Tudo em Menos de 5 Anos",
            "traducao": "",
            "potencial_narrativo": "Storytelling psicológico sobre dinheiro não conquistado, pressão de parentes e armadilhas de padrão de vida.",
            "gancho": "Receber quinhentos mil reais de uma vez parece o fim de todos os problemas financeiros, mas as estatísticas brasileiras mostram que, para a maioria das famílias, é o começo do endividamento mais rápido da vida.",
            "gatilho_neural": "Psicologia do dinheiro + Choque de realidade",
        },
    ],
    "gta a la une": [
        {
            "titulo": "Pourquoi le Jeu Vidéo a Atteint Sa Limite Avec GTA 6",
            "traducao": "Por Que o Videogame Atingiu Seu Limite Com GTA 6",
            "potencial_narrativo": "Ensaio documental 100% focado no jogo (estilo Mano. — 8GD39QLKtyY): orçamento histórico, escala de Leonida e o teto técnico atingido pela Rockstar Games.",
            "gancho": "Plus d'une décennie de développement, un budget qui dépasse Hollywood et un monde ouvert d'une densité jamais vue : avec GTA 6, le jeu vidéo vient peut-être d'atteindre sa limite absolue.",
            "gatilho_neural": "Tese de limite da indústria + Escala GTA 6",
        },
        {
            "titulo": "L'Incroyable Technologie Cachée Derrière GTA 6 (600 000 Animations & RAGE 9)",
            "traducao": "A Incrível Tecnologia Oculta Por Trás de GTA 6 (600.000 Animações & RAGE 9)",
            "potencial_narrativo": "Análise técnica visual 100% dentro do jogo (estilo Rou — I-bJ61bouDo): patentes RAGE 9, Euphoria, água/lama em tempo real e IA com memória persistente.",
            "gancho": "Six cent mille animations dynamiques, une eau simulée en temps réel et des passants dotés d'une vraie mémoire : voici la technologie secrète qui fait tourner GTA 6.",
            "gatilho_neural": "Curiosidade tecnológica + Segredo Rockstar",
        },
        {
            "titulo": "GTA 6 Fait des Choses Qu'on N'Aurait JAMAIS Imaginées Dans GTA 5 !",
            "traducao": "GTA 6 Faz Coisas Que JAMAIS Teríamos Imaginado em GTA 5!",
            "potencial_narrativo": "Comparativo direto entre a física, inventário limitado de armas, clima dinâmico e interiores exploráveis de Leonida frente a Los Santos (estilo G3ADRIEN OFF & Rockstar Mag').",
            "gancho": "Pendant plus d'une décennie, Los Santos a défini les règles du monde ouvert. Mais douze nouvelles mécaniques physiques intégrées dans GTA 6 s'apprêtent à tout réécrire.",
            "gatilho_neural": "Comparativo direto + Evolução confirmada",
        },
        {
            "titulo": "Voilà, C'Était GTA V : L'Héritage Complet Avant l'Arrivée de GTA 6",
            "traducao": "Eis o Que Foi GTA V: O Legado Completo Antes da Chegada de GTA 6",
            "potencial_narrativo": "Retrospectiva 100% focada no jogo (estilo Rockstar Mag' — dPSpuFYoEF8): Michael, Franklin e Trevor, missões lendárias de Los Santos e a transição para Vice City.",
            "gancho": "Trois braqueurs inoubliables, une carte devenue mythique et douze ans au sommet du jeu vidéo : avant le grand départ pour Vice City, retour complet sur ce qu'était vraiment GTA V.",
            "gatilho_neural": "Nostalgia GTA V + Passagem de bastão",
        },
        {
            "titulo": "Les 10 Missions les Plus Folles de l'Histoire de GTA (Et Pourquoi Elles Sont Cultes)",
            "traducao": "As 10 Missões Mais Insanas da História de GTA (E Por Que Elas São Cult)",
            "potencial_narrativo": "Ranking documental das missões que marcaram gerações (Three Leaf Clover em GTA IV, End of the Line em San Andreas, Vice City e GTA V) e como inspiram GTA 6.",
            "gancho": "D'un braquage en plein cœur de Liberty City à la poursuite d'un train devenu légendaire à San Andreas, certaines missions ont changé l'histoire du jeu vidéo à jamais.",
            "gatilho_neural": "Ranking cult + Nostalgia de alta retenção",
        },
        {
            "titulo": "Tout Ce Qu'il Faut Savoir Avant de Jouer à GTA 6 (Carte, Personnages & Gameplay)",
            "traducao": "Tudo o Que Você Precisa Saber Antes de Jogar GTA 6 (Mapa, Personagens & Gameplay)",
            "potencial_narrativo": "Guia essencial 100% focado no jogo (estilo Vico GTA): Leonida, Vice City, Everglades, Lucia & Jason e novas mecânicas confirmadas pela Rockstar.",
            "gancho": "Des néons d'Ocean Beach jusqu'aux marécages sauvages de Leonida, voici absolument tout ce qu'il faut connaître avant de poser les mains sur GTA 6.",
            "gatilho_neural": "Guia essencial + Antecipação máxima",
        },
    ],
}


def atualizar_aprendizado_diario_ascensao(db, ch, perfil=None, canais_virais=None):
    """Motor Autoevolutivo Diário: analisa todos os dias os canais em ascensão do nicho,
    extrai os gatilhos de alta velocidade (views/inscrito), registra o aprendizado diário
    em `db['aprendizado_diario_ascensao'][cid]` e evita repetição de pautas entre os dias."""
    ch = ch or {}
    cid = str(ch.get("id") or "geral")
    hoje_iso = dt.date.today().isoformat()
    perfil = perfil or obter_perfil_editorial_canal(ch)
    ch_key = _normalizar_chave_canal(ch.get("nome", ""))

    if not isinstance(db.get("aprendizado_diario_ascensao"), dict):
        db["aprendizado_diario_ascensao"] = {}

    reg = db["aprendizado_diario_ascensao"].get(cid)
    if not isinstance(reg, dict):
        reg = {
            "canal_id": cid,
            "canal_nome": ch.get("nome") or perfil.get("canal_nome") or "",
            "dias_aprendidos": 0,
            "data_ultimo_aprendizado": "",
            "historico_temas_diarios": [],
            "padroes_aprendidos_hoje": [],
            "canais_ascensao_detectados": [],
            "gatilhos_em_alta": [],
        }

    if not canais_virais:
        canais_virais = _garantir_urls_clicaveis_canais_virais([], ch_key=ch_key)

    # Calcula velocidade de ascensão (views / inscritos) e extrai padrões reais dos canais e vídeos líderes
    canais_asc = []
    padroes = []
    gatilhos = []
    for cv in (canais_virais or [])[:6]:
        if not isinstance(cv, dict):
            continue
        nm_c = (cv.get("canal") or "").strip()
        vw_t = int(cv.get("views_totais") or 0)
        subs = max(1, int(cv.get("inscritos") or 1))
        vel = round(vw_t / subs, 1)
        top_v = (cv.get("top_videos") or [{}])[0] if (cv.get("top_videos")) else {}
        tit_top = (top_v.get("titulo") or "").strip()
        url_top = (top_v.get("url") or cv.get("url") or "").strip()
        canais_asc.append({
            "canal": nm_c,
            "url_canal": cv.get("url") or "",
            "velocidade_views_sub": vel,
            "destaque": cv.get("destaque") or "Em Ascensão",
            "video_referencia": tit_top,
            "url_video": url_top,
            "views_video": int(top_v.get("views") or 0),
        })
        if tit_top:
            if "?" in tit_top or tit_top.lower().startswith("what if"):
                gatilhos.append("Pergunta Hipotética Direta + Escala Numérica")
            elif any(c.isdigit() for c in tit_top):
                gatilhos.append("Especificidade Numérica + Prova Visual no Título")
            else:
                gatilhos.append("Lacuna de Curiosidade + Contraste de Consequência")
            padroes.append(f"{nm_c} ({vel}x views/inscrito): \"{tit_top}\"")

    if reg.get("data_ultimo_aprendizado") != hoje_iso:
        reg["dias_aprendidos"] = max(1, int(reg.get("dias_aprendidos") or 0) + 1)
        reg["data_ultimo_aprendizado"] = hoje_iso

    reg["canais_ascensao_detectados"] = canais_asc[:6]
    reg["padroes_aprendidos_hoje"] = padroes[:5] or [
        f"Monitoramento ativo dos benchmarks de {perfil.get('canal_nome', 'Canal')} ({hoje_iso})"
    ]
    reg["gatilhos_em_alta"] = list(dict.fromkeys(gatilhos))[:4] or [
        "Curiosidade Inevitável V8",
        "Contraste Visual Imediato nos Primeiros 15s",
    ]
    reg["resumo_aprendizado_hoje"] = (
        f"Aprendizado Diário #{reg['dias_aprendidos']} ({hoje_iso}): analisados {len(canais_asc)} canais em ascensão no nicho "
        f"({', '.join(x['canal'] for x in canais_asc[:3])}). Gatilho dominante de hoje: {' + '.join(reg['gatilhos_em_alta'][:2])}."
    )
    db["aprendizado_diario_ascensao"][cid] = reg
    return reg


def garantir_pauta_instantanea_hoje(db, ch, atual=None, perfil=None, forcar_rotacao=False):
    """Garante que a Sugestão do Dia apareça INSTANTANEAMENTE (< 20ms) em Português-BR perfeito (zero Mojibake),
    atualize AUTOMATICAMENTE a cada novo dia com aprendizado dos canais em ascensão e traga todos os canais e vídeos 100% clicáveis."""
    import copy as _copy
    ch = ch or {}
    cid = str(ch.get("id") or "")
    perfil = _copy.deepcopy(perfil or obter_perfil_editorial_canal(ch))
    hoje_iso = dt.date.today().isoformat()
    idioma = (ch.get("idioma") or "pt").lower()[:2]
    ch_key = _normalizar_chave_canal(ch.get("nome", ""))

    atual_limpo = claude.corrigir_mojibake_ptbr(_copy.deepcopy(atual)) if isinstance(atual, dict) else {}
    mudou = (atual_limpo != atual) if isinstance(atual, dict) else True

    # Garante sempre canais virais com URLs clicáveis e vídeos em alta detalhados e clicáveis
    canais_virais_atuais = _garantir_urls_clicaveis_canais_virais(
        atual_limpo.get("canais_virais_nicho") or [],
        ch_key=ch_key,
    )
    em_alta_det = _montar_em_alta_detalhado(canais_virais_atuais, atual_limpo.get("em_alta") or [])
    aprendizado_hoje = atualizar_aprendizado_diario_ascensao(db, ch, perfil=perfil, canais_virais=canais_virais_atuais)

    # Monta o banco completo de temas aprovados + extras do canal (sempre limpos em PT-BR)
    prioridades_aprovadas = list(perfil.get("temas_prioritarios_aprovados") or [])
    extras_canal = []
    for k_ex, lista_ex in SUGESTOES_EXTRAS_CANAIS_V8.items():
        if k_ex in ch_key or ch_key in k_ex:
            extras_canal = list(lista_ex)
            break

    todos_candidatos = []
    vistos_norm = set()

    def _add_cand(item_d):
        if not isinstance(item_d, dict):
            return
        tit_c = claude.corrigir_mojibake_ptbr((item_d.get("titulo") or item_d.get("assunto") or "").strip())
        if not tit_c or _titulo_viola_perfil(tit_c, perfil):
            return
        tn = re.sub(r"\W+", "", _sem_acentos(tit_c.lower()))
        if not tn or tn in vistos_norm:
            return
        vistos_norm.add(tn)
        info_f = verificar_tema_ja_feito(tit_c, db, ch)
        neural = _analisar_titulo_neural_v8(tit_c, ch, perfil, idx=len(todos_candidatos), eh_campeao=(len(todos_candidatos) == 0))
        todos_candidatos.append({
            "titulo": tit_c,
            "traducao": claude.corrigir_mojibake_ptbr((item_d.get("traducao") or "").strip()),
            "por_que": claude.corrigir_mojibake_ptbr((item_d.get("potencial_narrativo") or item_d.get("por_que") or "").strip()),
            "gancho": claude.corrigir_mojibake_ptbr((item_d.get("gancho") or "").strip()),
            "gatilho_neural": claude.corrigir_mojibake_ptbr((item_d.get("gatilho_neural") or neural.get("gatilho_neural") or "").strip()),
            "ctr_score": int(item_d.get("ctr_score") or neural.get("ctr_score") or 98),
            "ja_feito": bool(info_f.get("ja_feito")),
            "oculto": bool(info_f.get("oculto")),
        })

    for pr in prioridades_aprovadas:
        _add_cand(pr)
    for ex in extras_canal:
        _add_cand(ex)
    if isinstance(atual_limpo.get("tema"), dict):
        _add_cand(atual_limpo["tema"])
    for nv_old in (atual_limpo.get("novos") or []):
        _add_cand(nv_old)

    ineditos = [c for c in todos_candidatos if not c.get("ja_feito") and not c.get("oculto")] or todos_candidatos

    assunto_atual = ((atual_limpo.get("tema") or {}).get("assunto") or "").strip()
    info_assunto_atual = verificar_tema_ja_feito(assunto_atual, db, ch) if assunto_atual else {"ja_feito": True}
    mudou_dia = bool(atual_limpo.get("data") != hoje_iso)
    precisa_novo_tema = bool(
        not atual_limpo
        or not assunto_atual
        or mudou_dia
        or _titulo_viola_perfil(assunto_atual, perfil)
        or info_assunto_atual.get("ja_feito")
        or info_assunto_atual.get("oculto")
        or forcar_rotacao
    )

    if not precisa_novo_tema and atual_limpo.get("tema"):
        if atual_limpo.get("canais_virais_nicho") != canais_virais_atuais:
            atual_limpo["canais_virais_nicho"] = canais_virais_atuais
            mudou = True
        if atual_limpo.get("em_alta_detalhado") != em_alta_det:
            atual_limpo["em_alta_detalhado"] = em_alta_det
            mudou = True
        if atual_limpo.get("aprendizado_diario") != aprendizado_hoje:
            atual_limpo["aprendizado_diario"] = aprendizado_hoje
            mudou = True
        if not atual_limpo.get("perfil_editorial"):
            atual_limpo["perfil_editorial"] = {
                "canal_nome": perfil["canal_nome"],
                "idioma_exato": perfil["idioma_exato"],
                "formato_real": perfil["formato_real"],
                "contexto_e_publico": perfil["contexto_e_publico"],
                "diretriz_gerador": perfil["diretriz_gerador"],
                "o_que_priorizar": perfil.get("o_que_priorizar") or [],
                "o_que_evitar": perfil.get("o_que_evitar") or [],
                "como_aproveitar_virais": perfil.get("como_aproveitar_virais") or "",
                "avaliacao_temas_exemplo": perfil.get("avaliacao_temas_exemplo") or [],
                "temas_prioritarios_aprovados": prioridades_aprovadas,
                "canais_benchmark": perfil.get("canais_benchmark") or [],
            }
            mudou = True
        return claude.corrigir_mojibake_ptbr(atual_limpo), mudou

    # Rotaciona de forma inteligente no novo dia (ou quando o usuário pede rotação), evitando repetir o assunto anterior
    hist_diario = list(aprendizado_hoje.get("historico_temas_diarios") or [])
    escolhido = ineditos[0] if ineditos else {
        "titulo": f"Sugestão Campeã Neural V8 — {perfil.get('canal_nome', 'Canal')}",
        "traducao": "",
        "por_que": perfil.get("diretriz_gerador") or "",
        "gancho": "",
        "gatilho_neural": "Curiosidade Inevitável + Alto Contraste V8",
        "ctr_score": 99,
    }
    if len(ineditos) > 1:
        if forcar_rotacao and assunto_atual:
            idx_at = next((i for i, c in enumerate(ineditos) if c["titulo"].lower() == assunto_atual.lower()), -1)
            escolhido = ineditos[(idx_at + 1) % len(ineditos)]
        elif mudou_dia:
            # No novo dia, escolhe com base no dia do ano + evita o tema que estava ontem
            seed_dia = dt.date.today().toordinal()
            cands_sem_ontem = [c for c in ineditos if c["titulo"].lower() != assunto_atual.lower() and c["titulo"].lower() not in [h.lower() for h in hist_diario[-3:]]]
            if not cands_sem_ontem:
                cands_sem_ontem = [c for c in ineditos if c["titulo"].lower() != assunto_atual.lower()] or ineditos
            escolhido = cands_sem_ontem[seed_dia % len(cands_sem_ontem)]

    if escolhido.get("titulo") and escolhido["titulo"] not in hist_diario:
        hist_diario.append(escolhido["titulo"])
        aprendizado_hoje["historico_temas_diarios"] = hist_diario[-20:]
        if cid and isinstance(db.get("aprendizado_diario_ascensao"), dict):
            db["aprendizado_diario_ascensao"][cid] = aprendizado_hoje

    # Monta variações de título em Português-BR claro + idioma do canal
    restantes = [c for c in ineditos if c["titulo"].lower() != escolhido["titulo"].lower()]
    titulos_var = [
        {
            "titulo": escolhido["titulo"],
            "traducao": escolhido.get("traducao") or "",
            "ctr_score": 99,
            "gatilho_neural": escolhido.get("gatilho_neural") or "Campeão Neural V8",
        }
    ]
    for idx_r, r_cand in enumerate(restantes[:4]):
        titulos_var.append({
            "titulo": r_cand["titulo"],
            "traducao": r_cand.get("traducao") or "",
            "ctr_score": max(95, 98 - idx_r),
            "gatilho_neural": r_cand.get("gatilho_neural") or "Fórmula Neural V8",
        })

    novos_lista = []
    for idx_n, n_cand in enumerate(restantes):
        novos_lista.append({
            "titulo": n_cand["titulo"],
            "traducao": n_cand.get("traducao") or "",
            "ctr_score": max(94, 98 - (idx_n % 5)),
            "gatilho_neural": n_cand.get("gatilho_neural") or "Alto CTR Neural V8",
            "por_que": n_cand.get("por_que") or "Tema validado pelo DNA Editorial do canal com forte retenção visual.",
            "emocao_viral": n_cand.get("gatilho_neural") or "Curiosidade + Impacto Visual",
        })

    em_alta_str = [f"[{d['canal']}] {d['titulo']} ({d['views']:,} views)".replace(",", ".") for d in em_alta_det[:10]]
    nomes_bench_hoje = ", ".join(x.get("canal", "") for x in canais_virais_atuais[:3] if x.get("canal"))
    gatilhos_hoje_txt = " + ".join((aprendizado_hoje.get("gatilhos_em_alta") or ["Alto CTR Neural V8"])[:2])

    pauta_nova = {
        "analise_nicho_hoje": (
            f"Análise Diária Autoevolutiva ({hoje_iso} · Dia #{aprendizado_hoje.get('dias_aprendidos', 1)}) para {perfil['canal_nome']}: "
            f"cruzamos os canais em ascensão do nicho ({nomes_bench_hoje or 'benchmarks oficiais'}) e identificamos o padrão vencedor de hoje "
            f"({gatilhos_hoje_txt}), selecionando temas inéditos 100% alinhados ao formato {perfil['formato_real'][:110]}."
        ),
        "tema": {
            "assunto": escolhido["titulo"],
            "traducao": escolhido.get("traducao") or "",
            "ctr_score": 99,
            "gatilho_neural": escolhido.get("gatilho_neural") or "Campeão Neural V8",
            "por_que": escolhido.get("por_que") or perfil.get("diretriz_gerador") or "",
            "emocao_aproveitada": escolhido.get("gatilho_neural") or "Curiosidade imediata e retenção narrativa",
            "gancho": escolhido.get("gancho") or "",
            "titulos": titulos_var,
        },
        "novos": novos_lista[:10],
        "data": hoje_iso,
        "em_alta": em_alta_str or (atual_limpo.get("em_alta") or [])[:10],
        "em_alta_detalhado": em_alta_det,
        "canais_virais_nicho": canais_virais_atuais,
        "aprendizado_diario": aprendizado_hoje,
        "perfil_editorial": {
            "canal_nome": perfil["canal_nome"],
            "idioma_exato": perfil["idioma_exato"],
            "formato_real": perfil["formato_real"],
            "contexto_e_publico": perfil["contexto_e_publico"],
            "diretriz_gerador": perfil["diretriz_gerador"],
            "o_que_priorizar": perfil.get("o_que_priorizar") or [],
            "o_que_evitar": perfil.get("o_que_evitar") or [],
            "como_aproveitar_virais": perfil.get("como_aproveitar_virais") or "",
            "avaliacao_temas_exemplo": perfil.get("avaliacao_temas_exemplo") or [],
            "temas_prioritarios_aprovados": prioridades_aprovadas,
            "canais_benchmark": perfil.get("canais_benchmark") or [],
        },
    }
    return claude.corrigir_mojibake_ptbr(pauta_nova), True


def sincronizar_perfis_editoriais_no_banco(db):
    """Preenche automaticamente os campos `publico`, `tese`, `evitar` e `diretriz_pauta` nos canais do banco
    quando estiverem vazios, garante que o novo canal `GTA à la Une` (Francês `fr-FR`) esteja cadastrado e
    atualiza as pautas diárias com aprendizado de canais em ascensão."""
    alterou = False
    canais = db.setdefault("channels", [])

    # Garante que o canal GTA à la Une (https://www.youtube.com/@GTA%C3%A0laUne) em Francês (fr) exista no banco local
    gta_id = "a8068857-d56f-4aba-baf3-ea2b7ebda5bb"
    ch_gta = next(
        (c for c in canais if c.get("id") == gta_id or "gta" in _normalizar_chave_canal(c.get("nome", ""))),
        None,
    )
    perf_gta = PERFIS_EDITORIAIS_CANAIS["gta a la une"]
    if not ch_gta:
        ch_gta = {
            "id": gta_id,
            "nome": "GTA à la Une",
            "idioma": "fr",
            "idioma_dp": "Francês",
            "nicho": "Gaming — Grand Theft Auto (Rockstar Games)",
            "subnicho": "GTA IV & GTA VI (Sortie de Novembre), Grand Theft Auto, Secrets & Analyses (Francês fr-FR)",
            "publico": perf_gta["contexto_e_publico"],
            "tese": perf_gta["formato_real"],
            "diretriz_pauta": perf_gta["diretriz_gerador"],
            "cta": "Abonnez-vous à GTA à la Une et activez la cloche !",
            "evitar": "; ".join(perf_gta["o_que_evitar"][:3]),
            "cor": "#10b981",
            "perfil": "padrao",
            "youtube_channel_url": "https://www.youtube.com/@GTA%C3%A0laUne",
            "dp": {
                "url_canal": "https://www.youtube.com/@GTA%C3%A0laUne",
                "channel_thumbnail": "https://yt3.ggpht.com/UNwCLV5_c6zNILueld_hPpAn0Iz1naxwSRHabqZqZhbLUnyI9qwH4c31X39xzDd4aSEmiZ0G=s240-c-k-c0x00ffffff-no-rj",
                "horario_postagem": ["19:00"],
                "is_youtube_linked": True,
                "youtube_channel_id": "UCDHTE3vPssCo-Tta_z2ay1A",
                "youtube_channel_url": "https://www.youtube.com/@GTA%C3%A0laUne",
                "narrator": {
                    "configured": True,
                    "canal_id": gta_id,
                    "canal_name": "GTA à la Une",
                    "voice_id": "2915e0a6-6851-4b96-ae94-0ec3738955fa",
                    "voice_name": "Léo - Reassuring and Dynamic",
                    "speed": 1.0,
                    "volume": 1.0,
                    "subtitle_enabled": True,
                    "subtitle_words": 5,
                    "subtitle_case": "normal",
                    "subtitle_veo_words": 5,
                },
            },
        }
        canais.append(ch_gta)
        alterou = True
    else:
        if ch_gta.get("idioma") != "fr" or ch_gta.get("idioma_dp") != "Francês":
            ch_gta["idioma"] = "fr"
            ch_gta["idioma_dp"] = "Francês"
            alterou = True
        if not ch_gta.get("cta") or "inscreva" in str(ch_gta.get("cta") or "").lower():
            ch_gta["cta"] = "Abonnez-vous à GTA à la Une et activez la cloche !"
            alterou = True
        if "novembro" not in str(ch_gta.get("subnicho") or "").lower() and "novembre" not in str(ch_gta.get("subnicho") or "").lower():
            ch_gta["nicho"] = "Gaming — Grand Theft Auto (Rockstar Games)"
            ch_gta["subnicho"] = "GTA IV & GTA VI (Sortie de Novembre), Grand Theft Auto, Secrets & Analyses (Francês fr-FR)"
            ch_gta["diretriz_pauta"] = perf_gta["diretriz_gerador"]
            ch_gta["tese"] = perf_gta["formato_real"]
            alterou = True
        if not ch_gta.get("youtube_channel_url"):
            ch_gta["youtube_channel_url"] = "https://www.youtube.com/@GTA%C3%A0laUne"
            alterou = True

    for ch in canais:
        perfil = obter_perfil_editorial_canal(ch)
        if not (ch.get("publico") or "").strip():
            ch["publico"] = perfil["contexto_e_publico"]
            alterou = True
        if not (ch.get("tese") or "").strip():
            ch["tese"] = perfil["formato_real"]
            alterou = True
        if not (ch.get("evitar") or "").strip() and perfil.get("o_que_evitar"):
            ch["evitar"] = "; ".join(perfil["o_que_evitar"][:3])
            alterou = True
        if not (ch.get("diretriz_pauta") or "").strip():
            ch["diretriz_pauta"] = perfil["diretriz_gerador"]
            alterou = True
    # Também corrige qualquer texto com Mojibake já salvo em db["pautas"]
    if isinstance(db.get("pautas"), dict):
        for cid_p, p_obj in list(db["pautas"].items()):
            p_limpo = claude.corrigir_mojibake_ptbr(p_obj)
            if p_limpo != p_obj:
                db["pautas"][cid_p] = p_limpo
                alterou = True
    return alterou


def gerar(db, ch, log=print):
    idioma = ch.get("idioma", "pt")
    perfil = obter_perfil_editorial_canal(ch)
    feitos = [v["titulo"] for v in db.get("videos", []) if v.get("channel_id") == ch["id"]][-60:]
    feitos_yt = [v.get("titulo") for v in (ch.get("youtube_videos_publicados") or []) if v.get("titulo")]
    concluidos_man = list(ch.get("temas_concluidos_manual") or [])
    ocultos_man = list(ch.get("temas_ocultos_manual") or [])
    ideias = [i["titulo"] for i in db.get("ideas", []) if i.get("channel_id") == ch["id"]][-30:]
    kanban = [k["titulo"] for k in db.get("kanban", []) if k.get("channel_id") == ch["id"]][-40:]
    todos_feitos_lista = feitos + feitos_yt + concluidos_man + ocultos_man + ideias + kanban

    intel_viral = _buscar_inteligencia_nichos_virais(ch, perfil, log, rapido=True)
    alta = intel_viral["videos_inspiracao"]
    canais_virais = intel_viral["canais_pareados"]
    em_alta_det = intel_viral.get("em_alta_detalhado") or _montar_em_alta_detalhado(canais_virais, alta)
    aprendizado_hoje = atualizar_aprendizado_diario_ascensao(db, ch, perfil=perfil, canais_virais=canais_virais)

    hoje = dt.date.today().strftime("%d/%m/%Y")
    trad = idioma != "pt"

    prioridades_aprovadas = perfil.get("temas_prioritarios_aprovados") or []
    avaliacao_exemplos = perfil.get("avaliacao_temas_exemplo") or []

    bloco_exemplos_aval = ""
    if avaliacao_exemplos:
        linhas_av = [
            f"- \"{x['tema']}\" -> [{x['status'].upper()}] {x['avaliacao']}"
            for x in avaliacao_exemplos
        ]
        bloco_exemplos_aval = "CALIBRAGEM EDITORIAL (O QUE DESCARTAR VS. O QUE APROVAR NESTE CANAL):\n" + "\n".join(linhas_av) + "\n\n"

    bloco_prioridades = ""
    if prioridades_aprovadas:
        linhas_pr = [
            f"- Prioridade #{x['prioridade']}: \"{x['titulo']}\" — Potencial narrativo: {x['potencial_narrativo']}"
            for x in prioridades_aprovadas
        ]
        bloco_prioridades = "TEMAS-MODELO DE ALTÍSSIMO POTENCIAL APROVADOS PARA ESTE CANAL:\n" + "\n".join(linhas_pr) + "\n\n"

    bloco_aprendizado_diario = (
        f"APRENDIZADO DIÁRIO DOS CANAIS EM ASCENSÃO (DIA #{aprendizado_hoje.get('dias_aprendidos', 1)}):\n"
        + "\n".join(f"- {p_ap}" for p_ap in (aprendizado_hoje.get("padroes_aprendidos_hoje") or []))
        + f"\n- Gatilhos em ascensão detectados hoje: {', '.join(aprendizado_hoje.get('gatilhos_em_alta') or [])}\n\n"
    )

    p = f"""Você é o Diretor Editorial Chefe + Especialista em TÍTULOS NEURAIS V8 de alta taxa de clique (CTR) no YouTube. Hoje é {hoje}.
Sua missão é montar a SUGESTÃO DO DIA para o canal **{perfil['canal_nome']}**, entregando títulos que JÁ PASSARAM PELA ANÁLISE DE TÍTULOS NEURAIS V8 (Curiosidade Inevitável + Contraste Visual + Gatilho Neural de Clique + Score CTR 95–99%), obedecendo 100% à proposta editorial real deste canal.
Escreva todas as explicações, gatilhos e traduções em Português do Brasil (pt-BR) perfeitamente acentuado (UTF-8 puro).

═══════════════════════════════════════════════════════════════
1. DNA EDITORIAL OFICIAL DO CANAL: {perfil['canal_nome']}
═══════════════════════════════════════════════════════════════
• IDIOMA EXATO DOS TÍTULOS E GANCHOS: {perfil['idioma_exato']}
• FORMATO REAL E PROPOSTA DO CANAL: {perfil['formato_real']}
• PÚBLICO E CONTEXTO: {perfil['contexto_e_publico']}

• DIRETRIZ OBRIGATÓRIA DO GERADOR DE SUGESTÕES:
"{perfil['diretriz_gerador']}"

• O QUE PRIORIZAR SEMPRE:
{chr(10).join('  - ' + x for x in perfil.get('o_que_priorizar', []))}

• O QUE EVITAR TERMINANTEMENTE (NUNCA SUGIRA ISSO):
{chr(10).join('  - ' + x for x in perfil.get('o_que_evitar', []))}

• COMO APROVEITAR OS ASSUNTOS EM ALTA / NICHOS VIRAIS:
{perfil.get('como_aproveitar_virais', '')}

{bloco_exemplos_aval}{bloco_prioridades}{bloco_aprendizado_diario}═══════════════════════════════════════════════════════════════
2. VÍDEOS E CANAIS EXPLODINDO AGORA NO NICHO (NICHOS VIRAIS + RADAR):
═══════════════════════════════════════════════════════════════
{chr(10).join('- ' + t for t in alta) if alta else '(Use os benchmarks do nicho acima)'}

═══════════════════════════════════════════════════════════════
3. JÁ FEITOS OU NO KANBAN (NÃO REPITA):
═══════════════════════════════════════════════════════════════
{chr(10).join('- ' + t for t in (feitos + kanban + ideias)[:25]) or '(nenhum ainda)'}

═══════════════════════════════════════════════════════════════
4. SUA ENTREGA JÁ COM ANÁLISE DE TÍTULOS NEURAIS V8 (SOMENTE JSON VÁLIDO):
═══════════════════════════════════════════════════════════════
1) "analise_nicho_hoje": 1 parágrafo curto (em português do Brasil) explicando qual emoção humana e formato estão explodindo agora nos canais virais em ascensão e como você adaptou isso hoje para a diretriz exata do canal {perfil['canal_nome']}.
2) "tema": a melhor sugestão Campeã Neural V8 para produzir HOJE, contendo:
   - "assunto": Título Campeão Neural #1 altamente magnético no idioma do canal ({perfil['idioma_exato']}, até 75 caracteres)
   { '- "traducao": tradução fiel para o português do Brasil' if trad else ''}
   - "ctr_score": nota neural de CTR de 96 a 99
   - "gatilho_neural": nome curto do gatilho neural V8 aplicado (em português do Brasil)
   - "por_que": potencial narrativo e visual detalhado (em português do Brasil)
   - "emocao_aproveitada": qual emoção humana dos vídeos virais este tema captura (em português do Brasil, 1 frase)
   - "gancho": as primeiras 2 a 3 frases faladas que abrem o vídeo (no idioma do canal: {perfil['idioma_exato']})
   - "titulos": 5 variações de Títulos Neurais V8 de alto CTR para este tema (no idioma do canal, até 75 caracteres, cada um com "ctr_score" de 95 a 99, "gatilho_neural" em português do Brasil{', e "traducao" para o português do Brasil' if trad else ''})
3) "novos": 6 outros Títulos Neurais V8 inéditos e extraordinários para os próximos dias, 100% alinhados à DIRETRIZ OBRIGATÓRIA DO GERADOR acima, cada um com:
   - "titulo": título neural V8 no idioma do canal ({perfil['idioma_exato']})
   { '- "traducao": tradução fiel para o português do Brasil' if trad else ''}
   - "ctr_score": nota neural de CTR (94 a 99)
   - "gatilho_neural": gatilho neural V8 aplicado (em português do Brasil)
   - "por_que": potencial narrativo (em português do Brasil)
   - "emocao_viral": a emoção ou gatilho que faz esse tema viralizar no nicho

Responda SOMENTE JSON:
{{
  "analise_nicho_hoje": "",
  "tema": {{
    "assunto": "",
    "ctr_score": 99,
    "gatilho_neural": "",
    "por_que": "",
    "emocao_aproveitada": "",
    "gancho": "",
    "titulos": [{{"titulo": ""{', "traducao": ""' if trad else ''}, "ctr_score": 99, "gatilho_neural": ""}}]
  }},
  "novos": [
    {{"titulo": ""{', "traducao": ""' if trad else ''}, "ctr_score": 97, "gatilho_neural": "", "por_que": "", "emocao_viral": ""}}
  ]
}}"""

    try:
        r = claude.json_pref("roteiro", p, timeout_codex=32)
        if not isinstance(r, dict) or not r.get("tema"):
            raise RuntimeError("Resposta incompleta")
        r = claude.corrigir_mojibake_ptbr(r)
    except Exception:
        atual_ant = (db.get("pautas") or {}).get(ch.get("id"))
        r, _ = garantir_pauta_instantanea_hoje(db, ch, atual_ant, perfil, forcar_rotacao=True)

    # Pós-validação rigorosa de alinhamento editorial:
    novos_limpos = []
    for nv in (r.get("novos") or []):
        if isinstance(nv, dict) and nv.get("titulo") and not _titulo_viola_perfil(nv["titulo"], perfil):
            novos_limpos.append(claude.corrigir_mojibake_ptbr(nv))

    prioridades_nao_feitas = [
        pr for pr in prioridades_aprovadas
        if not verificar_tema_ja_feito(pr.get("titulo") or "", db, ch).get("ja_feito")
    ] or prioridades_aprovadas

    if _titulo_viola_perfil((r.get("tema") or {}).get("assunto", ""), perfil) and prioridades_nao_feitas:
        pr1 = prioridades_nao_feitas[0]
        r["tema"] = {
            "assunto": pr1["titulo"],
            "traducao": pr1.get("traducao") or "",
            "por_que": pr1["potencial_narrativo"],
            "emocao_aproveitada": "Liberdade inicial vs. isolamento absoluto, necessidade de recomeçar e pertencimento.",
            "gancho": pr1.get("gancho") or "",
            "titulos": [
                {"titulo": pr1["titulo"], "traducao": pr1.get("traducao") or ""},
            ] + [
                {"titulo": x["titulo"], "traducao": x.get("traducao") or ""}
                for x in prioridades_nao_feitas[1:5]
            ],
        }
    elif "recomeco" in _normalizar_chave_canal(ch.get("nome", "")) and prioridades_nao_feitas:
        pr1 = prioridades_nao_feitas[0]
        tits_atuais = (r.get("tema") or {}).get("titulos") or []
        tits_atuais = [t for t in tits_atuais if isinstance(t, dict) and not _titulo_viola_perfil(t.get("titulo", ""), perfil)]
        if not any(pr1["titulo"].lower() in (t.get("titulo") or "").lower() for t in tits_atuais):
            tits_atuais.insert(0, {"titulo": pr1["titulo"], "traducao": pr1.get("traducao") or ""})
        r["tema"]["titulos"] = tits_atuais[:6]

    titulos_novos_set = {(x.get("titulo") or "").strip().lower() for x in novos_limpos}
    for pr in prioridades_nao_feitas:
        if pr["titulo"].strip().lower() not in titulos_novos_set:
            novos_limpos.insert(0, {
                "titulo": pr["titulo"],
                "traducao": pr.get("traducao") or "",
                "por_que": pr["potencial_narrativo"],
                "emocao_viral": "Prioridade Editorial Aprovada do Canal",
                "prioridade_oficial": pr.get("prioridade"),
            })
            titulos_novos_set.add(pr["titulo"].strip().lower())

    r["novos"] = novos_limpos[:10]
    r["data"] = dt.date.today().isoformat()
    r["em_alta"] = alta[:10]
    r["em_alta_detalhado"] = em_alta_det
    r["canais_virais_nicho"] = canais_virais
    r["aprendizado_diario"] = aprendizado_hoje
    r["perfil_editorial"] = {
        "canal_nome": perfil["canal_nome"],
        "idioma_exato": perfil["idioma_exato"],
        "formato_real": perfil["formato_real"],
        "contexto_e_publico": perfil["contexto_e_publico"],
        "diretriz_gerador": perfil["diretriz_gerador"],
        "o_que_priorizar": perfil.get("o_que_priorizar") or [],
        "o_que_evitar": perfil.get("o_que_evitar") or [],
        "como_aproveitar_virais": perfil.get("como_aproveitar_virais") or "",
        "avaliacao_temas_exemplo": avaliacao_exemplos,
        "temas_prioritarios_aprovados": prioridades_aprovadas,
        "canais_benchmark": perfil.get("canais_benchmark") or [],
    }
    r, _, diag = enriquecer_pauta_e_diagnostico_canal(db, ch, r, perfil)
    r["diagnostico_canal"] = diag
    return claude.corrigir_mojibake_ptbr(r)

