"""Perfis de canal: cada um dá ao vídeo uma cara própria (cores, fontes, filtro, transição, legenda, ritmo e efeitos preferidos).

O perfil fica no cadastro do canal ("perfil") e vira o padrão do Estúdio; dá para trocar em cada vídeo.
"""

PERFIS = {
    "padrao": {
        "nome": "Padrão", "desc": "Limpo e neutro, serve para qualquer nicho",
        "filtro": "nenhum", "transicao": "fade", "legenda": {"estilo": "", "cor": "#FFFFFF"},
        "efeitos": ["pessoa", "data", "local", "numero", "frase", "linha_tempo", "mapa", "capitulo"],
        "segundos_cena": 0, "tom": "",
    },
    "true_crime": {
        "nome": "True Crime", "desc": "Quadro de investigação, fichas, documentos com tarjas, fotos sépia",
        "filtro": "dramatico", "transicao": "fade", "legenda": {"estilo": "", "cor": "#FFFFFF"},
        "efeitos": ["quadro", "ficha", "documento", "pessoa", "duas_pessoas", "citacao", "linha_tempo", "data", "local", "mapa", "nome", "capitulo"],
        "abertura": "quadro", "segundos_cena": 4,
        "tom": "Narração de documentário de crime real: suspense crescente, fatos verificáveis, respeito às vítimas, ganchos no fim de cada bloco.",
    },
    "jornal": {
        "nome": "Jornal", "desc": "Faixa amarela, etiquetas vermelhas, nome e função de quem fala",
        "filtro": "contraste", "transicao": "corte", "legenda": {"estilo": "jornal"},
        "efeitos": ["nome", "citacao", "numero", "local", "pessoa", "duas_pessoas", "colagem", "linha_tempo", "mapa"],
        "segundos_cena": 3,
        "tom": "Linguagem de telejornal: direto, objetivo, frases curtas, sempre citando a fonte.",
    },
    "historia": {
        "nome": "História", "desc": "Sépia, linha do tempo, mapas, documentos antigos, capítulos",
        "filtro": "sepia", "transicao": "fade", "legenda": {"estilo": "", "cor": "#F4EAD2"},
        "efeitos": ["linha_tempo", "ano", "mapa", "citacao", "documento", "capitulo", "pessoa", "data", "colagem", "sequencia", "escala"],
        "segundos_cena": 5,
        "tom": "Documentário histórico: contexto, datas e lugares exatos, personagens com nome, narrativa em capítulos.",
    },
    "horror": {
        "nome": "Horror / Mistério", "desc": "Frio e escuro, frases de impacto, documentos, quadro de pistas",
        "filtro": "horror", "transicao": "fade", "legenda": {"estilo": "", "cor": "#E2E2E6"},
        "efeitos": ["frase", "documento", "quadro", "ficha", "data", "local", "mapa", "capitulo", "citacao"],
        "abertura": "frase", "segundos_cena": 5,
        "tom": "Mistério e horror real: atmosfera, pausas, perguntas sem resposta, sem exagerar nem inventar fatos.",
    },
    "natureza": {
        "nome": "Natureza", "desc": "Cores vivas, mapa de satélite, comparação de escala, números",
        "filtro": "natural", "transicao": "fade", "legenda": {"estilo": "", "cor": "#FFFFFF"},
        "efeitos": ["mapa", "escala", "numero", "local", "frase", "sequencia", "capitulo"],
        "segundos_cena": 5,
        "tom": "Documentário de natureza: encantamento, curiosidades com números reais, comparações que dão noção de tamanho.",
    },
}

EFEITOS_DESC = {
    "pessoa": "foto da pessoa em cartão com o nome (quando a narração APRESENTA alguém real pelo nome)",
    "duas_pessoas": "dois cartões lado a lado (apresenta duas pessoas juntas)",
    "data": "data escrita letra por letra → layout_texto = a data por extenso",
    "local": "plaquinha com o nome do lugar → layout_texto = nome curto do lugar",
    "ano": "selo com o ano (fato/filmagem de arquivo) → layout_texto = o ano",
    "citacao": "\"a frase real\": frase LITERAL de documento/declaração → layout_texto = a frase exata (até 220 caracteres), layout_fonte = de onde é",
    "colagem": "grade com várias fotos (panorama de um lugar/evento)",
    "quadro": "quadro de investigação (fotos presas com alfinete, fio vermelho e bilhetes) → layout_texto = até 3 pistas curtas separadas por | ; pessoas = nomes das fotos",
    "linha_tempo": "linha do tempo → layout_texto = 2 a 5 marcos 'ANO: fato curto' separados por | (ex.: '1912: Titanic parte | 1985: destroços achados')",
    "ficha": "ficha/arquivo de uma pessoa ou caso → layout_texto = 'Campo: valor' separados por | (ex.: 'Nome: ... | Idade: ... | Visto por último: ...')",
    "numero": "número enorme contando na tela → layout_texto = 'número | rótulo curto' (ex.: '1.517 | mortos no naufrágio')",
    "escala": "comparação de tamanho com barras → layout_texto = 2 a 4 itens 'Nome: valor unidade' separados por | (mesma unidade em todos)",
    "documento": "documento com tarjas pretas que se abrem e a palavra-chave marcada → layout_texto = a frase do documento, layout_destaque = a palavra-chave, layout_fonte = nome do documento",
    "capitulo": "cartela de capítulo (\"PARTE II\") quando a história muda de fase → layout_texto = título curto do capítulo (2 a 5 palavras)",
    "mapa": "mergulho de satélite até o lugar com alfinete → layout_texto = lugar com cidade e país (ex.: 'Pripyat, Ucrânia'), coordenadas = [lat, lon], zoom = 5 (país) a 16 (prédio)",
    "frase": "frase de impacto entre cantoneiras, com brilho → layout_texto = frase forte de até 12 palavras tirada da narração",
    "nome": "nome e função de quem fala/aparece (tarja embaixo) → layout_texto = 'Nome | função'",
    "sequencia": "sequência rápida de fotos com flash (vários rostos, objetos ou lugares da mesma série)",
}


def get(chave):
    return PERFIS.get(chave or "padrao") or PERFIS["padrao"]


def lista():
    return [{"id": k, "nome": p["nome"], "desc": p["desc"]} for k, p in PERFIS.items()]


def regras_efeitos(chave, n_cenas):
    """Texto para o prompt da pesquisa: quais efeitos usar e como preencher."""
    p = get(chave)
    pref = p["efeitos"]
    outros = [k for k in EFEITOS_DESC if k not in pref]
    linhas = [f'- "{k}": {EFEITOS_DESC[k]}' for k in pref] + [f'- "{k}": {EFEITOS_DESC[k]} (use pouco neste canal)' for k in outros]
    extra = ""
    if p.get("abertura"):
        extra = f'\n- A cena 1 abre o vídeo com "{p["abertura"]}" (abertura imersiva), se o conteúdo permitir.'
    return (f"PERFIL DO CANAL: {p['nome']} — prefira os efeitos na ordem abaixo.\n" + "\n".join(linhas) +
            '\n- "midia": todas as outras cenas (só a imagem/vídeo).' + extra +
            "\n- Use efeito em no máximo 1 a cada 3 cenas; nunca o mesmo efeito em cenas seguidas; \"capitulo\" só quando a história muda de fase (no máximo 1 a cada 25 cenas)."
            "\n- Só use o efeito se a narração der o conteúdo (data, número, lugar, frase). Nunca invente números ou frases.")
