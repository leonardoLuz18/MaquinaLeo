"""Modelos de prompt. Você copia, cola no Claude/ChatGPT/Gemini/Grok e cola a resposta de volta."""
import json
import re

IDIOMAS = {
    "pt": "português do Brasil",
    "es": "espanhol",
    "en": "inglês (americano)",
    "fr": "francês (fr-FR)",
}


def _idioma(channel):
    return IDIOMAS.get((channel or {}).get("idioma", "pt"), "português do Brasil")


def _contexto_canal(channel):
    c = channel or {}
    fns = c.get("funcoes_especiais_video") or []
    fns_txt = ", ".join(str(x) for x in fns) if isinstance(fns, list) else str(fns)
    return (
        "# CONTEXTO DO CANAL (não repita isso na resposta, use como base)\n"
        f"- Canal: {c.get('nome','')}\n"
        f"- Nicho: {c.get('nicho','')}\n"
        f"- Subnicho: {c.get('subnicho','')}\n"
        f"- Público-alvo: {c.get('publico','')}\n"
        f"- Tese/promessa do canal: {c.get('tese','')}\n"
        f"- Idioma do canal: {_idioma(c)}\n"
        + (f"- Personagem recorrente do canal: {c.get('personagem')}\n" if c.get("personagem") else "")
        + (f"- Formato customizado dos vídeos (Chat <-> DarkPlanner): {c.get('formato_video_custom')}\n" if c.get("formato_video_custom") else "")
        + (f"- Estilo visual ativo: {c.get('estilo_visual')}\n" if c.get("estilo_visual") else "")
        + (f"- Funções especiais exigidas nos vídeos: {fns_txt}\n" if fns_txt else "")
        + (f"- Diretrizes diretas do usuário no Chat: {c.get('regras_custom_chat')}\n" if c.get("regras_custom_chat") else "")
    )


def roteiro(channel, video, palavras_por_minuto=150):
    b = video.get("briefing", {})
    dur = float(b.get("duracao_min") or 10)
    palavras = int(dur * palavras_por_minuto)
    refs = (b.get("referencias") or "").strip()
    refs_txt = f"\n# MATERIAL DE REFERÊNCIA (use como base factual, não copie frases)\n{refs}\n" if refs else ""
    refs_txt += _extras_briefing(b)
    return f"""Você é um roteirista sênior de canais Dark no YouTube (vídeos sem rosto, só narração + imagens), especialista em retenção.

{_contexto_canal(channel)}
# VÍDEO
- Título: {video.get('titulo','')}
- Duração alvo: {dur:g} minutos (≈ {palavras} palavras de narração)
- Estilo de narração: {b.get('tipo_narrativa','')}
- Estrutura: {b.get('estrutura','')}
- Público deste vídeo: {b.get('publico') or (channel or {}).get('publico','')}
- Chamada para ação: {b.get('cta','')}
- Contexto extra: {b.get('contexto','')}
{refs_txt}
# REGRAS
1. Escreva SOMENTE o texto que será narrado, em {_idioma(channel)}. Sem títulos de seção, sem marcações de cena, sem [música], sem emojis.
2. Os primeiros 30 segundos são um gancho forte: abra com a cena/fato mais intrigante e faça uma promessa clara do que a pessoa vai descobrir.
3. Crie "loops abertos" a cada 1–2 minutos (perguntas que só se resolvem mais à frente).
4. Frases curtas e visuais — cada frase deve poder virar uma imagem.
5. Use fatos verificáveis. Se algo for incerto, diga que é incerto. Não invente nomes, datas ou números.
6. Termine com uma conclusão que pague a promessa do título e com a chamada para ação de forma natural.
7. Mire em aproximadamente {palavras} palavras.

Responda apenas com o roteiro, em texto corrido, separado em parágrafos.
"""


def _extras_briefing(b):
    t = ""
    if (b.get("produto") or "").strip():
        t += f"\n# PRODUTO A INDICAR (afiliado)\n{b['produto']}\nCite o produto UMA vez, de forma natural e útil para a história (nunca como anúncio forçado), e convide a pessoa a ver o link na descrição.\n"
    if (b.get("serie") or "").strip():
        t += f"\n# SÉRIE / NOVELA\nEste vídeo é o episódio {b.get('episodio') or '?'} da série \"{b['serie']}\".\n"
        if (b.get("resumo_anterior") or "").strip():
            t += f"Resumo do que aconteceu até agora: {b['resumo_anterior']}\nComece com uma recapitulação de 2 frases e termine com um gancho para o próximo episódio.\n"
    return t


def roteiro_estrutura(channel, video, partes, palavras_por_minuto=150):
    b = video.get("briefing", {})
    dur = float(b.get("duracao_min") or 30)
    palavras = int(dur * palavras_por_minuto)
    return f"""Você é um roteirista sênior de canais Dark no YouTube. Vamos escrever um roteiro LONGO em {partes} partes.

{_contexto_canal(channel)}
# VÍDEO
- Título: {video.get('titulo','')}
- Duração alvo: {dur:g} minutos (≈ {palavras} palavras no total, ≈ {palavras // partes} por parte)
- Estilo de narração: {b.get('tipo_narrativa','')} · Estrutura: {b.get('estrutura','')}
- Contexto extra: {b.get('contexto','')}
{_extras_briefing(b)}
{('# MATERIAL DE REFERÊNCIA' + chr(10) + b.get('referencias','')) if (b.get('referencias') or '').strip() else ''}

# TAREFA
Crie APENAS a estrutura (ainda não escreva o roteiro): divida o vídeo em {partes} partes. Para cada parte dê: o que acontece, os fatos que entram, o loop aberto que ela deixa e como termina. A parte 1 começa com o gancho dos primeiros 30 segundos. A última parte paga a promessa do título.
Responda em tópicos, em português.
"""


def roteiro_parte(channel, video, k, partes, estrutura, final_anterior="", palavras_por_minuto=150):
    b = video.get("briefing", {})
    dur = float(b.get("duracao_min") or 30)
    alvo = int(dur * palavras_por_minuto / partes)
    cont = f"\n# COMO TERMINOU A PARTE ANTERIOR (continue exatamente daqui, sem repetir)\n...{final_anterior[-700:]}\n" if final_anterior else ""
    return f"""Continue o roteiro do vídeo "{video.get('titulo','')}". Escreva SOMENTE a PARTE {k} de {partes}.

{_contexto_canal(channel)}
# ESTRUTURA COMBINADA
{estrutura}
{cont}
# REGRAS
- Somente o texto narrado, em {_idioma(channel)}, sem títulos, sem marcações, sem "Parte {k}".
- ≈ {alvo} palavras. Frases curtas e visuais. Fatos verificáveis.
- {"Comece com o gancho forte dos primeiros 30 segundos." if k == 1 else "Não recapitule; siga a narrativa."}
- {"Termine pagando a promessa do título e com a chamada para ação." if k == partes else "Termine com um loop aberto que puxe para a próxima parte."}
"""


TITULO_SCHEMA = {
    "nota_ctr": 0, "curiosidade": 0, "clareza": 0, "emocao": 0,
    "problemas": ["..."], "alternativas": [{"titulo": "...", "porque": "..."}],
}


def validar_titulo(channel, video, opcoes=""):
    return f"""Você é especialista em CTR de títulos do YouTube para canais Dark.

{_contexto_canal(channel)}
# TÍTULO PRINCIPAL
{video.get('titulo','')}
{('# OUTRAS OPÇÕES QUE ESTOU CONSIDERANDO' + chr(10) + opcoes) if opcoes.strip() else ''}

# RESUMO DO VÍDEO
{(video.get('roteiro') or '')[:1500]}

Avalie de 0 a 100: nota_ctr (geral), curiosidade, clareza e emoção. Aponte problemas (tamanho, palavra fraca, promessa que o vídeo não cumpre, clickbait que gera rejeição). Proponha 6 alternativas melhores em {_idioma(channel)}, até 70 caracteres.
Responda SOMENTE com JSON válido neste formato:
{json.dumps(TITULO_SCHEMA, ensure_ascii=False, indent=2)}
"""


PUBLICADO_SCHEMA = {
    "diagnostico": "uma frase", "nota": 0,
    "pontos": [{"metrica": "CTR", "leitura": "...", "acao": "..."}],
    "proximo_video": "o que repetir e o que mudar no próximo",
    "titulos_alternativos": ["..."], "ideias_thumb": ["..."],
}


def video_publicado(channel, video, metricas):
    return f"""Você é analista de canais Dark no YouTube. Analise o desempenho deste vídeo publicado.

{_contexto_canal(channel)}
# VÍDEO
Título: {video.get('titulo','')}
Duração: {video.get('briefing',{}).get('duracao_min','')} min

# MÉTRICAS DO YOUTUBE STUDIO (coladas pelo dono do canal)
{metricas}

Compare com referências de canais dark (CTR bom acima de 6–8%, retenção média boa acima de 35–40% em vídeos de 10+ min, queda forte nos primeiros 30s indica hook fraco).
Responda SOMENTE com JSON válido neste formato:
{json.dumps(PUBLICADO_SCHEMA, ensure_ascii=False, indent=2)}
"""


MAPA_SCHEMA = {
    "nicho": "...",
    "subnichos": [{
        "nome": "...", "potencial": "alto|médio|baixo", "concorrencia": "alta|média|baixa", "rpm": "faixa estimada em US$",
        "por_que": "...", "temas": [{"titulo": "ideia de vídeo", "gancho": "..."}],
    }],
}


def mapa_nichos(semente, idioma="pt"):
    return f"""Você é estrategista de canais Dark (faceless) no YouTube.
Monte um MAPA DO NICHO "{semente}" para canais em {IDIOMAS.get(idioma, idioma)}.
Liste de 6 a 8 subnichos. Para cada um: potencial de views, concorrência, RPM estimado (faixa), por que funciona e 5 temas de vídeo com títulos prontos (no idioma do canal) e o gancho.
Priorize subnichos com demanda alta e poucos canais bons (oportunidade para canal novo).
Responda SOMENTE com JSON válido neste formato:
{json.dumps(MAPA_SCHEMA, ensure_ascii=False, indent=2)}
"""


ANALISE_SCHEMA = {
    "nota_geral": 0,
    "resumo": "uma frase com o diagnóstico",
    "hook": {"nota": 0, "pontos_fortes": ["..."], "pontos_fracos": ["..."]},
    "dimensoes": [{"nome": "Retenção", "nota": 0, "comentario": "..."}],
    "melhorias": [{"ordem": 1, "acao": "...", "impacto_estimado": "+5 pontos", "como_fazer": "..."}],
    "titulo_sugerido": "...",
}


def analise(channel, video):
    b = video.get("briefing", {})
    return f"""Você é um consultor sênior de roteiros para YouTube, especializado em canais Dark (mistérios, true crime, curiosidades, documentários). Você analisa roteiros com o rigor de quem já produziu vídeos com mais de 10 milhões de views.

{_contexto_canal(channel)}
# CONTEXTO
**Título:** {video.get('titulo','')}
**Duração alvo:** {b.get('duracao_min','')} minutos

# ROTEIRO PARA ANÁLISE
{video.get('roteiro','')}

# TAREFA
Avalie o roteiro de 0 a 100. Analise: hook (primeiros 30s), promessa do título x entrega, retenção/loops abertos, ritmo, clareza, precisão factual, emoção e final/CTA.
Dê no máximo 5 melhorias, em ordem de impacto, cada uma com instrução prática.

Responda SOMENTE com um JSON válido neste formato (sem texto antes ou depois):
{json.dumps(ANALISE_SCHEMA, ensure_ascii=False, indent=2)}
"""


def correcao(channel, video):
    a = video.get("analise") or {}
    melhorias = "\n".join(
        f"{m.get('ordem','')}. {m.get('acao','')} — {m.get('como_fazer','')}" for m in a.get("melhorias", [])
    )
    return f"""Reescreva o roteiro abaixo aplicando TODAS as melhorias listadas. Mantenha o idioma ({_idioma(channel)}), o tamanho aproximado e os fatos. Responda apenas com o roteiro final, em texto corrido, sem comentários.

{_contexto_canal(channel)}
# TÍTULO
{video.get('titulo','')}

# MELHORIAS A APLICAR
{melhorias}

# ROTEIRO ATUAL
{video.get('roteiro','')}
"""


CENAS_EXEMPLO = [
    {
        "n": 1,
        "tipo": "pessoa_real | lugar | evento_historico | objeto | conceito",
        "pessoa_real": "nome da pessoa real que aparece, ou vazio",
        "termos_busca": ["2 a 4 buscas curtas em INGLÊS, da mais exata para a mais genérica"],
        "descricao_visual": "o que deve aparecer na tela, em português",
        "prompt_ia": "prompt em inglês para gerar a imagem por IA caso não exista mídia real (sem texto, sem logo, sem rosto de pessoa real identificável)",
    }
]


def cenas(channel, video):
    linhas = []
    for c in video.get("cenas", []):
        linhas.append(f"{c['n']}. {c['texto']}")
    lista = "\n".join(linhas)
    return f"""Você é um editor de vídeos documentais. Para cada cena numerada abaixo, decida o que deve aparecer na tela e como encontrar essa mídia em bancos de imagens/vídeos reais (Wikimedia Commons, Pixabay, Pexels).

{_contexto_canal(channel)}
# TÍTULO DO VÍDEO
{video.get('titulo','')}

# REGRAS
- Prefira mídia REAL e específica (a pessoa, o lugar, o evento, a época). Só use algo genérico quando não houver como ser específico.
- "termos_busca" sempre em INGLÊS, curtos (2 a 5 palavras), do mais exato ao mais genérico.
- Se a cena cita uma pessoa real, coloque o nome dela em "pessoa_real" e no primeiro termo de busca.
- Mantenha coerência visual entre cenas vizinhas (mesma época, mesmo lugar).
- Se a cena mostrar o personagem recorrente do canal, descreva-o sempre do mesmo jeito no "prompt_ia".

# CENAS
{lista}

Responda SOMENTE com um JSON válido: uma lista com um objeto por cena, exatamente neste formato:
{json.dumps(CENAS_EXEMPLO, ensure_ascii=False, indent=2)}
"""


DESCRICAO_SCHEMA = {
    "titulos": ["5 opções de título (até 70 caracteres)"],
    "descricao": "descrição completa para o YouTube, com os 2 primeiros parágrafos fortes",
    "tags": ["15 a 25 tags"],
    "hashtags": ["#3", "#hashtags"],
    "capitulos": [{"tempo": "00:00", "titulo": "..."}],
    "thumb_textos": ["3 textos curtos (2 a 4 palavras) para a thumbnail"],
    "thumb_prompts": ["2 prompts em inglês para gerar a imagem da thumbnail"],
}


def descricao(channel, video, capitulos_auto=""):
    return f"""Você é especialista em SEO e CTR para YouTube em canais Dark.

{_contexto_canal(channel)}
# TÍTULO ATUAL
{video.get('titulo','')}

# MARCAÇÕES DE TEMPO APROXIMADAS (início de cada trecho)
{capitulos_auto}

# ROTEIRO
{video.get('roteiro','')}

{('# PRODUTO AFILIADO (coloque o link no início da descrição, de forma natural)' + chr(10) + video.get('briefing',{}).get('produto','')) if (video.get('briefing',{}).get('produto') or '').strip() else ''}
Escreva tudo em {_idioma(channel)}. Responda SOMENTE com um JSON válido neste formato:
{json.dumps(DESCRICAO_SCHEMA, ensure_ascii=False, indent=2)}
"""


TITULOS_SCHEMA = {"ideias": [{"titulo": "...", "gancho": "a curiosidade que prende", "porque": "por que deve funcionar"}]}


def titulos(channel, referencias, quantidade=20):
    refs = "\n".join(f"- {r.get('titulo','')} ({r.get('views', '?')} views, canal {r.get('canal','')})" for r in referencias)
    return f"""Você é estrategista de conteúdo para canais Dark no YouTube.

{_contexto_canal(channel)}
# VÍDEOS DE REFERÊNCIA QUE ESTÃO PERFORMANDO NO NICHO
{refs or '(nenhuma referência selecionada — use seu conhecimento do nicho)'}

# TAREFA
Crie {quantidade} ideias de vídeo NOVAS para este canal, modelando os padrões que funcionam nas referências (tema, curiosidade, estrutura do título), mas sem copiar.
Títulos em {_idioma(channel)}, até 70 caracteres, com curiosidade forte e promessa clara.

Responda SOMENTE com um JSON válido neste formato:
{json.dumps(TITULOS_SCHEMA, ensure_ascii=False, indent=2)}
"""


def parse_json(texto):
    """Extrai JSON de uma resposta de IA (aceita ```json ... ```, texto em volta, etc.)."""
    if texto is None:
        raise ValueError("Resposta vazia")
    t = texto.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", t, re.S)
    if m:
        t = m.group(1).strip()
    try:
        return json.loads(t)
    except Exception:
        pass
    starts = [i for i in (t.find("{"), t.find("[")) if i >= 0]
    if not starts:
        raise ValueError("Não encontrei JSON na resposta")
    s = min(starts)
    closer = "}" if t[s] == "{" else "]"
    e = t.rfind(closer)
    if e <= s:
        raise ValueError("JSON incompleto")
    frag = t[s : e + 1]
    frag = re.sub(r",\s*([}\]])", r"\1", frag)  # vírgula sobrando
    try:
        return json.loads(frag)
    except Exception:
        pass
    try:  # aspas dentro do texto sem barra (ex.: "a frase "real" dele") — o erro mais comum das IAs
        return json.loads(_consertar_aspas(frag))
    except Exception:
        pass
    if frag.startswith("["):  # salva os itens bons de uma lista com um item quebrado
        itens = []
        for pedaco in re.split(r"}\s*,\s*{", frag.strip()[1:-1].strip()):
            p_ = pedaco.strip()
            p_ = ("{" if not p_.startswith("{") else "") + p_ + ("}" if not p_.endswith("}") else "")
            for tentativa in (p_, _consertar_aspas(p_)):
                try:
                    itens.append(json.loads(tentativa))
                    break
                except Exception:
                    continue
        if itens:
            return itens
    return json.loads(frag)


def _consertar_aspas(t):
    """Escapa aspas que estão no meio de um texto (a aspa só fecha o texto se vier seguida de , : } ])."""
    out, dentro, i = [], False, 0
    while i < len(t):
        ch = t[i]
        if ch == "\\" and dentro:
            out.append(t[i:i + 2])
            i += 2
            continue
        if ch == '"':
            if not dentro:
                dentro = True
            else:
                resto = t[i + 1:].lstrip()
                if not resto or resto[0] in ",:}]":
                    dentro = False
                else:
                    out.append('\\"')
                    i += 1
                    continue
        elif ch == "\n" and dentro:
            out.append("\\n")
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


ESTILOS_VISUAIS = {
    "cinematic": ("Cinematic", "cinematic film still, dramatic lighting, shallow depth of field, anamorphic, rich color grading"),
    "documentario": ("Documentário realista", "photorealistic documentary photograph, natural light, true to life details"),
    "arquivo": ("Arquivo histórico", "archival historical photograph, period accurate, film grain"),
    "noir": ("Noir sombrio", "dark noir style, high contrast black and white, deep shadows, moody"),
    "pintura": ("Pintura a óleo", "classical oil painting, visible brush strokes, museum quality"),
    "ilustracao": ("Ilustração 2D", "detailed 2D digital illustration, clean lines, rich colors"),
    "anime": ("Anime", "anime style illustration, expressive lighting, detailed backgrounds"),
    "3d": ("Animação 3D", "stylized 3D animated film render, soft global illumination"),
    "aquarela": ("Aquarela", "watercolor painting, soft washes, paper texture"),
}

META_EXEMPLO = [{
    "n": 1, "personagem": "nome do personagem do canal que aparece, ou vazio",
    "prompt_imagem": "prompt em inglês para imagem 16:9",
    "prompt_video": "prompt em inglês para clipe de 8 segundos (Veo/Flow): sujeito, ação, câmera, luz, som ambiente",
    "fala": "só no modo personagem fala: a frase que o personagem diz no clipe",
}]


def meta_prompt(channel, video, tipo_cenas="imagens", estilo_txt="", personagem_fala=False):
    pers = (channel or {}).get("personagens") or []
    if not pers and (channel or {}).get("personagem"):
        pers = [{"nome": "Personagem", "descricao": channel["personagem"]}]
    pers_txt = "\n".join(f"- {p.get('nome')}: {p.get('descricao')}" for p in pers) or "(nenhum — não invente personagens fixos)"
    linhas = "\n".join(f"{c['n']}. [{c.get('fim',0)-c.get('inicio',0):.1f}s] {c['texto']}" for c in video.get("cenas", []))
    fala = """
# MODO PERSONAGEM FALA
Não existe narração separada: em cada cena o personagem diz o texto da cena dentro do clipe (voz do Flow/Veo).
Coloque em "fala" a frase da cena, curta (até ~20 palavras, cabe em 8 s), e no prompt_video descreva o personagem falando para a câmera, com a fala entre aspas e "speaks in Brazilian Portuguese" (ou o idioma do canal).""" if personagem_fala else ""
    return f"""Você é diretor de arte de um canal Dark no YouTube. Gere os prompts visuais de TODAS as cenas abaixo para gerar no Google Flow (Veo para vídeo, Nano Banana para imagem).

{_contexto_canal(channel)}
# VÍDEO
{video.get('titulo','')}

# FORMATO DAS CENAS
{"Vídeos: clipes de 8 segundos (Veo). Cada prompt_video descreve 1 ação contínua, movimento de câmera e som ambiente." if tipo_cenas == "videos" else "Imagens 16:9 (o editor anima com zoom/pan)."}

# ESTILO VISUAL (igual em todas as cenas)
{estilo_txt}

# PERSONAGENS DO CANAL (originais; descreva SEMPRE do mesmo jeito quando aparecerem)
{pers_txt}

# REGRAS
- Prompts em inglês, concretos e visuais (lugar, época, objetos, luz, enquadramento).
- Nunca desenhe rosto ou aparência de pessoa real (famosos, políticos, vítimas): use silhueta, de costas, mãos, multidão de longe.
- Sem texto, letreiro, logo ou marca d'água na imagem.
- Mantenha continuidade entre cenas vizinhas.
{fala}

# CENAS
{linhas}

Responda SOMENTE com JSON válido: uma lista com um objeto por cena neste formato:
{json.dumps(META_EXEMPLO, ensure_ascii=False, indent=2)}
"""
