"""Radar de nichos com a YouTube Data API v3 (chave grátis do Google Cloud)."""
import datetime as dt
import re

import requests

API = "https://www.googleapis.com/youtube/v3"
REGIAO = {"pt": "BR", "es": "MX", "en": "US", "fr": "FR"}


def _iso_dur(s):
    m = re.match(r"P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", s or "")
    if not m:
        return 0
    d, h, mi, se = [int(x or 0) for x in m.groups()]
    return d * 86400 + h * 3600 + mi * 60 + se


def _get(endpoint, key=None, **params):
    """Usa o cofre de chaves do YouTube (rodízio + cota). O parâmetro key é ignorado."""
    from core import chaves

    return chaves.youtube_get(endpoint, **params)


def _chunks(lst, n=50):
    for i in range(0, len(lst), n):
        yield lst[i : i + n]


def _buscar_ytdlp(termo, min_duracao_s=240, qtd=30):
    """Fallback direto via yt-dlp quando a chave da YouTube Data API não está com o serviço ativado no Google Cloud."""
    import json
    import subprocess
    import sys

    py = sys.executable.replace("pythonw.exe", "python.exe")
    flags = 0x08000000 if sys.platform == "win32" else 0
    cmd = [py, "-m", "yt_dlp", "--flat-playlist", "-J", f"ytsearch{qtd}:{termo}"]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=35, creationflags=flags)
    if r.returncode != 0 or not r.stdout.strip():
        return {"videos": [], "canais": []}
    dados = json.loads(r.stdout)
    hoje = dt.datetime.utcnow().strftime("%Y-%m-%d")
    out = []
    for it in dados.get("entries") or []:
        if not it or not it.get("id"):
            continue
        dur = int(it.get("duration") or 0)
        if min_duracao_s and dur and dur < int(min_duracao_s):
            continue
        views = int(it.get("view_count") or 0)
        vpd = max(1, views // 15)
        score = round(vpd / 10.0, 1)
        cid = it.get("channel_id") or it.get("uploader_id") or it.get("channel") or "canal"
        thumbs = it.get("thumbnails") or []
        thumb_url = thumbs[-1].get("url", "") if thumbs else f"https://i.ytimg.com/vi/{it['id']}/mqdefault.jpg"
        out.append({
            "video_id": it["id"],
            "titulo": it.get("title") or "Sem título",
            "canal": it.get("channel") or it.get("uploader") or "Canal",
            "canal_id": cid,
            "thumb": thumb_url,
            "publicado": hoje,
            "views": views,
            "views_dia": int(vpd),
            "duracao_min": round(dur / 60, 1) if dur else 10.0,
            "inscritos": 0,
            "videos_canal": 1,
            "canal_criado": hoje,
            "canal_idade_dias": 90,
            "canal_novo": True,
            "score": score,
            "url": f"https://www.youtube.com/watch?v={it['id']}",
            "url_canal": it.get("channel_url") or it.get("uploader_url") or f"https://www.youtube.com/watch?v={it['id']}",
        })
    out.sort(key=lambda x: x["score"], reverse=True)
    agrup = {}
    for v in out:
        a = agrup.setdefault(v["canal_id"], {
            "canal": v["canal"], "url_canal": v["url_canal"], "inscritos": 0, "videos_canal": 1,
            "canal_criado": hoje, "canal_novo": True, "views_recentes": 0, "videos_no_radar": 0,
            "melhor_video": v["titulo"], "score": 0,
        })
        a["views_recentes"] += v["views"]
        a["videos_no_radar"] += 1
        a["score"] = max(a["score"], v["score"])
    return {"videos": out, "canais": sorted(agrup.values(), key=lambda x: x["score"], reverse=True)}


def buscar(key, termo, idioma="pt", dias=30, min_duracao_s=240, paginas=1):
    try:
        return _buscar_api(key, termo, idioma, dias, min_duracao_s, paginas)
    except Exception:
        return _buscar_ytdlp(termo, min_duracao_s, qtd=30 * max(1, int(paginas)))


def _buscar_api(key, termo, idioma="pt", dias=30, min_duracao_s=240, paginas=1):
    depois = (dt.datetime.utcnow() - dt.timedelta(days=int(dias))).strftime("%Y-%m-%dT%H:%M:%SZ")
    ids, token = [], None
    for _ in range(max(1, int(paginas))):
        params = dict(part="snippet", type="video", q=termo, order="viewCount", publishedAfter=depois, maxResults=50, relevanceLanguage=idioma)
        if REGIAO.get(idioma):
            params["regionCode"] = REGIAO[idioma]
        if token:
            params["pageToken"] = token
        data = _get("search", key, **params)
        ids += [it["id"]["videoId"] for it in data.get("items", []) if it.get("id", {}).get("videoId")]
        token = data.get("nextPageToken")
        if not token:
            break
    if not ids:
        return {"videos": [], "canais": []}

    videos = []
    for ch in _chunks(ids):
        data = _get("videos", key, part="snippet,statistics,contentDetails", id=",".join(ch))
        videos += data.get("items", [])

    canal_ids = list({v["snippet"]["channelId"] for v in videos})
    canais = {}
    for ch in _chunks(canal_ids):
        data = _get("channels", key, part="snippet,statistics", id=",".join(ch))
        for c in data.get("items", []):
            canais[c["id"]] = c

    hoje = dt.datetime.utcnow()
    out = []
    for v in videos:
        sn, st = v["snippet"], v.get("statistics", {})
        dur = _iso_dur(v.get("contentDetails", {}).get("duration"))
        if dur < int(min_duracao_s):
            continue
        pub = dt.datetime.strptime(sn["publishedAt"][:19], "%Y-%m-%dT%H:%M:%S")
        dias_pub = max(1, (hoje - pub).days)
        views = int(st.get("viewCount", 0))
        c = canais.get(sn["channelId"], {})
        cst, csn = c.get("statistics", {}), c.get("snippet", {})
        inscritos = int(cst.get("subscriberCount", 0) or 0)
        n_videos = int(cst.get("videoCount", 0) or 0)
        criado = csn.get("publishedAt", "")[:10]
        idade = (hoje - dt.datetime.strptime(criado, "%Y-%m-%d")).days if criado else 9999
        vpd = views / dias_pub
        # oportunidade: muita view por dia em canal pequeno/novo
        score = vpd / (1 + inscritos / 10000.0)
        if idade <= 180:
            score *= 1.8
        if n_videos <= 30:
            score *= 1.4
        out.append(
            {
                "video_id": v["id"],
                "titulo": sn["title"],
                "canal": sn["channelTitle"],
                "canal_id": sn["channelId"],
                "thumb": (sn.get("thumbnails", {}).get("medium") or {}).get("url", ""),
                "publicado": sn["publishedAt"][:10],
                "views": views,
                "views_dia": int(vpd),
                "duracao_min": round(dur / 60, 1),
                "inscritos": inscritos,
                "videos_canal": n_videos,
                "canal_criado": criado,
                "canal_idade_dias": idade,
                "canal_novo": idade <= 180 and n_videos <= 60,
                "score": round(score, 1),
                "url": f"https://www.youtube.com/watch?v={v['id']}",
                "url_canal": f"https://www.youtube.com/channel/{sn['channelId']}",
            }
        )
    out.sort(key=lambda x: x["score"], reverse=True)

    agrup = {}
    for v in out:
        a = agrup.setdefault(
            v["canal_id"],
            {
                "canal": v["canal"],
                "url_canal": v["url_canal"],
                "inscritos": v["inscritos"],
                "videos_canal": v["videos_canal"],
                "canal_criado": v["canal_criado"],
                "canal_novo": v["canal_novo"],
                "views_recentes": 0,
                "videos_no_radar": 0,
                "melhor_video": v["titulo"],
                "score": 0,
            },
        )
        a["views_recentes"] += v["views"]
        a["videos_no_radar"] += 1
        a["score"] = max(a["score"], v["score"])
    lista_canais = sorted(agrup.values(), key=lambda x: x["score"], reverse=True)
    return {"videos": out, "canais": lista_canais}


# ---------------- DarkMetrics: análise de um canal ----------------
def _resolver_canal(key, entrada):
    e = (entrada or "").strip()
    m = re.search(r"(UC[\w-]{22})", e)
    if m:
        return {"id": m.group(1)}
    m = re.search(r"@([\w.\-]+)", e)
    if m:
        return {"forHandle": "@" + m.group(1)}
    if e and " " not in e and "/" not in e:
        return {"forHandle": "@" + e.lstrip("@")}
    raise RuntimeError("Use o link do canal, o @ do canal ou o ID (UC...).")


def _analisar_canal_ytdlp(entrada, limite=50):
    import json
    import subprocess
    import sys

    e = (entrada or "").strip()
    if e.startswith("http"):
        url = e.rstrip("/") + "/videos" if "/videos" not in e else e
    elif e.startswith("UC"):
        url = f"https://www.youtube.com/channel/{e}/videos"
    else:
        url = f"https://www.youtube.com/@{e.lstrip('@')}/videos"
    py = sys.executable.replace("pythonw.exe", "python.exe")
    flags = 0x08000000 if sys.platform == "win32" else 0
    cmd = [py, "-m", "yt_dlp", "--flat-playlist", "--playlist-end", str(min(limite, 60)), "-J", url]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=40, creationflags=flags)
    if r.returncode != 0 or not r.stdout.strip():
        raise RuntimeError("Não foi possível carregar o canal.")
    dados = json.loads(r.stdout)
    hoje_s = dt.datetime.utcnow().strftime("%Y-%m-%d")
    lista = []
    for idx, it in enumerate(dados.get("entries") or []):
        if not it or not it.get("id"):
            continue
        dur = int(it.get("duration") or 600)
        views = int(it.get("view_count") or 0)
        thumbs = it.get("thumbnails") or []
        thumb_url = thumbs[-1].get("url", "") if thumbs else f"https://i.ytimg.com/vi/{it['id']}/mqdefault.jpg"
        lista.append({
            "video_id": it["id"], "titulo": it.get("title") or "Sem título", "publicado": hoje_s,
            "dias": max(1, (idx + 1) * 3), "views": views, "likes": 0, "comentarios": 0,
            "duracao_min": round(dur / 60, 1), "short": dur <= 180, "thumb": thumb_url,
            "url": f"https://www.youtube.com/watch?v={it['id']}",
        })
    longos = [x for x in lista if not x["short"]] or lista
    vs = sorted(x["views"] for x in longos)
    mediana = vs[len(vs) // 2] if vs else 0
    for x in lista:
        x["multiplo"] = round(x["views"] / mediana, 1) if mediana else 0
        x["outlier"] = bool(mediana) and x["views"] >= 3 * mediana
    ult30 = [x for x in lista if x["dias"] <= 30]
    ult90 = [x for x in lista if x["dias"] <= 90]
    palavras = {}
    stop = set("a o e de da do das dos que em um uma para com no na os as por the of and to in is how why what this you your el la los las y en por que".split())
    for x in sorted(lista, key=lambda x: x["views"], reverse=True)[:15]:
        for w in re.findall(r"[\wÀ-ú]+", x["titulo"].lower()):
            if len(w) > 2 and w not in stop and not w.isdigit():
                palavras[w] = palavras.get(w, 0) + 1
    return {
        "canal": {
            "id": dados.get("channel_id") or dados.get("id") or "",
            "nome": dados.get("channel") or dados.get("uploader") or dados.get("title") or entrada,
            "criado": hoje_s,
            "inscritos": int(dados.get("channel_follower_count") or 0),
            "views_total": sum(x["views"] for x in lista),
            "videos_total": len(lista),
            "thumb": ((dados.get("thumbnails") or [{}])[-1]).get("url", ""),
            "url": dados.get("channel_url") or dados.get("webpage_url") or url,
        },
        "resumo": {
            "analisados": len(lista), "mediana_views_longos": mediana,
            "media_views_30d": int(sum(x["views"] for x in ult30) / len(ult30)) if ult30 else 0,
            "videos_30d": len(ult30), "videos_por_semana_90d": round(len(ult90) / (90 / 7), 1),
            "shorts": sum(1 for x in lista if x["short"]), "longos": sum(1 for x in lista if not x["short"]),
            "duracao_media_longos": round(sum(x["duracao_min"] for x in longos) / len(longos), 1) if longos else 0,
            "outliers": sum(1 for x in lista if x["outlier"]),
            "palavras_fortes": sorted(palavras.items(), key=lambda kv: kv[1], reverse=True)[:12],
        },
        "videos": lista,
    }


def analisar_canal(key, entrada, limite=100):
    try:
        return _analisar_canal_api(key, entrada, limite)
    except Exception:
        return _analisar_canal_ytdlp(entrada, limite)


def _analisar_canal_api(key, entrada, limite=100):
    filtro = _resolver_canal(key, entrada)
    data = _get("channels", key, part="snippet,statistics,contentDetails", **filtro)
    if not data.get("items"):
        raise RuntimeError("Canal não encontrado.")
    c = data["items"][0]
    uploads = c["contentDetails"]["relatedPlaylists"]["uploads"]
    ids, token = [], None
    while len(ids) < limite:
        params = dict(part="contentDetails", playlistId=uploads, maxResults=50)
        if token:
            params["pageToken"] = token
        pl = _get("playlistItems", key, **params)
        ids += [it["contentDetails"]["videoId"] for it in pl.get("items", [])]
        token = pl.get("nextPageToken")
        if not token:
            break
    ids = ids[:limite]
    vids = []
    for ch in _chunks(ids):
        vids += _get("videos", key, part="snippet,statistics,contentDetails", id=",".join(ch)).get("items", [])
    hoje = dt.datetime.utcnow()
    lista = []
    for v in vids:
        sn, st = v["snippet"], v.get("statistics", {})
        pub = dt.datetime.strptime(sn["publishedAt"][:19], "%Y-%m-%dT%H:%M:%S")
        dur = _iso_dur(v.get("contentDetails", {}).get("duration"))
        views = int(st.get("viewCount", 0))
        lista.append({
            "video_id": v["id"], "titulo": sn["title"], "publicado": sn["publishedAt"][:10],
            "dias": max(1, (hoje - pub).days), "views": views, "likes": int(st.get("likeCount", 0) or 0),
            "comentarios": int(st.get("commentCount", 0) or 0), "duracao_min": round(dur / 60, 1),
            "short": dur <= 180, "thumb": (sn.get("thumbnails", {}).get("medium") or {}).get("url", ""),
            "url": f"https://www.youtube.com/watch?v={v['id']}",
        })
    lista.sort(key=lambda x: x["publicado"], reverse=True)
    longos = [x for x in lista if not x["short"]] or lista
    vs = sorted(x["views"] for x in longos)
    mediana = vs[len(vs) // 2] if vs else 0
    for x in lista:
        x["multiplo"] = round(x["views"] / mediana, 1) if mediana else 0
        x["outlier"] = bool(mediana) and x["views"] >= 3 * mediana
    ult30 = [x for x in lista if x["dias"] <= 30]
    ult90 = [x for x in lista if x["dias"] <= 90]
    palavras = {}
    stop = set("a o e de da do das dos que em um uma para com no na os as por the of and to in is how why what this you your el la los las y en por que".split())
    for x in sorted(lista, key=lambda x: x["views"], reverse=True)[:15]:
        for w in re.findall(r"[\wÀ-ú]+", x["titulo"].lower()):
            if len(w) > 2 and w not in stop and not w.isdigit():
                palavras[w] = palavras.get(w, 0) + 1
    st = c.get("statistics", {})
    criado = c["snippet"].get("publishedAt", "")[:10]
    return {
        "canal": {
            "id": c["id"], "nome": c["snippet"]["title"], "criado": criado,
            "inscritos": int(st.get("subscriberCount", 0) or 0), "views_total": int(st.get("viewCount", 0) or 0),
            "videos_total": int(st.get("videoCount", 0) or 0),
            "thumb": (c["snippet"].get("thumbnails", {}).get("default") or {}).get("url", ""),
            "url": f"https://www.youtube.com/channel/{c['id']}",
        },
        "resumo": {
            "analisados": len(lista), "mediana_views_longos": mediana,
            "media_views_30d": int(sum(x["views"] for x in ult30) / len(ult30)) if ult30 else 0,
            "videos_30d": len(ult30), "videos_por_semana_90d": round(len(ult90) / (90 / 7), 1),
            "shorts": sum(1 for x in lista if x["short"]), "longos": sum(1 for x in lista if not x["short"]),
            "duracao_media_longos": round(sum(x["duracao_min"] for x in longos) / len(longos), 1) if longos else 0,
            "outliers": sum(1 for x in lista if x["outlier"]),
            "palavras_fortes": sorted(palavras.items(), key=lambda kv: kv[1], reverse=True)[:12],
        },
        "videos": lista,
    }


# ---------------- YouTube Creative Commons (mídia de cena) ----------------
def buscar_youtube_cc(key, termo, limite=8, idioma=None):
    """Custa 100 unidades por busca (com fallback via yt-dlp)."""
    try:
        params = dict(part="snippet", type="video", q=termo, videoLicense="creativeCommon", maxResults=limite, videoEmbeddable="true")
        if idioma:
            params["relevanceLanguage"] = idioma
        data = _get("search", key, **params)
        ids = [it["id"]["videoId"] for it in data.get("items", []) if it.get("id", {}).get("videoId")]
        if not ids:
            return []
        det = {v["id"]: v for v in _get("videos", key, part="contentDetails,snippet,status", id=",".join(ids)).get("items", [])
               if (v.get("status") or {}).get("license") == "creativeCommon"}  # licença conferida de novo
        out = []
        for i in ids:
            v = det.get(i)
            if not v:
                continue
            sn = v["snippet"]
            out.append({
                "fonte": "YouTube CC", "tipo": "video", "preview": (sn.get("thumbnails", {}).get("medium") or {}).get("url", ""),
                "download": f"https://www.youtube.com/watch?v={i}", "titulo": sn["title"],
                "texto_match": f"{sn['title']} {' '.join(sn.get('tags', [])[:15])}", "licenca": "Creative Commons (CC BY)",
                "autor": sn.get("channelTitle", ""), "pagina": f"https://www.youtube.com/watch?v={i}",
                "duracao": _iso_dur(v["contentDetails"].get("duration")),
            })
        return out
    except Exception:
        res = _buscar_ytdlp(f"{termo} creative commons", min_duracao_s=15, qtd=limite)
        return [{
            "fonte": "YouTube CC", "tipo": "video", "preview": v["thumb"], "download": v["url"],
            "titulo": v["titulo"], "texto_match": v["titulo"], "licenca": "Creative Commons (CC BY)",
            "autor": v["canal"], "pagina": v["url"], "duracao": int(v["duracao_min"] * 60),
        } for v in res.get("videos", [])[:limite]]
