"""Real Lab: busca inteligente de mídia por cena.

1. (Gemini) escolhe os termos de busca de cada cena que ainda não tem.
2. Busca em todas as fontes (Wikimedia, Pixabay, Pexels, Openverse, Met, Smithsonian, Europeana)
   + um "pool" do YouTube Creative Commons feito com poucos assuntos por vídeo (economiza cota).
3. (Gemini) confere se a mídia mostra o que a cena diz; reprovadas ficam registradas com o motivo.
4. Cenas sem mídia boa vão para IA (até o máximo %), gerada automaticamente se você quiser.
"""
import io
import os
import threading
import time
import urllib.parse

import requests

from core import gemini, media, prompts, radar, storage
from core.storage import Tx

UA = media.UA

LOOKS = {
    "pb_arquivo": ("Preto e branco de arquivo", "black and white archival photograph, film grain, soft contrast, historical press photo"),
    "vintage": ("Vintage desbotado", "faded vintage color photograph, 1970s film stock, warm tones, light grain"),
    "moderno_4k": ("Moderno e nítido (4K)", "modern sharp 4K photograph, natural colors, high detail, crisp focus"),
    "documental": ("Documental natural", "cinematic documentary photograph, natural light, muted colors, 35mm, high detail"),
    "noturno": ("Escuro e dramático", "dark moody cinematic photograph, low key lighting, deep shadows, dramatic atmosphere"),
}
SEGURANCA_IA = ("no recognizable face of any real person; people only as silhouettes, seen from behind, hands, or distant crowds; "
                "no text, no letters, no logos, no watermark")


def tem_gemini():
    db = storage.load()
    return bool(db.get("chaves", {}).get("gemini") or db["settings"].get("gemini_key"))


# ---------------- 1. termos automáticos ----------------
def termos_auto(vid, job=None):
    db = storage.load()
    v = storage.find(db["videos"], vid)
    ch = storage.find(db["channels"], v["channel_id"]) or {}
    faltam = [c for c in v["cenas"] if not c.get("termos_busca")]
    for i in range(0, len(faltam), 40):
        lote = faltam[i : i + 40]
        if job is not None:
            job["etapa"] = f"IA escolhendo termos de busca (cenas {lote[0]['n']}–{lote[-1]['n']})"
        vv = dict(v, cenas=lote)
        from core import claude

        res = claude.json_pref("pesquisa", prompts.cenas(ch, vv), vid)
        if isinstance(res, dict):
            res = res.get("cenas") or next((x for x in res.values() if isinstance(x, list)), [])
        por_n = {int(x.get("n", 0)): x for x in res if isinstance(x, dict)}
        with Tx() as db2:
            v2 = storage.find(db2["videos"], vid)
            v2["chamadas_ia"] = v2.get("chamadas_ia", 0) + 1
            for c in v2["cenas"]:
                x = por_n.get(c["n"])
                if x and not c.get("termos_busca"):
                    tb = x.get("termos_busca") or []
                    c["termos_busca"] = [tb] if isinstance(tb, str) else [str(t) for t in tb][:4]
                    for k in ("tipo", "pessoa_real", "descricao_visual", "prompt_ia"):
                        c[k] = x.get(k) or c.get(k, "")


# ---------------- 2. pool do YouTube ----------------
def assuntos_youtube(v, ch, n):
    cenas = v["cenas"]
    if tem_gemini():
        try:
            resumo = "\n".join(f"{c['n']}. {c['texto'][:160]}" for c in cenas[:: max(1, len(cenas) // 60)])
            j = gemini.gerar_json(f"""Escolha os {n} assuntos visuais principais deste vídeo para buscar vídeos Creative Commons no YouTube
(eventos, pessoas, lugares, objetos que aparecem muito). Para cada um dê uma busca curta em INGLÊS e outra em PORTUGUÊS.
Título: {v['titulo']}
Cenas:
{resumo}
Responda SOMENTE JSON: {{"assuntos": [{{"assunto": "...", "en": "...", "pt": "..."}}]}}""", v["id"])
            itens = j.get("assuntos", []) if isinstance(j, dict) else j
            return [x for x in itens if isinstance(x, dict)][:n]
        except Exception:
            pass
    vistos, out = set(), []
    for c in cenas[:: max(1, len(cenas) // (n * 2 or 1))]:
        t = (c.get("termos_busca") or [""])[0]
        if t and t.lower() not in vistos:
            vistos.add(t.lower())
            out.append({"assunto": t, "en": t, "pt": ""})
        if len(out) >= n:
            break
    return out


def pool_youtube(v, ch, settings, job=None):
    n = int(settings.get("youtube_assuntos", 8) or 0)
    if n <= 0:
        return [], []
    from core import chaves

    if not chaves.tem("youtube") and not settings.get("youtube_api_key"):
        return [], []
    pool, erros = [], []
    for a in assuntos_youtube(v, ch, n):
        for idioma, q in (("en", a.get("en")), ("pt", a.get("pt"))):
            if not q:
                continue
            if job is not None:
                job["etapa"] = f"YouTube CC: {q}"
            try:
                res = radar.buscar_youtube_cc(None, q, 8, idioma)
            except Exception as e:
                erros.append(f"YouTube: {str(e)[:120]}")
                if "cota" in str(e).lower() or "quota" in str(e).lower():
                    return pool, erros
                continue
            for x in res:
                x["assunto"] = a.get("assunto", q)
            pool += res
    vistos, uniq = set(), []
    for x in pool:
        if x["download"] not in vistos:
            vistos.add(x["download"])
            uniq.append(x)
    return uniq, erros


# ---------------- 3. conferência ----------------
def _bytes_preview(url):
    url = (url or "").replace("/480px-", "/500px-")  # Wikimedia só aceita tamanhos padrão de miniatura
    if url.startswith("local:"):
        with open(url[6:].split("#")[0], "rb") as f:
            dados = f.read()
    else:
        r = requests.get(url, headers={"User-Agent": UA}, timeout=25)
        if r.status_code in (400, 404) and media.wikimedia_original(url) != url:
            r = requests.get(media.wikimedia_original(url), headers={"User-Agent": UA}, timeout=60)
        r.raise_for_status()
        dados = r.content
    try:
        from PIL import Image

        im = Image.open(io.BytesIO(dados)).convert("RGB")
        im.thumbnail((640, 640))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=82)
        return buf.getvalue(), "image/jpeg"
    except Exception:
        return dados, "image/jpeg"


MOTIVOS = {
    "entidade_errada": "entidade errada", "pessoa_falando": "pessoa falando", "texto_gravado": "texto gravado",
    "baixa_qualidade": "baixa qualidade", "sem_relacao": "sem relação",
}


def conferir(cena, cand, vid, contexto_ok=False):
    dados, mime = _bytes_preview(cand.get("preview") or cand["download"])
    return gemini.conferir_midia(dados, mime, cena, vid, contexto_ok)


# ---------------- processamento de uma cena ----------------
_USO_LOCK = threading.RLock()


def processar_cena(cena, settings, pool, usados, anterior, vid, conferir_ia, chamadas):
    cands, erros = media.candidatos_cena(cena, settings)
    # mistura o pool do YouTube pontuado para esta cena
    termos = cena.get("termos_busca") or []
    chave_pt = " ".join(sorted(set(w for w in media._tokens(cena.get("texto", "")) if len(w) > 4), key=len, reverse=True)[:5])
    for x in pool:
        melhor = max([media.pontuar(t, f"{x.get('texto_match','')} {x.get('assunto','')}", i, cena.get("pessoa_real", ""))[0] for i, t in enumerate(termos[:6])] or [0])
        if x.get("noticia"):  # material das últimas horas: casa pelo texto da cena (em português) e ganha bônus
            melhor = max(melhor, media.pontuar(chave_pt, x.get("texto_match", ""), 1, "")[0] + 2.5) if chave_pt else melhor
        if melhor >= 4:
            y = dict(x)
            y["nota"] = melhor
            y["match"] = "exata" if melhor >= 8 else "parecida"
            cands.append(y)
    # fora logo de cara: tela verde/estúdio virtual, shorts e vídeos em pé (ficam amadores no documentário)
    cands = [c for c in cands if not media.TERMOS_RUINS.search(f"{c.get('titulo', '')} {c.get('texto_match', '')}")
             and not (c.get("tipo") == "video" and (c.get("altura") or 0) > (c.get("largura") or 0) * 1.05 and c.get("largura"))
             and not (c.get("tipo") == "video" and str(c.get("fonte", "")).startswith("YouTube") and 0 < (c.get("duracao") or 0) <= 65)]
    so_videos = settings.get("preferencia_midia") == "videos"
    if so_videos:
        # modo Vídeos: todos os vídeos aproveitáveis vêm antes de qualquer foto
        cands.sort(key=lambda c: (c["tipo"] == "video" and c["nota"] >= 3.5, c["nota"]), reverse=True)
    else:
        cands.sort(key=lambda c: c["nota"] + media.bonus_video(c, cena, settings), reverse=True)
    cena["candidatos"] = [{k: v for k, v in c.items() if k != "texto_match"} for c in cands[:30]]
    avisos = []
    modo = settings.get("modo_ia", "real_ia")
    corte = 8 if modo == "mais_ia" else 4
    max_conf = int(settings.get("conferencias_por_cena", 3) or 3)
    rapido = bool(settings.get("modo_rapido"))
    if so_videos:
        max_conf += 1 if rapido else 2  # tenta mais vídeos antes de cair para foto
    if rapido:
        max_conf = min(max_conf, 3)
    escolha = None

    lim_rep = [max(1, int(settings.get("max_repeticao", 1) or 1))]

    def elegivel(c):
        corte_c = 3.5 if (so_videos and c["tipo"] == "video") else corte
        if c["nota"] < corte_c:
            return False
        dl_u = c.get("download") or ""
        with _USO_LOCK:
            if dl_u in usados and usados[dl_u] >= lim_rep[0]:
                return False
            # Verifica também chave normalizada sem query string contra histórico de vídeos anteriores do canal
            dl_norm = dl_u.split("?")[0].split("#")[0].strip().lower()
            if dl_norm and dl_norm in usados and usados[dl_norm] >= lim_rep[0]:
                return False
        return dl_u != anterior

    fila = [c for c in cands if elegivel(c)]
    if fila and not conferir_ia:
        escolha = fila[0]
    elif (fila and rapido and fila[0]["nota"] >= 9 and fila[0].get("match") == "exata" and fila[0]["fonte"] == "Wikimedia Commons"
          and fila[0]["tipo"] == "foto" and cena.get("pessoa_real")):  # só foto exata da pessoa citada passa sem conferir
        escolha = dict(fila[0], conferida=False, aceita_direto=True)  # nota alta e termo exato: aceita sem conferir
    elif fila:
        tam = 4 if rapido else 6
        rodadas = 1 if rapido else 2
        if so_videos:  # cada lote: os melhores vídeos + a melhor foto (se nenhum vídeo servir, a foto salva a cena)
            vids = [c for c in fila if c["tipo"] == "video"]
            fotos = [c for c in fila if c["tipo"] != "video"]
            lotes = [vids[r * (tam - 1):(r + 1) * (tam - 1)] + fotos[r:r + 1] for r in range(rodadas)]
        else:
            lotes = [fila[r * tam:(r + 1) * tam] for r in range(rodadas)]
        for lote in lotes:
            if not lote:
                break
            from concurrent.futures import ThreadPoolExecutor

            def prev(c):
                try:
                    return c, _bytes_preview(c.get("preview") or c["download"])
                except Exception:
                    return c, None

            with ThreadPoolExecutor(max_workers=4) as ex:
                baixados = [(c, p) for c, p in ex.map(prev, lote) if p]
            if not baixados:
                continue
            try:
                d = gemini.conferir_lote(
                    [(p[0], p[1], f"{c['fonte']}: {c.get('titulo','')[:80]}", c["tipo"] == "video") for c, p in baixados],
                    cena,
                    vid,
                    modo_inteligencia="carbon_high",
                )
                chamadas[0] += 1
            except Exception as e:
                avisos.append(f"Conferência falhou: {str(e)[:120]}")
                if baixados[0][0]["nota"] >= 7:  # sem conferir, só aceita o que bateu muito bem pelas palavras
                    escolha = baixados[0][0]
                break
            por_i = {x["i"]: x for x in d["resultados"]}
            def aprovada(k):
                x = por_i.get(k) or {}
                try:
                    nota = float(x.get("nota") or 0)
                except (TypeError, ValueError):
                    nota = 0
                return bool(x.get("serve")) and nota >= 6

            servem = [(k, c) for k, (c, _) in enumerate(baixados, 1) if aprovada(k)]
            for k, (c, _) in enumerate(baixados, 1):
                x = por_i.get(k) or {}
                if x and not aprovada(k):
                    avisos.append(f"{c['fonte']} não entrou: {MOTIVOS.get(x.get('motivo'), x.get('motivo', 'não serve'))} — {x.get('na_imagem','')}".strip(" —"))
            if servem:
                k, c = next(((k, c) for k, c in servem if k == d["melhor"]), servem[0])
                x = por_i.get(k) or {}
                escolha = dict(
                    c,
                    na_imagem=x.get("na_imagem", ""),
                    nota=max(c["nota"], x.get("nota") or 0),
                    conferida=True,
                    modelo_verificacao=d.get("modelo_ia") or "gemini-4-carbon",
                )
                break
    cena["avisos"] = avisos
    if escolha:
        with _USO_LOCK:  # várias cenas ao mesmo tempo: confere de novo antes de reservar (ZERO repetição)
            dl_esc = escolha["download"]
            dl_esc_norm = dl_esc.split("?")[0].split("#")[0].strip().lower()
            if usados.get(dl_esc, 0) >= lim_rep[0] or (dl_esc_norm and usados.get(dl_esc_norm, 0) >= lim_rep[0]):
                escolha = next((dict(c, conferida=False) for c in fila if c is not escolha and c["download"] != dl_esc
                                and usados.get(c["download"], 0) == 0
                                and usados.get(c["download"].split("?")[0].split("#")[0].strip().lower(), 0) == 0
                                and c["nota"] >= 5), None)
            if escolha:
                dl_f = escolha["download"]
                dl_fn = dl_f.split("?")[0].split("#")[0].strip().lower()
                usados[dl_f] = usados.get(dl_f, 0) + 1
                if dl_fn:
                    usados[dl_fn] = usados.get(dl_fn, 0) + 1
    if escolha:
        cena["midia"] = dict(escolha, origem="auto")
        cena["status"] = "escolhida"
        return escolha["download"], erros
    cena["midia"] = None
    cena["status"] = "ia"
    return None, erros


def aplicar_limite_ia(cenas, settings):
    modo = settings.get("modo_ia", "real_ia")
    pct = float(settings.get("max_cenas_ia_pct", 30) or 0)
    if modo == "so_real":
        pct = 0
    elif modo == "mais_ia":
        pct = max(pct, 60)
    sem = [c for c in cenas if c.get("status") == "ia" and not c.get("forcar_ia")]
    limite = int(len(cenas) * pct / 100)
    if len(sem) > limite:
        sem.sort(key=lambda c: (c.get("candidatos") or [{"nota": -1}])[0]["nota"], reverse=True)
        for c in sem[: len(sem) - limite]:
            if c.get("candidatos"):
                c["midia"] = dict(c["candidatos"][0], origem="auto")
                c["status"] = "escolhida"
                c.setdefault("avisos", []).append("Entrou a melhor mídia genérica (limite de cenas por IA).")


# ---------------- 4. look e IA ----------------
def medir_look(vid, pasta):
    """Mede as fotos reais aprovadas (cor, saturação, nitidez) e escolhe o look das imagens de IA."""
    from PIL import Image, ImageFilter, ImageStat

    db = storage.load()
    v = storage.find(db["videos"], vid)
    fotos = [c for c in v["cenas"] if c.get("midia") and c["midia"].get("tipo") == "foto" and c["midia"].get("origem") != "ia"][:16]
    if not fotos:
        return "documental", 0
    sats, lums, nitidez, quente = [], [], [], []
    for c in fotos:
        m = c["midia"]
        try:
            if m.get("arquivo"):
                p = m["arquivo"] if os.path.isabs(m["arquivo"]) else os.path.join(pasta, m["arquivo"])
                im = Image.open(p)
            else:
                dados, _ = _bytes_preview(m.get("preview") or m["download"])
                im = Image.open(io.BytesIO(dados))
            im = im.convert("RGB")
            im.thumbnail((320, 320))
            hsv = im.convert("HSV")
            st = ImageStat.Stat(hsv)
            sats.append(st.mean[1] / 255)
            lums.append(st.mean[2] / 255)
            r, g, b = ImageStat.Stat(im).mean
            quente.append((r - b) / 255)
            nitidez.append(ImageStat.Stat(im.convert("L").filter(ImageFilter.FIND_EDGES)).stddev[0])
        except Exception:
            continue
    if not sats:
        return "documental", 0
    n = len(sats)
    s, l, q, nt = sum(sats) / n, sum(lums) / n, sum(quente) / n, sum(nitidez) / n
    if s < 0.08:
        look = "pb_arquivo"
    elif s < 0.25 and q > 0.05:
        look = "vintage"
    elif l < 0.3:
        look = "noturno"
    elif nt > 38 and s > 0.28:
        look = "moderno_4k"
    else:
        look = "documental"
    return look, n


def texto_look(settings, video):
    escolha = settings.get("ia_look_modo", "auto")
    if escolha == "auto":
        k = video.get("look_ia") or "documental"
        return LOOKS.get(k, LOOKS["documental"])[1]
    if escolha == "custom":
        return settings.get("ia_look", "")
    return LOOKS.get(escolha, LOOKS["documental"])[1]


def prompt_ia_cena(cena, settings, video, estilo=""):
    base = cena.get("prompt_ia") or cena.get("descricao_visual") or cena.get("texto", "")
    partes = [base]
    if estilo:
        partes.append(estilo)
    partes.append(texto_look(settings, video))
    partes.append(SEGURANCA_IA)
    return ", ".join(p.strip().rstrip(".") for p in partes if p and p.strip())


def gerar_ia_cena(cena, settings, video, pasta):
    motor = settings.get("ia_motor", "pollinations")
    W, H = [int(x) for x in settings.get("resolucao", "1920x1080").split("x")]
    prompt = prompt_ia_cena(cena, settings, video, (video.get("estilo_visual") or {}).get("prompt", ""))
    destino = os.path.join(pasta, "midia", f"cena_{cena['n']:03d}_ia")
    if motor == "gemini":
        dados, mime = gemini.gerar_imagem(prompt + f". Aspect ratio {'16:9' if W >= H else '9:16'}.", video["id"])
        ext = ".png" if "png" in mime else ".jpg"
    elif motor == "pollinations":
        url = "https://image.pollinations.ai/prompt/" + urllib.parse.quote(prompt[:900])
        ultimo = None
        for t in range(3):
            r = requests.get(url, params={"width": min(W, 1920), "height": min(H, 1920), "nologo": "true", "seed": cena["n"] * 7 + t, "model": "flux"},
                             headers={"User-Agent": UA}, timeout=180)
            if r.ok and r.headers.get("content-type", "").startswith("image"):
                dados, ext = r.content, ".jpg"
                break
            ultimo = f"{r.status_code} {r.text[:120]}"
            time.sleep(6 * (t + 1))
        else:
            raise RuntimeError(f"Pollinations não gerou: {ultimo}")
    else:
        raise RuntimeError("Geração automática desligada (motor manual: use os prompts no Flow e importe o lote).")
    path = destino + ext
    with open(path, "wb") as f:
        f.write(dados)
    return {"fonte": f"IA ({'Gemini' if motor == 'gemini' else 'Pollinations'})", "tipo": "foto", "arquivo": os.path.relpath(path, pasta),
            "titulo": prompt[:120], "origem": "ia", "nota": 7, "match": "ia", "prompt_usado": prompt}


# ---------------- job completo ----------------
def job_midia(vid, job, so_pendentes=False, so_ns=None):
    db = storage.load()
    s = dict(db["settings"], **(job.get("settings_extra") or {}))
    v = storage.find(db["videos"], vid)
    ch = storage.find(db["channels"], v["channel_id"]) or {}
    usar_ia = tem_gemini() and s.get("conferir_com_ia", True)
    chamadas = [0]
    job["erros"] = []
    if usar_ia and any(not c.get("termos_busca") for c in v["cenas"]):
        try:
            termos_auto(vid, job)
        except Exception as e:
            job["erros"].append(f"Termos automáticos: {str(e)[:150]}")
    pool = []
    pendentes = [c for c in v["cenas"] if c.get("status") not in ("escolhida", "manual") and not c.get("forcar_ia")]
    if so_pendentes and not pendentes:
        job["etapa"] = "Nenhuma cena pendente — nada para buscar"
        job["total"] = job["feito"] = 0
        return
    if so_ns or (so_pendentes and v.get("pool_youtube")):
        pool = v.get("pool_youtube") or []  # reaproveita: não gasta cota do YouTube de novo
    else:
        job["etapa"] = "Buscando vídeos Creative Commons no YouTube"
        pool, errs = pool_youtube(storage.find(storage.load()["videos"], vid), ch, s, job)
        job["erros"] += errs
        with Tx() as dbp:
            vp = storage.find(dbp["videos"], vid)
            vp["pool_youtube"] = [dict(x) for x in pool][:200]
    v = storage.find(storage.load()["videos"], vid)
    if v.get("pool_noticias"):  # Notícia de agora: fotos e vídeos das últimas horas entram na disputa
        pool = list(pool) + [dict(x) for x in v["pool_noticias"]]
    usados, anterior = {}, None
    # Carrega o histórico de fotos e vídeos já utilizados em TODOS os vídeos anteriores deste canal para evitar qualquer repetição entre vídeos!
    try:
        from core import darkplanner_sync as _dps_rl
        hist_c = _dps_rl.obter_historico_midias_canal(
            canal_id=str(v.get("channel_id") or ch.get("id") or ""),
            canal_nome=str(ch.get("nome") or ""),
            excluir_titulo=str(v.get("titulo") or ""),
        )
        for ch_hist in (hist_c.get("chaves_usadas") or set()):
            if ch_hist:
                usados[ch_hist] = 999
    except Exception:
        pass
    alvo = []
    for c in v["cenas"]:
        manual = c.get("midia") and c["midia"].get("origem") in ("manual", "ia")
        if so_ns is not None:
            sel = c["n"] in so_ns
        else:
            sel = not (so_pendentes and c.get("status") in ("escolhida", "manual")) and not manual and not c.get("forcar_ia")
        if not sel and c.get("midia"):
            chave = c["midia"].get("download") or c["midia"].get("arquivo")
            if chave:
                usados[chave] = usados.get(chave, 0) + 1
                chave_norm = str(chave).split("?")[0].split("#")[0].strip().lower()
                if chave_norm:
                    usados[chave_norm] = usados.get(chave_norm, 0) + 1
        if sel:
            alvo.append(c["n"])
    job["total"] = len(alvo)
    cenas_db = {x["n"]: x for x in storage.find(storage.load()["videos"], vid)["cenas"]}
    anteriores = {}  # n -> mídia da cena anterior (para não repetir a mesma em seguida)
    for k_, n_ in enumerate(alvo):
        ant = cenas_db.get(n_ - 1, {}).get("midia") if n_ - 1 not in alvo else None
        anteriores[n_] = (ant or {}).get("download")

    def uma_cena(n):
        cena = dict(cenas_db[n])
        cena.setdefault("canal_nome", ch.get("nome") or "")
        cena.setdefault("assunto_video", v.get("titulo") or "")
        midia_antiga = cena.get("midia")
        try:
            escolhido, errs = processar_cena(cena, s, pool, usados, anteriores.get(n), vid, usar_ia, chamadas)
            anteriores[n + 1] = escolhido
            if not cena.get("midia") and midia_antiga:  # não achou nada melhor: mantém o que já tinha
                cena["midia"], cena["status"] = midia_antiga, "escolhida"
            job["erros"] += errs[:1]
        except Exception as e:
            job["erros"].append(f"Cena {n}: {str(e)[:120]}")
            return
        try:
            with Tx() as db2:
                v2 = storage.find(db2["videos"], vid)
                for c2 in v2["cenas"]:
                    if c2["n"] == n:
                        for campo in ("candidatos", "midia", "status", "avisos"):
                            c2[campo] = cena.get(campo)
                        break
        except Exception as e:
            job["erros"].append(f"Cena {n}: não consegui salvar ({str(e)[:100]}) — clique em Buscar de novo")

    from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

    n_par = max(1, int(s.get("cenas_paralelo", 3) or 1))
    pendentes_f = set()
    feitos = [0]
    with ThreadPoolExecutor(max_workers=n_par) as ex:
        fila_n = list(alvo)
        try:
            while fila_n or pendentes_f:
                while fila_n and len(pendentes_f) < n_par:
                    if job.get("checar"):
                        job["checar"]()
                    n = fila_n.pop(0)
                    pendentes_f.add(ex.submit(uma_cena, n))
                    job["etapa"] = f"Cena {n}: buscando{' e conferindo (Gemini 4 Carbon High)' if usar_ia else ''}" + (f" ({n_par} ao mesmo tempo)" if n_par > 1 else "")
                prontos, pendentes_f = wait(pendentes_f, timeout=1, return_when=FIRST_COMPLETED)
                feitos[0] += len(prontos)
                job["feito"] = feitos[0]
        except BaseException:
            for f in pendentes_f:
                f.cancel()
            raise
    job["feito"] = job["total"]
    _limitar_repeticao(vid, s)
    _sem_repetir_vizinha(vid, s)
    with Tx() as db3:
        v3 = storage.find(db3["videos"], vid)
        aplicar_limite_ia(v3["cenas"], db3["settings"])
        v3["etapas"]["midia"] = True
        v3["chamadas_ia"] = v3.get("chamadas_ia", 0) + chamadas[0]
        cenas_finais_hist = list(v3.get("cenas") or [])
    try:
        from core import darkplanner_sync as _dps_reg
        _dps_reg.registrar_midias_usadas_no_canal(
            canal_id=str(v.get("channel_id") or ch.get("id") or ""),
            canal_nome=str(ch.get("nome") or ""),
            titulo_projeto=str(v.get("titulo") or vid),
            cenas_reais=cenas_finais_hist,
        )
    except Exception:
        pass
    # look medido nas fotos reais aprovadas
    try:
        look, n_fotos = medir_look(vid, storage.video_dir(vid))
        with Tx() as db4:
            v4 = storage.find(db4["videos"], vid)
            v4["look_ia"], v4["look_medido_em"] = look, n_fotos
    except Exception:
        pass
    if s.get("ia_auto", False) and s.get("ia_motor", "pollinations") != "manual" and not job.get("sem_ia_auto"):
        job_ia(vid, job)


def _limitar_repeticao(vid, settings):
    """Garante ZERO repetição da mesma mídia no vídeo todo (lim=1 por padrão; se passar, pega o próximo candidato inédito)."""
    lim = max(1, int(settings.get("max_repeticao", 1) or 1))
    with Tx() as db:
        v = storage.find(db["videos"], vid)
        uso = {}
        for c in v["cenas"]:
            d = (c.get("midia") or {}).get("download")
            if d:
                uso[d] = uso.get(d, 0) + 1
        visto = {}
        for c in v["cenas"]:  # apenas a 1ª aparição fica; qualquer repetição troca por candidato inédito
            m = c.get("midia") or {}
            d = m.get("download")
            if not d:
                continue
            visto[d] = visto.get(d, 0) + 1
            if visto[d] <= lim or m.get("origem") not in ("auto", None):
                continue
            prox = next((x for x in (c.get("candidatos") or []) if uso.get(x.get("download"), 0) == 0 and x.get("nota", 0) >= 4.5
                         and not media.TERMOS_RUINS.search(str(x.get("titulo", "")))), None)
            if prox:
                uso[d] -= 1
                uso[prox["download"]] = 1
                visto[prox["download"]] = 1
                c["midia"] = dict(prox, origem="auto")


def _sem_repetir_vizinha(vid, settings):
    """Com várias cenas ao mesmo tempo, duas vizinhas podem pegar a mesma mídia: troca a segunda."""
    with Tx() as db:
        v = storage.find(db["videos"], vid)
        cs = v["cenas"]
        usados = {}
        for c in cs:
            d = (c.get("midia") or {}).get("download")
            if d:
                usados[d] = usados.get(d, 0) + 1
        for i in range(1, len(cs)):
            a, b = cs[i - 1].get("midia") or {}, cs[i].get("midia") or {}
            if not a.get("download") or a.get("download") != b.get("download") or b.get("origem") not in ("auto", None):
                continue
            prox = next((x for x in (cs[i].get("candidatos") or []) if x.get("download") != a.get("download")
                         and usados.get(x.get("download"), 0) == 0 and x.get("nota", 0) >= 3.5), None)
            if prox:
                usados[b["download"]] -= 1
                usados[prox["download"]] = 1
                cs[i]["midia"] = dict(prox, origem="auto")


def job_ia(vid, job, so_ns=None):
    db = storage.load()
    s = dict(db["settings"], **(job.get("settings_extra") or {}))
    v = storage.find(db["videos"], vid)
    pasta = storage.video_dir(vid)
    alvo = [c for c in v["cenas"] if (c["n"] in so_ns if so_ns else (c.get("status") == "ia" and not c.get("midia")))]
    job["total"], job["feito"] = len(alvo), 0
    for i, c in enumerate(alvo):
        if job.get("checar"):
            job["checar"]()
        job["feito"] = i
        job["etapa"] = f"Gerando imagem por IA — cena {c['n']}"
        try:
            m = gerar_ia_cena(c, s, v, pasta)
        except Exception as e:
            job.setdefault("erros", []).append(f"IA cena {c['n']}: {str(e)[:150]}")
            if "desligada" in str(e):
                break
            continue
        with Tx() as db2:
            v2 = storage.find(db2["videos"], vid)
            c2 = next(x for x in v2["cenas"] if x["n"] == c["n"])
            c2["midia"], c2["status"] = m, "escolhida"
    job["feito"] = job["total"]
