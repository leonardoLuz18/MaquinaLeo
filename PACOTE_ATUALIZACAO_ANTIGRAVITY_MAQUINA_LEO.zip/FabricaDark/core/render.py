"""Montagem do MP4 com FFmpeg: cada cena vira um trecho (foto com zoom suave ou vídeo), junta tudo, põe narração, música e legenda."""
import os
import re
import shutil
import subprocess
import time
import threading

JOBS = {}
CHECAR = {}  # vid -> função chamada entre cenas (Estúdio: pausar/parar)


def ffmpeg_bin():
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    p = shutil.which("ffmpeg")
    if p:
        return p
    raise RuntimeError("FFmpeg não encontrado. Rode o iniciar.bat de novo para instalar.")


FFMPEG_LIMITE = 20 * 60  # segundos; juntar o vídeo todo leva bem menos que isso
EXT_IMAGEM = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")


def _run(args, cwd=None):
    flags = 0
    if os.name == "nt":
        flags = 0x08000000  # CREATE_NO_WINDOW
    try:
        # limite de tempo: um FFmpeg travado não pode segurar a geração para sempre (a cena usa a mídia da vizinha)
        p = subprocess.run(args, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=flags,
                           timeout=FFMPEG_LIMITE)
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"FFmpeg travou (passou de {FFMPEG_LIMITE // 60} min) e foi interrompido")
    if p.returncode != 0:
        linhas = [x for x in (p.stderr or "").splitlines() if x.strip() and not x.startswith(("  lib", "  configuration", "  built with", "ffmpeg version", "  Metadata", "    "))]
        raise RuntimeError("FFmpeg: " + " | ".join(linhas[-4:])[-600:])
    return p


def duracao_midia(path):
    flags = 0x08000000 if os.name == "nt" else 0
    p = subprocess.run([ffmpeg_bin(), "-i", path], capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=flags)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", p.stderr)
    if not m:
        return None
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


FILTROS = {
    "nenhum": "",
    "pb": "hue=s=0",
    "sepia": "colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131",
    "quente": "colorbalance=rs=.08:gs=.02:bs=-.08",
    "frio": "colorbalance=rs=-.06:bs=.08",
    "contraste": "eq=contrast=1.25:saturation=1.1",
    "dramatico": "eq=contrast=1.2:saturation=0.75:brightness=-0.03",
    "horror": "eq=contrast=1.22:saturation=0.45:brightness=-0.05,colorbalance=rs=-.05:gs=-.01:bs=.07",
    "natural": "eq=contrast=1.05:saturation=1.18",
}


def _pos(settings, ed, cena, dur):
    f = []
    filtro = cena.get("filtro") or ed.get("filtro") or "nenhum"
    if FILTROS.get(filtro):
        f.append(FILTROS[filtro])
    if settings.get("grao", True):
        f += ["eq=contrast=1.06:saturation=0.92", "noise=alls=6:allf=t", "vignette=PI/5"]
    tr = ed.get("transicao", "corte")
    d = min(0.35, dur / 4)
    if tr == "fade":
        f += [f"fade=t=in:st=0:d={d:.2f}", f"fade=t=out:st={max(0, dur - d):.2f}:d={d:.2f}"]
    elif tr == "flash":
        f.append(f"fade=t=in:st=0:d={d:.2f}:color=white")
    return ",".join(f)


_OK_CACHE = {}


def midia_ok(arq, tipo=None):
    """A mídia existe, abre e tem imagem de verdade (não é um arquivo vazio, minúsculo ou uma tela lisa)?"""
    if not arq or not os.path.exists(arq):
        return False
    try:
        chave = (arq, os.path.getmtime(arq), os.path.getsize(arq))
    except OSError:
        return False
    if chave in _OK_CACHE:
        return _OK_CACHE[chave]
    ok = False
    try:
        ext = os.path.splitext(arq)[1].lower()
        if tipo == "video" or ext in (".mp4", ".webm", ".mov", ".mkv", ".m4v", ".avi"):
            from core import media

            ok = os.path.getsize(arq) > 50000 and media.video_ok(arq)
        else:
            from PIL import Image, ImageStat

            with Image.open(arq) as im:
                w, h = im.size
                st = ImageStat.Stat(im.convert("L").resize((64, 64)))
                ok = w >= 320 and h >= 240 and st.stddev[0] > 6
    except Exception:
        ok = False
    _OK_CACHE[chave] = ok
    return ok


def dims(path):
    flags = 0x08000000 if os.name == "nt" else 0
    p = subprocess.run([ffmpeg_bin(), "-i", path], capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=flags)
    m = re.search(r"Video:.*?(\d{2,5})x(\d{2,5})", p.stderr)
    return (int(m.group(1)), int(m.group(2))) if m else None


MOVIMENTOS = {"zoom_in": 0, "zoom_out": 1, "pan_dir": 2, "pan_esq": 3}


def _zoom_expr(i, frames, W, H, movimento="auto"):
    # 4 movimentos alternados para não ficar repetitivo (ou o escolhido no editor)
    mov = MOVIMENTOS.get(movimento, i % 4)
    z_in = f"min(1+0.12*on/{frames},1.12)"
    z_out = f"max(1.12-0.12*on/{frames},1.0)"
    centro_x = "iw/2-(iw/zoom/2)"
    centro_y = "ih/2-(ih/zoom/2)"
    if mov == 0:
        return f"zoompan=z='{z_in}':x='{centro_x}':y='{centro_y}'"
    if mov == 1:
        return f"zoompan=z='{z_out}':x='{centro_x}':y='{centro_y}'"
    if mov == 2:
        return f"zoompan=z='1.1':x='(iw-iw/zoom)*on/{frames}':y='{centro_y}'"
    return f"zoompan=z='1.1':x='(iw-iw/zoom)*(1-on/{frames})':y='{centro_y}'"


def _base(i, cena, dur, out_path, W, H, fps, settings, pos, tmp):
    from core import templates

    ff = ffmpeg_bin()
    frames = max(1, int(round(dur * fps)))
    enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-an"]
    extra = ("," + pos) if pos else ""
    midia = (cena.get("midia") or {}).get("arquivo")
    if midia and os.path.exists(midia):
        tipo = (cena.get("midia") or {}).get("tipo", "foto")
        if os.path.splitext(midia)[1].lower() in EXT_IMAGEM:
            tipo = "foto"  # vídeo que não baixou e virou a miniatura .jpg: tratar como vídeo travava o FFmpeg para sempre
        if tipo == "video":
            dm = dims(midia)
            if dm and dm[0] / max(1, dm[1]) < (W / H) * 0.8:
                fc = (f"[0:v]fps={fps},split[a][b];[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=20:2,eq=brightness=-0.12[bg];"
                      f"[b]scale={W}:{H}:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1{extra}[v]")
                _run([ff, "-y", "-stream_loop", "-1", "-i", midia, "-t", f"{dur:.3f}", "-filter_complex", fc, "-map", "[v]", "-r", str(fps), *enc, out_path])
            else:
                vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={fps},setsar=1{extra}"
                _run([ff, "-y", "-stream_loop", "-1", "-i", midia, "-t", f"{dur:.3f}", "-vf", vf, "-r", str(fps), *enc, out_path])
            return
        ar = templates.proporcao(midia)
        if ar and ar < (W / H) * 0.8:
            midia = templates.foto_em_pe(midia, W, H, os.path.join(tmp, f"pe_{i}.jpg"))
        movimento = cena.get("movimento") or "auto"
        if settings.get("zoom_suave", True) and movimento != "parado":
            W2, H2 = int(W * 1.5) // 2 * 2, int(H * 1.5) // 2 * 2
            vf = (
                f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},scale={W2}:{H2},"
                f"{_zoom_expr(i, frames, W, H, movimento)}:d={frames}:s={W}x{H}:fps={fps},setsar=1{extra}"
            )
            _run([ff, "-y", "-i", midia, "-vf", vf, "-frames:v", str(frames), *enc, out_path])
        else:
            vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1{extra}"
            _run([ff, "-y", "-loop", "1", "-i", midia, "-t", f"{dur:.3f}", "-r", str(fps), "-vf", vf, *enc, out_path])
        return
    # cena sem mídia: fundo escuro (para você trocar depois)
    _run([ff, "-y", "-f", "lavfi", "-i", f"color=c=0x101418:s={W}x{H}:r={fps}", "-t", f"{dur:.3f}", "-vf", "setsar=1" + extra, *enc, out_path])


def render_trecho(i, cena, dur, out_path, settings, ed=None, video=None):
    from core import templates

    ed = ed or {}
    ff = ffmpeg_bin()
    W, H = [int(x) for x in settings.get("resolucao", "1920x1080").split("x")]
    fps = int(settings.get("fps", 30))
    enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-an"]
    tmp = os.path.join(os.path.dirname(out_path), "_tmp")
    os.makedirs(tmp, exist_ok=True)
    tpl = ed.get("template", "nenhum")
    pos = _pos(settings, ed, cena, dur)
    if tpl == "documentario":
        x, y, w, h = templates.caixa_doc(W, H)
        inner = os.path.join(tmp, f"in_{i}.mp4")
        _base(i, cena, dur, inner, w, h, fps, settings, "", tmp)
        nome = cena.get("nome_tela") if cena.get("nome_tela") is not None else (cena.get("pessoa_real", "") if ed.get("doc_nome_auto", True) else "")
        bg = templates.doc_fundo(W, H, cena.get("titulo_tela") or ed.get("titulo_doc", ""), nome, os.path.join(tmp, f"bg_{i}.png"))
        fc = f"[0:v][1:v]overlay={x}:{y}:shortest=1,setsar=1" + ("," + pos if pos else "") + "[v]"
        _run([ff, "-y", "-loop", "1", "-framerate", str(fps), "-i", bg, "-i", inner, "-filter_complex", fc, "-map", "[v]",
              "-t", f"{dur:.3f}", "-r", str(fps), *enc, out_path])
    elif tpl == "telejornal":
        base = os.path.join(tmp, f"base_{i}.mp4")
        _base(i, cena, dur, base, W, H, fps, settings, pos, tmp)
        manchete = cena.get("titulo_tela") or ed.get("manchete") or (video or {}).get("titulo", "")
        ov = templates.telejornal_overlay(W, H, manchete, cena.get("nome_tela") or ed.get("rotulo", "URGENTE"), os.path.join(tmp, f"ov_{i}.png"))
        _run([ff, "-y", "-i", base, "-loop", "1", "-i", ov, "-filter_complex", "[0:v][1:v]overlay=0:0:shortest=1,format=yuv420p[v]",
              "-map", "[v]", *enc, out_path])
    else:
        _base(i, cena, dur, out_path, W, H, fps, settings, pos, tmp)
    # montagem animada da cena (cartões, data, local, citação, colagem…)
    estilo = ed.get("estilo_edicao") or "padrao"
    if ed.get("montagens", True) is False:
        return
    if (cena.get("layout") or "midia") != "midia" or estilo == "true_crime" or (cena.get("midia") or {}).get("fonte") == "YouTube (notícia)":
        from core import layouts

        try:
            layouts.aplicar(i, cena, dur, out_path, W, H, fps, estilo, tmp, ff, _run, (video or {}).get("idioma", "pt"))
        except Exception as e:  # a montagem é enfeite: se falhar, fica a cena simples
            print("layout falhou na cena", i + 1, e)


def previa_cena(i, cena, settings, out_path, ed=None, video=None):
    s = dict(settings)
    W, H = [int(x) for x in s.get("resolucao", "1920x1080").split("x")]
    s["resolucao"] = f"{W // 3 // 2 * 2}x{H // 3 // 2 * 2}"
    s["fps"] = 24
    dur = max(0.5, min(12, cena["fim"] - cena["inicio"]))
    render_trecho(i, cena, dur, out_path, s, ed, video)
    return out_path


def _job(video_id, msg=None, pct=None, **kw):
    j = JOBS.setdefault(video_id, {"log": []})
    if msg:
        j["etapa"] = msg
        j["log"].append(msg)
    if pct is not None:
        j["pct"] = pct
    j.update(kw)


def renderizar(video, settings, pasta):
    vid = video["id"]
    JOBS[vid] = {"log": [], "pct": 0, "rodando": True, "erro": "", "saida": ""}
    try:
        ff = ffmpeg_bin()
        cenas = video["cenas"]
        if not cenas:
            raise RuntimeError("O vídeo não tem cenas.")
        trechos_dir = os.path.join(pasta, "trechos")
        os.makedirs(trechos_dir, exist_ok=True)
        lista = []
        # nenhuma cena fica preta: mídia que falta, vazia ou quebrada vira a da cena válida mais próxima
        validas = [midia_ok((c.get("midia") or {}).get("arquivo"), (c.get("midia") or {}).get("tipo")) for c in cenas]
        if not any(validas):
            raise RuntimeError("Nenhuma cena tem mídia válida para montar.")
        cenas = list(cenas)
        for i, ok in enumerate(validas):
            if not ok:
                j = min((k for k, v in enumerate(validas) if v), key=lambda k: (abs(k - i), k < i))
                cenas[i] = dict(cenas[i], midia=dict(cenas[j]["midia"]), layout="midia" if cenas[i].get("layout") in ("pessoa", "duas_pessoas", "colagem") else cenas[i].get("layout"))
                _job(vid, f"Cena {i+1}: mídia vazia ou quebrada — usei a da cena {j+1}")
        import hashlib
        import json as _json

        ed_cache = {k: (video.get("editor") or {}).get(k) for k in ("template", "filtro", "transicao", "titulo_doc", "manchete", "rotulo", "doc_nome_auto", "estilo_edicao")}
        cfg_cache = {k: settings.get(k) for k in ("resolucao", "fps", "grao", "zoom_suave")}
        reaproveitados = 0
        for i, c in enumerate(cenas):
            if CHECAR.get(vid):
                CHECAR[vid]()
            dur = max(0.5, c["fim"] - c["inicio"])
            out = os.path.join(trechos_dir, f"t{i+1:04d}.mp4")
            arq = (c.get("midia") or {}).get("arquivo") or ""
            chave = hashlib.md5(_json.dumps([arq, os.path.getmtime(arq) if arq and os.path.exists(arq) else 0, round(dur, 3), i % 4,
                                             c.get("movimento"), c.get("filtro"), c.get("titulo_tela"), c.get("nome_tela"), c.get("pessoa_real"),
                                             (c.get("midia") or {}).get("tipo"), ed_cache, cfg_cache, video.get("titulo"),
                                             c.get("layout"), c.get("layout_texto"), c.get("layout_fonte"), c.get("pessoas"), c.get("layout_imgs"),
                                             c.get("layout_destaque"), c.get("layout_mapa"), c.get("capitulo_num"), "lay3"] + (["neutro"] if c.get("fundo_neutro") else []), sort_keys=True, default=str).encode()).hexdigest()
            marca = out + ".key"
            if os.path.exists(out) and os.path.exists(marca) and open(marca).read() == chave:
                reaproveitados += 1
                lista.append(out)
                continue
            _job(vid, f"Cena {i+1}/{len(cenas)}", pct=int(i / len(cenas) * 85))
            try:
                render_trecho(i, c, dur, out, settings, video.get("editor") or {}, video)
            except Exception as e:
                if CHECAR.get(vid) and "Parado" in type(e).__name__:
                    raise
                # mídia desta cena quebrada: usa a da cena vizinha mais próxima para o vídeo não parar
                ok = False
                for j in sorted(range(len(cenas)), key=lambda j: abs(j - i)):
                    if j == i:
                        continue
                    m = cenas[j].get("midia") or {}
                    if not (m.get("arquivo") and os.path.exists(m["arquivo"])):
                        continue
                    try:
                        render_trecho(i, dict(c, midia=m), dur, out, settings, video.get("editor") or {}, video)
                        _job(vid, f"Cena {i+1}: arquivo com problema — usei a mídia da cena {j+1}")
                        JOBS[vid].setdefault("trocadas", []).append(i + 1)
                        ok = True
                        break
                    except Exception:
                        continue
                if not ok:
                    raise RuntimeError(f"Cena {i+1}: não consegui montar ({str(e)[-200:]})")
            with open(marca, "w") as fm:
                fm.write(chave)
            lista.append(out)
        if reaproveitados:
            _job(vid, f"{reaproveitados} cena(s) reaproveitadas (sem mudança)")
        if (video.get("editor") or {}).get("audio_dos_clipes"):
            _job(vid, "Áudio dos clipes (personagem fala)", pct=86)
            falas = _audio_dos_clipes(video, pasta, ff)
            if falas and not (video.get("narracao") and os.path.exists(video.get("narracao"))):
                video = dict(video, narracao=falas)
        from core import templates

        ed = video.get("editor") or {}
        W, H = [int(x) for x in settings.get("resolucao", "1920x1080").split("x")]
        fps = int(settings.get("fps", 30))
        # textos de impacto e CTA (tempo global)
        sobre = []
        for k, cta in enumerate(ed.get("ctas") or []):
            padrao_cta = {"en": "SUBSCRIBE", "es": "SUSCRÍBETE", "fr": "ABONNEZ-VOUS"}.get(video.get("idioma"), "INSCREVA-SE")
            png = templates.cta_png(W, H, cta.get("texto") or padrao_cta, os.path.join(pasta, f"cta_{k}.png"))
            sobre.append((png, float(cta.get("inicio", 0)), float(cta.get("duracao", 5))))
        impactos = set()
        for k, tx in enumerate(ed.get("textos") or []):
            png = templates.texto_impacto_png(W, H, tx.get("texto", ""), os.path.join(pasta, f"impacto_{k}.png"))
            sobre.append((png, float(tx.get("inicio", 0)), float(tx.get("duracao", 3))))
            impactos.add(png)
        # legenda: vira imagem (sem depender da biblioteca de legendas do FFmpeg, que trava em alguns Windows)
        leg_cfg = ed.get("legenda") or {}
        margem_tpl = {"documentario": 6, "telejornal": 62}.get(ed.get("template"), 40)
        srt_path = os.path.join(pasta, "legendas.srt")
        legenda_on = settings.get("legenda_queimada", True) and leg_cfg.get("ativa", True) and os.path.exists(srt_path)
        entradas = _ler_srt(srt_path) if legenda_on else []
        estilo_leg = {k: leg_cfg.get(k) for k in ("tamanho", "cor", "posicao", "caixa", "margem", "estilo")} | {"margem_tpl": margem_tpl}
        try:
            from core import layouts as _lay

            estilo_leg["acc"] = list(_lay.tema(ed.get("estilo_edicao"))["acc"])  # cor de destaque do perfil (neon, karaokê)
        except Exception:
            pass

        finais = []
        base = 0.0
        refeitos = 0
        for i, c in enumerate(cenas):
            if CHECAR.get(vid):
                CHECAR[vid]()
            dur = max(0.5, c["fim"] - c["inicio"])
            t_ini, t_fim = base, base + dur
            base = t_fim
            trecho = lista[i]
            subs = [(max(0.0, a - t_ini), min(dur, b - t_ini), t) for a, b, t in entradas if b > t_ini and a < t_fim and min(dur, b - t_ini) - max(0.0, a - t_ini) > 0.05]
            efeito = (c.get("layout") or "midia") not in ("midia", "local", "ano", "pessoa", "duas_pessoas")
            ovs = [(png, max(0.0, a - t_ini), min(dur, a + d - t_ini)) for png, a, d in sobre if a + d > t_ini and a < t_fim
                   and not (efeito and png in impactos)]  # texto de impacto não cobre os efeitos (número, frase, quadro…)
            borda = "in" if i == 0 else "out" if i == len(cenas) - 1 else ""  # entrada e saída suaves do vídeo
            if not subs and not ovs and not borda:
                finais.append(trecho)
                continue
            out = os.path.join(trechos_dir, f"f{i+1:04d}.mp4")
            chave_base = open(trecho + ".key").read() if os.path.exists(trecho + ".key") else str(os.path.getmtime(trecho))
            chave = hashlib.md5(_json.dumps([chave_base, subs, [(os.path.basename(p), hashlib.md5(open(p, "rb").read()).hexdigest(), a, b) for p, a, b in ovs], estilo_leg, W, H, borda],
                                            default=str).encode()).hexdigest()
            if os.path.exists(out) and os.path.exists(out + ".key") and open(out + ".key").read() == chave:
                finais.append(out)
                continue
            _job(vid, f"Legenda e textos: cena {i+1}/{len(cenas)}", pct=87 + int(i / len(cenas) * 10))
            imgs = []
            for k, (a, b, t) in enumerate(subs):
                if estilo_leg.get("estilo") == "karaoke":  # uma imagem por palavra falada (a palavra da vez acende)
                    for j, pa, pb in templates.palavras_tempo(t, a, b):
                        imgs.append((templates.legenda_png(W, H, t, estilo_leg, os.path.join(trechos_dir, "_tmp", f"leg_{i+1}_{k}_{j}.png"), ativa=j), pa, pb))
                    continue
                imgs.append((templates.legenda_png(W, H, t, estilo_leg, os.path.join(trechos_dir, "_tmp", f"leg_{i+1}_{k}.png")), a, b))
            imgs += ovs
            args = [ff, "-y", "-i", trecho]
            cadeia, atual = [], "0:v"
            for n, (png, a, b) in enumerate(imgs):
                args += ["-loop", "1", "-framerate", str(fps), "-t", f"{dur:.3f}", "-i", png]
                cadeia.append(f"[{atual}][{n+1}:v]overlay=0:0:enable='between(t,{a:.3f},{b:.3f})'[o{n}]")
                atual = f"o{n}"
            if borda == "in":
                cadeia.append(f"[{atual}]fade=t=in:st=0:d={min(0.8, dur / 3):.2f}[fz]")
                atual = "fz"
            elif borda == "out":
                d_ = min(1.4, dur / 2)
                cadeia.append(f"[{atual}]fade=t=out:st={max(0, dur - d_):.2f}:d={d_:.2f}[fz]")
                atual = "fz"
            args += ["-filter_complex", ";".join(cadeia), "-map", f"[{atual}]", "-t", f"{dur:.3f}", "-r", str(fps),
                     "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-an", out]
            _run(args)
            with open(out + ".key", "w") as fk:
                fk.write(chave)
            refeitos += 1
            finais.append(out)

        with open(os.path.join(pasta, "lista.txt"), "w", encoding="utf-8") as f:
            for p in finais:
                f.write(f"file 'trechos/{os.path.basename(p)}'\n")
        _job(vid, "Juntando cenas", pct=97)
        _run([ff, "-y", "-f", "concat", "-safe", "0", "-i", "lista.txt", "-c", "copy", "video_mudo.mp4"], cwd=pasta)

        _job(vid, "Narração e música", pct=98)
        args = [ff, "-y", "-i", "video_mudo.mp4"]
        narr, mus = video.get("narracao"), video.get("musica")
        tem_narr = bool(narr and os.path.exists(narr))
        tem_mus = bool(mus and os.path.exists(mus))
        idx, fc, amap = 1, [], None
        if tem_narr:
            args += ["-i", narr]
            i_narr, idx = idx, idx + 1
        if tem_mus:
            args += ["-stream_loop", "-1", "-i", mus]
            i_mus, idx = idx, idx + 1
        if tem_narr and tem_mus:
            vol = float(video.get("musica_volume", 0.12))
            fc.append(f"[{i_mus}:a]volume={vol}[m];[{i_narr}:a][m]amix=inputs=2:duration=first:dropout_transition=0[a]")
            amap = "[a]"
        elif tem_narr:
            amap = f"{i_narr}:a"
        elif tem_mus:
            amap = f"{i_mus}:a"
        if amap:  # som entra e sai suave (sem corte seco no fim)
            fim_a = max(0.0, base - 1.4)
            fonte_a = amap if amap.startswith("[") else f"[{amap}]"
            fc.append(f"{fonte_a}afade=t=in:st=0:d=0.3,afade=t=out:st={fim_a:.2f}:d=1.4[afim]")
            amap = "[afim]"
        # efeitos sonoros ligados ao que aparece na tela (pancada no texto, máquina no documento, whoosh na foto…)
        trilha_sfx = None
        if ed.get("sfx", True) and settings.get("efeitos_sonoros", True):
            try:
                _job(vid, "Efeitos sonoros", pct=98)
                trilha_sfx = trilha_efeitos(cenas, ed, base, pasta, ff)
            except Exception as e:
                print("efeitos sonoros falharam:", e)
                trilha_sfx = None
        if trilha_sfx:
            args += ["-i", trilha_sfx]
            i_sfx, idx = idx, idx + 1
            vol_s = float(settings.get("sfx_volume", 0.6))
            if amap:
                fc.append(f"[{i_sfx}:a]volume={vol_s}[sx];{amap}[sx]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[afx]")
            else:
                fc.append(f"[{i_sfx}:a]volume={vol_s}[afx]")
            amap = "[afx]"
        if fc:
            args += ["-filter_complex", ";".join(fc)]
        args += ["-map", "0:v"]
        if amap:
            args += ["-map", amap, "-c:a", "aac", "-b:a", "192k"]
        args += ["-c:v", "copy", "-t", f"{base:.3f}", "-movflags", "+faststart", "final.mp4"]
        _run(args, cwd=pasta)  # vídeo só é copiado: leva segundos
        aviso = ""
        saida = os.path.join(pasta, "final.mp4")
        _job(vid, "Pronto!" + (" " + aviso if aviso else ""), pct=100, saida=saida, aviso=aviso)
    except Exception as e:
        _job(vid, "Erro", erro=str(e))
    finally:
        JOBS[vid]["rodando"] = False


# ---------------------------------------------------------------- efeitos sonoros (sintetizados, sem direitos autorais)
SFX = {  # nome: (duração, expressão do som, filtros)
    "whoosh": (0.9, "(random(0)*2-1)*pow(sin(PI*t/0.9),2)*0.6", "highpass=f=500,lowpass=f=4500"),
    "pancada": (1.2, "sin(2*PI*(45+90*exp(-12*t))*t)*exp(-4*t)*0.9+(random(0)*2-1)*exp(-35*t)*0.45", "lowpass=f=3500"),
    "boom": (2.6, "sin(2*PI*(36+70*exp(-6*t))*t)*exp(-1.5*t)*0.95+(random(0)*2-1)*exp(-3*t)*0.25", "lowpass=f=900"),
    "subida": (1.8, "(random(0)*2-1)*pow(t/1.8,2)*0.4+sin(2*PI*(150+260*t)*t)*pow(t/1.8,2)*0.2", "highpass=f=300"),
    "maquina": (1.0, "(random(0)*2-1)*exp(-170*mod(t,0.12))*0.55*lt(t,0.95)", "highpass=f=1400"),
    "radar": (1.4, "sin(2*PI*1100*t)*exp(-5*t)*0.35+sin(2*PI*1650*t)*exp(-7*t)*0.15", "anull"),
    "pop": (0.35, "sin(2*PI*(600+900*t)*t)*exp(-14*t)*0.5", "anull"),
}
SFX_POR_LAYOUT = {
    "capitulo": "boom",
    "documento": "maquina", "ficha": "maquina", "citacao": "maquina", "data": "maquina", "linha_tempo": "maquina",
    "numero": "pancada", "ano": "pancada", "escala": "pancada", "frase": "pancada",
    "mapa": "radar", "local": "radar",
    "pessoa": "whoosh", "duas_pessoas": "whoosh", "colagem": "whoosh", "quadro": "whoosh", "sequencia": "whoosh", "nome": "whoosh",
}


def _banco_sfx(pasta, ff):
    banco = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(pasta))), "sfx")
    os.makedirs(banco, exist_ok=True)
    arqs = {}
    for nome, (d, expr, filtros) in SFX.items():
        p = os.path.join(banco, f"{nome}.wav")
        if not os.path.exists(p) or os.path.getsize(p) < 1000:
            _run([ff, "-y", "-f", "lavfi", "-i", f"aevalsrc=exprs='{expr}':s=44100:d={d}", "-af", f"{filtros},afade=t=out:st={d * 0.8:.2f}:d={d * 0.2:.2f}",
                  "-ac", "2", p])
        arqs[nome] = p
    return arqs


def eventos_sfx(cenas, ed):
    """Lista (segundo, som) a partir do que aparece em cada cena, dos textos de impacto e do botão de inscrição."""
    ev = []
    t = 0.0
    anterior = "midia"
    for c in cenas:
        dur = max(0.5, c["fim"] - c["inicio"])
        lay = c.get("layout") or "midia"
        som = SFX_POR_LAYOUT.get(lay)
        if lay == "capitulo":
            ev.append((max(0.0, t - 1.6), "subida"))
        if som:
            ev.append((t + (0.15 if som == "maquina" else 0.0), som))
        elif anterior != "midia" and lay == "midia":
            ev.append((t, "whoosh"))  # volta do efeito para a filmagem
        anterior = lay
        t += dur
    for tx in ed.get("textos") or []:
        ev.append((float(tx.get("inicio", 0)), "pancada"))
    for cta in ed.get("ctas") or []:
        ev.append((float(cta.get("inicio", 0)), "pop"))
    ev.sort()
    prio = {"boom": 5, "subida": 5, "pancada": 4, "maquina": 3, "radar": 3, "pop": 3, "whoosh": 1}
    final = []
    for s, som in ev:  # nada de um som em cima do outro: fica o mais importante
        if final and s - final[-1][0] < 1.2 and som not in ("boom", "subida") and final[-1][1] not in ("boom", "subida"):
            if prio.get(som, 0) > prio.get(final[-1][1], 0):
                final[-1] = (s, som)
            continue
        final.append((s, som))
    return final[:220]


def trilha_efeitos(cenas, ed, total, pasta, ff):
    eventos = eventos_sfx(cenas, ed)
    if not eventos:
        return None
    banco = _banco_sfx(pasta, ff)
    usados = sorted({s for _, s in eventos})
    args = [ff, "-y"]
    for s in usados:
        args += ["-i", banco[s]]
    partes, rot = [], []
    for k, s in enumerate(usados):
        meus = [(i, t) for i, (t, x) in enumerate(eventos) if x == s]
        partes.append(f"[{k}:a]asplit={len(meus)}" + "".join(f"[s{i}]" for i, _ in meus) if len(meus) > 1 else f"[{k}:a]anull[s{meus[0][0]}]")
        for i, t in meus:
            ms = int(t * 1000)
            partes.append(f"[s{i}]adelay={ms}|{ms}[e{i}]")
            rot.append(f"[e{i}]")
    partes.append("".join(rot) + f"amix=inputs={len(rot)}:duration=longest:normalize=0,apad,atrim=0:{total:.3f}[out]")
    script = os.path.join(pasta, "sfx_filtro.txt")
    with open(script, "w", encoding="utf-8") as f:
        f.write(";\n".join(partes))
    saida = os.path.join(pasta, "efeitos_sonoros.wav")
    args += ["-filter_complex_script", script, "-map", "[out]", "-ac", "2", "-ar", "44100", saida]
    _run(args)
    return saida


def _ler_srt(path):
    def seg(t):
        h, m, r = t.strip().replace(",", ".").split(":")
        return int(h) * 3600 + int(m) * 60 + float(r)

    out = []
    try:
        txt = open(path, encoding="utf-8").read()
    except Exception:
        return out
    for bloco in re.split(r"\n\s*\n", txt.strip()):
        linhas = [x for x in bloco.strip().splitlines() if x.strip()]
        for k, l in enumerate(linhas):
            if "-->" in l:
                a, b = l.split("-->")
                try:
                    out.append((seg(a), seg(b), " ".join(linhas[k + 1:])))
                except ValueError:
                    pass
                break
    return out


def _audio_dos_clipes(video, pasta, ff):
    """Modo personagem fala: usa o som de cada clipe (voz do Flow/Veo) como trilha de falas."""
    d = os.path.join(pasta, "falas")
    os.makedirs(d, exist_ok=True)
    partes = []
    for i, c in enumerate(video["cenas"]):
        dur = max(0.5, c["fim"] - c["inicio"])
        out = os.path.join(d, f"f{i:04d}.wav")
        m = (c.get("midia") or {})
        arq = m.get("arquivo")
        try:
            if not (arq and os.path.exists(arq) and m.get("tipo") == "video"):
                raise RuntimeError
            _run([ff, "-y", "-i", arq, "-vn", "-t", f"{dur:.3f}", "-af", f"apad=whole_dur={dur:.3f}", "-ar", "44100", "-ac", "2", out])
        except Exception:
            _run([ff, "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", f"{dur:.3f}", out])
        partes.append(out)
    with open(os.path.join(d, "lista.txt"), "w", encoding="utf-8") as f:
        for p in partes:
            f.write(f"file '{os.path.basename(p)}'\n")
    saida = os.path.join(pasta, "falas.wav")
    _run([ff, "-y", "-f", "concat", "-safe", "0", "-i", "lista.txt", "-c", "copy", saida], cwd=d)
    return saida


def iniciar(video, settings, pasta, ao_terminar=None):
    def alvo():
        renderizar(video, settings, pasta)
        if ao_terminar:
            ao_terminar(JOBS.get(video["id"], {}))

    t = threading.Thread(target=alvo, daemon=True)
    t.start()
