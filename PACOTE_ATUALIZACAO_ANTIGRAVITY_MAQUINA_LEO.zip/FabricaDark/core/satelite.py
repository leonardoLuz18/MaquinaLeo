"""Zoom de satélite: acha as coordenadas do lugar e baixa os ladrilhos do mapa em vários níveis de zoom.

Na montagem, gera o "mergulho" da Terra até o lugar (estilo Google Earth), com o alfinete no fim.
Imagens: Esri World Imagery (com crédito na tela); nomes de países/cidades: camada de referência da Esri.
"""
import io
import json
import math
import os
from concurrent.futures import ThreadPoolExecutor

import requests
from PIL import Image

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FabricaDark/1.0"
SAT = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
REF = "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"
LADO = 256
QW, QH = 1280, 720  # tamanho de trabalho do mosaico (depois é ampliado para a resolução do vídeo)


def geocodificar(lugar):
    """Nominatim (OpenStreetMap). Retorna (lat, lon, zoom_sugerido) ou None."""
    r = requests.get("https://nominatim.openstreetmap.org/search", params={"q": lugar, "format": "json", "limit": 1},
                     headers={"User-Agent": UA, "Accept-Language": "pt-BR,en"}, timeout=20)
    r.raise_for_status()
    j = r.json()
    if not j:
        return None
    x = j[0]
    lat, lon = float(x["lat"]), float(x["lon"])
    try:
        s, n, o, l = [float(v) for v in x["boundingbox"]]
        vao = max(abs(l - o), abs(n - s) * 1.6, 0.002)
        z = int(math.log2(360 * (QW / LADO) / vao)) - 1
    except Exception:
        z = 12
    return lat, lon, max(4, min(17, z))


def _px(lat, lon, z):
    n = 2 ** z * LADO
    x = (lon + 180) / 360 * n
    la = math.radians(max(-85, min(85, lat)))
    y = (1 - math.log(math.tan(la) + 1 / math.cos(la)) / math.pi) / 2 * n
    return x, y


def _ladrilho(url, z, x, y):
    n = 2 ** z
    x %= n
    if y < 0 or y >= n:
        return None
    r = requests.get(url.format(z=z, x=x, y=y), headers={"User-Agent": UA}, timeout=20)
    if r.status_code != 200 or len(r.content) < 200:
        return None
    return Image.open(io.BytesIO(r.content)).convert("RGBA")


def mosaico(lat, lon, z, rotulos=True):
    """Imagem QW×QH centrada no ponto, no nível z."""
    cx, cy = _px(lat, lon, z)
    x0, y0 = cx - QW / 2, cy - QH / 2
    tx0, ty0 = int(x0 // LADO), int(y0 // LADO)
    tx1, ty1 = int((x0 + QW) // LADO), int((y0 + QH) // LADO)
    tarefas = [(tx, ty) for tx in range(tx0, tx1 + 1) for ty in range(ty0, ty1 + 1)]
    out = Image.new("RGBA", ((tx1 - tx0 + 1) * LADO, (ty1 - ty0 + 1) * LADO), (8, 14, 30, 255))
    with ThreadPoolExecutor(8) as ex:
        sat = list(ex.map(lambda t: _ladrilho(SAT, z, *t), tarefas))
        ref = list(ex.map(lambda t: _ladrilho(REF, z, *t), tarefas)) if rotulos else [None] * len(tarefas)
    ok = 0
    for (tx, ty), a, b in zip(tarefas, sat, ref):
        pos = ((tx - tx0) * LADO, (ty - ty0) * LADO)
        if a:
            out.alpha_composite(a, pos)
            ok += 1
        if b:
            out.alpha_composite(b, pos)
    if ok < len(tarefas) * 0.6:
        raise RuntimeError(f"mapa incompleto no zoom {z}")
    ox, oy = int(x0 - tx0 * LADO), int(y0 - ty0 * LADO)
    return out.crop((ox, oy, ox + QW, oy + QH)).convert("RGB")


def preparar(lugar, pasta, coords=None, zoom=None, log=print):
    """Baixa os mosaicos de cada nível. Retorna True se ficou pronto (grava info.json na pasta)."""
    info_p = os.path.join(pasta, "info.json")
    if os.path.exists(info_p):
        return True
    g = None
    try:
        g = geocodificar(lugar)
    except Exception as e:
        log(f"mapa: não achei '{lugar}' ({str(e)[:80]})")
    if not g and coords:
        try:
            g = (float(coords[0]), float(coords[1]), int(zoom or 12))
        except Exception:
            g = None
    if not g:
        return False
    lat, lon, z1 = g
    if zoom:
        try:
            z1 = max(4, min(17, int(zoom)))
        except Exception:
            pass
    z0 = max(2, z1 - 9)
    os.makedirs(pasta, exist_ok=True)
    for z in range(z0, z1 + 1):
        mosaico(lat, lon, z, rotulos=z <= 11).save(os.path.join(pasta, f"z{z:02d}.jpg"), quality=92)
    json.dump({"lugar": lugar, "lat": lat, "lon": lon, "z0": z0, "z1": z1}, open(info_p, "w"))
    return True


def quadros_zoom(pasta, W, H, dur, fps, saida_dir):
    """Gera os quadros do mergulho (z0 → z1) com aceleração suave. Retorna o padrão dos JPGs ou None."""
    try:
        info = json.load(open(os.path.join(pasta, "info.json")))
    except Exception:
        return None
    z0, z1 = info["z0"], info["z1"]
    niveis = {}
    for z in range(z0, z1 + 1):
        p = os.path.join(pasta, f"z{z:02d}.jpg")
        if os.path.exists(p):
            niveis[z] = Image.open(p).convert("RGB")
    if z1 not in niveis:
        return None
    os.makedirs(saida_dir, exist_ok=True)
    total = max(2, int(round(dur * fps)))
    voo = max(2, int(total * 0.75))
    for k in range(total):
        u = min(1.0, k / (voo - 1))
        e = u * u * (3 - 2 * u)  # suave no começo e no fim
        zf = z0 + (z1 - z0) * e
        L = min(z1, int(math.floor(zf)))
        while L not in niveis and L < z1:
            L += 1
        s = 2 ** (zf - L)
        im = niveis[L]
        cw, ch = QW / s, QH / s
        x0, y0 = (QW - cw) / 2, (QH - ch) / 2
        fr = im.resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + cw, y0 + ch))
        fr.save(os.path.join(saida_dir, f"m_{k + 1:04d}.jpg"), quality=90)
    return os.path.join(saida_dir, "m_%04d.jpg")
