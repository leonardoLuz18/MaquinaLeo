"""Divide o roteiro em cenas e gera SRT com tempos proporcionais ao número de palavras."""
import re


def _sentencas(texto):
    texto = re.sub(r"\s+", " ", texto or "").strip()
    if not texto:
        return []
    partes = re.split(r"(?<=[\.\!\?…])\s+(?=[\"“'A-ZÁÉÍÓÚÂÊÔÃÕÇÀ0-9¿¡])", texto)
    out = []
    for p in partes:
        p = p.strip()
        if not p:
            continue
        # sentenças muito longas: quebra em vírgula/ponto-e-vírgula
        if len(p.split()) > 40:
            sub = re.split(r"(?<=[,;:])\s+", p)
            buf = ""
            for s in sub:
                if buf and len((buf + " " + s).split()) > 28:
                    out.append(buf.strip())
                    buf = s
                else:
                    buf = (buf + " " + s).strip()
            if buf:
                out.append(buf)
        else:
            out.append(p)
    return out


def contar_palavras(t):
    return len((t or "").split())


def dividir_cenas(roteiro, segundos_por_cena=8, palavras_por_minuto=150):
    alvo = max(6, round(segundos_por_cena * palavras_por_minuto / 60.0))
    cenas, buf = [], []
    for s in _sentencas(roteiro):
        n_buf = sum(contar_palavras(x) for x in buf)
        n_s = contar_palavras(s)
        if buf and (n_buf >= alvo or n_buf + n_s > alvo * 1.6):
            cenas.append(" ".join(buf))
            buf = []
        buf.append(s)
    if buf:
        if cenas and sum(contar_palavras(x) for x in buf) < alvo * 0.35:
            cenas[-1] += " " + " ".join(buf)
        else:
            cenas.append(" ".join(buf))
    return [
        {
            "n": i + 1,
            "texto": t,
            "palavras": contar_palavras(t),
            "inicio": 0.0,
            "fim": 0.0,
            "tipo": "",
            "pessoa_real": "",
            "termos_busca": [],
            "descricao_visual": "",
            "prompt_ia": "",
            "midia": None,
            "candidatos": [],
            "status": "pendente",
        }
        for i, t in enumerate(cenas)
    ]


def aplicar_tempos(cenas, duracao_total=None, palavras_por_minuto=150):
    total_palavras = sum(max(1, c.get("palavras") or contar_palavras(c["texto"])) for c in cenas) or 1
    if not duracao_total:
        duracao_total = total_palavras / palavras_por_minuto * 60.0
    t = 0.0
    for c in cenas:
        d = duracao_total * max(1, c.get("palavras") or contar_palavras(c["texto"])) / total_palavras
        c["inicio"] = round(t, 3)
        t += d
        c["fim"] = round(t, 3)
    if cenas:
        cenas[-1]["fim"] = round(duracao_total, 3)
    return cenas


def aplicar_tempos_blocos(cenas, blocos, pausa=0.35):
    """Sincroniza melhor: usa a duração real de cada bloco de voz (o ritmo da fala varia ao longo do vídeo)."""
    blocos = [b for b in blocos if b.get("duracao")]
    if not blocos or not cenas:
        return False
    pal_blocos = [contar_palavras(b["texto"]) for b in blocos]
    pal_cenas = [max(1, c.get("palavras") or contar_palavras(c["texto"])) for c in cenas]
    if abs(sum(pal_blocos) - sum(pal_cenas)) > 0.03 * sum(pal_cenas) + 3:
        return False
    marcos = []  # (palavra_inicial, tempo_inicial, palavras, duracao_fala)
    w = t = 0.0
    for b, n in zip(blocos, pal_blocos):
        marcos.append((w, t, n, b["duracao"]))
        w += n
        t += b["duracao"] + pausa
    total_t = t

    def tempo_da_palavra(idx):
        for w0, t0, n, d in marcos:
            if idx < w0 + n or (w0, t0, n, d) == marcos[-1]:
                frac = 0 if n == 0 else min(1.0, (idx - w0) / n)
                return t0 + frac * d
        return total_t

    idx = 0
    for c, n in zip(cenas, pal_cenas):
        c["inicio"] = round(tempo_da_palavra(idx), 3)
        idx += n
    for i, c in enumerate(cenas):
        c["fim"] = cenas[i + 1]["inicio"] if i + 1 < len(cenas) else round(total_t, 3)
    return True


def _ts(s):
    ms = int(round(s * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    sec, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def gerar_srt(cenas, max_palavras=7):
    blocos, idx = [], 1
    for c in cenas:
        palavras = c["texto"].split()
        if not palavras:
            continue
        chunks, buf = [], []
        for w in palavras:
            buf.append(w)
            if len(buf) >= max_palavras or (re.search(r"[\.\!\?…,;:]$", w) and len(buf) >= 3):
                chunks.append(buf)
                buf = []
        if buf:
            if chunks and len(buf) <= 2:
                chunks[-1].extend(buf)
            else:
                chunks.append(buf)
        dur = c["fim"] - c["inicio"]
        total = len(palavras)
        t = c["inicio"]
        for ch in chunks:
            d = dur * len(ch) / total
            blocos.append(f"{idx}\n{_ts(t)} --> {_ts(t + d)}\n{' '.join(ch)}\n")
            idx += 1
            t += d
    return "\n".join(blocos)


def capitulos_aprox(cenas, n=6):
    if not cenas:
        return ""
    passo = max(1, len(cenas) // n)
    linhas = []
    for c in cenas[::passo]:
        m, s = divmod(int(c["inicio"]), 60)
        linhas.append(f"{m:02d}:{s:02d} — {c['texto'][:90]}")
    return "\n".join(linhas)
