"""Armazenamento simples em JSON (data/db.json) + pastas por vídeo."""
import json
import os
import threading
import time
import uuid

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "db.json")
VIDEOS_DIR = os.path.join(DATA_DIR, "videos")

_lock = threading.RLock()

DEFAULT_DB = {
    "settings": {
        "youtube_api_key": "AIzaSyBgcAfDrYwAOcE2EStaXsArTObdOt3ti3A",
        "pixabay_key": "45800004-26b1150e3f63cd68e9dadcf49",
        "pexels_key": "",
        "pexels_modo_direto": True,
        "segundos_por_cena": 8,
        "palavras_por_minuto": 150,
        "resolucao": "1920x1080",
        "fps": 30,
        "grao": True,
        "legenda_queimada": True,
        "zoom_suave": True,
        "max_cenas_ia_pct": 30,
        "gemini_key": "AQ.Ab8RN6Ijcws11rfFDVTj-ZQQnQfi5rgpFq_eUXp-XJB73laTYQ",
        "gemini_tts_modelo": "gemini-2.5-flash-preview-tts",
        "ia_look": "cinematic documentary photograph, natural light, muted colors, 35mm, high detail, no text, no watermark",
        "voz_motor": "edge",
        "voz_edge_pt": "pt-BR-AntonioNeural",
        "voz_edge_en": "en-US-GuyNeural",
        "voz_edge_es": "es-MX-JorgeNeural",
        "voz_edge_fr": "fr-FR-HenriNeural",
        "voz_gemini": "Charon",
        "voz_velocidade": "+0%",
        "voz_estilo": "",
        "gemini_ordem": "pagas",
        "gemini_so_gratuitas": False,
        "gemini_modelo_pagas": "",
        "gemini_modelo_gratis": "gemini-flash-lite-latest",
        "gemini_img_modelo": "",
        "limite_gasto_video": 10,
        "gemini_preco_in": 0.30,
        "gemini_preco_out": 2.50,
        "precos_conferidos_em": "",
        "dolar": 5.40,
        "dolar_data": "",
        "youtube_assuntos": 8,
        "modo_ia": "real_ia",
        "ia_auto": False,
        "ia_motor": "pollinations",
        "ia_look_modo": "auto",
        "conferir_com_ia": True,
        "conferencias_por_cena": 3,
        "max_repeticao": 1,
        "aceitar_cc_by_sa": False,
        "fontes_ativas": {},
        "smithsonian_key": "Bp6tw7zQcGm69FWfDDfJwwCHBqJWfWR8DTgmzqL9",
        "europeana_key": "",
        "unsplash_key": "O8XXY9tmnxHrdhLnlbEQ9-h9yWmZwmcw2VrKrNN2ff4",
        "unsplash_app_id": "1116622",
        "unsplash_secret": "Hz5LtN2psaK98RTiSeNtJIh9nztapo_2EeRT-F8xYtM",
        "unsplash_auth_code": "9LP5nXk7sgJxhIBKwSNf49Iov4L0z0chombpNrxGjj0",
        "cenas_paralelo": 3,
        "modo_rapido": False,
        "gemini_paralelo": True,
        "claude_modelo": "gpt-4o",
        "claude_tarefas": {"roteiro": True, "pesquisa": True, "impacto": True, "seo": True},
        "claude_modo": "auto",
        "claude_assinatura": {},
        "gpt_modelo": "gpt-4o",
        "gpt_tarefas": {"roteiro": True, "pesquisa": True, "impacto": True, "seo": True},
        "antigravity_ativo": True,
        "antigravity_modo": "v8_ninja_pro",
        "antigravity_palavras": 2000,
        "antigravity_blocos": 6,
        "darkplanner_exe": r"C:\Users\leona\AppData\Local\Programs\darkplanner\Dark Planner.exe",
        "darkplanner_watch": r"C:\Users\leona\Downloads\DarkPlanner\DarkPlanner_WatchFolder",
        "estilos_custom": [],
        "preferencia_midia": "equilibrado",
    },
    "channels": [],
    "videos": [],
    "ideas": [],
    "radar_saved": [],
    "mapas": [],
    "financeiro": [],
    "metricas": [],
    "chaves": {},
    "consumo": {},
    "kanban": [],
    "pautas": {},
}

STEPS = ["briefing", "roteiro", "analise", "narracao", "cenas", "midia", "editor", "montagem", "descricao", "thumb"]


def new_id(prefix=""):
    return prefix + uuid.uuid4().hex[:10]


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _ensure():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(VIDEOS_DIR, exist_ok=True)
    if not os.path.exists(DB_PATH):
        _write(DEFAULT_DB)


def _write(db):
    tmp = DB_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)
    # No Windows, o antivírus/indexador/OneDrive às vezes "segura" o db.json por instantes
    # (WinError 5 / 32). Em vez de quebrar, tenta de novo por alguns segundos.
    ultimo = None
    for tentativa in range(40):
        try:
            os.replace(tmp, DB_PATH)
            return
        except PermissionError as e:
            ultimo = e
            time.sleep(0.05 + tentativa * 0.02)
    # último recurso: escreve direto por cima (sem o arquivo temporário)
    try:
        with open(DB_PATH, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
        try:
            os.remove(tmp)
        except OSError:
            pass
    except PermissionError:
        raise ultimo


def _ler():
    for tentativa in range(40):
        try:
            with open(DB_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except PermissionError:
            time.sleep(0.05 + tentativa * 0.02)
    with open(DB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def load():
    with _lock:
        _ensure()
        db = _ler()
        for k, v in DEFAULT_DB.items():
            if k not in db:
                db[k] = json.loads(json.dumps(v))
        for k, v in DEFAULT_DB["settings"].items():
            db["settings"].setdefault(k, v)
            if v and isinstance(v, str) and k.endswith(("_key", "_app_id", "_secret", "_auth_code")) and not db["settings"].get(k):
                db["settings"][k] = v
        modelo = new_video("", "")
        for v in db["videos"]:
            for k, val in modelo.items():
                if k not in v:
                    v[k] = json.loads(json.dumps(val))
            for k, val in modelo["briefing"].items():
                v["briefing"].setdefault(k, val)
            for k in STEPS:
                v["etapas"].setdefault(k, False)
        return db


def save(db):
    with _lock:
        _ensure()
        _write(db)


class Tx:
    """with Tx() as db: ... -> salva no final."""

    def __enter__(self):
        _lock.acquire()
        self.db = load()
        return self.db

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                save(self.db)
        finally:
            _lock.release()
        return False


def find(items, item_id):
    for it in items:
        if str(it.get("id")) == str(item_id) or (it.get("dp_id") is not None and str(it.get("dp_id")) == str(item_id)):
            return it
    return None


def get_video(db, vid):
    if not vid or not isinstance(db, dict):
        return None
    return find(db.get("videos") or [], vid)


def get_channel(db, cid):
    if not cid or not isinstance(db, dict):
        return None
    return find(db.get("channels") or [], cid)


def video_dir(video_id):
    d = os.path.join(VIDEOS_DIR, video_id)
    os.makedirs(os.path.join(d, "midia"), exist_ok=True)
    return d


def new_video(channel_id, titulo):
    return {
        "id": new_id("v"),
        "channel_id": channel_id,
        "titulo": titulo,
        "criado_em": now(),
        "data_publicacao": "",
        "publicado": False,
        "etapas": {s: False for s in STEPS},
        "briefing": {
            "duracao_min": 12,
            "tipo_narrativa": "Narrador sombrio",
            "estrutura": "Storytelling",
            "publico": "",
            "contexto": "",
            "referencias": "",
            "cta": "CTA no final",
            "produto": "",
            "serie": "",
            "episodio": "",
            "resumo_anterior": "",
            "partes": 1,
            "estrutura_texto": "",
        },
        "partes_roteiro": [],
        "blocos_voz": [],
        "voz": {},
        "narracao_origem": "",
        "thumbs": [],
        "titulo_check": None,
        "cenas_cfg": {"tipo_cenas": "imagens", "estilo": "cinematic", "personagem_fala": False},
        "editor": {"template": "nenhum", "filtro": "nenhum", "transicao": "corte", "legenda": {"ativa": True, "tamanho": 15, "cor": "#FFFFFF", "posicao": "baixo", "caixa": False}, "ctas": []},
        "historico": [],
        "custo_ia_brl": 0,
        "chamadas_ia": 0,
        "publicado_analise": None,
        "roteiro": "",
        "analise": None,
        "cenas": [],
        "srt": "",
        "narracao": "",
        "musica": "",
        "musica_volume": 0.12,
        "saida": "",
        "descricao": None,
    }
