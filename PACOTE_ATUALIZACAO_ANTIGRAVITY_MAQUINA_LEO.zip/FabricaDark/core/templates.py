"""Molduras do Video Lab (Documentário, Telejornal), CTA e composição de foto em pé."""
import os
import random

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

MONO = [r"C:\Windows\Fonts\courbd.ttf", r"C:\Windows\Fonts\consolab.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"]
SANS = [r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\segoeuib.ttf", "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


def fonte(lista, tam):
    for f in lista:
        if os.path.exists(f):
            try:
                return ImageFont.truetype(f, tam)
            except Exception:
                pass
    return ImageFont.load_default()


def caixa_doc(W, H):
    """Retângulo onde a mídia entra no template Documentário (x, y, w, h), sempre par."""
    w = int(W * 0.66) // 2 * 2
    h = int(w * H / W) // 2 * 2
    x = (W - w) // 2 // 2 * 2
    y = int(H * 0.17) // 2 * 2
    return x, y, w, h


def doc_fundo(W, H, titulo, nome, saida):
    random.seed(7)
    papel = Image.new("RGB", (W, H), (236, 228, 212))
    d = ImageDraw.Draw(papel)
    passo = max(24, W // 48)
    for x in range(0, W, passo):
        d.line([(x, 0), (x, H)], fill=(222, 212, 194), width=1)
    for y in range(0, H, passo):
        d.line([(0, y), (W, y)], fill=(222, 212, 194), width=1)
    # textura leve
    ruido = Image.effect_noise((W // 4, H // 4), 18).resize((W, H)).convert("L")
    papel = Image.composite(papel, Image.new("RGB", (W, H), (214, 204, 186)), ruido.point(lambda p: 255 - p // 6))
    d = ImageDraw.Draw(papel)
    x, y, w, h = caixa_doc(W, H)
    sombra = Image.new("L", (W, H), 0)
    ImageDraw.Draw(sombra).rectangle([x + 10, y + 12, x + w + 10, y + h + 12], fill=110)
    sombra = sombra.filter(ImageFilter.GaussianBlur(14))
    papel = Image.composite(Image.new("RGB", (W, H), (120, 110, 95)), papel, sombra)
    d = ImageDraw.Draw(papel)
    d.rectangle([x - 8, y - 8, x + w + 8, y + h + 8], fill=(250, 247, 240))
    if titulo:
        f = fonte(MONO, max(16, H // 40))
        d.text((x, y - H // 18), titulo.upper(), font=f, fill=(40, 36, 30))
    if nome:
        f = fonte(MONO, max(16, H // 38))
        tw = d.textlength(nome.upper(), font=f)
        by = y + h + H // 40
        d.rectangle([x, by, x + tw + 28, by + H // 22], fill=(250, 247, 240), outline=(60, 54, 45), width=2)
        d.text((x + 14, by + H // 140), nome.upper(), font=f, fill=(40, 36, 30))
    papel.save(saida)
    return saida


def telejornal_overlay(W, H, manchete, rotulo, saida, cor="#C8102E"):
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    bh = H // 9
    by = H - bh - H // 14
    tag_w = int(W * 0.14)
    d.rectangle([0, by, W, by + bh], fill=(12, 16, 28, 228))
    d.rectangle([0, by, tag_w, by + bh], fill=cor)
    ft = fonte(SANS, bh // 3)
    tag = (rotulo or "URGENTE").upper()[:14]
    tw = d.textlength(tag, font=ft)
    d.text(((tag_w - tw) / 2, by + bh / 2 - bh / 6), tag, font=ft, fill="white")
    fm = fonte(SANS, int(bh / 2.6))
    txt = (manchete or "").upper()
    while txt and d.textlength(txt, font=fm) > W - tag_w - 60:
        txt = txt[:-2]
    d.text((tag_w + 30, by + bh / 2 - bh / 5), txt, font=fm, fill="white")
    d.rectangle([0, by + bh, W, by + bh + H // 120], fill=cor)
    im.save(saida)
    return saida


def cta_png(W, H, texto, saida):
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    f = fonte(SANS, H // 24)
    t = (texto or "INSCREVA-SE").upper()
    tw = d.textlength(t, font=f)
    bw, bh = int(tw + H // 10), H // 13
    x, y = W - bw - W // 30, H // 14
    d.rounded_rectangle([x, y, x + bw, y + bh], radius=bh // 4, fill=(204, 0, 0, 240))
    d.text((x + (bw - tw) / 2, y + bh / 2 - H // 46), t, font=f, fill="white")
    im.save(saida)
    return saida


def foto_em_pe(path, W, H, saida):
    """Foto em pé/quadrada: entra inteira no centro, sobre ela mesma desfocada."""
    im = Image.open(path).convert("RGB")
    fundo = ImageOps.fit(im, (W, H), Image.LANCZOS).filter(ImageFilter.GaussianBlur(max(20, W // 60)))
    fundo = Image.eval(fundo, lambda p: int(p * 0.6))
    frente = im.copy()
    frente.thumbnail((W, H), Image.LANCZOS)
    fundo.paste(frente, ((W - frente.width) // 2, (H - frente.height) // 2))
    fundo.save(saida, "JPEG", quality=92)
    return saida


def proporcao(path):
    try:
        with Image.open(path) as im:
            return im.width / max(1, im.height)
    except Exception:
        return None


def texto_impacto_png(W, H, texto, saida):
    """Frase de impacto grande no centro-baixo, com faixa escura (estilo documentário)."""
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    t = (texto or "").upper().strip()
    tam = H // 11
    f = fonte(SANS, tam)
    while d.textlength(t, font=f) > W * 0.86 and tam > H // 24:
        tam -= 4
        f = fonte(SANS, tam)
    tw = d.textlength(t, font=f)
    y = int(H * 0.40)
    d.rectangle([0, y - tam * 0.35, W, y + tam * 1.35], fill=(0, 0, 0, 150))
    d.text(((W - tw) / 2, y), t, font=f, fill=(255, 255, 255, 255), stroke_width=max(2, tam // 18), stroke_fill=(0, 0, 0, 255))
    d.rectangle([(W - tw) / 2, y + tam * 1.15, (W + tw) / 2, y + tam * 1.15 + max(4, H // 140)], fill=(249, 115, 22, 255))
    im.save(saida)
    return saida


ESTILOS_LEGENDA = {
    "": ("Clássica", "branca com contorno preto"),
    "jornal": ("Jornal", "faixa amarela, texto preto"),
    "vermelha": ("Urgente", "faixa vermelha, texto branco"),
    "destaque": ("Destaque", "maiúscula grossa, palavra-chave em amarelo"),
    "karaoke": ("Karaokê", "a palavra falada acende na hora"),
    "pilula": ("Pílula", "caixa arredondada escura, moderna"),
    "caixa": ("Caixa", "fundo preto translúcido"),
    "neon": ("Neon", "brilho colorido em volta"),
    "cinema": ("Cinema", "fina e elegante, com sombra suave"),
    "maquina": ("Máquina de escrever", "fonte de datilografia em faixa escura"),
}
LEVE_F = [r"C:\Windows\Fonts\segoeui.ttf", r"C:\Windows\Fonts\arial.ttf", "/usr/share/fonts/truetype/google-fonts/Poppins-Medium.ttf",
          "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
GROSSA_F = [r"C:\Windows\Fonts\impact.ttf", r"C:\Windows\Fonts\arialbd.ttf", "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


def _rgb(c, padrao=(255, 214, 0)):
    if isinstance(c, (list, tuple)):
        return tuple(int(x) for x in c[:3])
    c = str(c or "").lstrip("#")
    try:
        return tuple(int(c[k:k + 2], 16) for k in (0, 2, 4))
    except Exception:
        return padrao


def _chave(palavras):
    """Palavra que ganha destaque: número/valor, senão a mais longa (>= 5 letras)."""
    import re as _re

    for k, w in enumerate(palavras):
        if _re.search(r"\d", w):
            return k
    cands = [(len(w.strip(".,;:!?")), k) for k, w in enumerate(palavras) if len(w.strip(".,;:!?")) >= 5]
    return max(cands)[1] if cands else -1


def palavras_tempo(texto, a, b):
    """Divide o tempo da legenda entre as palavras (proporcional ao tamanho) — usado no karaokê."""
    ws = (texto or "").split()
    if not ws:
        return []
    pesos = [len(w) + 2 for w in ws]
    tot = sum(pesos)
    out, t = [], a
    for k, p in enumerate(pesos):
        d = (b - a) * p / tot
        out.append((k, t, t + d if k < len(ws) - 1 else b))
        t += d
    return out


def legenda_png(W, H, texto, estilo, saida, ativa=None):
    """Legenda queimada como imagem. estilo["estilo"] escolhe o visual; ativa = índice da palavra acesa (karaokê)."""
    from PIL import ImageFilter

    os.makedirs(os.path.dirname(saida), exist_ok=True)
    estilo = estilo or {}
    tipo = estilo.get("estilo") or ("caixa" if estilo.get("caixa") else "")
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    tam = max(14, int(H * float(estilo.get("tamanho") or 15) / 288))
    margem = int(H * float(estilo.get("margem") or estilo.get("margem_tpl") or 40) / 288)
    pos = estilo.get("posicao") or "baixo"
    cor = _rgb(estilo.get("cor") or "#FFFFFF", (255, 255, 255))
    acc = _rgb(estilo.get("acc") or "#FFD600")
    amarelo = (255, 214, 0)

    def y_inicio(bloco):
        return margem if pos == "topo" else (H - bloco) // 2 if pos == "meio" else H - margem - bloco

    if tipo in ("jornal", "vermelha"):  # faixa de telejornal
        tam_j = max(12, int(tam * 0.62))
        fj = fonte(SANS, tam_j)
        linhas = _quebrar_txt((texto or "").upper(), fj, W * 0.7, d)
        alt_j = int(tam_j * 1.35)
        y = y_inicio(alt_j * len(linhas))
        fundo, tinta = ((255, 214, 0, 255), (10, 10, 10, 255)) if tipo == "jornal" else ((200, 16, 46, 255), (255, 255, 255, 255))
        for k, l in enumerate(linhas):
            tw = d.textlength(l, font=fj)
            x = (W - tw) / 2
            yy = y + k * alt_j
            d.rectangle([x - tam_j * 0.45, yy - tam_j * 0.12, x + tw + tam_j * 0.45, yy + alt_j - tam_j * 0.1], fill=fundo)
            d.text((x, yy), l, font=fj, fill=tinta)
        im.save(saida)
        return saida

    if tipo in ("destaque", "karaoke"):  # palavra a palavra, com uma palavra colorida
        maius = tipo == "destaque"
        tam2 = int(tam * (1.12 if maius else 1.0))
        f = fonte(GROSSA_F if maius else SANS, tam2)
        txt = (texto or "").upper() if maius else (texto or "")
        palavras = txt.split()
        realce = _chave(palavras) if maius else (ativa if ativa is not None else -1)
        # quebra mantendo o índice de cada palavra
        linhas, atual = [], []
        esp = d.textlength(" ", font=f)
        for k, w in enumerate(palavras):
            larg = sum(d.textlength(palavras[j], font=f) for j in atual) + esp * len(atual) + d.textlength(w, font=f)
            if atual and larg > W * 0.8:
                linhas.append(atual)
                atual = []
            atual.append(k)
        if atual:
            linhas.append(atual)
        alt = int(tam2 * 1.25)
        y = y_inicio(alt * len(linhas))
        for ln in linhas:
            tw = sum(d.textlength(palavras[j], font=f) for j in ln) + esp * (len(ln) - 1)
            x = (W - tw) / 2
            for j in ln:
                w = palavras[j]
                c_ = amarelo if j == realce else cor
                d.text((x, y), w, font=f, fill=c_ + (255,), stroke_width=max(2, tam2 // 11), stroke_fill=(0, 0, 0, 255))
                x += d.textlength(w, font=f) + esp
            y += alt
        im.save(saida)
        return saida

    if tipo == "maquina":
        f = fonte(MONO, max(12, int(tam * 0.82)))
    elif tipo == "cinema":
        f = fonte(LEVE_F, max(12, int(tam * 0.9)))
    else:
        f = fonte(SANS, tam)
    linhas = _quebrar_txt(texto, f, W * (0.74 if tipo in ("pilula", "maquina", "cinema") else 0.86), d)
    alt = int(f.size * 1.3)
    bloco = alt * len(linhas)
    y0 = y_inicio(bloco)
    if tipo == "maquina":  # faixa escura de ponta a ponta
        d.rectangle([0, y0 - f.size * 0.45, W, y0 + bloco + f.size * 0.2], fill=(8, 8, 8, 175))
    camada = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dc = ImageDraw.Draw(camada)
    for k, l in enumerate(linhas):
        tw = d.textlength(l, font=f)
        x, y = (W - tw) / 2, y0 + k * alt
        if tipo == "caixa":
            d.rectangle([x - f.size * 0.3, y - f.size * 0.08, x + tw + f.size * 0.3, y + alt - f.size * 0.05], fill=(0, 0, 0, 150))
            d.text((x, y), l, font=f, fill=cor + (255,))
        elif tipo == "pilula":
            r = alt * 0.55
            d.rounded_rectangle([x - f.size * 0.7, y - f.size * 0.12, x + tw + f.size * 0.7, y + alt - f.size * 0.02], radius=int(r),
                                fill=(14, 14, 18, 205))
            d.text((x, y), l, font=f, fill=cor + (255,))
        elif tipo == "maquina":
            d.text((x, y), l, font=f, fill=(236, 228, 210, 255))
        elif tipo == "cinema":
            dc.text((x + 2, y + 3), l, font=f, fill=(0, 0, 0, 230))
            d.text((x, y), l, font=f, fill=cor + (255,))
        elif tipo == "neon":
            dc.text((x, y), l, font=f, fill=acc + (255,), stroke_width=max(3, f.size // 8), stroke_fill=acc + (255,))
            d.text((x, y), l, font=f, fill=(255, 255, 255, 255))
        else:
            d.text((x, y), l, font=f, fill=cor + (255,), stroke_width=max(2, f.size // 14), stroke_fill=(0, 0, 0, 255))
    if tipo in ("cinema", "neon"):  # sombra/brilho desfocado por baixo do texto
        camada = camada.filter(ImageFilter.GaussianBlur(max(3, f.size // (6 if tipo == "cinema" else 4))))
        if tipo == "neon":
            camada = Image.alpha_composite(camada, camada)
        camada.alpha_composite(im)
        im = camada
    im.save(saida)
    return saida


def _quebrar_txt(texto, f, largura, d):
    linhas, atual = [], ""
    for w in (texto or "").split():
        t = (atual + " " + w).strip()
        if d.textlength(t, font=f) > largura and atual:
            linhas.append(atual)
            atual = w
        else:
            atual = t
    if atual:
        linhas.append(atual)
    return linhas
