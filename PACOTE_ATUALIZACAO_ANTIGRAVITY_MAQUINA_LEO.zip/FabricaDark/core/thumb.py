"""ThumbLab: monta thumbnails 1280x720 (fundo + texto grande com contorno) em estilos de canal dark."""
import os

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

W, H = 1280, 720

FONTES = [
    r"C:\Windows\Fonts\impact.ttf",
    r"C:\Windows\Fonts\arialbd.ttf",
    r"C:\Windows\Fonts\seguibl.ttf",
    "/usr/share/fonts/truetype/google-fonts/Poppins-Black.ttf",
    "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]

ESTILOS = {
    "impacto": "Texto branco gigante com contorno, fundo escurecido do lado do texto",
    "faixa": "Faixa vermelha atrás da frase",
    "misterio": "Fundo escuro com vinheta forte, círculo vermelho de destaque",
    "contraste": "Fundo preto e branco, texto amarelo",
}


def _fonte(tam, preferida=""):
    for f in ([preferida] if preferida else []) + FONTES:
        if f and os.path.exists(f):
            try:
                return ImageFont.truetype(f, tam)
            except Exception:
                continue
    return ImageFont.load_default()


def _cover(img):
    """Ajusta a imagem para 1280x720 (16:9) preservando a área central e superior (evita cortar cabeças/avatares)."""
    im_rgb = img.convert("RGB")
    w0, h0 = im_rgb.size
    if w0 <= 0 or h0 <= 0:
        return Image.new("RGB", (W, H), (20, 20, 24))
    # Usa centering=(0.5, 0.38) para nunca cortar o topo da cabeça do avatar quando vem de 1536x1024 (3:2)
    return ImageOps.fit(im_rgb, (W, H), Image.LANCZOS, centering=(0.5, 0.38))


def _largura_linha_real(linha, fonte, draw, contorno=0):
    palavras = (linha or "").split()
    if not palavras:
        return 0.0
    total = 0.0
    for i, p in enumerate(palavras):
        suf = " " if i < len(palavras) - 1 else ""
        total += draw.textlength(p + suf, font=fonte)
    return total + (contorno * 2.5)


def _quebrar(texto, fonte, largura, draw, contorno=0):
    palavras, linhas, atual = (texto or "").split(), [], ""
    larg_util = max(120.0, float(largura) - (contorno * 2.5))
    for p in palavras:
        teste = (atual + " " + p).strip()
        if _largura_linha_real(teste, fonte, draw, 0) <= larg_util or not atual:
            atual = teste
        else:
            linhas.append(atual)
            atual = p
    if atual:
        linhas.append(atual)
    return linhas


def _ajustar(texto, draw, largura, altura_max, max_tam=148, min_tam=34):
    """Reduz automaticamente o tamanho da fonte até que TODAS as palavras e linhas (incluindo contorno/faixa)
    caibam 100% dentro da largura e altura seguras — garantindo ZERO palavras cortadas."""
    palavras = (texto or "").split()
    if not palavras:
        f = _fonte(min_tam)
        return f, [], min_tam

    for max_linhas_perm in (3, 4):
        tam = max_tam
        while tam >= min_tam:
            f = _fonte(tam)
            contorno = max(4, tam // 14)
            pad_extra = (tam * 0.28) + (contorno * 2.5)
            larg_segura = max(140.0, float(largura) - pad_extra)

            # 1) Verifica se nenhuma palavra isolada ultrapassa a largura segura
            maior_palavra = max(draw.textlength(p, font=f) for p in palavras)
            if maior_palavra <= larg_segura:
                linhas = _quebrar(texto, f, larg_segura, draw, contorno=0)
                maior_linha = max((_largura_linha_real(l, f, draw, contorno) for l in linhas), default=0.0)
                alt = len(linhas) * tam * 1.08
                if len(linhas) <= max_linhas_perm and alt <= altura_max and maior_linha <= (largura - 8):
                    return f, linhas, tam
            tam -= 4

    f = _fonte(min_tam)
    contorno = max(3, min_tam // 14)
    return f, _quebrar(texto, f, max(140.0, largura - 24), draw, contorno=contorno), min_tam


def _remover_fundo_solido_avatar(av_rgba):
    """Se o avatar enviado for JPG/PNG com fundo sólido/gradiente simples, remove o fundo
    automaticamente por flood-fill a partir das bordas para criar um recorte limpo."""
    aw, ah = av_rgba.size
    extrema_alpha = av_rgba.getchannel("A").getextrema()
    if extrema_alpha and extrema_alpha[0] < 210:
        return av_rgba, True

    px = av_rgba.load()
    cantos = [
        px[0, 0][:3],
        px[aw - 1, 0][:3],
        px[0, min(ah - 1, int(ah * 0.25))][:3],
        px[aw - 1, min(ah - 1, int(ah * 0.25))][:3],
    ]
    r_bg = sum(c[0] for c in cantos) // len(cantos)
    g_bg = sum(c[1] for c in cantos) // len(cantos)
    b_bg = sum(c[2] for c in cantos) // len(cantos)

    # Verifica se os cantos superiores são razoavelmente uniformes (fundo de estúdio/cor sólida)
    var_cantos = max(abs(c[0] - r_bg) + abs(c[1] - g_bg) + abs(c[2] - b_bg) for c in cantos)
    if var_cantos > 115:
        return av_rgba, False

    # Flood-fill BFS nas bordas (em resolução reduzida para velocidade instantânea)
    sw, sh = min(220, aw), min(220, ah)
    small = av_rgba.resize((sw, sh), Image.BILINEAR)
    spx = small.load()
    visitado = [[False] * sh for _ in range(sw)]
    mask_s = Image.new("L", (sw, sh), 255)
    mp = mask_s.load()
    fila = []

    for x in range(sw):
        fila.append((x, 0))
    for y in range(sh):
        fila.append((0, y))
        fila.append((sw - 1, y))

    limiar = 62
    while fila:
        cx, cy = fila.pop()
        if cx < 0 or cx >= sw or cy < 0 or cy >= sh or visitado[cx][cy]:
            continue
        visitado[cx][cy] = True
        r, g, b, _ = spx[cx, cy]
        dist = abs(r - r_bg) + abs(g - g_bg) + abs(b - b_bg)
        if dist <= limiar:
            mp[cx, cy] = 0
            fila.append((cx + 1, cy))
            fila.append((cx - 1, cy))
            fila.append((cx, cy + 1))
            fila.append((cx, cy - 1))

    mask_full = mask_s.resize((aw, ah), Image.BILINEAR).filter(ImageFilter.GaussianBlur(1.8))
    out = av_rgba.copy()
    out.putalpha(mask_full)
    return out, True


def _aplicar_avatar_canal(base, avatar_path, lado_texto="esquerda"):
    """Insere o Avatar do Canal no lado oposto ao texto com recorte inteligente, rim-light e sombra 3D."""
    if not avatar_path or not os.path.exists(avatar_path):
        return base
    try:
        av = Image.open(avatar_path).convert("RGBA")
        aw, ah = av.size
        if aw < 20 or ah < 20:
            return base

        av_cut, tem_recorte = _remover_fundo_solido_avatar(av)

        if tem_recorte:
            target_h = int(H * 0.90)
            escala = min((W * 0.44) / aw, target_h / ah)
            nw, nh = max(1, int(aw * escala)), max(1, int(ah * escala))
            av_res = av_cut.resize((nw, nh), Image.LANCZOS)
            x_av = (W - nw - 28) if lado_texto != "direita" else 28
            y_av = max(18, H - nh)

            base_rgba = base.convert("RGBA")
            alpha_ch = av_res.getchannel("A")

            # Sombra projetada suave + Rim Glow sutil para integrar o avatar na cena
            sombra = Image.new("RGBA", (nw + 40, nh + 40), (0, 0, 0, 0))
            sombra_mask = Image.new("L", (nw + 40, nh + 40), 0)
            sombra_mask.paste(alpha_ch, (20, 20))
            sombra_mask = sombra_mask.filter(ImageFilter.GaussianBlur(14))
            preto_sombra = Image.new("RGBA", (nw + 40, nh + 40), (0, 0, 0, 210))
            sombra = Image.composite(preto_sombra, sombra, sombra_mask)
            base_rgba.alpha_composite(sombra, (max(0, x_av - 12), max(0, y_av - 8)))

            base_rgba.alpha_composite(av_res, (x_av, y_av))
            return base_rgba.convert("RGB")
        else:
            # Imagem com cenário complexo: mescla com máscara elíptica/gradiente suave sem bloco quadrado duro
            lado_av = "direita" if lado_texto != "direita" else "esquerda"
            larg_av = int(W * 0.45)
            av_fit = ImageOps.fit(av.convert("RGB"), (larg_av, H), Image.LANCZOS, centering=(0.5, 0.32))
            av_fit = ImageEnhance.Contrast(av_fit).enhance(1.12)
            mask = Image.new("L", (larg_av, H), 255)
            md = ImageDraw.Draw(mask)
            fade_w = int(larg_av * 0.42)
            for x_m in range(fade_w):
                t = x_m / max(1, fade_w)
                alpha_m = int(255 * (t * t * (3 - 2 * t)))  # smoothstep
                pos_x = x_m if lado_av == "direita" else (larg_av - 1 - x_m)
                md.line([(pos_x, 0), (pos_x, H)], fill=alpha_m)
            base_out = base.copy()
            x_dest = (W - larg_av) if lado_av == "direita" else 0
            base_out.paste(av_fit, (x_dest, 0), mask)
            return base_out
    except Exception as e_av:
        print("Aviso ao mesclar avatar na thumb:", e_av)
        return base


def _detectar_zona_livre_texto(base_rgb, lado_pref="esquerda", forcar_lado=False):
    """Analisa a densidade de detalhes/bordas na metade esquerda vs direita (e topo vs base) da imagem 16:9
    para posicionar o texto onde há mais espaço livre (negative space), evitando cobrir o rosto/corpo do personagem."""
    lado_final = "direita" if str(lado_pref or "").lower() == "direita" else "esquerda"
    pos_v_auto = "topo"
    try:
        small = base_rgb.convert("L").resize((160, 90), Image.BILINEAR)
        edges = small.filter(ImageFilter.FIND_EDGES)
        px = edges.load()

        def _energia_regiao(x0, y0, x1, y1):
            soma = 0
            cont = 0
            for yy in range(y0, y1):
                for xx in range(x0, x1):
                    soma += px[xx, yy]
                    cont += 1
            return (soma / max(1, cont))

        # Compara os 42% da esquerda vs 42% da direita na faixa central onde ficam rostos/personagens
        en_esq = _energia_regiao(6, 12, 68, 78)
        en_dir = _energia_regiao(92, 12, 154, 78)
        if not forcar_lado:
            if lado_final == "esquerda" and en_esq > en_dir * 1.22:
                lado_final = "direita"
            elif lado_final == "direita" and en_dir > en_esq * 1.22:
                lado_final = "esquerda"

        # No lado escolhido, verifica se o terço superior é mais limpo que o centro/base
        x_ini, x_fim = (6, 68) if lado_final == "esquerda" else (92, 154)
        en_topo = _energia_regiao(x_ini, 8, x_fim, 42)
        en_meio = _energia_regiao(x_ini, 28, x_fim, 64)
        pos_v_auto = "topo" if en_topo <= en_meio * 1.15 else "centro"
    except Exception:
        pass
    return lado_final, pos_v_auto


def gerar(
    fundo_path,
    texto,
    destaque,
    estilo,
    lado,
    saida,
    cor_destaque="#FFD400",
    avatar_path="",
    compositar_avatar=False,
    posicao_vertical="auto",
    escala_texto=1.0,
    forcar_lado=False,
):
    texto = (texto or "").upper().strip()
    destaque = (destaque or "").upper().strip()
    base = _cover(Image.open(fundo_path)) if fundo_path and os.path.exists(fundo_path) else Image.new("RGB", (W, H), (20, 20, 24))

    lado_auto, pos_v_sug = _detectar_zona_livre_texto(base, lado_pref=lado, forcar_lado=bool(forcar_lado or compositar_avatar))
    lado = lado_auto

    if compositar_avatar and avatar_path and os.path.exists(avatar_path):
        base = _aplicar_avatar_canal(base, avatar_path, lado_texto=lado)

    if estilo == "contraste":
        base = ImageOps.grayscale(base).convert("RGB")
        base = ImageEnhance.Contrast(base).enhance(1.26)
    else:
        base = ImageEnhance.Contrast(base).enhance(1.10)
        base = ImageEnhance.Color(base).enhance(1.10)
        try:
            base = base.filter(ImageFilter.UnsharpMask(radius=1.3, percent=110, threshold=3))
        except Exception:
            pass

    # Se texto estiver vazio (ex.: arte pura ou texto nativo renderizado pelo GPT), salva apenas a base tratada
    if not texto:
        base.save(saida, "PNG")
        return saida

    escala_f = max(0.45, min(1.45, float(escala_texto or 1.0)))

    if estilo == "misterio":
        preto = Image.new("RGB", (W, H), (0, 0, 0))
        vin = Image.new("L", (W, H), 0)
        ImageDraw.Draw(vin).ellipse([-W * 0.12, -H * 0.18, W * 1.12, H * 1.18], fill=255)
        vin = vin.filter(ImageFilter.GaussianBlur(110))
        base = Image.composite(base, preto, vin)

    base_rgba = base.convert("RGBA")
    txt_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ext_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    shd_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(txt_layer)
    de = ImageDraw.Draw(ext_layer)
    ds = ImageDraw.Draw(shd_layer)

    margem_x = 54
    margem_y = 48
    # Limita a largura máxima da caixa de texto a 38% da tela para NUNCA invadir o centro/rosto do personagem!
    area_w = int(W * min(0.44, max(0.28, 0.38 * (0.85 + 0.15 * escala_f))))
    altura_util = int((H - (margem_y * 2)) * 0.68)
    max_tam_calc = max(48, min(142, int(round(112 * escala_f))))
    min_tam_calc = max(28, min(54, int(round(34 * escala_f))))
    fonte, linhas, tam = _ajustar(texto, d, area_w, altura_util, max_tam=max_tam_calc, min_tam=min_tam_calc)
    contorno = max(5, tam // 11)
    passo_y = tam * 1.07
    alt_total = len(linhas) * passo_y

    pos_v = str(posicao_vertical or "auto").lower().strip()
    if pos_v == "auto":
        pos_v = pos_v_sug
    if pos_v in ("topo", "top", "alto", "superior"):
        y = max(margem_y, int(H * 0.10))
    elif pos_v in ("base", "bottom", "baixo", "inferior"):
        # Mantém fora do canto inferior direito do timestamp do YouTube
        margem_inf = 98 if lado == "direita" else 58
        y = max(margem_y, H - margem_inf - alt_total)
    else:
        y = max(margem_y, min(H - margem_y - alt_total, (H - alt_total) * 0.34))

    # Almofada de contraste localizada APENAS atrás do bloco de texto (preserva 100% da iluminação da arte)
    if linhas and estilo != "faixa":
        larg_max_bloco = max((_largura_linha_real(l, fonte, d, contorno) for l in linhas), default=240.0)
        bx0 = (W - margem_x - larg_max_bloco) if lado == "direita" else margem_x
        bx1 = bx0 + larg_max_bloco
        cushion = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        cd = ImageDraw.Draw(cushion)
        cd.rounded_rectangle(
            [max(0, bx0 - 38), max(0, y - 28), min(W, bx1 + 38), min(H, y + alt_total + 28)],
            radius=36,
            fill=(0, 0, 0, 108),
        )
        cushion = cushion.filter(ImageFilter.GaussianBlur(36))
        base_rgba.alpha_composite(cushion)

    cor_dest = cor_destaque if estilo != "contraste" else "#FFFFFF"
    cor_base = "#FFD400" if estilo == "contraste" else "#FFFFFF"
    dest_set = {w.strip(".,!?:;\"'") for w in destaque.split() if w.strip(".,!?:;\"'")}
    extrude_depth = max(3, min(8, tam // 16))

    for linha in linhas:
        largura_linha = _largura_linha_real(linha, fonte, d, contorno=0)
        if lado == "direita":
            x0 = max(margem_x, W - margem_x - largura_linha - contorno)
        else:
            x0 = margem_x
        if x0 + largura_linha + contorno > W - margem_x:
            x0 = max(36, W - margem_x - largura_linha - contorno)

        if estilo == "faixa":
            pad = tam * 0.12
            rx0 = max(24, x0 - pad)
            rx1 = min(W - 24, x0 + largura_linha + pad)
            d.rounded_rectangle([rx0, y - pad * 0.22, rx1, y + tam * 1.04], radius=10, fill="#D1121B")

        x = x0
        palavras_linha = linha.split()
        for idx_p, palavra in enumerate(palavras_linha):
            p_limpa = palavra.strip(".,!?:;\"'")
            cor = cor_dest if p_limpa in dest_set else cor_base
            if estilo == "faixa":
                cor = "#FFFFFF" if cor == cor_base else "#FFD400"
            sw = contorno if estilo != "faixa" else max(2, contorno // 2)
            # Sombra difusa externa
            ds.text(
                (x + extrude_depth + 4, y + extrude_depth + 6),
                palavra,
                font=fonte,
                fill=(0, 0, 0, 215),
                stroke_width=sw + 4,
                stroke_fill=(0, 0, 0, 215),
            )
            # Extrusão 3D discreta e sólida
            for step_e in range(extrude_depth, 0, -1):
                de.text(
                    (x + step_e, y + step_e),
                    palavra,
                    font=fonte,
                    fill=(8, 10, 15, 255),
                    stroke_width=sw,
                    stroke_fill=(8, 10, 15, 255),
                )
            # Texto principal com contorno escuro nítido
            d.text((x, y), palavra, font=fonte, fill=cor, stroke_width=sw, stroke_fill="#07090E")
            suf = " " if idx_p < len(palavras_linha) - 1 else ""
            x += d.textlength(palavra + suf, font=fonte)
        y += passo_y

    shd_layer = shd_layer.filter(ImageFilter.GaussianBlur(8))
    base_rgba.alpha_composite(shd_layer)
    base_rgba.alpha_composite(ext_layer)
    base_rgba.alpha_composite(txt_layer)
    base_out = base_rgba.convert("RGB")

    if estilo == "misterio":
        dm = ImageDraw.Draw(base_out)
        cx = int(W * 0.72) if lado != "direita" else int(W * 0.28)
        cy, r = int(H * 0.5), int(H * 0.26)
        for k in range(10):
            dm.ellipse([cx - r - k, cy - r - k, cx + r + k, cy + r + k], outline="#E11D2A")

    base_out.save(saida, "PNG")
    return saida


