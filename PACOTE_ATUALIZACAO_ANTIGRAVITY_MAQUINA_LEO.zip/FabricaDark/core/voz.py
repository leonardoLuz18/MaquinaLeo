"""VozLab: narração por blocos. Motores: Edge (grátis, sem chave) e Gemini TTS (sua chave grátis do Google AI Studio)."""
import asyncio
import base64
import os
import re
import wave

import requests

VOZES_EDGE = {
    "pt": [
        ("pt-BR-AntonioNeural", "Antonio — masculina, grave"),
        ("pt-BR-FranciscaNeural", "Francisca — feminina"),
        ("pt-BR-ThalitaMultilingualNeural", "Thalita — feminina, natural"),
        ("pt-BR-MacerioMultilingualNeural", "Macerio — masculina, natural"),
        ("pt-PT-DuarteNeural", "Duarte — masculina (Portugal)"),
    ],
    "en": [
        ("en-US-GuyNeural", "Guy — male, documentary"),
        ("en-US-ChristopherNeural", "Christopher — male, deep"),
        ("en-US-AndrewMultilingualNeural", "Andrew — male, warm"),
        ("en-US-BrianMultilingualNeural", "Brian — male, casual"),
        ("en-US-EricNeural", "Eric — male"),
        ("en-GB-RyanNeural", "Ryan — male (UK)"),
        ("en-US-AriaNeural", "Aria — female"),
        ("en-US-JennyNeural", "Jenny — female"),
        ("en-GB-SoniaNeural", "Sonia — female (UK)"),
    ],
    "es": [
        ("es-MX-JorgeNeural", "Jorge — masculina (México)"),
        ("es-MX-DaliaNeural", "Dalia — femenina (México)"),
        ("es-ES-AlvaroNeural", "Álvaro — masculina (España)"),
        ("es-US-AlonsoNeural", "Alonso — masculina (EUA)"),
        ("es-AR-TomasNeural", "Tomás — masculina (Argentina)"),
    ],
    "fr": [
        ("fr-FR-HenriNeural", "Henri — masculine, grave et documentaire (France)"),
        ("fr-FR-RemyMultilingualNeural", "Rémy — masculine, naturelle et dynamique (France)"),
        ("fr-FR-DeniseNeural", "Denise — féminine, claire (France)"),
        ("fr-FR-VivienneMultilingualNeural", "Vivienne — féminine, naturelle (France)"),
        ("fr-CA-AntoineNeural", "Antoine — masculine (Québec/Canada)"),
    ],
}

VOZES_GEMINI = [
    ("Charon", "informativa, grave"), ("Fenrir", "intensa"), ("Orus", "firme"), ("Algenib", "rouca"),
    ("Iapetus", "clara"), ("Enceladus", "sussurrada"), ("Umbriel", "tranquila"), ("Alnilam", "firme"),
    ("Rasalgethi", "informativa"), ("Sadaltager", "experiente"), ("Schedar", "equilibrada"), ("Gacrux", "madura"),
    ("Kore", "feminina firme"), ("Aoede", "feminina leve"), ("Leda", "feminina jovem"), ("Despina", "feminina suave"),
    ("Sulafat", "feminina calorosa"), ("Zephyr", "feminina clara"), ("Puck", "animada"), ("Achird", "amigável"),
]


def dividir_blocos(roteiro, max_chars=900):
    unidades = []
    for p in re.split(r"\n+", roteiro or ""):
        p = p.strip()
        if not p:
            continue
        if len(p) > max_chars:
            unidades += [f.strip() for f in re.split(r"(?<=[\.\!\?…])\s+", p) if f.strip()]
        else:
            unidades.append(p)
    blocos, buf = [], ""
    for u in unidades:
        if buf and len(buf) + len(u) + 1 > max_chars:
            blocos.append(buf)
            buf = u
        else:
            buf = f"{buf}\n{u}" if buf else u
    if buf:
        blocos.append(buf)
    return [{"i": i + 1, "texto": t, "arquivo": "", "duracao": 0, "status": "pendente", "erro": ""} for i, t in enumerate(blocos)]


def gerar_edge(texto, voz, caminho_sem_ext, velocidade="+0%", tom="+0Hz"):
    import edge_tts

    path = caminho_sem_ext + ".mp3"

    async def _go():
        com = edge_tts.Communicate(texto, voz, rate=velocidade or "+0%", pitch=tom or "+0Hz")
        await com.save(path)

    asyncio.run(_go())
    if not os.path.exists(path) or os.path.getsize(path) < 500:
        raise RuntimeError("O Edge não devolveu áudio (verifique a internet ou troque a voz).")
    return path


def gerar_gemini(texto, voz, caminho_sem_ext, chave, modelo="gemini-2.5-flash-preview-tts", estilo=""):
    if not chave:
        raise RuntimeError("Coloque sua chave do Gemini em Configurações (aistudio.google.com → Get API key).")
    prompt = f"{estilo.strip()}:\n{texto}" if estilo.strip() else texto
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voz}}},
        },
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"
    r = requests.post(url, params={"key": chave}, json=body, timeout=180)
    if not r.ok:
        try:
            msg = r.json()["error"]["message"]
        except Exception:
            msg = r.text[:300]
        raise RuntimeError(f"Gemini: {msg}")
    try:
        part = r.json()["candidates"][0]["content"]["parts"][0]["inlineData"]
    except Exception:
        raise RuntimeError("Gemini não devolveu áudio para este bloco (tente de novo).")
    pcm = base64.b64decode(part["data"])
    rate = 24000
    m = re.search(r"rate=(\d+)", part.get("mimeType", ""))
    if m:
        rate = int(m.group(1))
    path = caminho_sem_ext + ".wav"
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return path


PROVEDORES = {
    "edge": {"nome": "Edge (Microsoft)", "chave": False, "info": "Grátis e sem chave. Vozes neurais da Microsoft. Bom para começar; sem garantia de uso comercial."},
    "gemini": {"nome": "Gemini (Google AI Studio)", "chave": True, "info": "Usa suas chaves do Gemini. Gratuito: poucos pedidos por dia e lento (bom para amostras e roteiros curtos). Com faturamento: ~US$ 0,40 por 25 min de áudio."},
    "azure": {"nome": "Azure AI Speech", "chave": True, "info": "Plano Free (F0): 500 mil caracteres/mês de voz neural. Standard: US$ 15 por 1 milhão de caracteres. Precisa da região (ex.: brazilsouth)."},
    "elevenlabs": {"nome": "ElevenLabs", "chave": True, "info": "Free: 10 mil créditos/mês, só vozes padrão e sem licença comercial. Starter (US$ 5–6/mês, 30 mil créditos) libera uso comercial e vozes da biblioteca."},
    "darkplanner": {"nome": "DarkPlanner", "chave": True, "info": "Usa a API do seu plano DarkPlanner (Pro, Plus ou Master): cole a chave dpk_… do painel. No Estúdio 1 clique a narração inteira sai num pedido só (gasta 1 áudio do limite diário) e já vem com a legenda certinha no tempo."},
    "fish": {"nome": "Fish Audio", "chave": True, "info": "US$ 15 por 1 milhão de bytes de texto (~US$ 0,30 num roteiro de 20 min). Você usa o ID de uma voz (modelo) do fish.audio. O plano pago é o que dá licença comercial."},
}


def _xml(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def gerar_azure(texto, voz, caminho_sem_ext, chave, regiao, velocidade="+0%"):
    lang = "-".join(voz.split("-")[:2]) if voz.count("-") >= 2 else "pt-BR"
    ssml = (f"<speak version='1.0' xml:lang='{lang}' xmlns='http://www.w3.org/2001/10/synthesis'><voice name='{voz}'>"
            f"<prosody rate='{velocidade or '+0%'}'>{_xml(texto)}</prosody></voice></speak>")
    r = requests.post(f"https://{regiao}.tts.speech.microsoft.com/cognitiveservices/v1", data=ssml.encode("utf-8"), timeout=180,
                      headers={"Ocp-Apim-Subscription-Key": chave, "Content-Type": "application/ssml+xml",
                               "X-Microsoft-OutputFormat": "audio-24khz-96kbitrate-mono-mp3", "User-Agent": "FabricaDark"})
    if not r.ok:
        raise RuntimeError(f"Azure {r.status_code}: {r.text[:200] or 'verifique chave e região'}")
    path = caminho_sem_ext + ".mp3"
    with open(path, "wb") as f:
        f.write(r.content)
    return path


def vozes_azure(chave, regiao):
    r = requests.get(f"https://{regiao}.tts.speech.microsoft.com/cognitiveservices/voices/list", headers={"Ocp-Apim-Subscription-Key": chave}, timeout=30)
    r.raise_for_status()
    return [(v["ShortName"], f"{v.get('LocalName', v['ShortName'])} — {v.get('Gender','')} ({v.get('Locale','')})") for v in r.json()
            if v.get("Locale", "")[:2] in ("pt", "en", "es", "fr")]


def gerar_eleven(texto, voz_id, caminho_sem_ext, chave, modelo="eleven_multilingual_v2"):
    r = requests.post(f"https://api.elevenlabs.io/v1/text-to-speech/{voz_id}", params={"output_format": "mp3_44100_128"}, timeout=300,
                      headers={"xi-api-key": chave, "Content-Type": "application/json"},
                      json={"text": texto, "model_id": modelo or "eleven_multilingual_v2"})
    if not r.ok:
        raise RuntimeError(f"ElevenLabs {r.status_code}: {r.text[:200]}")
    path = caminho_sem_ext + ".mp3"
    with open(path, "wb") as f:
        f.write(r.content)
    return path


def vozes_eleven(chave):
    r = requests.get("https://api.elevenlabs.io/v1/voices", headers={"xi-api-key": chave}, timeout=30)
    r.raise_for_status()
    return [(v["voice_id"], f"{v['name']} ({(v.get('labels') or {}).get('accent','')} {(v.get('labels') or {}).get('gender','')})".replace("( )", "").strip())
            for v in r.json().get("voices", [])]


def plano_eleven(chave):
    r = requests.get("https://api.elevenlabs.io/v1/user/subscription", headers={"xi-api-key": chave}, timeout=20)
    r.raise_for_status()
    j = r.json()
    return j.get("tier", ""), j.get("character_count", 0), j.get("character_limit", 0)


def gerar_fish(texto, voz_id, caminho_sem_ext, chave, modelo="s1"):
    body = {"text": texto, "format": "mp3", "mp3_bitrate": 128}
    if voz_id:
        body["reference_id"] = voz_id
    r = requests.post("https://api.fish.audio/v1/tts", json=body, timeout=300,
                      headers={"Authorization": f"Bearer {chave}", "Content-Type": "application/json", "model": modelo or "s1"})
    if not r.ok:
        raise RuntimeError(f"Fish Audio {r.status_code}: {r.text[:200]}")
    path = caminho_sem_ext + ".mp3"
    with open(path, "wb") as f:
        f.write(r.content)
    return path


# ---------------------------------------------------------------- DarkPlanner (API de áudio + Conta Pro conectada)
DP_BASE = "https://app.darkplanner.com.br/api/v1/audio"
DP_API_ROOT = "https://app.darkplanner.com.br/api"


def _dp_headers(chave=None):
    if chave and str(chave).startswith("dpk_"):
        return {"X-API-Key": chave, "Content-Type": "application/json"}, DP_BASE
    from core import darkplanner_sync
    tok = chave.replace("Bearer ", "").strip() if (chave and not str(chave).startswith("dpk_")) else darkplanner_sync.token()
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}, f"{DP_API_ROOT}/audio-tts"


def _dp(metodo, caminho, chave=None, **kw):
    import time as _t

    headers, base = _dp_headers(chave)
    # mapeia /download/{id} e /status/{id} quando usa /audio-tts com Bearer token
    if base.endswith("/audio-tts"):
        if caminho.startswith("/download/"):
            jid = caminho.split("/download/")[1]
            caminho = f"/job/{jid}/download"
        elif caminho.startswith("/status/"):
            jid = caminho.split("/status/")[1]
            caminho = f"/history?limit=30&_jid={jid}"
    for tentativa in range(4):
        r = requests.request(metodo, base + caminho, headers=headers, timeout=60, **kw)
        diario = any(x in r.text.lower() for x in ("diário", "diario", "daily", "crédito", "credito"))
        if r.status_code == 429 and tentativa < 3 and not diario:
            _t.sleep(float(r.headers.get("Retry-After") or 5))
            continue
        if not r.ok:
            erros = {401: "chave/sessão inválida", 403: "plano sem acesso à API ou assinatura inativa", 429: "limite de áudios do dia atingido"}
            raise RuntimeError(f"DarkPlanner {r.status_code}: {erros.get(r.status_code, '')} {r.text[:160]}".strip())
        j = r.json()
        if base.endswith("/audio-tts") and "_jid=" in caminho:
            jid = caminho.split("_jid=")[1]
            itens = j if isinstance(j, list) else (j.get("items") or j.get("history") or j.get("jobs") or [])
            achou = next((x for x in itens if (x.get("job_id") or x.get("jobId") or x.get("id")) == jid), None)
            return achou or {"status": "processing"}
        return j
    raise RuntimeError("DarkPlanner: muitas consultas seguidas, tente de novo em instantes")


def darkplanner_vozes(chave=None):
    from core import darkplanner_sync
    fav_ids = {}
    try:
        favs = (darkplanner_sync.req("GET", "/audio-tts/favorites") or {}).get("favorites", [])
        for f in favs:
            fav_ids[f.get("voice_id")] = f"⭐ {f.get('voice_name', f.get('voice_id'))} (Favorita)"
    except Exception:
        pass
    d = _dp("GET", "/voices", chave)
    todas = []
    for vid, label in fav_ids.items():
        todas.append((vid, label))
    for x in d.get("voices", []):
        if x["id"] in fav_ids:
            continue
        todas.append((x["id"], f"{x.get('name', x['id'])}" + (f" ({x['gender']})" if x.get("gender") else "")))
    return todas


def darkplanner_uso(chave=None):
    return _dp("GET", "/usage", chave)


def _vel_dp(velocidade):
    try:
        return max(0.5, min(1.5, 1 + float(str(velocidade or "+0%").replace("%", "")) / 100))
    except ValueError:
        return 1.0


def darkplanner_gerar(texto, voz_id, caminho_sem_ext, chave, velocidade="+0%", checar=None, aviso=None, limite_s=2400):
    """Gera um áudio na DarkPlanner e baixa o MP3 e a legenda (.srt) com o tempo de cada fala. Devolve (mp3, srt|None)."""
    import time as _t

    if not voz_id:
        raise RuntimeError("Escolha uma voz da DarkPlanner.")
    job = _dp("POST", "/generate", chave, json={"text": texto, "voice_id": voz_id, "title": os.path.basename(caminho_sem_ext),
                                                  "speed": _vel_dp(velocidade), "subtitle_words": 6, "subtitle_case": "normal"})
    jid = job.get("job_id")
    if not jid:
        raise RuntimeError(f"DarkPlanner não devolveu o job: {str(job)[:150]}")
    inicio = _t.time()
    while True:
        if checar:
            checar()
        _t.sleep(4)  # a API aceita no máximo 1 consulta por segundo
        st = _dp("GET", f"/status/{jid}", chave)
        s = st.get("status")
        if s == "completed":
            break
        if s in ("failed", "blocked", "expired"):
            raise RuntimeError(f"DarkPlanner: áudio {s}" + (f" — {st.get('error_message')}" if st.get("error_message") else ""))
        if aviso:
            aviso(f"DarkPlanner gerando a narração… ({int(_t.time() - inicio)}s)")
        if _t.time() - inicio > limite_s:
            raise RuntimeError("DarkPlanner demorou demais para gerar o áudio")
    dl = _dp("GET", f"/download/{jid}", chave)

    def baixar(url, destino):
        if url.startswith("/"):
            url = DP_BASE.split("/api/")[0] + url
        r = requests.get(url, timeout=300)
        r.raise_for_status()
        with open(destino, "wb") as f:
            f.write(r.content)
        return destino

    mp3 = baixar(dl["audio_url"], caminho_sem_ext + ".mp3")
    srt = None
    if dl.get("srt_url"):
        try:
            srt = baixar(dl["srt_url"], caminho_sem_ext + ".srt")
        except Exception:
            srt = None
    return mp3, srt


def gerar_com(motor, texto, cfg, destino, settings, conta=None):
    """Gera um áudio com o motor escolhido. conta = item do cofre (para motores com chave)."""
    if motor == "edge":
        return gerar_edge(texto, cfg.get("voz_edge", "pt-BR-AntonioNeural"), destino, cfg.get("velocidade", "+0%"), cfg.get("tom", "+0Hz"))
    if motor == "gemini":
        from core import gemini as gm

        return gerar_gemini(texto, cfg.get("voz_gemini", "Charon"), destino, conta["key"] if conta else gm.primeira_chave(),
                            settings.get("gemini_tts_modelo") or "gemini-2.5-flash-preview-tts", cfg.get("estilo", ""))
    if motor == "azure":
        return gerar_azure(texto, cfg.get("voz_azure") or cfg.get("voz_edge", "pt-BR-AntonioNeural"), destino, conta["key"], conta.get("regiao", "brazilsouth"), cfg.get("velocidade", "+0%"))
    if motor == "elevenlabs":
        if not cfg.get("voz_elevenlabs"):
            raise RuntimeError("Escolha uma voz do ElevenLabs.")
        return gerar_eleven(texto, cfg["voz_elevenlabs"], destino, conta["key"], cfg.get("modelo_elevenlabs"))
    if motor == "fish":
        return gerar_fish(texto, cfg.get("voz_fish", ""), destino, conta["key"], cfg.get("modelo_fish") or "s1")
    if motor == "darkplanner":
        return darkplanner_gerar(texto, cfg.get("voz_darkplanner", ""), destino, conta["key"] if conta else None, cfg.get("velocidade", "+0%"))[0]
    raise RuntimeError("Motor de voz desconhecido.")


def gerar_bloco(bloco, settings, pasta, voz_cfg):
    from core import chaves

    destino = os.path.join(pasta, "voz", f"bloco_{bloco['i']:03d}")
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    for ext in (".mp3", ".wav"):
        if os.path.exists(destino + ext):
            os.remove(destino + ext)
    motor = voz_cfg.get("motor", "edge")
    if motor in ("edge", "darkplanner"):
        contas = [c for c in chaves.lista(storage_db(), motor) if c.get("status") != "invalida"] or [None]
    elif motor == "gemini":
        contas = chaves.ordem("gemini") or [None]
    else:
        contas = [c for c in chaves.lista(storage_db(), motor) if c.get("status") != "invalida"]
        if not contas:
            raise RuntimeError(f"Conecte uma conta de {PROVEDORES[motor]['nome']} em Conexões.")
    ultimo = None
    for conta in contas:
        try:
            path = gerar_com(motor, bloco["texto"], voz_cfg, destino, settings, conta)
            chaves.consumo_add("tts", motor, caracteres=len(bloco["texto"]), bytes=len(bloco["texto"].encode("utf-8")))
            return path
        except Exception as e:
            ultimo = e
            msg = str(e).lower()
            if conta and any(x in msg for x in ("quota", "429", "limit", "credit", "insufficient", "401", "payment")):
                continue  # próxima conta
            raise
    raise RuntimeError(str(ultimo))


def storage_db():
    from core import storage

    return storage.load()


def juntar(arquivos, saida, ffmpeg, pausa=0.35):
    import subprocess

    args = [ffmpeg, "-y"]
    for a in arquivos:
        args += ["-i", a]
    partes = []
    for i in range(len(arquivos)):
        partes.append(f"[{i}:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=mono,apad=pad_dur={pausa}[a{i}]")
    fc = ";".join(partes) + ";" + "".join(f"[a{i}]" for i in range(len(arquivos))) + f"concat=n={len(arquivos)}:v=0:a=1[out]"
    args += ["-filter_complex", fc, "-map", "[out]", "-c:a", "libmp3lame", "-b:a", "192k", saida]
    flags = 0x08000000 if os.name == "nt" else 0
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=flags)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-800:])
    return saida
