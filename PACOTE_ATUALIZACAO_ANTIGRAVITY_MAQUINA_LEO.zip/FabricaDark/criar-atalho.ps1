# Cria o atalho "Fabrica Dark" na Area de Trabalho e no Menu Iniciar (abre como aplicativo, sem janela preta)
$pasta = $PSScriptRoot
$alvo = Join-Path $pasta ".venv\Scripts\pythonw.exe"
$icone = Join-Path $pasta "static\icone.ico"
$sh = New-Object -ComObject WScript.Shell
foreach ($dest in @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Programs"))) {
    $lnk = $sh.CreateShortcut((Join-Path $dest "Fabrica Dark.lnk"))
    $lnk.TargetPath = $alvo
    $lnk.Arguments = "app.py --app"
    $lnk.WorkingDirectory = $pasta
    $lnk.IconLocation = "$icone,0"
    $lnk.Description = "Fabrica Dark - producao de canais dark"
    $lnk.Save()
}
