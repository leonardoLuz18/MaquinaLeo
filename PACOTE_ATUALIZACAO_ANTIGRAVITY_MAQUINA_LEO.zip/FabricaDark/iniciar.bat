@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Fabrica Dark - Inicializando

rem ============================================================================
rem 0. Encerra instancia antiga em 2o plano e limpa cache da janela do app
rem ============================================================================
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { (($_.Name -match '^pythonw?\.exe$') -and ($_.CommandLine -like '*app.py*')) -or (($_.Name -match '^(chrome|msedge)\.exe$') -and ($_.CommandLine -like '*janela-app*')) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep -Milliseconds 800" >nul 2>nul
del /f /q "data\app.lock" >nul 2>nul
rmdir /s /q "data\janela-app\Default\Cache" >nul 2>nul
rmdir /s /q "data\janela-app\Default\Code Cache" >nul 2>nul
rmdir /s /q "data\janela-app\Default\GPUCache" >nul 2>nul
rmdir /s /q "data\janela-app\Default\Network\Cache" >nul 2>nul

rem ============================================================================
rem 1. Verifica se a .venv ja existe e esta funcionando de verdade
rem ============================================================================
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import sys; print(sys.version)" >nul 2>nul
    if !errorlevel!==0 goto deps
    echo  Ambiente .venv anterior incompleto. Recriando...
    rmdir /s /q ".venv" >nul 2>nul
)

echo.
echo  ========================================================================
echo   Primeira execucao: preparando a Fabrica Dark (so acontece uma vez)...
echo  ========================================================================
echo.

rem ============================================================================
rem 2. Procura o Python real instalado no Windows (ignorando atalho da Store)
rem ============================================================================
set "PY_CMD="

where py >nul 2>nul
if !errorlevel!==0 (
    py -3 -c "import sys; print(sys.executable)" >nul 2>nul
    if !errorlevel!==0 set "PY_CMD=py -3"
)

if not defined PY_CMD (
    for %%P in (
        "%LocalAppData%\Programs\Python\Python313\python.exe"
        "%LocalAppData%\Programs\Python\Python312\python.exe"
        "%LocalAppData%\Programs\Python\Python311\python.exe"
        "%LocalAppData%\Programs\Python\Python310\python.exe"
        "%ProgramFiles%\Python313\python.exe"
        "%ProgramFiles%\Python312\python.exe"
        "%ProgramFiles%\Python311\python.exe"
        "%ProgramFiles%\Python310\python.exe"
        "C:\Python313\python.exe"
        "C:\Python312\python.exe"
        "C:\Python311\python.exe"
        "C:\Python310\python.exe"
        "%UserProfile%\anaconda3\python.exe"
        "%UserProfile%\miniconda3\python.exe"
    ) do (
        if not defined PY_CMD (
            if exist "%%~P" (
                "%%~P" -c "import sys; print(sys.version)" >nul 2>nul
                if !errorlevel!==0 set "PY_CMD="%%~P""
            )
        )
    )
)

if not defined PY_CMD (
    python -c "import sys; print(sys.version)" >nul 2>nul
    if !errorlevel!==0 set "PY_CMD=python"
)

rem ============================================================================
rem 3. Se nao tiver Python instalado no PC, baixa e instala automaticamente!
rem ============================================================================
if not defined PY_CMD (
    echo  Python ainda nao instalado neste computador.
    echo  Baixando e instalando o Python 3.12 automaticamente para voce...
    echo  Por favor, aguarde cerca de 1 a 2 minutos...
    echo.
    set "PY_INST=%TEMP%\python-3.12.7-amd64.exe"
    curl.exe -L -s -o "!PY_INST!" "https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
    if not exist "!PY_INST!" (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '!PY_INST!'"
    )
    if exist "!PY_INST!" (
        echo  Instalando Python 3.12 ^(adicionando ao PATH automaticamente^)...
        "!PY_INST!" /passive InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1 SimpleInstall=1
        del /q "!PY_INST!" >nul 2>nul
    )
    if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
        set "PY_CMD="%LocalAppData%\Programs\Python\Python312\python.exe""
    ) else (
        where py >nul 2>nul
        if !errorlevel!==0 set "PY_CMD=py -3"
    )
)

if not defined PY_CMD (
    echo.
    echo  Nao foi possivel localizar ou instalar o Python automaticamente.
    echo  Instale em https://www.python.org/downloads/ e MARQUE a opcao "Add python.exe to PATH".
    echo  Depois rode este arquivo de novo.
    pause
    exit /b 1
)

echo  Criando ambiente virtual (.venv) com !PY_CMD!...
!PY_CMD! -m venv .venv
if not exist ".venv\Scripts\python.exe" (
    echo  Tentando instalar modulo venv...
    !PY_CMD! -m pip install --user virtualenv >nul 2>nul
    !PY_CMD! -m virtualenv .venv
)

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo  Falha ao criar a pasta .venv. Tente rodar como Administrador.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>nul

:deps
rem ============================================================================
rem 4. Instala/atualiza dependencias quando o requirements.txt muda
rem ============================================================================
fc /b requirements.txt ".venv\req_ok.txt" >nul 2>nul
if %errorlevel%==0 goto sync_local
echo.
echo  Instalando/atualizando componentes da Fabrica Dark...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo  Falha ao instalar as dependencias. Verifique a internet e tente de novo.
    pause
    exit /b 1
)
copy /y requirements.txt ".venv\req_ok.txt" >nul

:sync_local
rem ============================================================================
rem 5. Sincroniza automaticamente com D:\AUTOMACAO DARK\MAQUINA LEO\FabricaDark
rem ============================================================================
".venv\Scripts\python.exe" -c "from core import atualizador; atualizador.sincronizar_ao_iniciar()" >nul 2>nul

:atalho
rem Cria (ou atualiza) o atalho com icone na Area de Trabalho e no Menu Iniciar
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0criar-atalho.ps1" >nul 2>nul

rem Abre como aplicativo, sem a janela preta
if exist ".venv\Scripts\pythonw.exe" (
    start "" ".venv\Scripts\pythonw.exe" app.py --app
) else (
    start "" ".venv\Scripts\python.exe" app.py --app
)
exit /b 0
