// Fábrica Dark — interface
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const main = $('#main');
const _MAPA_MOJIBAKE_JS = [
  ['â€™', '’'], ['â€˜', '‘'], ['â€œ', '“'], ['â€\u009d', '”'], ['â€”', '—'], ['â€“', '–'], ['â€¦', '…'],
  ['Ã¡', 'á'], ['Ã\u00a1', 'á'], ['Ã©', 'é'], ['Ã\u00a9', 'é'], ['Ã­', 'í'], ['Ã\u00ad', 'í'],
  ['Ã³', 'ó'], ['Ã\u00b3', 'ó'], ['Ãº', 'ú'], ['Ã\u00ba', 'ú'], ['Ã£', 'ã'], ['Ã\u00a3', 'ã'],
  ['Ãµ', 'õ'], ['Ã\u00b5', 'õ'], ['Ã§', 'ç'], ['Ã\u00a7', 'ç'], ['Ãª', 'ê'], ['Ã\u00aa', 'ê'],
  ['Ã´', 'ô'], ['Ã\u00b4', 'ô'], ['Ã¢', 'â'], ['Ã\u00a2', 'â'], ['Ã\u00a0', 'à'], ['Ã  ', 'à '], [' Ã ', ' à '],
  ['Ã±', 'ñ'], ['Ã¼', 'ü'],
  ['Ã\u0081', 'Á'], ['Ã‰', 'É'], ['Ã\u0089', 'É'], ['Ã\u008d', 'Í'], ['Ã“', 'Ó'], ['Ã\u0093', 'Ó'],
  ['Ãš', 'Ú'], ['Ã\u009a', 'Ú'], ['Ãƒ', 'Ã'], ['Ã\u0083', 'Ã'], ['Ã•', 'Õ'], ['Ã\u0095', 'Õ'],
  ['Ã‡', 'Ç'], ['Ã\u0087', 'Ç'], ['ÃŠ', 'Ê'], ['Ã\u008a', 'Ê'], ['Ã”', 'Ô'], ['Ã\u0094', 'Ô'],
  ['Ã‚', 'Â'], ['Ã\u0082', 'Â'], ['Ã€', 'À'], ['Ã\u0080', 'À'],
  ['Â°', '°'], ['Âº', 'º'], ['Âª', 'ª'], ['Â·', '·']
];
window.limparMojibake = function limparMojibake(v) {
  if (v === null || v === undefined) return v;
  if (Array.isArray(v)) return v.map(limparMojibake);
  if (typeof v === 'object') {
    const outObj = {};
    for (const k of Object.keys(v)) outObj[k] = limparMojibake(v[k]);
    return outObj;
  }
  if (typeof v !== 'string' || !v) return v;
  if (!v.includes('Ã') && !v.includes('Â') && !v.includes('â€')) return v;
  let s = v;
  for (const [k, rep] of _MAPA_MOJIBAKE_JS) {
    if (s.includes(k)) s = s.split(k).join(rep);
  }
  s = s.replace(/([a-zA-Zçáéíóúãõêôâ])Ã(?=[bcdfghjklmnpqrstvwxyz]|o\b|da\b|do\b|dos\b|das\b|na\b|nas\b|no\b|nos\b|sta\b|smo\b)/g, '$1í');
  s = s.replace(/\bÃ(?=[bcdfghjklmnpqrstvwxyz][a-z])/g, 'Í');
  return s;
};
const esc = s => window.limparMojibake(String(s ?? '')).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => Number(n || 0).toLocaleString('pt-BR');
const IDIOMAS = {pt: 'Português', es: 'Espanhol', en: 'Inglês', fr: 'Francês'};
const AIS = [
  ['ChatGPT (GPT)', 'ai-gpt', 'https://chatgpt.com/'],
  ['Gemini', 'ai-gem', 'https://gemini.google.com/app'],
  ['Antigravity V8', 'ai-ag', 'antigravity://v8'],
  ['DarkPlanner', 'ai-dp', 'darkplanner://open'],
];
const STEPS = [
  ['briefing', 'Briefing'], ['roteiro', 'Roteiro'], ['analise', 'Análise'], ['narracao', 'Narração'], ['cenas', 'Cenas e SRT'],
  ['midia', 'Mídia'], ['editor', 'Editor'], ['montagem', 'Montagem'], ['descricao', 'Descrição e tags'], ['thumb', 'Thumbnail'],
];

const S = {view: 'painel', channels: [], settings: {}, video: null, step: 'briefing', radar: null, filtroCena: 'todas', abertos: new Set()};

window._fdPipelineControllers = new Set();
window.abortarRequisicoesPipelineFabricaDark = function () {
  let abortadas = 0;
  if (window._fdPipelineControllers && window._fdPipelineControllers.size) {
    for (const ctrl of Array.from(window._fdPipelineControllers)) {
      try { ctrl.abort(); abortadas++; } catch (_eAb) {}
    }
    window._fdPipelineControllers.clear();
  }
  return abortadas;
};

async function api(url, opt = {}) {
  const o = {...opt};
  if (o.json !== undefined) { o.body = JSON.stringify(o.json); o.headers = {'Content-Type': 'application/json'}; o.method = o.method || 'POST'; delete o.json; }
  const ehPipelineCancelavel = !o.signal && typeof url === 'string' && !url.includes('/api/chat-operacional/') && (
    url.includes('/api/antigravity/') ||
    url.includes('/api/skill6/') ||
    url.includes('/api/dp/gerar-audio') ||
    url.includes('/api/dp/editar-srt') ||
    url.includes('/api/midias-reais/') ||
    url.includes('/api/thumb/')
  );
  let ctrlLocal = null;
  if (ehPipelineCancelavel && typeof AbortController !== 'undefined') {
    ctrlLocal = new AbortController();
    o.signal = ctrlLocal.signal;
    window._fdPipelineControllers.add(ctrlLocal);
  }
  try {
    const r = await fetch(url, o);
    let d = null; try { d = window.limparMojibake(await r.json()); } catch { d = null; }
    if (!r.ok) throw new Error((d && d.erro) || `Erro ${r.status}`);
    return d;
  } catch (err) {
    if (err && (err.name === 'AbortError' || String(err.message || '').toLowerCase().includes('aborted'))) {
      const eStop = new Error('⏸ Processo interrompido pelo usuário na Fábrica Dark.');
      eStop.foiInterrompidoUsuario = true;
      throw eStop;
    }
    throw err;
  } finally {
    if (ctrlLocal) window._fdPipelineControllers.delete(ctrlLocal);
  }
}
function toast(msg, err = false) {
  const d = document.createElement('div'); d.textContent = msg; if (err) d.className = 'err';
  $('#toast').appendChild(d); setTimeout(() => d.remove(), err ? 7000 : 3500);
}
async function safe(fn) {
  try { return await fn(); }
  catch (e) {
    if (e && e.foiInterrompidoUsuario) return;
    toast(e.message, true);
  }
}
function modal(html) { $('#modal-box').innerHTML = html; $('#modal').classList.remove('hidden'); }
function fecharModal() { $('#modal').classList.add('hidden'); }
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') fecharModal(); });
async function copiar(t) {
  try { await navigator.clipboard.writeText(t); }
  catch { const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
  toast('Copiado!');
}
function chName(id) { const c = S.channels.find(c => c.id === id); return c ? c.nome : '(sem canal)'; }
function chDot(id) { const c = S.channels.find(c => c.id === id); return `<span class="chcolor" style="background:${esc(c?.cor || '#555')}"></span>`; }
function chOptions(sel, vazio = false) {
  return (vazio ? '<option value="">Todos os canais</option>' : '') + S.channels.map(c => `<option value="${c.id}" ${c.id === sel ? 'selected' : ''}>${esc(c.nome)}</option>`).join('');
}

// bloco "copiar prompt + abrir IA"
function blocoPrompt(id, titulo, dica = '') {
  return `<div class="card"><h3>${titulo}</h3>${dica ? `<p class="mut small">${dica}</p>` : ''}
  <div class="copybox" id="${id}-box">Carregando…</div>
  <div class="row" style="margin-top:10px"><button class="pri" data-copy="${id}">Copiar prompt</button><span class="mut small">Depois cole na IA que preferir:</span></div>
  <div class="row ai-row" style="margin-top:8px">${AIS.map(([n, c, u]) => `<button class="${c}" data-ai="${u}" data-src="${id}">${n}</button>`).join('')}</div></div>`;
}
function ligarPrompt(id, texto) {
  const box = $(`#${id}-box`); if (!box) return;
  box.textContent = texto;
  $$(`[data-copy="${id}"]`).forEach(b => b.onclick = () => copiar(texto));
  $$(`[data-src="${id}"]`).forEach(b => b.onclick = async () => { await copiar(texto); window.open(b.dataset.ai, '_blank'); });
}

// ---------------- navegação ----------------
$$('#nav a').forEach(a => a.onclick = () => go(a.dataset.view));
async function go(view, extra) {
  S.view = view;
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.view === view || (view === 'video' && a.dataset.view === 'videos') || (view === 'acompanhar' && a.dataset.view === 'estudio')));
  S.channels = await api('/api/channels');
  S.settings = await api('/api/settings');
  const views = {painel, canais, radar: radarView, ideias, videos, video: videoView, config, mapa: mapaView, metrics: metricsView, financeiro: financeiroView, conexoes: (...x) => conexoesView(...x), consumo: (...x) => consumoView(...x), estudio: (...x) => estudioView(...x), acompanhar: (...x) => acompanharView(...x)};
  await safe(() => (views[view] || (window.EXTRA_VIEWS || {})[view])(extra));
  window.scrollTo(0, 0);
}

// ---------------- painel ----------------
async function painel() {
  const p = await api('/api/painel');
  if (!S.channels.length) {
    main.innerHTML = `<h1>Bem-vindo à Fábrica Dark</h1><p class="sub">Comece cadastrando um canal.</p>
    <div class="empty">Nenhum canal ainda.<br><br><button class="pri" onclick="go('canais')">Cadastrar canal</button></div>`;
    return;
  }
  const tot = k => p.reduce((s, x) => s + x[k], 0);
  main.innerHTML = `<h1>Painel</h1><p class="sub">Antes de publicar, monte o processo. Publicar é a consequência.</p>
  <div class="grid g4">
    <div class="card"><div class="stat">${tot('ideias')}<small>ideias na fila</small></div></div>
    <div class="card"><div class="stat">${tot('em_producao')}<small>em produção</small></div></div>
    <div class="card"><div class="stat">${tot('estoque')}<small>prontos em estoque</small></div></div>
    <div class="card"><div class="stat">${tot('publicados')}<small>publicados</small></div></div>
  </div>
  <h2>Semana à frente, por canal</h2>
  <div class="grid g3">${p.map(x => {
    const meta = Number(x.canal.meta_semana || 3), ok = x.estoque >= meta;
    return `<div class="card"><div class="row"><h3 style="margin:0">${chDot(x.canal.id)}${esc(x.canal.nome)}</h3><span class="sp"></span><span class="pill">${IDIOMAS[x.canal.idioma] || ''}</span></div>
    <p class="mut small" style="margin:4px 0 10px">${esc(x.canal.nicho || '')}</p>
    <div class="row small"><span>Estoque: <b>${x.estoque}</b> / meta ${meta}</span><span class="sp"></span><span class="pill ${ok ? 'ok' : 'warn'}">${ok ? 'semana garantida' : `faltam ${meta - x.estoque}`}</span></div>
    <div class="prog" style="margin:8px 0"><div style="width:${Math.min(100, x.estoque / meta * 100)}%"></div></div>
    <div class="row small mut"><span>${x.ideias} ideias</span><span>${x.em_producao} em produção</span><span>${x.agendados_semana} agendados (7 dias)</span></div>
    ${(x.videos_producao || []).length ? `<div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--line)">
      <div class="small mut" style="margin-bottom:4px">⏳ Em produção neste canal:</div>
      ${(x.videos_producao || []).slice(0, 3).map(vp => `<div class="row small" style="gap:6px;margin-bottom:4px">
        <a href="#" data-p-open="${vp.id}" class="sp" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(vp.titulo)}</a>
        <button class="sm pri" data-p-concluir="${vp.id}" style="background:#059669;border-color:#10b981;padding:2px 8px;font-size:11px" title="Marcar este vídeo como Concluído">✅ Concluir</button>
      </div>`).join('')}
    </div>` : ''}
    <div class="row" style="margin-top:10px"><button class="sm" onclick="go('videos','${x.canal.id}')">Vídeos</button><button class="sm" onclick="go('ideias','${x.canal.id}')">Ideias</button></div></div>`;
  }).join('')}</div>`;
  $$('[data-p-open]').forEach(a => a.onclick = e => { e.preventDefault(); go('video', a.dataset.pOpen); });
  $$('[data-p-concluir]').forEach(b => b.onclick = () => safe(async () => {
    b.disabled = true; b.textContent = '…';
    const r = await api(`/api/videos/${b.dataset.pConcluir}/concluir`, {json: {concluido: true}});
    toast(r.msg || '✅ Vídeo marcado como Concluído!');
    painel();
  }));
}

// ---------------- canais ----------------
async function canais() {
  main.innerHTML = `<div class="row"><div><h1>Canais</h1><p class="sub">Cada canal guarda o nicho, o público e a tese. Isso entra em todos os prompts.</p></div><span class="sp"></span><button class="pri" id="novo">+ Novo canal</button></div>
  ${S.channels.length ? `<div class="grid g3">${S.channels.map(c => `<div class="card">
    <div class="row"><h3 style="margin:0">${chDot(c.id)}${esc(c.nome)}</h3><span class="sp"></span><span class="pill">${IDIOMAS[c.idioma] || ''}</span></div>
    <p class="small" style="margin:8px 0 2px"><b>Nicho:</b> ${esc(c.nicho)}</p><p class="small mut" style="margin:0">${esc(c.subnicho || '')}</p>
    <p class="small mut">${esc(c.publico || '')}</p>
    <div class="row"><button class="sm" data-edit="${c.id}">Editar</button><button class="sm danger" data-del="${c.id}">Excluir</button></div></div>`).join('')}</div>`
    : '<div class="empty">Nenhum canal cadastrado.</div>'}`;
  $('#novo').onclick = () => formCanal({});
  $$('[data-edit]').forEach(b => b.onclick = () => formCanal(S.channels.find(c => c.id === b.dataset.edit)));
  $$('[data-del]').forEach(b => b.onclick = () => safe(async () => {
    if (!confirm('Excluir este canal e as ideias dele? Os vídeos ficam guardados.')) return;
    await api('/api/channels/' + b.dataset.del, {method: 'DELETE'}); go('canais');
  }));
}
window.PERFIS_CANAL = [
  ['padrao', 'Padrão', 'limpo e neutro, serve para qualquer nicho'],
  ['true_crime', 'True Crime', 'quadro de investigação, fichas, documentos com tarjas, fotos sépia'],
  ['jornal', 'Jornal', 'faixa amarela, etiquetas vermelhas, nome e função de quem fala'],
  ['historia', 'História', 'sépia, linha do tempo, mapas, documentos antigos, capítulos'],
  ['horror', 'Horror / Mistério', 'frio e escuro, frases de impacto, documentos, quadro de pistas'],
  ['natureza', 'Natureza', 'cores vivas, zoom de satélite, comparação de escala, números'],
];
function formCanal(c) {
  const cores = ['#f97316', '#ef4444', '#eab308', '#22c55e', '#14b8a6', '#3b82f6', '#8b5cf6', '#ec4899', '#a3a3a3'];
  modal(`<h3>${c.id ? 'Editar canal' : 'Novo canal'}</h3>
  <div class="f"><label>Nome do canal</label><input id="c-nome" value="${esc(c.nome)}"></div>
  <div class="grid g2"><div class="f"><label>Nicho</label><input id="c-nicho" value="${esc(c.nicho)}" placeholder="Ex.: Agricultura de sobrevivência"></div>
  <div class="f"><label>Subnicho</label><input id="c-subnicho" value="${esc(c.subnicho)}" placeholder="Ex.: Cultivos em ambientes extremos"></div></div>
  <div class="grid g2"><div class="f"><label>Idioma</label><select id="c-idioma">${Object.entries(IDIOMAS).map(([k, v]) => `<option value="${k}" ${c.idioma === k ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
  <div class="f"><label>Meta de vídeos prontos por semana</label><input id="c-meta" type="number" min="1" value="${esc(c.meta_semana || 3)}"></div></div>
  <div class="f"><label>Perfil visual (cara dos vídeos no Estúdio)</label><select id="c-perfil">${PERFIS_CANAL.map(([k, n, d]) => `<option value="${k}" ${(c.perfil || 'padrao') === k ? 'selected' : ''}>${n} — ${d}</option>`).join('')}</select></div>
  <div class="f"><label>Público-alvo</label><input id="c-publico" value="${esc(c.publico)}" placeholder="Ex.: Adultos de 25 a 65 anos interessados em…"></div>
  <div class="f"><label>Tese / promessa do canal</label><textarea id="c-tese" style="min-height:70px">${esc(c.tese)}</textarea></div>
  <div class="f"><label>Personagem recorrente (opcional — aparece igual em todas as imagens de IA)</label><input id="c-personagem" value="${esc(c.personagem)}" placeholder="Ex.: homem de 60 anos, barba grisalha, chapéu de couro, casaco marrom"></div>
  <div class="f"><label>Link do canal (opcional)</label><input id="c-url" value="${esc(c.url)}"></div>
  <div class="f"><label>Cor</label><div class="row">${cores.map(k => `<span data-cor="${k}" style="width:24px;height:24px;border-radius:6px;background:${k};cursor:pointer;outline:${(c.cor || '#f97316') === k ? '2px solid #fff' : 'none'}"></span>`).join('')}</div></div>
  <div class="row end"><button onclick="fecharModal()">Cancelar</button><button class="pri" id="c-salvar">Salvar</button></div>`);
  let cor = c.cor || '#f97316';
  $$('[data-cor]').forEach(s => s.onclick = () => { cor = s.dataset.cor; $$('[data-cor]').forEach(x => x.style.outline = x.dataset.cor === cor ? '2px solid #fff' : 'none'); });
  $('#c-salvar').onclick = () => safe(async () => {
    const d = {id: c.id, cor}; ['nome', 'nicho', 'subnicho', 'idioma', 'publico', 'tese', 'url', 'personagem', 'perfil'].forEach(k => d[k] = $('#c-' + k).value.trim());
    d.meta_semana = Number($('#c-meta').value) || 3;
    if (!d.nome) return toast('Dê um nome ao canal', true);
    await api('/api/channels', {json: d}); fecharModal(); toast('Canal salvo'); go('canais');
  });
}

// ---------------- radar ----------------
async function radarView() {
  main.innerHTML = `<h1>Radar de nichos</h1><p class="sub">Procura vídeos que estão explodindo agora e destaca canais novos/pequenos — sinal de nicho em alta.</p>
  ${S.settings.youtube_api_key ? '' : `<div class="hint">Para o radar funcionar, coloque sua chave grátis da YouTube Data API em <a href="#" onclick="go('config')">Configurações</a>.</div>`}
  <div class="card"><div class="grid g4">
    <div class="f" style="grid-column:span 2"><label>Tema / palavra-chave</label><input id="r-termo" placeholder="Ex.: true crime, mistérios do universo, hinos antigos" value="${esc(S.radarTermo || '')}"></div>
    <div class="f"><label>Idioma</label><select id="r-idioma">${Object.entries(IDIOMAS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
    <div class="f"><label>Publicados nos últimos</label><select id="r-dias"><option value="7">7 dias</option><option value="30" selected>30 dias</option><option value="90">90 dias</option></select></div>
    <div class="f"><label>Duração mínima</label><select id="r-dur"><option value="0">Qualquer (inclui Shorts)</option><option value="240" selected>4 min+</option><option value="600">10 min+</option><option value="1200">20 min+</option></select></div>
    <div class="f"><label>Profundidade</label><select id="r-pag"><option value="1">50 vídeos (100 cotas)</option><option value="2">100 vídeos (200 cotas)</option></select></div>
  </div><div class="row"><button class="pri" id="r-go">Buscar</button><span class="sp"></span>
  <label style="margin:0"><input type="checkbox" id="r-novos"> Só canais novos (até 6 meses)</label>
  <label style="margin:0">Máx. inscritos <input id="r-maxsub" type="number" placeholder="sem limite" style="width:120px"></label></div></div>
  <div id="r-res"></div>`;
  $('#r-go').onclick = () => safe(async () => {
    const termo = $('#r-termo').value.trim(); if (!termo) return toast('Digite um tema', true);
    S.radarTermo = termo;
    $('#r-res').innerHTML = '<p class="mut">Buscando…</p>';
    S.radar = await api('/api/radar', {json: {termo, idioma: $('#r-idioma').value, dias: +$('#r-dias').value, min_duracao_s: +$('#r-dur').value, paginas: +$('#r-pag').value}});
    desenharRadar();
  });
  if (S.radar) desenharRadar();
}
function desenharRadar() {
  const base = S.radar, novos = $('#r-novos')?.checked, maxs = Number($('#r-maxsub')?.value || 0);
  const okV = x => (!novos || x.canal_novo) && (!maxs || x.inscritos <= maxs);
  const r = {videos: base.videos.filter(okV), canais: base.canais.filter(okV)};
  if ($('#r-novos')) { $('#r-novos').onchange = desenharRadar; $('#r-maxsub').onchange = desenharRadar; }
  $('#r-res').innerHTML = `<div class="card"><div class="row"><h3 style="margin:0">Canais em destaque</h3><span class="sp"></span><span class="mut small">ordenados por oportunidade</span></div>
  <table><tr><th>Canal</th><th>Inscritos</th><th>Vídeos</th><th>Criado</th><th>Views (no radar)</th><th>Melhor vídeo</th></tr>
  ${r.canais.slice(0, 15).map(c => `<tr><td><a href="${c.url_canal}" target="_blank">${esc(c.canal)}</a> ${c.canal_novo ? '<span class="pill acc">canal novo</span>' : ''}</td><td>${fmt(c.inscritos)}</td><td>${c.videos_canal}</td><td>${c.canal_criado}</td><td>${fmt(c.views_recentes)}</td><td class="small">${esc(c.melhor_video)}</td></tr>`).join('')}</table></div>
  <div class="card"><div class="row"><h3 style="margin:0">Vídeos</h3><span class="sp"></span>
  <select id="r-canal" style="width:auto">${chOptions(S.channels[0]?.id)}</select><button class="pri sm" id="r-salvar">Salvar marcados como referência</button></div>
  <table><tr><th></th><th></th><th>Título</th><th>Views</th><th>Views/dia</th><th>Duração</th><th>Canal</th></tr>
  ${r.videos.map((v, i) => `<tr><td><input type="checkbox" data-ri="${i}"></td><td><img src="${v.thumb}" style="width:110px;border-radius:6px"></td>
  <td><a href="${v.url}" target="_blank">${esc(v.titulo)}</a><div class="small mut">${v.publicado}</div></td><td>${fmt(v.views)}</td><td>${fmt(v.views_dia)}</td><td>${v.duracao_min} min</td>
  <td class="small">${esc(v.canal)}<br><span class="mut">${fmt(v.inscritos)} insc · ${v.videos_canal} vídeos</span> ${v.canal_novo ? '<span class="pill acc">novo</span>' : ''}</td></tr>`).join('')}</table></div>`;
  $('#r-salvar').onclick = () => safe(async () => {
    const itens = $$('[data-ri]:checked').map(x => r.videos[+x.dataset.ri]);
    if (!itens.length) return toast('Marque pelo menos um vídeo', true);
    if (!$('#r-canal').value) return toast('Cadastre um canal primeiro', true);
    const res = await api('/api/radar/salvos', {json: {channel_id: $('#r-canal').value, itens}});
    toast(`${res.adicionados} referência(s) salvas. Gere títulos em "Ideias e títulos".`);
  });
}

// ---------------- ideias ----------------
async function ideias(cid) {
  cid = cid || S.ideiasCanal || S.channels[0]?.id || '';
  S.ideiasCanal = cid;
  if (!S.channels.length) { main.innerHTML = '<h1>Ideias e títulos</h1><div class="empty">Cadastre um canal primeiro.</div>'; return; }
  const [lista, refs] = await Promise.all([api('/api/ideas?channel=' + cid), api('/api/radar/salvos?channel=' + cid)]);
  main.innerHTML = `<div class="row"><div><h1>Ideias e títulos</h1><p class="sub">Banco de ideias por canal. Gere títulos modelando as referências salvas no radar.</p></div><span class="sp"></span>
  <select id="i-canal" style="width:auto">${chOptions(cid)}</select></div>
  <div class="grid g2">
    <div>${blocoPrompt('pt', `Gerar ideias (${refs.length} referência${refs.length === 1 ? '' : 's'} do radar)`, 'O prompt usa o nicho do canal e os vídeos que você salvou no radar.')}
      <div class="card"><h3>Cole aqui o JSON que a IA devolveu</h3><textarea id="i-json" placeholder='{"ideias":[...]}'></textarea>
      <div class="row end" style="margin-top:8px"><button class="pri" id="i-colar">Adicionar ideias</button></div></div>
      <div class="card"><h3>Adicionar título manual</h3><div class="row"><input id="i-manual" placeholder="Título do vídeo" style="flex:1"><button id="i-add">Adicionar</button></div></div>
      ${refs.length ? `<div class="card"><h3>Referências salvas</h3>${refs.map(r => `<div class="row small" style="margin-bottom:6px"><a href="${r.url}" target="_blank" style="flex:1">${esc(r.titulo)}</a><span class="mut">${fmt(r.views)}</span><button class="sm danger" data-rdel="${r.id}">×</button></div>`).join('')}</div>` : ''}
    </div>
    <div class="card"><h3>Fila de ideias (${lista.filter(i => !i.usada).length})</h3>
      ${lista.length ? lista.map(i => `<div style="padding:10px 0;border-bottom:1px solid var(--line);${i.usada ? 'opacity:.45' : ''}">
        <div class="row"><b style="flex:1">${esc(i.titulo)}</b>${i.usada ? '<span class="pill ok">virou vídeo</span>' : `<button class="sm pri" data-criar="${i.id}">Criar vídeo</button>`}<button class="sm danger" data-idel="${i.id}">×</button></div>
        ${i.gancho ? `<div class="small mut">${esc(i.gancho)}</div>` : ''}</div>`).join('') : '<div class="empty">Nenhuma ideia ainda.</div>'}
    </div></div>`;
  $('#i-canal').onchange = e => ideias(e.target.value);
  const p = await api('/api/titulos/prompt', {json: {channel_id: cid, quantidade: 20}});
  ligarPrompt('pt', p.prompt);
  $('#i-colar').onclick = () => safe(async () => {
    const r = await api('/api/titulos/colar', {json: {channel_id: cid, texto: $('#i-json').value}});
    toast(`${r.length} ideias adicionadas`); ideias(cid);
  });
  $('#i-add').onclick = () => safe(async () => {
    const t = $('#i-manual').value.trim(); if (!t) return;
    await api('/api/ideas', {json: {channel_id: cid, ideias: [{titulo: t}]}}); ideias(cid);
  });
  $$('[data-idel]').forEach(b => b.onclick = () => safe(async () => { await api('/api/ideas/' + b.dataset.idel, {method: 'DELETE'}); ideias(cid); }));
  $$('[data-rdel]').forEach(b => b.onclick = () => safe(async () => { await api('/api/radar/salvos?id=' + b.dataset.rdel, {method: 'DELETE'}); ideias(cid); }));
  $$('[data-criar]').forEach(b => b.onclick = () => safe(async () => { const v = await api(`/api/ideas/${b.dataset.criar}/criar_video`, {method: 'POST'}); go('video', v.id); }));
}

// ---------------- vídeos ----------------
async function videos(cid) {
  cid = cid ?? S.videosCanal ?? '';
  S.videosCanal = cid;
  const fStatus = S.videosFiltroStatus || 'todos';
  const [lista, resCriados] = await Promise.all([
    api('/api/videos' + (cid ? '?channel=' + cid : '')),
    api('/api/projetos-criados').catch(() => ({itens: []}))
  ]);
  const projsCriados = (resCriados && resCriados.itens) || [];
  lista.sort((a, b) => (b.criado_em || '').localeCompare(a.criado_em || ''));
  const nProd = lista.filter(v => !v.concluido && !v.pronto && !v.publicado).length;
  const nConc = lista.filter(v => (v.concluido || v.pronto) && !v.publicado).length;
  const nPub = lista.filter(v => v.publicado).length;
  const listaFiltrada = lista.filter(v => {
    if (fStatus === 'producao') return !v.concluido && !v.pronto && !v.publicado;
    if (fStatus === 'concluidos') return (v.concluido || v.pronto) && !v.publicado;
    if (fStatus === 'publicados') return Boolean(v.publicado);
    return true;
  });
  main.innerHTML = `<div class="row" style="flex-wrap:wrap;gap:10px"><div><h1>Vídeos</h1><p class="sub">Veja todos os vídeos criados, assista aos cortes .MP4, troque cenas, edite o roteiro/SRT ou refaça no <b>Estúdio 1 Clique</b> e no <b>DarkPlanner Studio</b>.</p></div><span class="sp"></span>
  <select id="v-canal" style="width:auto">${chOptions(cid, true)}</select><button class="pri" id="v-novo">+ Novo vídeo</button></div>

  ${projsCriados.length ? `
  <div class="card" style="border-color:#a855f7;background:rgba(124,58,237,.05);margin-bottom:14px">
    <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:8px">
      <h3 class="sp" style="margin:0;color:#e9d5ff">🎬 Projetos e Vídeos Criados (Estúdio V8 + DarkPlanner Studio — Editar e Refazer)</h3>
      <span class="pill" style="border-color:#a855f7;color:#d8b4fe">${projsCriados.length} vídeo(s)</span>
    </div>
    <div class="small mut" style="margin-bottom:10px">Clique em <b>🎬 Ver Cortes / Editar e Refazer</b> para assistir aos vídeos .MP4 de cada cena, trocar cortes individuais, editar o roteiro/SRT ou remontar no DarkPlanner Studio, ou clique em <b>✏️ Carregar no Estúdio 1 Clique</b> para refazer com a IA:</div>
    <div style="display:grid;gap:8px">
      ${projsCriados.map((it, idx) => {
        const ehReal = it.modo_skill === 'video_real' || it.tipo === 'studio';
        const aud = it.auditoria || {};
        const semRep = aud.repeticoes_restantes === 0 && (it.videos_mp4 || 0) > 0;
        return `<div class="kcard" style="margin:0;border-color:${ehReal ? '#38bdf8' : '#a855f7'};background:rgba(15,23,42,.75)">
          <div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-start">
            <div class="sp">
              <div class="row" style="gap:6px;flex-wrap:wrap">
                <b style="font-size:14px;color:#f8fafc">${esc(it.titulo)}</b>
                <span class="pill" style="border-color:${ehReal ? '#38bdf8' : '#a855f7'};color:${ehReal ? '#7dd3fc' : '#d8b4fe'}">${ehReal ? '🎬 Studio Vídeo Real' : '🎯 Skill 6 / Creator'}</span>
                ${it.concluido ? '<span class="pill ok">✅ Concluído</span>' : '<span class="pill warn">⏳ Em Produção</span>'}
                ${semRep ? '<span class="pill ok">🛡️ 0 Repetições</span>' : ''}
              </div>
              <div class="small mut" style="margin-top:4px">
                📺 Canal: <b style="color:#cbd5e1">${esc(it.canal_nome || '—')}</b> ·
                ⏱️ ~<b>${it.duracao_minutos || 10} min</b> (${(it.palavras_roteiro || 0).toLocaleString('pt-BR')} palavras) ·
                🎙 MP3: <b style="color:${it.tem_mp3 ? '#4ade80' : '#f87171'}">${it.tem_mp3 ? 'Sim' : 'Não'}</b> ·
                📄 SRT: <b>${it.blocos_srt || 0} blocos</b> ·
                🎞 Cortes: <b style="color:#38bdf8">${it.videos_mp4 || 0} vídeos .MP4</b>${it.fotos_jpg ? ` + ${it.fotos_jpg} fotos` : ''}
              </div>
            </div>
            <div class="row" style="gap:6px;flex-wrap:wrap">
              <button type="button" class="sm pri" data-vpc-modal="${idx}" style="background:#7c3aed;border-color:#a855f7;color:#fff;font-weight:700">🎬 Ver Cortes / Editar e Refazer</button>
              <button type="button" class="sm" data-vpc-load="${idx}" style="border-color:#38bdf8;color:#7dd3fc;font-weight:700">✏️ Carregar no Estúdio 1 Clique</button>
              ${it.pasta ? `<button type="button" class="sm" data-vpc-dir="${idx}" title="Abrir pasta dos arquivos no Windows">📂 Pasta</button>` : ''}
            </div>
          </div>
        </div>`;
      }).join('')}
    </div>
  </div>` : ''}

  <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:12px">
    <button class="sm ${fStatus === 'todos' ? 'pri' : ''}" data-vf="todos">Todos (${lista.length})</button>
    <button class="sm ${fStatus === 'producao' ? 'pri' : ''}" data-vf="producao">⏳ Em Produção (${nProd})</button>
    <button class="sm ${fStatus === 'concluidos' ? 'pri' : ''}" data-vf="concluidos" style="${fStatus === 'concluidos' ? 'background:#059669;border-color:#10b981' : 'border-color:#10b981;color:#34d399'}">✅ Concluídos (${nConc})</button>
    <button class="sm ${fStatus === 'publicados' ? 'pri' : ''}" data-vf="publicados">📢 Publicados (${nPub})</button>
  </div>
  ${listaFiltrada.length ? `<div class="card" style="padding:0"><table><tr><th>Título</th><th>Canal</th><th>Etapas</th><th>Nota</th><th>Status / Conclusão</th><th>Ações</th></tr>
  ${listaFiltrada.map(v => {
    const ehConc = Boolean(v.concluido || v.pronto || v.publicado);
    return `<tr style="${ehConc ? 'background:rgba(16,185,129,.05)' : ''}"><td><a href="#" data-open="${v.id}"><b>${esc(v.titulo)}</b></a><div class="small mut">${v.n_cenas} cenas · criado ${esc((v.criado_em || '').slice(0, 10))}${v.concluido_em ? ` · concluído ${esc(v.concluido_em.slice(0, 10))}` : ''}</div></td>
  <td class="small">${chDot(v.channel_id)}${esc(chName(v.channel_id))}</td>
  <td><div class="dots">${STEPS.map(([k]) => `<span class="${(ehConc || v.etapas?.[k]) ? 'on' : ''}" title="${k}"></span>`).join('')}</div></td>
  <td>${v.nota != null ? `<b>${v.nota}</b>` : '<span class="mut">—</span>'}</td>
  <td class="small">${v.publicado ? '<span class="pill ok">📢 publicado</span>' : ehConc ? '<span class="pill ok">✅ concluído (em estoque)</span>' : '<span class="pill warn">⏳ produzindo</span>'} ${esc(v.data_publicacao || '')}</td>
  <td><div class="row" style="gap:6px;flex-wrap:wrap;justify-content:flex-end">
    <button class="sm pri" data-v-edit-modal="${v.id}" data-v-tit="${esc(v.titulo)}" style="background:#7c3aed;border-color:#a855f7;color:#fff;font-weight:700" title="Ver cortes .mp4, editar roteiro/SRT e refazer no DarkPlanner Studio">🎬 Editar / Refazer</button>
    <button class="sm" data-v-load-est="${v.id}" data-v-tit="${esc(v.titulo)}" style="border-color:#38bdf8;color:#7dd3fc" title="Carregar no Estúdio 1 Clique">✏️ No Estúdio</button>
    ${!ehConc ? `<button class="sm pri" data-vconc="${v.id}" style="background:#059669;border-color:#10b981;color:#fff;font-weight:700">✅ Marcar Concluído</button>` : ''}
    ${ehConc && !v.publicado ? `<button class="sm" data-vpub="${v.id}" style="border-color:#38bdf8;color:#7dd3fc" title="Marcar como Publicado no YouTube">📢 Publicado</button>` : ''}
    ${ehConc ? `<button class="sm" data-vreabrir="${v.id}" title="Voltar status para Em Produção">↩ Reabrir</button>` : ''}
    <button class="sm danger" data-vdel="${v.id}" title="Excluir vídeo">×</button>
  </div></td></tr>`;
  }).join('')}</table></div>` : '<div class="empty">Nenhum vídeo neste filtro. Crie um a partir de uma ideia ou no Estúdio 1 Clique.</div>'}`;
  $$('[data-vpc-modal]').forEach(b => b.onclick = () => {
    const it = projsCriados[Number(b.dataset.vpcModal)];
    if (it && window.abrirModalEditarVideoCriado) window.abrirModalEditarVideoCriado(it.titulo, it.vid, it.slug);
  });
  $$('[data-vpc-load]').forEach(b => b.onclick = () => {
    const it = projsCriados[Number(b.dataset.vpcLoad)];
    if (it && window.carregarProjetoCriadoNoEstudio) window.carregarProjetoCriadoNoEstudio(it.titulo, it.vid, it.slug);
  });
  $$('[data-vpc-dir]').forEach(b => b.onclick = () => {
    const it = projsCriados[Number(b.dataset.vpcDir)];
    if (it && it.pasta && window.abrirPastaProjetoCriado) window.abrirPastaProjetoCriado(it.pasta);
  });
  $$('[data-v-edit-modal]').forEach(b => b.onclick = () => {
    if (window.abrirModalEditarVideoCriado) window.abrirModalEditarVideoCriado(b.dataset.vTit, b.dataset.vEditModal, '');
  });
  $$('[data-v-load-est]').forEach(b => b.onclick = () => {
    if (window.carregarProjetoCriadoNoEstudio) window.carregarProjetoCriadoNoEstudio(b.dataset.vTit, b.dataset.vLoadEst, '');
  });
  $('#v-canal').onchange = e => videos(e.target.value);
  $$('[data-vf]').forEach(b => b.onclick = () => { S.videosFiltroStatus = b.dataset.vf; videos(cid); });
  $('#v-novo').onclick = () => {
    if (!S.channels.length) return toast('Cadastre um canal primeiro', true);
    modal(`<h3>Novo vídeo</h3><div class="f"><label>Canal</label><select id="n-canal">${chOptions(cid || S.channels[0].id)}</select></div>
    <div class="f"><label>Título</label><input id="n-tit"></div><div class="row end"><button onclick="fecharModal()">Cancelar</button><button class="pri" id="n-ok">Criar</button></div>`);
    $('#n-ok').onclick = () => safe(async () => {
      const t = $('#n-tit').value.trim(); if (!t) return toast('Digite o título', true);
      const v = await api('/api/videos', {json: {channel_id: $('#n-canal').value, titulo: t}}); fecharModal(); go('video', v.id);
    });
  };
  $$('[data-open]').forEach(a => a.onclick = e => { e.preventDefault(); go('video', a.dataset.open); });
  $$('[data-vconc]').forEach(b => b.onclick = () => safe(async () => {
    b.disabled = true; b.textContent = '⏳ Concluindo…';
    const r = await api(`/api/videos/${b.dataset.vconc}/concluir`, {json: {concluido: true}});
    toast(r.msg || '✅ Vídeo marcado como Concluído!');
    videos(cid);
  }));
  $$('[data-vpub]').forEach(b => b.onclick = () => safe(async () => {
    b.disabled = true; b.textContent = '⏳…';
    const r = await api(`/api/videos/${b.dataset.vpub}/concluir`, {json: {concluido: true, publicado: true}});
    toast(r.msg || '📢 Vídeo marcado como Concluído e Publicado!');
    videos(cid);
  }));
  $$('[data-vreabrir]').forEach(b => b.onclick = () => safe(async () => {
    const r = await api(`/api/videos/${b.dataset.vreabrir}/concluir`, {json: {concluido: false, publicado: false}});
    toast(r.msg || '↩ Vídeo reaberto (Em Produção).');
    videos(cid);
  }));
  $$('[data-vdel]').forEach(b => b.onclick = () => safe(async () => { if (!confirm('Excluir este vídeo da lista?')) return; await api('/api/videos/' + b.dataset.vdel, {method: 'DELETE'}); videos(cid); }));
}

// ---------------- editor de vídeo ----------------
async function videoView(id) {
  if (id && (!S.video || S.video.id !== id)) S.step = 'briefing';
  S.video = await api('/api/videos/' + (id || S.video.id));
  const v = S.video;
  const ehConc = Boolean(v.concluido || v.saida || (v.dp_video && v.dp_video.checklist_pronto) || v.publicado);
  main.innerHTML = `<div class="row"><a href="#" onclick="go('videos');return false" class="small">← Vídeos</a><span class="sp"></span>
    ${ehConc ? `<span class="pill ok">${v.publicado ? '📢 CONCLUÍDO E PUBLICADO' : '✅ VÍDEO CONCLUÍDO'}</span>` : `<span class="pill warn">⏳ Em Produção</span>`}
    ${!ehConc ? `<button class="sm pri" id="vv-concluir" style="background:#059669;border-color:#10b981;color:#fff;font-weight:700">✅ Marcar Vídeo como Concluído</button>` : ''}
    ${ehConc && !v.publicado ? `<button class="sm pri" id="vv-publicar" style="background:#0284c7;border-color:#38bdf8">📢 Marcar como Publicado</button>` : ''}
    ${ehConc ? `<button class="sm" id="vv-reabrir">↩ Reabrir Produção</button>` : ''}
  </div>
  <div class="row" style="margin-top:6px"><h1 style="flex:1">${esc(v.titulo)}</h1><span class="small">${chDot(v.channel_id)}${esc(chName(v.channel_id))}</span></div>
  <div class="stepper">${STEPS.map(([k, n], i) => `<a data-step="${k}" class="${S.step === k ? 'on' : ''} ${(ehConc || v.etapas[k]) ? 'done' : ''}"><span class="n">${(ehConc || v.etapas[k]) ? '✓' : i + 1}</span>${n}</a>`).join('')}</div>
  <div id="step"></div>`;
  if ($('#vv-concluir')) $('#vv-concluir').onclick = () => safe(async () => {
    const r = await api(`/api/videos/${v.id}/concluir`, {json: {concluido: true}});
    toast(r.msg || '✅ Vídeo marcado como Concluído!');
    videoView(v.id);
  });
  if ($('#vv-publicar')) $('#vv-publicar').onclick = () => safe(async () => {
    const r = await api(`/api/videos/${v.id}/concluir`, {json: {concluido: true, publicado: true}});
    toast(r.msg || '📢 Vídeo marcado como Publicado!');
    videoView(v.id);
  });
  if ($('#vv-reabrir')) $('#vv-reabrir').onclick = () => safe(async () => {
    const r = await api(`/api/videos/${v.id}/concluir`, {json: {concluido: false, publicado: false}});
    toast(r.msg || '↩ Vídeo reaberto.');
    videoView(v.id);
  });
  $$('[data-step]').forEach(a => a.onclick = () => { S.step = a.dataset.step; videoView(); });
  const fns = {briefing: stBriefing, roteiro: stRoteiro, analise: stAnalise, narracao: stNarracao, cenas: stCenas, midia: stMidia, editor: stEditor, montagem: stMontagem, descricao: stDescricao, thumb: stThumb};
  await safe(() => fns[S.step](v));
}
function proxima(k) { const i = STEPS.findIndex(s => s[0] === k); S.step = STEPS[Math.min(i + 1, STEPS.length - 1)][0]; videoView(); }
function step() { return S.alvo || $('#step'); }

async function stBriefing(v) {
  const b = v.briefing;
  const opt = (arr, cur) => arr.map(x => `<option ${x === cur ? 'selected' : ''}>${x}</option>`).join('');
  step().innerHTML = `<div class="card"><h3>Briefing</h3>
  <div class="f"><label>Título do vídeo</label><input id="b-titulo" value="${esc(v.titulo)}"></div>
  <div class="grid g3">
    <div class="f"><label>Duração (minutos)</label><input id="b-dur" type="number" min="1" value="${esc(b.duracao_min)}"></div>
    <div class="f"><label>Tipo de narração</label><select id="b-tipo">${opt(['Narrador sombrio', 'Documentário sério', 'Suspense / ASMR', 'Investigativo', 'Sensacionalista', 'Personalizado'], b.tipo_narrativa)}</select></div>
    <div class="f"><label>Estrutura</label><select id="b-est">${opt(['Storytelling', 'Lista / Top', 'Investigação', 'Linha do tempo', 'Antes e depois', 'Pergunta e resposta'], b.estrutura)}</select></div>
  </div>
  <div class="grid g2"><div class="f"><label>Público deste vídeo (vazio = público do canal)</label><input id="b-pub" value="${esc(b.publico)}"></div>
  <div class="f"><label>Chamada para ação</label><select id="b-cta">${opt(['CTA no final', 'CTA no meio e no final', 'Sem CTA'], b.cta)}</select></div></div>
  <div class="f"><label>Contexto extra (ângulo, o que não pode faltar, tom)</label><textarea id="b-ctx" style="min-height:80px">${esc(b.contexto)}</textarea></div>
  <div class="f"><label>Material de referência (cole matérias, transcrições, fatos — a IA usa como base)</label><textarea id="b-ref">${esc(b.referencias)}</textarea></div>
  <div class="row" style="margin-bottom:14px"><label class="btn sm" style="margin:0;color:var(--txt)">Importar arquivo (TXT, PDF, DOCX)<input type="file" id="b-ref-arq" accept=".txt,.pdf,.docx,.md" hidden></label>
  <input id="b-ref-yt" placeholder="ou cole o link de um vídeo do YouTube para puxar a transcrição" style="flex:1"><button class="sm" id="b-ref-yt-ok">Puxar transcrição</button></div>
  <div class="grid g3">
    <div class="f"><label>Esse vídeo vende algum produto? (afiliado)</label><input id="b-prod" value="${esc(b.produto)}" placeholder="Nome do produto + link"></div>
    <div class="f"><label>Série / novela (opcional)</label><input id="b-serie" value="${esc(b.serie)}" placeholder="Nome da série"></div>
    <div class="f"><label>Episódio</label><input id="b-ep" value="${esc(b.episodio)}" placeholder="Ex.: 3"></div>
  </div>
  <div class="f"><label>Resumo dos episódios anteriores (só para série)</label><textarea id="b-resumo" style="min-height:60px">${esc(b.resumo_anterior)}</textarea></div>
  <div class="f"><label>Roteiro em partes (para vídeos longos — a IA escreve melhor em pedaços)</label><select id="b-partes" style="width:auto">${[1, 2, 3, 4, 5, 6, 8].map(n => `<option value="${n}" ${Number(b.partes || 1) === n ? 'selected' : ''}>${n === 1 ? 'Roteiro inteiro de uma vez' : n + ' partes'}</option>`).join('')}</select></div>
  <div class="row end"><button class="pri" id="b-ok">Salvar e ir para o roteiro →</button></div></div>`;
  const salvarRef = r => { $('#b-ref').value = r.video.briefing.referencias; toast(`${fmt(r.caracteres)} caracteres adicionados à referência`); };
  $('#b-ref-arq').onchange = () => safe(async () => { const fd = new FormData(); fd.append('arquivo', $('#b-ref-arq').files[0]); toast('Lendo arquivo…'); salvarRef(await api(`/api/videos/${v.id}/referencia`, {method: 'POST', body: fd})); });
  $('#b-ref-yt-ok').onclick = () => safe(async () => { const u = $('#b-ref-yt').value.trim(); if (!u) return; toast('Puxando transcrição…'); salvarRef(await api(`/api/videos/${v.id}/referencia`, {json: {youtube: u}})); });
  $('#b-ok').onclick = () => safe(async () => {
    await api('/api/videos/' + v.id, {method: 'PATCH', json: {titulo: $('#b-titulo').value.trim() || v.titulo, briefing: {
      duracao_min: Number($('#b-dur').value) || 10, tipo_narrativa: $('#b-tipo').value, estrutura: $('#b-est').value,
      publico: $('#b-pub').value, cta: $('#b-cta').value, contexto: $('#b-ctx').value, referencias: $('#b-ref').value,
      produto: $('#b-prod').value, serie: $('#b-serie').value, episodio: $('#b-ep').value, resumo_anterior: $('#b-resumo').value, partes: Number($('#b-partes').value)}}});
    proxima('briefing');
  });
}

async function stRoteiro(v) {
  if (Number(v.briefing.partes || 1) > 1) return stRoteiroPartes(v);
  step().innerHTML = `<div class="grid g2"><div>${blocoPrompt('pr', 'Prompt do roteiro', 'Copie, cole na IA e traga o roteiro de volta.')}</div>
  <div class="card"><h3>Roteiro</h3><textarea id="r-txt" style="min-height:380px;font-family:inherit;font-size:14px" placeholder="Cole aqui o roteiro que a IA escreveu">${esc(v.roteiro)}</textarea>
  <div class="row" style="margin-top:8px"><span class="mut small" id="r-cont"></span><span class="sp"></span><button class="pri" id="r-ok">Salvar e analisar →</button></div></div></div>`;
  const cont = () => { const n = $('#r-txt').value.trim().split(/\s+/).filter(Boolean).length; $('#r-cont').textContent = `${n} palavras · ~${(n / (S.settings.palavras_por_minuto || 150)).toFixed(1)} min de narração`; };
  $('#r-txt').oninput = cont; cont();
  ligarPrompt('pr', (await api(`/api/videos/${v.id}/prompt/roteiro`)).prompt);
  $('#r-ok').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/colar/roteiro`, {json: {texto: $('#r-txt').value}}); toast('Roteiro salvo'); proxima('roteiro'); });
  if (window.oficinaRoteiro && v.roteiro) { step().insertAdjacentHTML('beforeend', '<div id="oficina-box"></div>'); oficinaRoteiro(v, $('#oficina-box')); }
}

async function stAnaliseRoteiro(v) {
  if (!v.roteiro) { step().innerHTML = '<div class="empty">Cole o roteiro primeiro.</div>'; return; }
  const a = v.analise;
  step().innerHTML = `<div class="grid g2"><div>${blocoPrompt('pa', 'Prompt de análise', 'A IA dá uma nota de 0 a 100 e lista as melhorias em JSON.')}
    <div class="card"><h3>Cole o JSON da análise</h3><textarea id="a-json"></textarea><div class="row end" style="margin-top:8px"><button class="pri" id="a-ok">Processar análise</button></div></div></div>
    <div id="a-res">${a ? '' : `<div class="empty">Sem análise ainda.<br><br><button onclick="proxima('analise')">Pular análise →</button></div>`}</div></div>`;
  ligarPrompt('pa', (await api(`/api/videos/${v.id}/prompt/analise`)).prompt);
  $('#a-ok').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/colar/analise`, {json: {texto: $('#a-json').value}}); toast('Análise processada'); videoView(); });
  if (!a) return;
  const cor = n => n >= 80 ? 'var(--ok)' : n >= 60 ? 'var(--warn)' : 'var(--bad)';
  $('#a-res').innerHTML = `<div class="card"><div class="row"><div class="score" style="color:${cor(a.nota_geral)}">${a.nota_geral}</div><div class="sp"><b>Nota geral</b><div class="small mut">${esc(a.resumo || '')}</div></div></div>
    ${a.hook ? `<h2>Hook (primeiros 30s): <span style="color:${cor(a.hook.nota)}">${a.hook.nota}</span></h2>
    <div class="small"><b class="mut">Fortes:</b><ul>${(a.hook.pontos_fortes || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul><b class="mut">Fracos:</b><ul>${(a.hook.pontos_fracos || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
    ${(a.dimensoes || []).length ? `<table>${a.dimensoes.map(d => `<tr><td>${esc(d.nome)}</td><td style="color:${cor(d.nota)}"><b>${d.nota}</b></td><td class="small mut">${esc(d.comentario)}</td></tr>`).join('')}</table>` : ''}
    ${a.titulo_sugerido ? `<p class="small">Título sugerido: <b>${esc(a.titulo_sugerido)}</b> <button class="sm" id="a-tit">Usar</button></p>` : ''}</div>
    <div class="card"><h3>Melhorias</h3>${(a.melhorias || []).map(m => `<div style="margin-bottom:10px"><b>${m.ordem}. ${esc(m.acao)}</b> <span class="pill ok">${esc(m.impacto_estimado || '')}</span><div class="small mut">${esc(m.como_fazer)}</div></div>`).join('')}</div>
    ${blocoPrompt('pc', 'Aplicar melhorias', 'Gera o prompt que reescreve o roteiro com todas as melhorias. Cole o roteiro novo abaixo.')}
    <div class="card"><textarea id="c-txt" placeholder="Cole o roteiro corrigido"></textarea><div class="row end" style="margin-top:8px"><button id="c-ok">Substituir roteiro e reanalisar</button><button class="pri" onclick="proxima('analise')">Seguir para cenas →</button></div></div>`;
  ligarPrompt('pc', (await api(`/api/videos/${v.id}/prompt/correcao`)).prompt);
  $('#c-ok').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/colar/correcao`, {json: {texto: $('#c-txt').value}}); toast('Roteiro atualizado — rode a análise de novo'); videoView(); });
  if ($('#a-tit')) $('#a-tit').onclick = () => safe(async () => { await api('/api/videos/' + v.id, {method: 'PATCH', json: {titulo: a.titulo_sugerido}}); videoView(); });
}
async function stAnalise(v) {
  S.abaAnalise = S.abaAnalise || 'roteiro';
  const abas = {roteiro: 'Roteiro pronto', titulo: 'Validação de título', publicado: 'Vídeo publicado'};
  step().innerHTML = `<div class="row" style="margin-bottom:12px">${Object.entries(abas).map(([k, n]) => `<button class="${S.abaAnalise === k ? 'pri' : ''}" data-aba="${k}">${n}</button>`).join('')}</div><div id="aba"></div>`;
  $$('[data-aba]').forEach(b => b.onclick = () => { S.abaAnalise = b.dataset.aba; stAnalise(v); });
  const alvo = $('#aba');
  if (S.abaAnalise === 'roteiro') { S.alvo = alvo; try { await stAnaliseRoteiro(v); } finally { S.alvo = null; } return; }
  if (S.abaAnalise === 'titulo') return abaTitulo(v, alvo);
  return abaPublicado(v, alvo);
}

async function stCenas(v) {
  if (!v.roteiro) { step().innerHTML = '<div class="empty">Cole o roteiro primeiro.</div>'; return; }
  const dur = v.cenas.length ? v.cenas[v.cenas.length - 1].fim : 0;
  const comTermos = v.cenas.filter(c => (c.termos_busca || []).length).length;
  step().innerHTML = `<div class="grid g2">
  <div class="card"><h3>1. Narração (opcional agora, obrigatória na montagem)</h3>
    <p class="small mut">Gere a narração do roteiro na sua ferramenta de voz (ElevenLabs, Gemini, etc.) e envie aqui. Os tempos das cenas e da legenda se ajustam à duração real do áudio.</p>
    <div class="row"><input type="file" id="n-file" accept="audio/*" style="flex:1"><button id="n-up">Enviar</button></div>
    <p class="small">${v.narracao ? `✓ Narração: ${(v.narracao_duracao / 60 || 0).toFixed(1)} min` : '<span class="mut">Sem narração — tempos estimados pelo número de palavras.</span>'}</p>
    <h3 style="margin-top:16px">2. Dividir em cenas</h3>
    <div class="row"><label style="margin:0">Uma cena a cada</label><input id="d-seg" type="number" min="3" max="30" value="${S.settings.segundos_por_cena || 8}" style="width:80px"><span>segundos</span><button class="pri" id="d-ok">${v.cenas.length ? 'Dividir de novo' : 'Dividir roteiro'}</button></div>
    ${v.cenas.length ? `<p class="small" style="margin-top:10px">Seu vídeo vai ter <b>${v.cenas.length} cenas</b>, ~${(dur / v.cenas.length).toFixed(1)} s cada · duração ${(dur / 60).toFixed(1)} min. <a href="/api/videos/${v.id}/arquivo/legendas.srt?baixar=1">Baixar SRT</a></p>` : ''}
  </div>
  <div>${v.cenas.length ? blocoPrompt('pcn', '3. Prompt das cenas', 'A IA define o que mostrar em cada cena e os termos de busca de mídia real. Para vídeos longos, se a IA cortar a resposta, peça "continue" e cole o resto depois.') : ''}
  ${v.cenas.length ? `<div class="card"><h3>Cole o JSON das cenas</h3><textarea id="cn-json"></textarea><div class="row end" style="margin-top:8px"><span class="mut small sp">${comTermos}/${v.cenas.length} cenas com termos</span><button class="pri" id="cn-ok">Aplicar nas cenas</button></div></div>` : ''}</div></div>
  ${v.cenas.length ? `<div class="card" style="padding:0"><table><tr><th>#</th><th>Tempo</th><th>Narração</th><th>Visual / busca</th></tr>
  ${v.cenas.map(c => `<tr><td>${c.n}</td><td class="small mut">${tempo(c.inicio)}</td><td class="small" style="max-width:420px">${esc(c.texto)}</td>
  <td class="small">${c.pessoa_real ? `<span class="pill acc">${esc(c.pessoa_real)}</span>` : ''}${esc(c.descricao_visual || '')}<div>${(c.termos_busca || []).map(t => `<span class="tag">${esc(t)}</span>`).join('')}</div></td></tr>`).join('')}</table></div>
  <div class="row end"><button class="pri big" onclick="proxima('cenas')">Ir para mídia →</button></div>` : ''}`;
  $('#n-up').onclick = () => safe(async () => {
    const f = $('#n-file').files[0]; if (!f) return toast('Escolha o áudio', true);
    const fd = new FormData(); fd.append('arquivo', f); toast('Enviando…');
    await api(`/api/videos/${v.id}/narracao`, {method: 'POST', body: fd}); toast('Narração salva'); videoView();
  });
  $('#d-ok').onclick = () => safe(async () => {
    if (v.cenas.length && !confirm('Dividir de novo apaga as mídias escolhidas. Continuar?')) return;
    await api(`/api/videos/${v.id}/dividir`, {json: {segundos_por_cena: Number($('#d-seg').value)}}); videoView();
  });
  if (v.cenas.length) {
    ligarPrompt('pcn', (await api(`/api/videos/${v.id}/prompt/cenas`)).prompt);
    $('#cn-ok').onclick = () => safe(async () => {
      const r = await api(`/api/videos/${v.id}/colar/cenas`, {json: {texto: $('#cn-json').value}});
      if (r.aviso) toast(r.aviso, true); else toast('Cenas atualizadas');
      videoView();
    });
  }
}
function tempo(s) { s = Math.floor(s || 0); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; }

async function stMidia(v) {
  if (!v.cenas.length) { step().innerHTML = '<div class="empty">Divida o roteiro em cenas primeiro.</div>'; return; }
  const cont = {escolhida: 0, manual: 0, ia: 0, pendente: 0};
  v.cenas.forEach(c => cont[c.status] = (cont[c.status] || 0) + 1);
  const exatas = v.cenas.filter(c => c.midia && c.midia.match === 'exata').length;
  const videos = v.cenas.filter(c => c.midia && c.midia.tipo === 'video').length;
  const filtros = {todas: () => true, ia: c => c.status === 'ia' || !c.midia, parecidas: c => c.midia && c.midia.match !== 'exata', exatas: c => c.midia && c.midia.match === 'exata'};
  const lista = v.cenas.filter(filtros[S.filtroCena] || filtros.todas);
  const semKeys = !S.settings.pixabay_key && !S.settings.pexels_key;
  step().innerHTML = `
  ${semKeys ? `<div class="hint">Só o Wikimedia Commons está ativo. Coloque as chaves grátis do Pixabay e do Pexels em <a href="#" onclick="go('config')">Configurações</a> para ter vídeos e muito mais opções.</div>` : ''}
  <div class="card"><div class="row"><div class="sp"><b>${cont.escolhida + cont.manual} de ${v.cenas.length}</b> cenas com mídia · ${exatas} exatas · ${videos} com vídeo · <span style="color:var(--warn)">${cont.ia + cont.pendente} sem mídia (IA)</span></div>
  <button class="pri" id="m-buscar">${cont.escolhida + cont.manual ? 'Buscar de novo (só pendentes)' : 'Buscar mídia de todas as cenas'}</button>${cont.escolhida + cont.manual ? '<button id="m-buscar-tudo">Refazer tudo</button>' : ''}</div>
  <div id="m-prog" style="margin-top:10px"></div></div>
  <div class="card"><h3>Cenas sem mídia real boa → IA (Google Flow, Midjourney, etc.)</h3>
  <p class="small mut">Copie os prompts, gere as imagens/vídeos e salve com o número da cena no nome (ex.: <b>007.png</b>). Depois envie todos de uma vez aqui que cada arquivo entra na cena certa.</p>
  <div class="row"><button id="m-pia">Copiar prompts das cenas sem mídia</button><a class="btn" href="https://labs.google/fx/tools/flow" target="_blank">Abrir Google Flow</a><span class="sp"></span>
  <input type="file" id="m-lote" multiple accept="image/*,video/*" style="width:auto"><button class="pri" id="m-lote-ok">Importar lote</button></div></div>
  <div class="row" style="margin-bottom:10px">${Object.entries({todas: 'Todas', ia: 'Sem mídia', parecidas: 'Parecidas', exatas: 'Exatas'}).map(([k, n]) => `<button class="sm ${S.filtroCena === k ? 'pri' : ''}" data-f="${k}">${n}</button>`).join('')}
  <span class="sp"></span><button class="pri" onclick="proxima('midia')">Ir para montagem →</button></div>
  <div class="scene-grid">${lista.map(cardCena).join('')}</div>`;
  $$('[data-f]').forEach(b => b.onclick = () => { S.filtroCena = b.dataset.f; stMidia(v); });
  const iniciar = so => safe(async () => { await api(`/api/videos/${v.id}/buscar_midia`, {json: {so_pendentes: so}}); acompanharMidia(v.id); });
  $('#m-buscar').onclick = () => iniciar(cont.escolhida + cont.manual > 0);
  if ($('#m-buscar-tudo')) $('#m-buscar-tudo').onclick = () => confirm('Refazer a busca de todas as cenas (menos as que você escolheu na mão)?') && iniciar(false);
  $('#m-pia').onclick = () => safe(async () => { const r = await api(`/api/videos/${v.id}/prompts_ia`); if (!r.quantidade) return toast('Todas as cenas têm mídia'); copiar(r.texto); });
  $('#m-lote-ok').onclick = () => safe(async () => {
    const fs = $('#m-lote').files; if (!fs.length) return toast('Escolha os arquivos', true);
    const fd = new FormData(); [...fs].forEach(f => fd.append('arquivos', f)); toast('Enviando…');
    const r = await api(`/api/videos/${v.id}/importar_lote`, {method: 'POST', body: fd});
    toast(`${r.importados} importado(s)` + (r.ignorados.length ? ` · ignorados: ${r.ignorados.join(', ')}` : '')); videoView();
  });
  ligarCenas(v);
  const st = await api(`/api/videos/${v.id}/midia_status`); if (st.rodando) acompanharMidia(v.id);
}
function cardCena(c) {
  const m = c.midia;
  const thumb = m ? (m.arquivo ? (m.tipo === 'video' ? `<video src="/api/videos/${S.video.id}/midia/${c.n}" muted></video>` : `<img src="/api/videos/${S.video.id}/midia/${c.n}?t=${Date.now()}">`) : `<img src="${esc(m.preview)}" loading="lazy">`) : 'sem mídia — vai para IA';
  const badge = m ? `<span class="pill ${m.match === 'exata' ? 'ok' : m.match === 'parecida' ? 'warn' : 'bad'}">${m.match === 'exata' ? 'Exata' : m.match === 'parecida' ? 'Parecida' : 'Genérica'}</span><span class="pill">${m.tipo === 'video' ? 'vídeo' : 'foto'}</span>${m.nota != null ? `<span class="pill">nota ${m.nota}/10</span>` : ''}` : '<span class="pill bad">IA</span>';
  const aberto = S.abertos.has(c.n);
  return `<div class="scene" id="sc-${c.n}"><div class="thumb">${thumb}${m?.tipo === 'video' ? '<span class="vt">▶ vídeo</span>' : ''}</div>
  <div>${badge}</div>
  <div class="small"><b>${String(c.n).padStart(2, '0')}</b> <span class="mut">${esc(m?.fonte || '')} · ${tempo(c.inicio)}</span></div>
  <div class="txt">${esc(c.texto)}</div>
  ${c.descricao_visual ? `<div class="small mut">plano: ${esc(c.descricao_visual)}</div>` : ''}
  ${m?.pagina ? `<div class="small"><a href="${esc(m.pagina)}" target="_blank">ver origem</a> <span class="mut">${esc(m.licenca || '')}</span></div>` : ''}
  <div class="acts">
    <button class="sm" data-cand="${c.n}">${aberto ? 'Fechar' : 'Outros candidatos'} (${(c.candidatos || []).length})</button>
    <button class="sm" data-termos="${c.n}">Buscar com meus termos</button>
    <label class="btn sm" style="margin:0;color:var(--txt)">Arquivo do computador<input type="file" data-arq="${c.n}" accept="image/*,video/*" hidden></label>
    <button class="sm" data-pessoa="${c.n}">Pessoa real</button>
    <button class="sm" data-contexto="${c.n}">Mídia de contexto</button>
    <button class="sm" data-yt="${c.n}">YouTube CC</button>
    <button class="sm" data-ia="${c.n}">Mandar para IA</button>
  </div>
  ${aberto ? `<div class="cands">${(c.candidatos || []).map((x, i) => `<div class="cand" data-pick="${c.n}:${i}"><img src="${esc(x.preview)}" loading="lazy"><div>${x.tipo === 'video' ? '▶ ' : ''}${esc(x.fonte)} · ${x.nota}/10<br><span class="mut">${esc((x.titulo || '').slice(0, 50))}</span></div></div>`).join('') || '<span class="mut small">Nenhum candidato. Busque com outros termos.</span>'}</div>` : ''}
  </div>`;
}
function ligarCenas(v) {
  const vid = v.id;
  const recarregar = async () => { S.video = await api('/api/videos/' + vid); stMidia(S.video); };
  $$('[data-cand]').forEach(b => b.onclick = () => { const n = +b.dataset.cand; S.abertos.has(n) ? S.abertos.delete(n) : S.abertos.add(n); stMidia(v); });
  $$('[data-pick]').forEach(d => d.onclick = () => safe(async () => {
    const [n, i] = d.dataset.pick.split(':').map(Number);
    await api(`/api/videos/${vid}/cenas/${n}/escolher`, {json: {indice: i}}); S.abertos.delete(n); toast(`Cena ${n} atualizada`); recarregar();
  }));
  $$('[data-termos]').forEach(b => b.onclick = () => {
    const n = +b.dataset.termos, c = v.cenas.find(x => x.n === n);
    const t = prompt('Termos de busca (em inglês funciona melhor), separados por ponto e vírgula:', (c.termos_busca || []).join('; '));
    if (!t) return;
    safe(async () => { toast('Buscando…'); const r = await api(`/api/videos/${vid}/cenas/${n}/buscar`, {json: {termos: t.split(';')}}); if (r.erros?.length) toast(r.erros[0], true); S.abertos.add(n); recarregar(); });
  });
  $$('[data-arq]').forEach(inp => inp.onchange = () => safe(async () => {
    const fd = new FormData(); fd.append('arquivo', inp.files[0]); toast('Enviando…');
    await api(`/api/videos/${vid}/cenas/${inp.dataset.arq}/arquivo`, {method: 'POST', body: fd}); recarregar();
  }));
  $$('[data-ia]').forEach(b => b.onclick = () => safe(async () => { await api(`/api/videos/${vid}/cenas/${b.dataset.ia}/ia`, {method: 'POST'}); recarregar(); }));
  const buscaModo = async (n, json, msg) => { toast(msg); const r = await api(`/api/videos/${vid}/cenas/${n}/buscar`, {json}); if (r.erros?.length) toast(r.erros[0], true); if (!(r.cena.candidatos || []).length) toast('Nada encontrado', true); S.abertos.add(n); recarregar(); };
  $$('[data-pessoa]').forEach(b => b.onclick = () => {
    const n = +b.dataset.pessoa, c = v.cenas.find(x => x.n === n);
    const nome = prompt('Nome da pessoa real (como aparece na Wikipédia):', c.pessoa_real || ''); if (!nome) return;
    safe(() => buscaModo(n, {modo: 'pessoa', nome}, 'Buscando fotos reais…'));
  });
  $$('[data-contexto]').forEach(b => b.onclick = () => safe(() => buscaModo(+b.dataset.contexto, {modo: 'contexto'}, 'Buscando mídia de contexto…')));
  $$('[data-yt]').forEach(b => b.onclick = () => {
    const n = +b.dataset.yt, c = v.cenas.find(x => x.n === n);
    const t = prompt('Buscar no YouTube (só vídeos Creative Commons). Cada busca gasta 100 cotas da sua chave:', (c.termos_busca || [])[0] || ''); if (!t) return;
    safe(() => buscaModo(n, {modo: 'youtube', termos: [t]}, 'Buscando no YouTube CC…'));
  });
}
async function acompanharMidia(vid) {
  const el = $('#m-prog'); if (!el) return;
  const st = await api(`/api/videos/${vid}/midia_status`);
  const pct = st.total ? Math.round(st.feito / st.total * 100) : 0;
  el.innerHTML = `<div class="small mut">${esc(st.etapa || '')} ${st.total ? `(${st.feito}/${st.total})` : ''}</div><div class="prog"><div style="width:${pct}%"></div></div>${st.erro ? `<div class="danger small">${esc(st.erro)}</div>` : ''}`;
  if (st.rodando) { setTimeout(() => S.view === 'video' && S.step === 'midia' && acompanharMidia(vid), 1500); return; }
  if (st.erros?.length) toast('Alguns bancos falharam: ' + [...new Set(st.erros)].slice(0, 2).join(' | '), true);
  S.video = await api('/api/videos/' + vid); stMidia(S.video);
  if (st.erro) toast(st.erro, true);
}

async function stMontagem(v) {
  const s = S.settings;
  const comMidia = v.cenas.filter(c => c.midia).length;
  step().innerHTML = `<div class="grid g2"><div class="card"><h3>Áudio</h3>
    <div class="f"><label>Narração ${v.narracao ? `<span class="pill ok">✓ ${(v.narracao_duracao / 60 || 0).toFixed(1)} min</span>` : '<span class="pill bad">faltando</span>'}</label><div class="row"><input type="file" id="mo-narr" accept="audio/*" style="flex:1"><button id="mo-narr-ok">Enviar</button></div></div>
    <div class="f"><label>Música de fundo (opcional) ${v.musica ? '<span class="pill ok">✓</span>' : ''}</label><div class="row"><input type="file" id="mo-mus" accept="audio/*" style="flex:1"><button id="mo-mus-ok">Enviar</button></div></div>
    <div class="f"><label>Volume da música: <b id="mo-vol-v">${Math.round((v.musica_volume || .12) * 100)}%</b></label><input type="range" id="mo-vol" min="0" max="0.5" step="0.01" value="${v.musica_volume || .12}"></div>
    <h3 style="margin-top:16px">Estilo</h3>
    <div class="row"><label style="margin:0"><input type="checkbox" id="mo-grao" ${s.grao ? 'checked' : ''}> Mesmo tratamento de cor + grão em todas as cenas</label></div>
    <div class="row"><label style="margin:0"><input type="checkbox" id="mo-zoom" ${s.zoom_suave ? 'checked' : ''}> Zoom/movimento suave nas fotos</label></div>
    <div class="row"><label style="margin:0"><input type="checkbox" id="mo-leg" ${s.legenda_queimada ? 'checked' : ''}> Legenda gravada no vídeo</label></div>
    <div class="f" style="margin-top:8px"><label>Formato</label><select id="mo-res"><option value="1920x1080" ${s.resolucao === '1920x1080' ? 'selected' : ''}>16:9 (1920×1080) — vídeo longo</option><option value="1080x1920" ${s.resolucao === '1080x1920' ? 'selected' : ''}>9:16 (1080×1920) — Shorts/TikTok/Reels</option><option value="1280x720" ${s.resolucao === '1280x720' ? 'selected' : ''}>16:9 (1280×720) — mais rápido</option></select></div>
  </div>
  <div class="card"><h3>Gerar vídeo</h3>
    <p class="small">${v.cenas.length} cenas · ${comMidia} com mídia · ${v.cenas.length - comMidia} ficarão com fundo escuro</p>
    ${!v.narracao ? '<div class="hint">Envie a narração antes de gerar — é ela que define o tempo de cada cena.</div>' : ''}
    <button class="pri big" id="mo-go" ${v.cenas.length ? '' : 'disabled'}>Gerar MP4</button>
    <div id="mo-prog" style="margin-top:12px"></div>
    ${v.saida ? `<h3 style="margin-top:16px">Resultado</h3><video controls src="/api/videos/${v.id}/arquivo/final.mp4?t=${Date.now()}"></video>
    <div class="row" style="margin-top:8px"><a class="btn pri" href="/api/videos/${v.id}/arquivo/final.mp4?baixar=1">Baixar MP4</a><a class="btn" href="/api/videos/${v.id}/arquivo/legendas.srt?baixar=1">Baixar SRT</a><a class="btn" href="/api/videos/${v.id}/arquivo/creditos.txt" target="_blank">Créditos das imagens</a><button id="mo-pasta">Abrir pasta</button></div>` : ''}
    <div class="row" style="margin-top:12px"><a class="btn" id="mo-pacote" href="/api/videos/${v.id}/pacote">Exportar pacote para CapCut (.zip)</a><span class="small mut">mídias numeradas + narração + SRT + cenas.csv</span></div>
  </div></div>
  <div class="row end"><button class="pri" onclick="proxima('montagem')">Descrição e tags →</button></div>`;
  const up = (inp, url) => safe(async () => { const f = $(inp).files[0]; if (!f) return toast('Escolha o arquivo', true); const fd = new FormData(); fd.append('arquivo', f); toast('Enviando…'); await api(url, {method: 'POST', body: fd}); toast('Enviado'); videoView(); });
  $('#mo-narr-ok').onclick = () => up('#mo-narr', `/api/videos/${v.id}/narracao`);
  $('#mo-mus-ok').onclick = () => up('#mo-mus', `/api/videos/${v.id}/musica`);
  $('#mo-vol').oninput = e => $('#mo-vol-v').textContent = Math.round(e.target.value * 100) + '%';
  $('#mo-vol').onchange = e => api('/api/videos/' + v.id, {method: 'PATCH', json: {musica_volume: Number(e.target.value)}});
  const salvarEstilo = () => api('/api/settings', {json: {grao: $('#mo-grao').checked, zoom_suave: $('#mo-zoom').checked, legenda_queimada: $('#mo-leg').checked, resolucao: $('#mo-res').value}}).then(s => S.settings = s);
  ['#mo-grao', '#mo-zoom', '#mo-leg', '#mo-res'].forEach(k => $(k).onchange = salvarEstilo);
  $('#mo-go').onclick = () => safe(async () => { await salvarEstilo(); await api(`/api/videos/${v.id}/render`, {method: 'POST'}); acompanharRender(v.id); });
  $('#mo-pacote').onclick = () => toast('Preparando o pacote (baixando mídias que faltam)… pode levar alguns minutos.');
  if ($('#mo-pasta')) $('#mo-pasta').onclick = () => safe(async () => { const r = await api(`/api/videos/${v.id}/abrir_pasta`, {method: 'POST'}); toast(r.pasta); });
  const st = await api(`/api/videos/${v.id}/render_status`); if (st.rodando) acompanharRender(v.id);
}
async function acompanharRender(vid) {
  const el = $('#mo-prog'); if (!el) return;
  const st = await api(`/api/videos/${vid}/render_status`);
  el.innerHTML = `<div class="small">${esc(st.etapa || '')}</div><div class="prog"><div style="width:${st.pct || 0}%"></div></div>${st.erro ? `<div class="copybox danger" style="margin-top:8px">${esc(st.erro)}</div>` : ''}${st.aviso ? `<div class="hint" style="margin-top:8px">${esc(st.aviso)}</div>` : ''}`;
  if (st.rodando) { setTimeout(() => S.view === 'video' && S.step === 'montagem' && acompanharRender(vid), 1500); return; }
  if (st.saida && !st.erro) { toast('Vídeo pronto!'); setTimeout(() => videoView(), 600); }
}

async function stDescricao(v) {
  const d = v.descricao;
  step().innerHTML = `<div class="grid g2"><div>${blocoPrompt('pd', 'Prompt de SEO', 'Títulos, descrição, tags, capítulos e ideias de thumbnail.')}
    <div class="card"><h3>Cole o JSON</h3><textarea id="d-json"></textarea><div class="row end" style="margin-top:8px"><button class="pri" id="d-ok">Processar</button></div></div>
    <div class="card"><h3>Publicação</h3><div class="row"><div class="sp"><label>Data de publicação</label><input type="date" id="d-data" value="${esc(v.data_publicacao)}"></div>
    <label style="margin:18px 0 0"><input type="checkbox" id="d-pub" ${v.publicado ? 'checked' : ''}> Já publicado</label></div></div></div>
  <div id="d-res">${d ? '' : '<div class="empty">Sem descrição ainda.</div>'}</div></div>`;
  ligarPrompt('pd', (await api(`/api/videos/${v.id}/prompt/descricao`)).prompt);
  $('#d-ok').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/colar/descricao`, {json: {texto: $('#d-json').value}}); videoView(); });
  $('#d-data').onchange = e => safe(() => api('/api/videos/' + v.id, {method: 'PATCH', json: {data_publicacao: e.target.value}}).then(() => toast('Data salva')));
  $('#d-pub').onchange = e => safe(() => api('/api/videos/' + v.id, {method: 'PATCH', json: {publicado: e.target.checked}}).then(() => toast('Atualizado')));
  if (!d) return;
  const desc = [d.descricao || '', '', (d.capitulos || []).map(c => `${c.tempo} ${c.titulo}`).join('\n'), '', (d.hashtags || []).join(' ')].join('\n').trim();
  $('#d-res').innerHTML = `<div class="card"><h3>Títulos</h3>${(d.titulos || []).map((t, i) => `<div class="row" style="margin-bottom:6px"><span style="flex:1">${esc(t)}</span><span class="mut small">${t.length}</span><button class="sm" data-usar="${i}">Usar</button><button class="sm" data-cp="${esc(t)}">Copiar</button></div>`).join('')}</div>
  <div class="card"><div class="row"><h3 style="margin:0">Descrição</h3><span class="sp"></span><button class="sm pri" id="cp-desc">Copiar</button></div><div class="copybox" style="margin-top:8px">${esc(desc)}</div></div>
  <div class="card"><div class="row"><h3 style="margin:0">Tags</h3><span class="sp"></span><button class="sm pri" id="cp-tags">Copiar</button></div><div style="margin-top:8px">${(d.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join('')}</div></div>
  <div class="card"><h3>Thumbnail</h3>${(d.thumb_textos || []).map(t => `<span class="tag">${esc(t)}</span>`).join('')}${(d.thumb_prompts || []).map(p => `<div class="row" style="margin-top:8px"><span class="small" style="flex:1">${esc(p)}</span><button class="sm" data-cp="${esc(p)}">Copiar</button></div>`).join('')}</div>`;
  $('#cp-desc').onclick = () => copiar(desc);
  $('#cp-tags').onclick = () => copiar((d.tags || []).join(', '));
  $$('[data-cp]').forEach(b => b.onclick = () => copiar(b.dataset.cp));
  $$('[data-usar]').forEach(b => b.onclick = () => safe(async () => { await api('/api/videos/' + v.id, {method: 'PATCH', json: {titulo: d.titulos[+b.dataset.usar]}}); toast('Título atualizado'); videoView(); }));
}

// ---------------- configurações ----------------
async function config() {
  const s = S.settings;
  main.innerHTML = `<h1>Configurações</h1><p class="sub">Chaves grátis das APIs e padrões de produção. Tudo fica salvo só no seu computador.</p>
  <div class="grid g2"><div class="card"><h3>Chaves</h3>
    <div class="f"><label>YouTube Data API v3 (radar) — <a href="https://console.cloud.google.com/apis/library/youtube.googleapis.com" target="_blank">criar chave grátis</a></label><input id="s-yt" value="${esc(s.youtube_api_key)}" type="password"></div>
    <div class="f"><label>Pixabay (fotos e vídeos) — <a href="https://pixabay.com/api/docs/" target="_blank">pegar chave grátis</a></label><input id="s-px" value="${esc(s.pixabay_key)}" type="password"></div>
    <div class="f"><label>Pexels (fotos e vídeos) — <a href="https://www.pexels.com/api/" target="_blank">pegar chave grátis</a></label><input id="s-pe" value="${esc(s.pexels_key)}" type="password"></div>
    <div class="f"><label>Gemini (narração com voz do Gemini) — <a href="https://aistudio.google.com/apikey" target="_blank">pegar chave grátis</a></label><input id="s-gem" value="${esc(s.gemini_key)}" type="password"></div>
    <div class="f"><label>Modelo de voz do Gemini</label><input id="s-gem-mod" value="${esc(s.gemini_tts_modelo)}"></div>
    <p class="small mut">Wikimedia Commons (fotos históricas e de pessoas reais) e as vozes do Edge funcionam sem chave.</p></div>
  <div class="card"><h3>Produção</h3>
    <div class="grid g2"><div class="f"><label>Segundos por cena (padrão)</label><input id="s-seg" type="number" value="${s.segundos_por_cena}"></div>
    <div class="f"><label>Palavras por minuto da narração</label><input id="s-ppm" type="number" value="${s.palavras_por_minuto}"></div>
    <div class="f"><label>FPS</label><select id="s-fps"><option ${s.fps == 24 ? 'selected' : ''}>24</option><option ${s.fps == 30 ? 'selected' : ''}>30</option></select></div></div>
    <p class="small mut">Português narrado costuma ficar entre 140 e 160 palavras por minuto.</p>
    <h3 style="margin-top:14px">IA nas cenas sem mídia real</h3>
    <div class="f"><label>Máximo de cenas por IA (%) — acima disso a ferramenta usa a melhor mídia genérica</label><input id="s-pct" type="number" min="0" max="100" value="${s.max_cenas_ia_pct}"></div>
    <div class="f"><label>Look da IA (vai no fim de cada prompt de imagem, para todas as cenas ficarem com a mesma cara)</label><textarea id="s-look" style="min-height:60px">${esc(s.ia_look)}</textarea></div></div></div>
  <button class="pri" id="s-ok">Salvar</button>`;
  $('#s-ok').onclick = () => safe(async () => {
    S.settings = await api('/api/settings', {json: {youtube_api_key: $('#s-yt').value.trim(), pixabay_key: $('#s-px').value.trim(), pexels_key: $('#s-pe').value.trim(),
      segundos_por_cena: Number($('#s-seg').value) || 8, palavras_por_minuto: Number($('#s-ppm').value) || 150, fps: Number($('#s-fps').value),
      gemini_key: $('#s-gem').value.trim(), gemini_tts_modelo: $('#s-gem-mod').value.trim() || 'gemini-2.5-flash-preview-tts', max_cenas_ia_pct: Number($('#s-pct').value), ia_look: $('#s-look').value.trim()}});
    toast('Configurações salvas');
  });
}

go('painel');
