// Fábrica Dark — módulos extras (VozLab, Editor, ThumbLab, Mapa de nichos, DarkMetrics, Financeiro, roteiro em partes, análises)
const brl = n => Number(n || 0).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'});

// ---------------- Roteiro em partes ----------------
async function stRoteiroPartes(v) {
  const n = Number(v.briefing.partes || 2);
  const partes = v.partes_roteiro || [];
  S.parteAtual = Math.min(S.parteAtual || 1, n);
  const k = S.parteAtual;
  const temEstr = !!(v.briefing.estrutura_texto || '').trim();
  step().innerHTML = `<div class="hint">Roteiro longo em <b>${n} partes</b>. Primeiro a IA monta a estrutura; depois você pede parte por parte (cada prompt já leva a estrutura e o final da parte anterior). Para escrever de uma vez, mude em Briefing.</div>
  <div class="grid g2"><div>${blocoPrompt('pe', '1. Estrutura do vídeo')}
    <div class="card"><h3>Cole a estrutura que a IA devolveu</h3><textarea id="pe-txt">${esc(v.briefing.estrutura_texto || '')}</textarea>
    <div class="row end" style="margin-top:8px"><button class="pri" id="pe-ok">Salvar estrutura</button></div></div></div>
  <div>${temEstr ? `<div class="card"><div class="row">${Array.from({length: n}, (_, i) => `<button class="sm ${k === i + 1 ? 'pri' : ''}" data-parte="${i + 1}">Parte ${i + 1} ${partes[i] ? '✓' : ''}</button>`).join('')}</div></div>
    ${blocoPrompt('pp', `2. Prompt da parte ${k} de ${n}`)}
    <div class="card"><h3>Cole a parte ${k}</h3><textarea id="pp-txt" style="min-height:220px;font-family:inherit">${esc(partes[k - 1] || '')}</textarea>
    <div class="row" style="margin-top:8px"><span class="mut small sp">${fmt(v.roteiro.split(/\s+/).filter(Boolean).length)} palavras no roteiro até agora</span><button class="pri" id="pp-ok">Salvar parte ${k}</button></div></div>`
    : '<div class="empty">Salve a estrutura para liberar as partes.</div>'}</div></div>
  ${partes.filter(Boolean).length === n ? `<div class="row end"><button class="pri big" onclick="proxima('roteiro')">Roteiro completo — analisar →</button></div>` : ''}`;
  ligarPrompt('pe', (await api(`/api/videos/${v.id}/prompt/estrutura`)).prompt);
  $('#pe-ok').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/colar/estrutura`, {json: {texto: $('#pe-txt').value}}); toast('Estrutura salva'); videoView(); });
  if (!temEstr) return;
  $$('[data-parte]').forEach(b => b.onclick = () => { S.parteAtual = +b.dataset.parte; videoView(); });
  ligarPrompt('pp', (await api(`/api/videos/${v.id}/prompt/parte?k=${k}`)).prompt);
  $('#pp-ok').onclick = () => safe(async () => {
    await api(`/api/videos/${v.id}/colar/parte`, {json: {texto: $('#pp-txt').value, k}});
    toast(`Parte ${k} salva`); if (k < n) S.parteAtual = k + 1; videoView();
  });
}

// ---------------- Análise: título e vídeo publicado ----------------
async function abaTitulo(v, alvo) {
  const t = v.titulo_check;
  alvo.innerHTML = `<div class="grid g2"><div><div class="card"><h3>Outras opções de título (opcional, uma por linha)</h3><textarea id="t-op" style="min-height:70px"></textarea><button class="sm" id="t-ger" style="margin-top:8px">Atualizar prompt</button></div>
  ${blocoPrompt('ptt', 'Prompt de validação de título')}
  <div class="card"><h3>Cole o JSON</h3><textarea id="t-json"></textarea><div class="row end" style="margin-top:8px"><button class="pri" id="t-ok">Processar</button></div></div></div>
  <div>${t ? `<div class="card"><div class="row"><div class="score">${t.nota_ctr ?? '—'}</div><div class="sp"><b>Nota de CTR</b><div class="small mut">curiosidade ${t.curiosidade ?? '—'} · clareza ${t.clareza ?? '—'} · emoção ${t.emocao ?? '—'}</div></div></div>
    <ul class="small">${(t.problemas || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>
    <div class="card"><h3>Alternativas</h3>${(t.alternativas || []).map((a, i) => `<div class="row" style="margin-bottom:8px"><div class="sp"><b>${esc(a.titulo || a)}</b><div class="small mut">${esc(a.porque || '')}</div></div><button class="sm" data-ut="${i}">Usar</button></div>`).join('')}</div>`
    : '<div class="empty">Valide o título antes de gravar a narração — é a parte que mais mexe no CTR.</div>'}</div></div>`;
  const carregar = async () => ligarPrompt('ptt', (await api(`/api/videos/${v.id}/prompt/titulo?opcoes=${encodeURIComponent($('#t-op').value)}`)).prompt);
  await carregar();
  $('#t-ger').onclick = () => safe(carregar);
  $('#t-ok').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/colar/titulo`, {json: {texto: $('#t-json').value}}); videoView(); });
  $$('[data-ut]').forEach(b => b.onclick = () => safe(async () => { const a = t.alternativas[+b.dataset.ut]; await api('/api/videos/' + v.id, {method: 'PATCH', json: {titulo: a.titulo || a}}); toast('Título atualizado'); videoView(); }));
}
async function abaPublicado(v, alvo) {
  const p = v.publicado_analise;
  alvo.innerHTML = `<div class="grid g2"><div><div class="card"><h3>Métricas do YouTube Studio</h3><p class="small mut">Cole o que tiver: impressões, CTR, visualizações, duração média, % de retenção, retenção aos 30 s, origem do tráfego, inscritos ganhos…</p>
  <textarea id="pb-met" placeholder="Impressões: 12.400&#10;CTR: 4,1%&#10;Duração média: 3:12 (27%)&#10;Retenção aos 30s: 58%"></textarea><button class="sm" id="pb-ger" style="margin-top:8px">Montar prompt</button></div>
  ${blocoPrompt('ppb', 'Prompt de análise do vídeo publicado')}
  <div class="card"><h3>Cole o JSON</h3><textarea id="pb-json"></textarea><div class="row end" style="margin-top:8px"><button class="pri" id="pb-ok">Processar</button></div></div></div>
  <div>${p ? `<div class="card"><div class="row"><div class="score">${p.nota ?? '—'}</div><div class="sp"><b>Diagnóstico</b><div class="small mut">${esc(p.diagnostico || '')}</div></div></div>
    <table>${(p.pontos || []).map(x => `<tr><td><b>${esc(x.metrica)}</b></td><td class="small">${esc(x.leitura)}<div class="mut">${esc(x.acao)}</div></td></tr>`).join('')}</table>
    <p class="small"><b>Próximo vídeo:</b> ${esc(p.proximo_video || '')}</p>
    ${(p.titulos_alternativos || []).length ? `<p class="small"><b>Títulos para testar:</b></p>${p.titulos_alternativos.map(x => `<span class="tag">${esc(x)}</span>`).join('')}` : ''}
    ${(p.ideias_thumb || []).length ? `<p class="small"><b>Thumbs para testar:</b></p><ul class="small">${p.ideias_thumb.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}</div>`
    : '<div class="empty">Depois de publicar, volte aqui com as métricas para saber o que ajustar.</div>'}</div></div>`;
  const carregar = async () => ligarPrompt('ppb', (await api(`/api/videos/${v.id}/prompt/publicado?metricas=${encodeURIComponent($('#pb-met').value)}`)).prompt);
  await carregar();
  $('#pb-ger').onclick = () => safe(carregar);
  $('#pb-ok').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/colar/publicado`, {json: {texto: $('#pb-json').value}}); videoView(); });
}

// ---------------- VozLab ----------------
async function stNarracao(v) {
  if (!v.roteiro) { step().innerHTML = '<div class="empty">Cole o roteiro primeiro.</div>'; return; }
  const vozes = S.vozes || (S.vozes = await api('/api/vozes'));
  const ch = S.channels.find(c => c.id === v.channel_id) || {};
  const idioma = ch.idioma || 'pt';
  const cfg = Object.assign({motor: S.settings.voz_motor || 'edge', voz_edge: S.settings['voz_edge_' + idioma] || vozes.edge[idioma][0][0], voz_gemini: S.settings.voz_gemini || 'Charon', velocidade: S.settings.voz_velocidade || '+0%', estilo: S.settings.voz_estilo || ''}, v.voz || {});
  const blocos = v.blocos_voz || [];
  const prontos = blocos.filter(b => b.status === 'pronto').length;
  const opcEdge = Object.entries(vozes.edge).map(([lg, lst]) => `<optgroup label="${IDIOMAS[lg]}">${lst.map(([id, n]) => `<option value="${id}" ${cfg.voz_edge === id ? 'selected' : ''}>${esc(n)}</option>`).join('')}</optgroup>`).join('');
  const opcGem = vozes.gemini.map(([id, n]) => `<option value="${id}" ${cfg.voz_gemini === id ? 'selected' : ''}>${id} — ${esc(n)}</option>`).join('');
  step().innerHTML = `<div class="grid g2"><div class="card"><h3>Voz</h3>
    <div class="grid g2"><div class="f"><label>Motor</label><select id="vz-motor"><option value="edge" ${cfg.motor === 'edge' ? 'selected' : ''}>Edge — grátis, sem chave</option><option value="gemini" ${cfg.motor === 'gemini' ? 'selected' : ''}>Gemini — mais expressiva (sua chave)</option></select></div>
    <div class="f" id="vz-f-edge"><label>Voz (Edge)</label><select id="vz-edge">${opcEdge}</select></div>
    <div class="f" id="vz-f-gem"><label>Voz (Gemini)</label><select id="vz-gem">${opcGem}</select></div>
    <div class="f" id="vz-f-vel"><label>Velocidade</label><select id="vz-vel">${['-15%', '-10%', '-5%', '+0%', '+5%', '+10%', '+15%'].map(x => `<option ${cfg.velocidade === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div></div>
    <div class="f" id="vz-f-est"><label>Direção da voz (Gemini) — como narrar</label><input id="vz-est" value="${esc(cfg.estilo)}" placeholder="Ex.: Narre em tom sombrio e misterioso, ritmo calmo, pausas dramáticas"></div>
    <div class="row"><button id="vz-teste">▶ Ouvir amostra</button><button id="vz-salvar">Salvar voz</button><audio id="vz-audio" controls style="height:34px;flex:1;display:none"></audio></div>
  </div>
  <div class="card"><h3>Já tem a narração pronta?</h3><p class="small mut">Se gravou ou gerou fora (ElevenLabs etc.), envie aqui e pule o VozLab.</p>
    <div class="row"><input type="file" id="vz-up" accept="audio/*" style="flex:1"><button id="vz-up-ok">Enviar</button></div>
    ${v.narracao ? `<h3 style="margin-top:16px">Narração atual <span class="pill ok">${(v.narracao_duracao / 60 || 0).toFixed(1)} min · ${v.narracao_origem === 'vozlab' ? 'VozLab' : 'enviada'}</span></h3><audio controls style="width:100%" src="/api/videos/${v.id}/voz/final?t=${Date.now()}"></audio>
    <div class="row end" style="margin-top:8px"><button class="pri" onclick="proxima('narracao')">Ir para cenas →</button></div>` : ''}</div></div>
  <div class="card"><div class="row"><h3 style="margin:0" class="sp">Blocos de narração ${blocos.length ? `<span class="pill">${prontos}/${blocos.length} prontos</span>` : ''}</h3>
    <button id="vz-prep">${blocos.length ? 'Dividir de novo' : 'Dividir roteiro em blocos'}</button>
    ${blocos.length ? `<button class="pri" id="vz-gerar">${prontos ? 'Gerar os que faltam' : 'Gerar todos'}</button><button id="vz-refazer">Refazer todos com a voz atual</button>` : ''}
    ${blocos.length && prontos === blocos.length ? '<button class="pri" id="vz-juntar">Juntar e usar como narração</button>' : ''}</div>
    <div id="vz-prog" style="margin-top:10px"></div>
    ${blocos.map(b => `<div style="border-top:1px solid var(--line);padding:10px 0"><div class="row"><b>${String(b.i).padStart(2, '0')}</b>
      <span class="pill ${b.status === 'pronto' ? 'ok' : b.status === 'erro' ? 'bad' : ''}">${b.status}${b.duracao ? ' · ' + b.duracao.toFixed(1) + 's' : ''}</span><span class="sp"></span>
      ${b.status === 'pronto' ? `<audio controls preload="none" src="/api/videos/${v.id}/voz/audio/${b.i}?t=${encodeURIComponent(b.arquivo)}" style="height:30px"></audio>` : ''}
      <button class="sm" data-regerar="${b.i}">${b.status === 'pronto' ? 'Regerar' : 'Gerar'}</button></div>
      ${b.erro ? `<div class="small danger">${esc(b.erro)}</div>` : ''}
      <textarea data-btxt="${b.i}" style="min-height:70px;font-family:inherit;margin-top:6px">${esc(b.texto)}</textarea></div>`).join('')}
  </div>`;
  const mostra = () => { const g = $('#vz-motor').value === 'gemini'; $('#vz-f-edge').style.display = g ? 'none' : ''; $('#vz-f-vel').style.display = g ? 'none' : ''; $('#vz-f-gem').style.display = g ? '' : 'none'; $('#vz-f-est').style.display = g ? '' : 'none'; };
  $('#vz-motor').onchange = mostra; mostra();
  const lerCfg = () => ({motor: $('#vz-motor').value, voz_edge: $('#vz-edge').value, voz_gemini: $('#vz-gem').value, velocidade: $('#vz-vel').value, estilo: $('#vz-est').value});
  const salvarCfg = (extra = {}) => api(`/api/videos/${v.id}/voz/config`, {method: 'PATCH', json: {...lerCfg(), ...extra}});
  $('#vz-salvar').onclick = () => safe(async () => {
    await salvarCfg();
    await api('/api/settings', {json: {voz_motor: $('#vz-motor').value, ['voz_edge_' + idioma]: $('#vz-edge').value, voz_gemini: $('#vz-gem').value, voz_velocidade: $('#vz-vel').value, voz_estilo: $('#vz-est').value}});
    toast('Voz salva (também como padrão do idioma)');
  });
  $('#vz-teste').onclick = () => safe(async () => {
    const c = lerCfg(); toast('Gerando amostra…');
    const amostra = (blocos[0]?.texto || v.roteiro).slice(0, 220);
    const r = await fetch('/api/voz/teste', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({motor: c.motor, voz: c.motor === 'gemini' ? c.voz_gemini : c.voz_edge, velocidade: c.velocidade, estilo: c.estilo, texto: amostra})});
    if (!r.ok) { let m = 'Falha na amostra'; try { m = (await r.json()).erro; } catch {} throw new Error(m); }
    const a = $('#vz-audio'); a.src = URL.createObjectURL(await r.blob()); a.style.display = ''; a.play();
  });
  $('#vz-up-ok').onclick = () => safe(async () => { const f = $('#vz-up').files[0]; if (!f) return toast('Escolha o áudio', true); const fd = new FormData(); fd.append('arquivo', f); toast('Enviando…'); await api(`/api/videos/${v.id}/narracao`, {method: 'POST', body: fd}); toast('Narração salva'); videoView(); });
  $('#vz-prep').onclick = () => safe(async () => { if (blocos.length && !confirm('Dividir de novo apaga os áudios gerados. Continuar?')) return; await salvarCfg(); await api(`/api/videos/${v.id}/voz/preparar`, {json: {}}); videoView(); });
  const gerar = i => safe(async () => { await salvarCfg(); await api(`/api/videos/${v.id}/voz/gerar`, {json: i ? {i} : {}}); acompanharVoz(v.id); });
  if ($('#vz-gerar')) $('#vz-gerar').onclick = () => gerar();
  if ($('#vz-refazer')) $('#vz-refazer').onclick = () => safe(async () => { if (!confirm('Gerar de novo todos os blocos com a voz atual?')) return; await salvarCfg({refazer_todos: true}); await api(`/api/videos/${v.id}/voz/gerar`, {json: {}}); acompanharVoz(v.id); });
  $$('[data-regerar]').forEach(b => b.onclick = () => gerar(+b.dataset.regerar));
  $$('[data-btxt]').forEach(t => t.onchange = () => safe(async () => { await api(`/api/videos/${v.id}/voz/bloco/${t.dataset.btxt}`, {method: 'PATCH', json: {texto: t.value}}); toast('Texto do bloco salvo — gere o áudio de novo'); }));
  if ($('#vz-juntar')) $('#vz-juntar').onclick = () => safe(async () => { toast('Juntando…'); await api(`/api/videos/${v.id}/voz/juntar`, {json: {}}); toast('Narração pronta!'); videoView(); });
  const st = await api(`/api/videos/${v.id}/voz/status`); if (st.rodando) acompanharVoz(v.id);
}
async function acompanharVoz(vid) {
  const el = $('#vz-prog'); if (!el) return;
  const st = await api(`/api/videos/${vid}/voz/status`);
  const pct = st.total ? Math.round(st.feito / st.total * 100) : 0;
  el.innerHTML = `<div class="small mut">${esc(st.etapa || '')} ${st.total ? `(${st.feito}/${st.total})` : ''}</div><div class="prog"><div style="width:${pct}%"></div></div>`;
  if (st.rodando) { setTimeout(() => S.view === 'video' && S.step === 'narracao' && acompanharVoz(vid), 1500); return; }
  if (st.erros?.length) toast(st.erros[0], true);
  if (st.erro) toast(st.erro, true);
  videoView();
}

// ---------------- Editor de cenas ----------------
async function stEditor(v) {
  if (!v.cenas.length) { step().innerHTML = '<div class="empty">Divida o roteiro em cenas primeiro.</div>'; return; }
  const movs = {auto: 'Automático', zoom_in: 'Zoom in', zoom_out: 'Zoom out', pan_dir: 'Pan →', pan_esq: '← Pan', parado: 'Parado'};
  const total = v.cenas[v.cenas.length - 1].fim;
  step().innerHTML = `<div class="card"><div class="row"><div class="sp"><b>Linha do tempo</b> · ${v.cenas.length} cenas · ${tempo(total)} ${v.narracao_duracao ? `· narração ${tempo(v.narracao_duracao)}` : ''}
    <div class="small mut">Ajuste a duração (o tempo vai/vem da cena seguinte, a narração não muda), escolha o movimento e veja a prévia de cada cena.</div></div>
    <button class="pri" id="ed-ok">Concluir editor →</button></div>
    <div style="display:flex;height:26px;margin-top:12px;border-radius:6px;overflow:hidden">${v.cenas.map(c => `<div title="Cena ${c.n}" style="flex:${(c.fim - c.inicio).toFixed(2)};background:${!c.midia ? '#5b2020' : c.midia.tipo === 'video' ? '#1e3a8a' : '#3a3f4a'};border-right:1px solid var(--bg)"></div>`).join('')}</div>
    <div class="small mut" style="margin-top:4px">cinza = foto · azul = vídeo · vermelho = sem mídia</div></div>
  <div class="card" style="padding:0"><table><tr><th>#</th><th></th><th>Início</th><th>Duração (s)</th><th>Movimento</th><th>Narração</th><th></th></tr>
  ${v.cenas.map((c, i) => { const m = c.midia; const src = m ? (m.arquivo ? `/api/videos/${v.id}/midia/${c.n}` : m.preview) : '';
    return `<tr><td>${c.n}</td><td style="width:110px">${src && m.tipo !== 'video' || (m && !m.arquivo) ? `<img src="${esc(src)}" loading="lazy" style="width:100px;aspect-ratio:16/9;object-fit:cover;border-radius:5px">` : m ? '<span class="pill">vídeo</span>' : '<span class="pill bad">sem mídia</span>'}</td>
    <td class="small mut">${tempo(c.inicio)}</td>
    <td><input type="number" step="0.1" min="0.6" data-dur="${c.n}" value="${(c.fim - c.inicio).toFixed(1)}" style="width:80px" ${i === v.cenas.length - 1 ? 'disabled title="A última cena termina junto com a narração"' : ''}></td>
    <td><select data-mov="${c.n}" style="width:auto" ${m && m.tipo === 'video' ? 'disabled' : ''}>${Object.entries(movs).map(([k, n]) => `<option value="${k}" ${(c.movimento || 'auto') === k ? 'selected' : ''}>${n}</option>`).join('')}</select></td>
    <td class="small" style="max-width:380px">${esc(c.texto)}</td><td><button class="sm" data-prev="${c.n}">Prévia</button></td></tr>`; }).join('')}</table></div>`;
  $$('[data-dur]').forEach(inp => inp.onchange = () => safe(async () => { S.video = await api(`/api/videos/${v.id}/cenas/${inp.dataset.dur}/editor`, {method: 'PATCH', json: {duracao: Number(inp.value)}}); stEditor(S.video); }));
  $$('[data-mov]').forEach(sel => sel.onchange = () => safe(async () => { await api(`/api/videos/${v.id}/cenas/${sel.dataset.mov}/editor`, {method: 'PATCH', json: {movimento: sel.value}}); toast('Movimento salvo'); }));
  $$('[data-prev]').forEach(b => b.onclick = () => safe(async () => {
    b.textContent = '…'; const r = await api(`/api/videos/${v.id}/cenas/${b.dataset.prev}/previa`, {method: 'POST'}); b.textContent = 'Prévia';
    modal(`<h3>Prévia da cena ${b.dataset.prev}</h3><video controls autoplay src="${r.url}?t=${Date.now()}"></video><div class="row end" style="margin-top:10px"><button onclick="fecharModal()">Fechar</button></div>`);
  }));
  $('#ed-ok').onclick = () => safe(async () => { await api('/api/videos/' + v.id, {method: 'PATCH', json: {etapas: {editor: true}}}); proxima('editor'); });
}

// ---------------- ThumbLab ----------------
async function stThumb(v) {
  const estilos = S.estilosThumb || (S.estilosThumb = await api('/api/thumb/estilos'));
  const comMidia = v.cenas.filter(c => c.midia && (c.midia.preview || c.midia.arquivo));
  const d = v.descricao || {};
  S.thumbFundo = S.thumbFundo || (v.thumb_fundo ? 'upload' : comMidia[0] ? 'cena:' + comMidia[0].n : 'upload');
  step().innerHTML = `<div class="grid g2"><div class="card"><h3>Fundo</h3>
    <div class="row"><label class="btn sm" style="margin:0;color:var(--txt)">Enviar imagem (ex.: gerada no Flow/Midjourney)<input type="file" id="th-up" accept="image/*" hidden></label>
    ${v.thumb_fundo ? `<button class="sm ${S.thumbFundo === 'upload' ? 'pri' : ''}" id="th-usar-up">Usar imagem enviada</button>` : ''}</div>
    ${comMidia.length ? `<p class="small mut" style="margin:10px 0 6px">ou escolha a mídia de uma cena:</p><div class="cands" style="max-height:260px;overflow:auto">${comMidia.map(c => `<div class="cand" data-fundo="cena:${c.n}" style="${S.thumbFundo === 'cena:' + c.n ? 'border-color:var(--acc)' : ''}">${c.midia.arquivo && c.midia.tipo === 'video' ? `<video src="/api/videos/${v.id}/midia/${c.n}#t=1" muted preload="metadata" style="width:100%;aspect-ratio:16/9;object-fit:cover;display:block"></video>` : `<img src="${esc(c.midia.arquivo ? `/api/videos/${v.id}/midia/${c.n}` : c.midia.preview)}" loading="lazy">`}<div>cena ${c.n}${c.midia.tipo === 'video' ? ' ▶' : ''}</div></div>`).join('')}</div>` : ''}
    <h3 style="margin-top:14px">Texto</h3>
    <div class="f"><label>Texto da thumb (2 a 5 palavras)</label><input id="th-txt" value="${esc(S.thumbTxt || (d.thumb_textos || [])[0] || '')}"></div>
    ${(d.thumb_textos || []).length ? `<div style="margin-bottom:10px">${d.thumb_textos.map(t => `<span class="tag" style="cursor:pointer" data-sug="${esc(t)}">${esc(t)}</span>`).join('')}</div>` : ''}
    <div class="grid g3"><div class="f"><label>Palavra(s) em destaque</label><input id="th-dest" value="${esc(S.thumbDest || '')}"></div>
    <div class="f"><label>Lado do texto</label><select id="th-lado"><option value="esquerda">Esquerda</option><option value="direita">Direita</option></select></div>
    <div class="f"><label>Cor do destaque</label><input type="color" id="th-cor" value="#ffd400" style="height:40px"></div></div>
    <div class="f"><label>Estilos (gera um de cada para comparar)</label>${Object.entries(estilos).map(([k, n]) => `<label style="margin:4px 0;color:var(--txt)"><input type="checkbox" data-est="${k}" checked> <b>${k}</b> <span class="mut">— ${esc(n)}</span></label>`).join('')}</div>
    <button class="pri big" id="th-go">Gerar thumbnails</button>
    ${(d.thumb_prompts || []).length ? `<h3 style="margin-top:16px">Prompts para gerar o fundo por IA</h3>${d.thumb_prompts.map(p => `<div class="row" style="margin-bottom:6px"><span class="small sp">${esc(p)}</span><button class="sm" data-cp="${esc(p)}">Copiar</button></div>`).join('')}` : ''}
  </div>
  <div class="card"><h3>Resultados</h3>${(v.thumbs || []).length ? `<div class="grid g2">${v.thumbs.map(t => `<div><img src="/api/videos/${v.id}/thumb/arquivo/${t.arquivo}" style="width:100%;border-radius:8px"><div class="row small"><span class="sp mut">${esc(t.estilo)}</span><a href="/api/videos/${v.id}/thumb/arquivo/${t.arquivo}?baixar=1">Baixar</a></div></div>`).join('')}</div>` : '<div class="empty">As thumbs aparecem aqui (1280×720, prontas para o YouTube).</div>'}</div></div>`;
  $('#th-up').onchange = () => safe(async () => { const fd = new FormData(); fd.append('arquivo', $('#th-up').files[0]); await api(`/api/videos/${v.id}/thumb/fundo`, {method: 'POST', body: fd}); S.thumbFundo = 'upload'; toast('Fundo enviado'); videoView(); });
  if ($('#th-usar-up')) $('#th-usar-up').onclick = () => { S.thumbFundo = 'upload'; stThumb(v); };
  $$('[data-fundo]').forEach(el => el.onclick = () => { S.thumbFundo = el.dataset.fundo; S.thumbTxt = $('#th-txt').value; S.thumbDest = $('#th-dest').value; stThumb(v); });
  $$('[data-sug]').forEach(el => el.onclick = () => { $('#th-txt').value = el.dataset.sug; });
  $$('[data-cp]').forEach(b => b.onclick = () => copiar(b.dataset.cp));
  $('#th-go').onclick = () => safe(async () => {
    const est = $$('[data-est]:checked').map(x => x.dataset.est); if (!est.length) return toast('Marque um estilo', true);
    if (!$('#th-txt').value.trim()) return toast('Escreva o texto da thumb', true);
    S.thumbTxt = $('#th-txt').value; S.thumbDest = $('#th-dest').value; toast('Gerando…');
    await api(`/api/videos/${v.id}/thumb/gerar`, {json: {fundo: S.thumbFundo, texto: $('#th-txt').value, destaque: $('#th-dest').value, lado: $('#th-lado').value, cor: $('#th-cor').value, estilos: est}});
    videoView();
  });
}

// ---------------- Mapa de nichos ----------------
async function mapaView() {
  const mapas = await api('/api/mapas');
  main.innerHTML = `<h1>Mapa de nichos</h1><p class="sub">Explore um nicho: subnichos, concorrência, RPM e temas prontos. Depois confirme a demanda no Radar.</p>
  <div class="grid g2"><div><div class="card"><div class="grid g2"><div class="f"><label>Nicho semente</label><input id="mp-sem" placeholder="Ex.: agricultura extrema, true crime, família real" value="${esc(S.mapaSem || '')}"></div>
    <div class="f"><label>Idioma do canal</label><select id="mp-id">${Object.entries(IDIOMAS).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></div></div>
    <button id="mp-ger">Montar prompt</button></div>
    ${blocoPrompt('pm', 'Prompt do mapa')}
    <div class="card"><h3>Cole o JSON</h3><textarea id="mp-json"></textarea><div class="row end" style="margin-top:8px"><button class="pri" id="mp-ok">Criar mapa</button></div></div></div>
  <div class="card"><h3>Mapas salvos</h3>${mapas.length ? mapas.map((m, i) => `<div class="row" style="padding:6px 0;border-bottom:1px solid var(--line)"><a href="#" data-mapa="${i}" class="sp">${esc(m.semente)}</a><span class="small mut">${IDIOMAS[m.idioma] || ''} · ${m.data.slice(0, 10)}</span><button class="sm danger" data-mdel="${m.id}">×</button></div>`).join('') : '<div class="empty">Nenhum mapa ainda.</div>'}</div></div>
  <div id="mp-view"></div>`;
  const carregar = async () => { S.mapaSem = $('#mp-sem').value; ligarPrompt('pm', (await api('/api/mapas/prompt', {json: {semente: $('#mp-sem').value || '(escreva o nicho)', idioma: $('#mp-id').value}})).prompt); };
  await carregar();
  $('#mp-ger').onclick = () => safe(carregar);
  $('#mp-ok').onclick = () => safe(async () => { const m = await api('/api/mapas', {json: {semente: $('#mp-sem').value, idioma: $('#mp-id').value, texto: $('#mp-json').value}}); toast('Mapa criado'); await mapaView(); desenharMapa(m); });
  $$('[data-mapa]').forEach(a => a.onclick = e => { e.preventDefault(); desenharMapa(mapas[+a.dataset.mapa]); });
  $$('[data-mdel]').forEach(b => b.onclick = () => safe(async () => { await api('/api/mapas/' + b.dataset.mdel, {method: 'DELETE'}); mapaView(); }));
  if (mapas[0]) desenharMapa(mapas[0]);
}
function desenharMapa(m) {
  const mp = m.mapa, cor = x => /alt/i.test(x || '') ? 'ok' : /m[ée]d/i.test(x || '') ? 'warn' : 'bad';
  const corC = x => /baix/i.test(x || '') ? 'ok' : /m[ée]d/i.test(x || '') ? 'warn' : 'bad';
  $('#mp-view').innerHTML = `<div class="card"><div class="row"><h2 style="margin:0" class="sp">${esc(mp.nicho || m.semente)}</h2>
    <span class="small mut">Adicionar temas ao canal:</span><select id="mp-canal" style="width:auto">${chOptions(S.channels[0]?.id)}</select></div></div>
  <div class="grid g3">${(mp.subnichos || []).map((s, i) => `<div class="card" style="border-top:3px solid var(--acc)"><h3>${esc(s.nome)}</h3>
    <div><span class="pill ${cor(s.potencial)}">potencial ${esc(s.potencial || '?')}</span><span class="pill ${corC(s.concorrencia)}">concorrência ${esc(s.concorrencia || '?')}</span>${s.rpm ? `<span class="pill">RPM ${esc(s.rpm)}</span>` : ''}</div>
    <p class="small mut">${esc(s.por_que || '')}</p>
    ${(s.temas || []).map((t, j) => `<div class="row small" style="padding:5px 0;border-top:1px solid var(--line)"><span class="sp">${esc(t.titulo || t)}</span><button class="sm" data-tema="${i}:${j}" title="Adicionar à fila de ideias">+ ideia</button></div>`).join('')}
    <div class="row" style="margin-top:8px"><button class="sm" data-radar="${esc(s.nome)}">Ver no Radar</button></div></div>`).join('')}</div>`;
  $$('[data-tema]').forEach(b => b.onclick = () => safe(async () => {
    if (!$('#mp-canal').value) return toast('Cadastre um canal primeiro', true);
    const [i, j] = b.dataset.tema.split(':').map(Number); const t = mp.subnichos[i].temas[j];
    await api('/api/ideas', {json: {channel_id: $('#mp-canal').value, ideias: [{titulo: t.titulo || t, gancho: t.gancho || ''}]}}); b.textContent = '✓'; b.disabled = true;
  }));
  $$('[data-radar]').forEach(b => b.onclick = () => { S.radarTermo = b.dataset.radar; go('radar'); });
}

// ---------------- DarkMetrics ----------------
async function metricsView(mid) {
  const hist = await api('/api/metricas');
  main.innerHTML = `<h1>DarkMetrics</h1><p class="sub">Raio-x de qualquer canal: frequência, média de views, e os vídeos fora da curva (outliers) para modelar.</p>
  ${S.settings.youtube_api_key ? '' : `<div class="hint">Precisa da chave da YouTube Data API em <a href="#" onclick="go('config')">Configurações</a>.</div>`}
  <div class="card"><div class="row"><input id="dm-in" placeholder="Link do canal, @do canal ou ID (UC...)" style="flex:1"><button class="pri" id="dm-go">Analisar</button></div>
  ${hist.length ? `<div style="margin-top:10px">${hist.map(h => `<span class="tag" style="cursor:pointer" data-h="${h.id}">${esc(h.canal.nome)} <span class="mut">${h.data.slice(5, 10)}</span></span>`).join('')}</div>` : ''}</div>
  <div id="dm-res"></div>`;
  $('#dm-go').onclick = () => safe(async () => { const e = $('#dm-in').value.trim(); if (!e) return; $('#dm-res').innerHTML = '<p class="mut">Analisando…</p>'; desenharMetrics(await api('/api/metricas', {json: {canal: e}})); });
  $$('[data-h]').forEach(t => t.onclick = () => safe(async () => desenharMetrics(await api('/api/metricas/' + t.dataset.h))));
  if (mid) desenharMetrics(await api('/api/metricas/' + mid));
}
function desenharMetrics(m) {
  const c = m.canal, r = m.resumo;
  S.dmFiltro = S.dmFiltro || 'todos';
  const lista = m.videos.filter(x => S.dmFiltro === 'todos' || (S.dmFiltro === 'outliers' ? x.outlier : S.dmFiltro === 'longos' ? !x.short : x.short));
  $('#dm-res').innerHTML = `<div class="card"><div class="row"><img src="${esc(c.thumb)}" style="width:48px;border-radius:50%"><div class="sp"><h2 style="margin:0"><a href="${c.url}" target="_blank">${esc(c.nome)}</a></h2><div class="small mut">criado em ${c.criado} · analisado ${m.data}</div></div><button class="sm danger" id="dm-del">Apagar</button></div></div>
  <div class="grid g4">
    <div class="card"><div class="stat">${fmt(c.inscritos)}<small>inscritos</small></div></div>
    <div class="card"><div class="stat">${fmt(r.mediana_views_longos)}<small>mediana de views (longos)</small></div></div>
    <div class="card"><div class="stat">${r.videos_por_semana_90d}<small>vídeos por semana (90 dias)</small></div></div>
    <div class="card"><div class="stat" style="color:var(--acc2)">${r.outliers}<small>outliers (3× a mediana)</small></div></div>
    <div class="card"><div class="stat">${fmt(r.media_views_30d)}<small>média de views (últimos 30 dias)</small></div></div>
    <div class="card"><div class="stat">${r.duracao_media_longos} min<small>duração média dos longos</small></div></div>
    <div class="card"><div class="stat">${r.longos} / ${r.shorts}<small>longos / shorts analisados</small></div></div>
    <div class="card"><div class="stat">${fmt(c.views_total)}<small>views totais · ${fmt(c.videos_total)} vídeos</small></div></div>
  </div>
  <div class="card"><h3>Palavras dos títulos que mais performam</h3>${r.palavras_fortes.map(([w, n]) => `<span class="tag">${esc(w)} <b>${n}</b></span>`).join('')}</div>
  <div class="card"><div class="row">${['todos', 'outliers', 'longos', 'shorts'].map(k => `<button class="sm ${S.dmFiltro === k ? 'pri' : ''}" data-dmf="${k}">${k}</button>`).join('')}<span class="sp"></span>
    <select id="dm-canal" style="width:auto">${chOptions(S.channels[0]?.id)}</select><button class="sm pri" id="dm-ref">Salvar outliers como referência</button></div>
  <table><tr><th></th><th>Título</th><th>Views</th><th>× mediana</th><th>Publicado</th><th>Duração</th></tr>
  ${lista.map(x => `<tr ${x.outlier ? 'style="background:#1d140b"' : ''}><td><img src="${esc(x.thumb)}" style="width:110px;border-radius:6px"></td><td><a href="${x.url}" target="_blank">${esc(x.titulo)}</a> ${x.outlier ? '<span class="pill acc">outlier</span>' : ''}</td>
  <td>${fmt(x.views)}</td><td><b style="color:${x.multiplo >= 3 ? 'var(--acc2)' : x.multiplo >= 1 ? 'var(--txt)' : 'var(--mut)'}">${x.multiplo}×</b></td><td class="small">${x.publicado}</td><td class="small">${x.duracao_min} min</td></tr>`).join('')}</table></div>`;
  $$('[data-dmf]').forEach(b => b.onclick = () => { S.dmFiltro = b.dataset.dmf; desenharMetrics(m); });
  $('#dm-del').onclick = () => safe(async () => { await api('/api/metricas/' + m.id, {method: 'DELETE'}); metricsView(); });
  $('#dm-ref').onclick = () => safe(async () => {
    if (!$('#dm-canal').value) return toast('Cadastre um canal primeiro', true);
    const itens = m.videos.filter(x => x.outlier).map(x => ({video_id: x.video_id, titulo: x.titulo, views: x.views, canal: c.nome, url: x.url, thumb: x.thumb}));
    if (!itens.length) return toast('Esse canal não tem outliers', true);
    const r2 = await api('/api/radar/salvos', {json: {channel_id: $('#dm-canal').value, itens}});
    toast(`${r2.adicionados} referência(s) salvas — gere ideias em "Ideias e títulos"`);
  });
}

// ---------------- Financeiro ----------------
async function financeiroView() {
  const hoje = new Date().toISOString().slice(0, 10);
  S.finMes = S.finMes ?? hoje.slice(0, 7);
  const f = await api('/api/financeiro?mes=' + S.finMes);
  const meses = [...new Set([hoje.slice(0, 7), ...f.meses])].sort().reverse();
  const cats = {receita: ['AdSense', 'Afiliado', 'Venda de produto', 'Patrocínio', 'Outros'], despesa: ['Ferramentas/IA', 'Voz', 'Edição/freela', 'Anúncios', 'Equipamento', 'Outros']};
  main.innerHTML = `<div class="row"><div><h1>Financeiro</h1><p class="sub">Receitas e despesas por canal.</p></div><span class="sp"></span>
  <select id="fi-mes" style="width:auto"><option value="">Todos os meses</option>${meses.map(m => `<option ${m === S.finMes ? 'selected' : ''}>${m}</option>`).join('')}</select><a class="btn" href="/api/financeiro.csv">Exportar CSV</a></div>
  <div class="grid g3"><div class="card"><div class="stat" style="color:var(--ok)">${brl(f.receita)}<small>receitas</small></div></div>
  <div class="card"><div class="stat" style="color:var(--bad)">${brl(f.despesa)}<small>despesas</small></div></div>
  <div class="card"><div class="stat" style="color:${f.lucro >= 0 ? 'var(--ok)' : 'var(--bad)'}">${brl(f.lucro)}<small>lucro</small></div></div></div>
  <div class="grid g2"><div class="card"><h3>Novo lançamento</h3>
    <div class="grid g2"><div class="f"><label>Tipo</label><select id="fi-tipo"><option value="receita">Receita</option><option value="despesa">Despesa</option></select></div>
    <div class="f"><label>Data</label><input type="date" id="fi-data" value="${hoje}"></div>
    <div class="f"><label>Canal</label><select id="fi-canal"><option value="">Geral (sem canal)</option>${chOptions('')}</select></div>
    <div class="f"><label>Categoria</label><select id="fi-cat"></select></div>
    <div class="f"><label>Descrição</label><input id="fi-desc"></div>
    <div class="f"><label>Valor (R$)</label><input id="fi-val" placeholder="0,00"></div></div>
    <button class="pri" id="fi-ok">Lançar</button></div>
  <div class="card"><h3>Por canal</h3><table><tr><th>Canal</th><th>Receita</th><th>Despesa</th><th>Lucro</th></tr>
    ${Object.entries(f.por_canal).map(([cid, x]) => `<tr><td>${cid ? chDot(cid) + esc(chName(cid)) : 'Geral'}</td><td>${brl(x.receita)}</td><td>${brl(x.despesa)}</td><td><b>${brl(x.receita - x.despesa)}</b></td></tr>`).join('') || '<tr><td colspan="4" class="mut">Sem lançamentos</td></tr>'}</table></div></div>
  <div class="card" style="padding:0"><table><tr><th>Data</th><th>Canal</th><th>Categoria</th><th>Descrição</th><th>Valor</th><th></th></tr>
  ${f.itens.map(x => `<tr><td class="small">${x.data}</td><td class="small">${x.canal_id ? esc(chName(x.canal_id)) : 'Geral'}</td><td class="small">${esc(x.categoria)}</td><td>${esc(x.descricao)}</td><td style="color:${x.tipo === 'receita' ? 'var(--ok)' : 'var(--bad)'}">${x.tipo === 'receita' ? '+' : '−'} ${brl(x.valor)}</td><td><button class="sm danger" data-fdel="${x.id}">×</button></td></tr>`).join('')}</table></div>`;
  const preencherCats = () => { $('#fi-cat').innerHTML = cats[$('#fi-tipo').value].map(c => `<option>${c}</option>`).join(''); };
  $('#fi-tipo').onchange = preencherCats; preencherCats();
  $('#fi-mes').onchange = e => { S.finMes = e.target.value; financeiroView(); };
  $('#fi-ok').onclick = () => safe(async () => {
    const val = $('#fi-val').value.trim(); if (!val) return toast('Digite o valor', true);
    await api('/api/financeiro', {json: {tipo: $('#fi-tipo').value, data: $('#fi-data').value, canal_id: $('#fi-canal').value, categoria: $('#fi-cat').value, descricao: $('#fi-desc').value, valor: val}});
    toast('Lançado'); financeiroView();
  });
  $$('[data-fdel]').forEach(b => b.onclick = () => safe(async () => { await api('/api/financeiro/' + b.dataset.fdel, {method: 'DELETE'}); financeiroView(); }));
}
