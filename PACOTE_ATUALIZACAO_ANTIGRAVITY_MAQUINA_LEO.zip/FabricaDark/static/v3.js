// Fábrica Dark v3 — Conexões, Consumo, Gemini direto, Real Lab completo, VozLab multi-provedor, Cenas (meta-prompt) e Video Lab.
// Este arquivo carrega por último e substitui algumas telas de app.js/modulos.js.

// ---------------- botão "Gerar direto (Gemini / GPT / Antigravity V8)" em todos os prompts ----------------
const PROMPT_ALVO = {pr: 'r-txt', pa: 'a-json', pc: 'c-txt', pcn: 'cn-json', pd: 'd-json', pt: 'i-json', pe: 'pe-txt', pp: 'pp-txt', ptt: 't-json', ppb: 'pb-json', pm: 'mp-json', pmeta: 'meta-json'};
blocoPrompt = function (id, titulo, dica = '') {
  const alvo = PROMPT_ALVO[id];
  return `<div class="card"><h3>${titulo}</h3>${dica ? `<p class="mut small">${dica}</p>` : ''}
  <div class="copybox" id="${id}-box">Carregando…</div>
  <div class="row" style="margin-top:10px"><button class="pri" data-copy="${id}">Copiar prompt</button>
  ${alvo ? `<button data-gem="${id}" title="Manda o prompt para o Motor (Gemini / GPT / Antigravity V8) e cola a resposta aqui embaixo">⚡ Gerar direto (Gemini / GPT / Antigravity V8)</button>` : ''}
  <span class="mut small">ou use:</span></div>
  <div class="row ai-row" style="margin-top:8px">${AIS.map(([n, c, u]) => `<button class="${c}" data-ai="${u}" data-src="${id}">${n}</button>`).join('')}</div></div>`;
};
ligarPrompt = function (id, texto) {
  const box = $(`#${id}-box`); if (!box) return;
  box.textContent = texto;
  $$(`[data-copy="${id}"]`).forEach(b => b.onclick = () => copiar(texto));
  $$(`[data-src="${id}"]`).forEach(b => b.onclick = async () => {
    const url = b.dataset.ai;
    await copiar(texto);
    if (url === 'antigravity://v8') {
      const btnGem = $(`[data-gem="${id}"]`);
      if (btnGem) { btnGem.click(); return; }
      toast('Prompt copiado para o Motor Antigravity V8!');
      return;
    }
    if (url === 'darkplanner://open') {
      safe(async () => {
        const r = await api('/api/darkplanner/acao', {json: {acao: 'enviar_roteiro', titulo: S.video?.titulo || 'prompt_v8', texto}});
        toast(r.msg || 'Enviado para o DarkPlanner!');
      });
      return;
    }
    window.open(url, '_blank');
  });
  $$(`[data-gem="${id}"]`).forEach(b => b.onclick = () => safe(async () => {
    const alvo = $('#' + PROMPT_ALVO[id]);
    b.disabled = true; const t0 = b.textContent; b.textContent = '⏳ Antigravity V8 + Gemini/GPT escrevendo…';
    try {
      const r = await api('/api/ia/gerar', {json: {prompt: texto, video_id: S.video?.id}});
      if (alvo) { alvo.value = r.texto; alvo.dispatchEvent(new Event('input')); alvo.scrollIntoView({behavior: 'smooth', block: 'center'}); }
      toast('Resposta gerada e colada — confira e salve.');
    } finally { b.disabled = false; b.textContent = t0; }
  }));
};

// ---------------- Conexões e chaves ----------------
async function conexoesView() {
  const c = await api('/api/conexoes');
  const s = S.settings;
  const statusPill = k => k.status === 'ok' ? '<span class="pill ok">Conectada</span>' : k.status === 'invalida' ? '<span class="pill bad">Inválida</span>' : '<span class="pill warn">não testada</span>';
  const cartao = (prov, k, extra = '') => `<div class="kcard"><div class="row"><b class="sp">${esc(k.apelido || prov)} <span class="mut small">${esc(k.final)}</span></b>${statusPill(k)}</div>
    <div class="small mut">${extra}${k.testada_em ? ` · testada em ${esc(k.testada_em)}` : ''}${k.info ? ` · ${esc(k.info)}` : ''}${k.plano ? ` · plano: ${esc(k.plano)}` : ''}</div>
    ${k.erro ? `<div class="small danger">${esc(k.erro)}</div>` : ''}
    <div class="row" style="margin-top:6px"><button class="sm" data-kt="${prov}:${k.id}">Testar</button><button class="sm" data-kx="${prov}:${k.id}">Trocar chave</button><button class="sm danger" data-kd="${prov}:${k.id}">Excluir</button></div></div>`;
  const add = (prov, txt) => `<button class="sm" data-kadd="${prov}" style="width:100%;justify-content:center">+ ${txt}</button>`;
  const est = c.estimativa;
  const gptKeys = c.openai || [];
  const dpLocal = c.darkplanner_local || {};
  const agCx = c.antigravity_codex || {};
  const agInfo = agCx.antigravity || {};
  const cxInfo = agCx.codex || {};
  const cascataLista = ((agCx.cascata_roteiro || {}).ordem) || [
    '1. Gemini Multi-Chaves (rotação automática 2.5-Flash / Flash-Lite / 2.0-Flash)',
    '2. Antigravity (Tokens da Conta / OAuth — sem travar por cota de API)',
    '3. OpenAI Codex (Login ChatGPT OAuth / Codex CLI)',
    '4. OpenAI GPT-4o / GPT-4o-mini (Failover final garantido)',
  ];
  main.innerHTML = `<h1>Conexões e chaves</h1><p class="sub">Vinculado com sua conta <b>Antigravity (Tokens)</b>, <b>OpenAI Codex (Login ChatGPT)</b>, <b>GPT (OpenAI)</b>, <b>Gemini</b> e <b>DarkPlanner</b>. Logue abaixo para falar no Chat e pedir alterações diretas nos canais, roteiros, temas e no site — com failover automático sem erro de cota.</p>
  <div class="card" style="border:1.5px solid #22d3ee;background:linear-gradient(180deg,rgba(8,51,68,.28),rgba(13,18,24,.95));margin-bottom:14px">
    <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:8px">
      <h3 class="sp" style="margin:0;color:#ecfeff">🔗 Vinculação de Conta: Antigravity + OpenAI Codex (Login, Tokens & Agente no Chat)</h3>
      <span class="pill ok">🛡️ Cascata Anti-Erro Gemini Ativa</span>
      <button type="button" class="sm pri" id="agcx-open-chat">💬 Abrir Chat Antigravity + Codex</button>
    </div>
    <p class="small mut" style="margin-top:0">Logue na sua conta <b>Antigravity</b> e <b>OpenAI Codex</b> para: <b>(1)</b> conversar no Chat do aplicativo pedindo alterações reais em roteiros, canais, prompts, temas e configurações, e <b>(2)</b> assumir automaticamente a criação de estruturas e roteiros por <b>tokens Antigravity / Codex / GPT</b> sempre que o Gemini estiver sobrecarregado.</p>
    <div class="grid g2" style="gap:12px">
      <div class="kcard" style="border-color:rgba(34,211,238,.4);background:#0b1118">
        <div class="row" style="gap:6px;flex-wrap:wrap">
          <b class="sp" style="color:#67e8f9">🚀 Conta Antigravity (Tokens & Agente)</b>
          ${agInfo.conectado ? '<span class="pill ok">Conectada</span>' : '<span class="pill warn">Aguardando Login</span>'}
        </div>
        <div class="small mut" style="margin-top:4px">
          Conta: <b>${esc(agInfo.conta || 'Não vinculada')}</b>${agInfo.metodo ? ` · modo: <code>${esc(agInfo.metodo)}</code>` : ''}${agInfo.dp_modelo ? ` · DP: <code>${esc(agInfo.dp_modelo)}</code>` : ''}
          ${agInfo.chamadas_sucesso ? ` · <b>${agInfo.chamadas_sucesso}</b> uso(s) (${(agInfo.tokens_consumidos || 0).toLocaleString('pt-BR')} tokens)` : ''}
        </div>
        <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:8px">
          <button type="button" class="sm pri" id="ag-btn-login">🔑 Logar Conta Antigravity</button>
          <button type="button" class="sm" id="ag-btn-test-chat">🤖 Testar Agente</button>
          ${agInfo.conectado ? '<button type="button" class="sm danger" id="ag-btn-disc">Desvincular</button>' : ''}
        </div>
        <div class="row" style="gap:6px;margin-top:8px">
          <input id="ag-tok-in" type="password" placeholder="Ou cole Token OAuth Antigravity (ya29... / token / chave)" style="flex:1">
          <input id="ag-acc-in" placeholder="Seu e-mail/conta (opcional)" style="max-width:170px">
          <button type="button" class="sm" id="ag-btn-save-tok">Vincular Token</button>
        </div>
      </div>

      <div class="kcard" style="border-color:rgba(16,185,129,.4);background:#0b1118">
        <div class="row" style="gap:6px;flex-wrap:wrap">
          <b class="sp" style="color:#6ee7b7">🧠 Conta OpenAI Codex (ChatGPT Login & CLI)</b>
          ${cxInfo.conectado ? '<span class="pill ok">Conectada</span>' : '<span class="pill warn">Aguardando Login</span>'}
        </div>
        <div class="small mut" style="margin-top:4px">
          Conta: <b>${esc(cxInfo.conta || 'Não vinculada')}</b>${cxInfo.metodo ? ` · modo: <code>${esc(cxInfo.metodo)}</code>` : ''} · ${cxInfo.tem_cli ? '<span style="color:#6ee7b7">Codex CLI detectado</span>' : 'API / Sessão OAuth'}
        </div>
        <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:8px">
          <button type="button" class="sm pri" id="cx-btn-login">🔑 Logar OpenAI Codex (OAuth)</button>
          <button type="button" class="sm" id="cx-btn-test-chat">🤖 Testar Codex</button>
          ${cxInfo.conectado ? '<button type="button" class="sm danger" id="cx-btn-disc">Desvincular</button>' : ''}
        </div>
        <div class="row" style="gap:6px;margin-top:8px">
          <input id="cx-tok-in" type="password" placeholder="Ou cole Token OAuth Codex (~/.codex) ou chave sk-..." style="flex:1">
          <input id="cx-acc-in" placeholder="E-mail ChatGPT (opcional)" style="max-width:170px">
          <button type="button" class="sm" id="cx-btn-save-tok">Vincular Codex</button>
        </div>
      </div>
    </div>
    <div class="hint" style="margin-top:10px;border-color:rgba(34,211,238,.3)">
      <b>🛡️ Ordem Automática Anti-Erro para Gerar Estrutura & Roteiro (Nunca trava por excesso de uso do Gemini):</b><br>
      ${cascataLista.map(item => `<span style="display:inline-block;margin-right:12px">✓ ${esc(item)}</span>`).join('')}
    </div>
  </div>
  <div class="grid g2">
  <div class="card"><h3>Gemini (Google AI Studio) <span class="pill">${c.gemini.length}/${c.limites.gemini}</span></h3>
    <p class="small mut">Escolhe termos de busca, confere se a mídia mostra o que a cena diz, escreve roteiros (botão ⚡) e pode narrar/gerar imagens. Uma chave por vez: quando bate o limite do dia, passa para a próxima ou alterna para o modelo Flash-Lite automaticamente.
    <a href="https://aistudio.google.com/apikey" target="_blank">Criar chave grátis</a></p>
    ${c.gemini.map(k => cartao('gemini', k, `<select data-ktipo="${k.id}" style="width:auto;padding:2px 6px"><option value="gratuita" ${k.tipo !== 'paga' ? 'selected' : ''}>Gratuita</option><option value="paga" ${k.tipo === 'paga' ? 'selected' : ''}>Paga</option></select> · ${k.usos || 0} chamadas hoje${k.esgotada ? ' · <b class="danger">esgotada hoje</b>' : ''}${k.modelo_auto ? ' · ' + esc(k.modelo_auto) : ''} `)).join('')}
    ${c.gemini.length < c.limites.gemini ? add('gemini', `Adicionar chave (${c.gemini.length} de ${c.limites.gemini})`) : ''}
    <div class="grid g2" style="margin-top:10px"><div class="f"><label>Ordem</label><select id="g-ordem"><option value="pagas" ${s.gemini_ordem === 'pagas' ? 'selected' : ''}>Pagas primeiro, depois gratuitas</option><option value="gratuitas" ${s.gemini_ordem === 'gratuitas' ? 'selected' : ''}>Gratuitas primeiro</option></select></div>
    <div class="f"><label style="margin-top:22px;color:var(--txt)"><input type="checkbox" id="g-sograt" ${s.gemini_so_gratuitas ? 'checked' : ''}> Usar só as gratuitas (nunca gastar)</label></div>
    <div class="f"><label>Modelo nas pagas</label><input id="g-mp" value="${esc(s.gemini_modelo_pagas)}" placeholder="automático"></div>
    <div class="f"><label>Modelo nas gratuitas</label><input id="g-mg" value="${esc(s.gemini_modelo_gratis)}" placeholder="gemini-2.5-flash-lite"></div></div>
    <div class="hint">Com 1 chave gratuita você faz cerca de <b>${est.videos_por_dia_por_chave}</b> busca(s) de vídeo por dia (média de ~${est.chamadas_por_video} chamadas por vídeo). Você tem ${est.gratuitas} gratuita(s): cerca de <b>${est.videos_por_dia}</b> por dia.</div>
  </div>
  <div class="card"><h3>GPT (OpenAI) + Antigravity V8 <span class="pill ok">Motor V8 Ativo</span> <span class="pill">${gptKeys.length}/${c.limites.openai || 4} chaves GPT</span></h3>
    <p class="small mut">Vinculado ao <b>ChatGPT / OpenAI API</b> e ao <b>Motor Antigravity V8 Ninja Pro</b> (sem vínculo com Claude). Se você adicionar uma chave da OpenAI (<code>sk-...</code>), ela roda nas tarefas marcadas abaixo; sem chave da OpenAI, o <b>Antigravity V8</b> usa o Gemini automaticamente com engenharia de retenção (145 PPM).
    <a href="https://platform.openai.com/api-keys" target="_blank">Criar chave OpenAI (GPT)</a></p>
    <div class="kcard" id="cl-ass"><b>🚀 Motor Antigravity V8 Ninja Pro (Integrado)</b> <span class="pill ok">Nativo</span>
      <div class="small mut" id="cl-ass-st">Verificando motor V8…</div>
      <div class="grid g2" style="margin-top:8px">
        <div class="f" style="margin:0"><label>Meta padrão de palavras (V8)</label><input id="ag-pal" type="number" step="100" value="${s.antigravity_palavras || 2000}"></div>
        <div class="f" style="margin:0"><label>Blocos narrativos padrão (V8)</label><input id="ag-blk" type="number" min="1" max="30" value="${s.antigravity_blocos || 6}"></div>
      </div>
    </div>
    <div class="small mut" style="margin:8px 0 4px">Chaves da API OpenAI (GPT-4o / GPT-4o Mini / o3-mini):</div>
    ${gptKeys.map(k => cartao('openai', k, `${k.usos || 0} chamadas hoje${k.esgotada ? ' · <b class="danger">sem cota</b>' : ''}${k.modelo_auto ? ' · ' + esc(k.modelo_auto) : ''} `)).join('')}
    ${gptKeys.length < (c.limites.openai || 4) ? add('openai', 'Adicionar chave do GPT (OpenAI)') : ''}
    <div class="grid g2" style="margin-top:10px"><div class="f"><label>Modo de Operação</label><select id="cl-modo">${[['auto', 'Automático (GPT + Antigravity V8 + Gemini)'], ['antigravity', 'Antigravity V8 + Gemini (Grátis)'], ['api', 'Priorizar chave da API OpenAI (GPT)']].map(([k, n]) => `<option value="${k}" ${(s.claude_modo || 'auto') === k ? 'selected' : ''}>${n}</option>`).join('')}</select>
    <label style="margin-top:8px">Modelo GPT (OpenAI)</label><select id="cl-mod">${[['gpt-4o', 'GPT-4o — máxima qualidade para roteiro'], ['gpt-4o-mini', 'GPT-4o Mini — rápido e econômico'], ['o3-mini', 'OpenAI o3-mini — raciocínio e estrutura']].map(([k, n]) => `<option value="${k}" ${(s.gpt_modelo || s.claude_modelo || 'gpt-4o') === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    <div class="f"><label>Usar GPT + Antigravity V8 em</label>${[['roteiro', 'Roteiro (e botão ⚡)', true], ['pesquisa', 'Pesquisa profunda das cenas', true], ['impacto', 'Textos de impacto', true], ['seo', 'Descrição, títulos e tags', true]].map(([k, n, pad]) => `<label style="margin:2px 0;color:var(--txt)"><input type="checkbox" data-cltar="${k}" ${((s.gpt_tarefas || s.claude_tarefas || {})[k] ?? pad) ? 'checked' : ''}> ${n}</label>`).join('')}</div></div>
  </div>
  <div class="card" style="border-color:#9333ea"><h3>🎬 DarkPlanner (API de Áudio + App Desktop) <span class="pill ok">${(c.darkplanner || []).length} chave(s)</span></h3>
    <p class="small mut">Integração completa com o seu <b>DarkPlanner</b>: gera a narração inteira num pedido só via API (com legenda <code>.srt</code> sincronizada), abre o aplicativo Desktop instalado no seu PC e exporta direto para a pasta <b>WatchFolder</b>.</p>
    <div class="kcard">
      <div class="row"><b class="sp">Aplicativo Desktop & WatchFolder</b>${dpLocal.exe_existe ? '<span class="pill ok">App Instalado</span>' : '<span class="pill warn">Web</span>'}</div>
      <div class="small mut">Local do programa: <code>${esc(dpLocal.pasta || 'C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner')}</code><br>Executável: <code>${esc(dpLocal.exe || '')}</code><br>WatchFolder: <code>${esc(dpLocal.watch || '')}</code></div>
      <div class="f" style="margin-top:8px"><label>Caminho do DarkPlanner no PC</label><input id="dp-path-in" value="${esc(s.darkplanner_exe || dpLocal.pasta || 'C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner')}"></div>
      <div class="row" style="margin-top:8px">
        <button class="sm ai-dp" id="dp-open-app">🚀 Abrir DarkPlanner Desktop</button>
        <button class="sm" id="dp-open-local">📁 Abrir Local do Programa</button>
        <button class="sm" id="dp-open-folder">📂 Abrir Pasta WatchFolder</button>
      </div>
    </div>
    <div class="small mut" style="margin:8px 0 4px">Chave da API de Áudio DarkPlanner (<code>dpk_...</code>):</div>
    ${(c.darkplanner || []).map(k => cartao('darkplanner', k, '')).join('')}
    ${add('darkplanner', 'Adicionar chave dpk_ do DarkPlanner')}
  </div>
  <div class="card"><h3>YouTube Data API <span class="pill">${c.youtube.length}/${c.limites.youtube}</span></h3>
    <p class="small mut">Radar, DarkMetrics e vídeos Creative Commons. Cada chave dá 10.000 unidades por dia (uma busca = 100). Cada chave precisa vir de um projeto diferente no Google Cloud. <a href="https://console.cloud.google.com/apis/library/youtube.googleapis.com" target="_blank">Criar chave</a></p>
    ${c.youtube.map(k => cartao('youtube', k, `${(k.unidades || 0).toLocaleString('pt-BR')} de 10.000 unidades hoje${k.esgotada ? ' · <b class="danger">esgotada</b>' : ''}`)).join('')}
    ${c.youtube.length < c.limites.youtube ? add('youtube', `Adicionar chave (${c.youtube.length} de ${c.limites.youtube})`) : ''}
    <div class="f" style="margin-top:10px"><label>Buscas do YouTube por vídeo (assuntos) — cada assunto é buscado em inglês e em português (2 × 100 unidades)</label>
    <select id="y-ass" style="width:auto">${[0, 4, 6, 8, 10, 15, 20].map(n => `<option value="${n}" ${Number(s.youtube_assuntos) === n ? 'selected' : ''}>${n === 0 ? 'Desligado' : n + (n === 8 ? ' (padrão)' : '')}</option>`).join('')}</select></div>
  </div>
  <div class="card"><h3>Bancos de imagem e vídeo</h3>
    ${[['pixabay_key', 'Pixabay', 'vídeos e fotos reais, grátis (fonte principal)', 'https://pixabay.com/api/docs/'], ['pexels_key', 'Pexels', 'Modo Direto no Site ativo com a sua conta conectada (download manual) ou via API', 'https://www.pexels.com/pt-br/videos/'],
      ['smithsonian_key', 'Smithsonian', 'fotos e obras do acervo aberto (só CC0)', 'https://api.data.gov/signup/'], ['europeana_key', 'Europeana', 'obras, gravuras e fotos de museus europeus (domínio público, CC0, CC BY)', 'https://pro.europeana.eu/page/get-api'], ['unsplash_key', 'Unsplash', `fotos modernas de alta qualidade (App ID: ${esc(s.unsplash_app_id || '1116622')} · Access Key + Secret configurados)`, 'https://unsplash.com/oauth/applications']]
      .map(([k, n, d, u]) => `<div class="kcard"><div class="row"><b class="sp">${n}</b>${s[k] ? '<span class="pill ok">Conectada (API)</span>' : k === 'pexels_key' ? '<span class="pill ok" style="background:rgba(16,185,129,.18);color:#10b981">Modo Direto no Site (Conta Conectada)</span>' : '<span class="pill">sem chave</span>'}</div><div class="small mut">${d} · <a href="${u}" target="_blank">${k === 'pexels_key' ? '🌐 Abrir Pexels Direto' : 'como pegar'}</a></div>
      <div class="row" style="margin-top:6px"><input data-sk="${k}" placeholder="${s[k] ? esc(s[k]) + ' (cole outra para trocar)' : k === 'pexels_key' ? 'Sem chave API — usando Modo Direto pelo Site (ou cole chave se tiver)' : 'cole a chave aqui'}" style="flex:1"><button class="sm" data-sksave="${k}">Guardar</button>${s[k] ? `<button class="sm danger" data-skdel="${k}">Remover</button>` : ''}${k === 'pexels_key' ? `<a class="btn sm pri" href="https://www.pexels.com/pt-br/videos/" target="_blank">🌐 Abrir Pexels (Conta Conectada)</a>` : ''}</div></div>`).join('')}
    <p class="small mut">Wikimedia Commons, Internet Archive (filmes e cinejornais antigos), NASA, Met Museum e Openverse entram sem chave. A licença de cada arquivo é lida: só passam domínio público, CC0 e CC BY.</p>
    <label style="color:var(--txt)"><input type="checkbox" id="s-sa" ${s.aceitar_cc_by_sa ? 'checked' : ''}> Aceitar também CC BY-SA (exige compartilhar pela mesma licença)</label>
  </div>
  <div class="card"><h3>Vozes (VozLab)</h3><p class="small mut">Você usa a SUA conta em cada provedor. O DarkPlanner e o Edge também aparecem no VozLab e no Estúdio 1 clique.</p>
    ${['darkplanner', 'azure', 'elevenlabs', 'fish'].map(p => `<div style="margin-bottom:12px"><div class="row"><b class="sp">${esc(c.provedores_tts[p].nome)}</b><span class="pill">${c[p].length} conectada(s)</span></div>
      <p class="small mut" style="margin:4px 0">${esc(c.provedores_tts[p].info)}</p>${c[p].map(k => cartao(p, k, p === 'azure' ? 'região ' + esc(k.regiao || 'brazilsouth') : '')).join('')}${add(p, 'Adicionar conta')}</div>`).join('')}
    <p class="small mut">Gemini (voz): usa as chaves do Gemini acima.</p>
  </div>
  </div>
  <button class="pri" id="cx-salvar">Salvar preferências</button>`;
  const rec = () => conexoesView();
  const abrirChatAgenteModo = (msgInicial = '') => {
    S.dpChatModoAgente = 'antigravity_codex';
    if (typeof window.abrirMonitorProcessoDp === 'function') {
      window.abrirMonitorProcessoDp();
      if (msgInicial && typeof window.preencherSugestaoChatOpDp === 'function') {
        window.preencherSugestaoChatOpDp('', {textoCustom: msgInicial});
      }
    } else {
      go('estudio');
      setTimeout(() => {
        S.dpChatModoAgente = 'antigravity_codex';
        if (typeof window.abrirMonitorProcessoDp === 'function') window.abrirMonitorProcessoDp();
      }, 250);
    }
  };
  if ($('#agcx-open-chat')) $('#agcx-open-chat').onclick = () => abrirChatAgenteModo();
  if ($('#ag-btn-test-chat')) $('#ag-btn-test-chat').onclick = () => abrirChatAgenteModo('Verifique minha conexão Antigravity + Codex e liste meus canais ativos.');
  if ($('#cx-btn-test-chat')) $('#cx-btn-test-chat').onclick = () => abrirChatAgenteModo('Usando Codex + Antigravity, revise as configurações dos meus canais.');
  if ($('#ag-btn-login')) $('#ag-btn-login').onclick = () => safe(async () => {
    $('#ag-btn-login').textContent = 'Abrindo login…';
    const r = await api('/api/conexoes/antigravity-codex/login', {json: {provedor: 'antigravity'}});
    toast(r.msg || 'Fluxo de login Antigravity iniciado! Se estiver em modo remoto, cole o token abaixo.', !r.ok);
    rec();
  });
  if ($('#cx-btn-login')) $('#cx-btn-login').onclick = () => safe(async () => {
    $('#cx-btn-login').textContent = 'Abrindo login Codex…';
    const r = await api('/api/conexoes/antigravity-codex/login', {json: {provedor: 'codex'}});
    toast(r.msg || 'Fluxo de login OpenAI Codex iniciado!', !r.ok);
    rec();
  });
  if ($('#ag-btn-save-tok')) $('#ag-btn-save-tok').onclick = () => safe(async () => {
    const tok = ($('#ag-tok-in')?.value || '').trim();
    const conta = ($('#ag-acc-in')?.value || '').trim();
    if (!tok) return toast('Cole o token ou chave Antigravity antes de clicar em Vincular.', true);
    const r = await api('/api/conexoes/antigravity-codex/salvar-token', {json: {provedor: 'antigravity', token: tok, conta}});
    toast(r.msg || (r.ok ? 'Conta Antigravity vinculada!' : r.erro), !r.ok);
    rec();
  });
  if ($('#cx-btn-save-tok')) $('#cx-btn-save-tok').onclick = () => safe(async () => {
    const tok = ($('#cx-tok-in')?.value || '').trim();
    const conta = ($('#cx-acc-in')?.value || '').trim();
    if (!tok) return toast('Cole o token OAuth do Codex ou chave sk-... antes de clicar em Vincular.', true);
    const r = await api('/api/conexoes/antigravity-codex/salvar-token', {json: {provedor: 'codex', token: tok, conta}});
    toast(r.msg || (r.ok ? 'Conta OpenAI Codex vinculada!' : r.erro), !r.ok);
    rec();
  });
  if ($('#ag-btn-disc')) $('#ag-btn-disc').onclick = () => safe(async () => {
    if (!confirm('Desvincular token salvo manualmente do Antigravity?')) return;
    await api('/api/conexoes/antigravity-codex/desconectar', {json: {provedor: 'antigravity'}});
    toast('Token manual Antigravity removido.');
    rec();
  });
  if ($('#cx-btn-disc')) $('#cx-btn-disc').onclick = () => safe(async () => {
    if (!confirm('Desvincular token salvo manualmente do OpenAI Codex?')) return;
    await api('/api/conexoes/antigravity-codex/desconectar', {json: {provedor: 'codex'}});
    toast('Token manual Codex removido.');
    rec();
  });
  const assTela = (a) => {
    const e = a.estado || {}, box = $('#cl-ass-st'); if (!box) return;
    box.innerHTML = `<span class="pill ok">Ativo</span> Motor Antigravity V8 Ninja Pro conectado com Gemini/GPT${e.testado_em ? ' · verificado em ' + esc(e.testado_em) : ''}
      ${e.erro ? `<div class="small danger">${esc(e.erro)}</div>` : ''}<div class="row" style="margin-top:6px"><button class="sm" id="cl-ass-t">Testar Motor Antigravity V8</button></div>`;
    $('#cl-ass-t').onclick = () => safe(async () => { $('#cl-ass-t').textContent = 'Testando…'; const r = await api('/api/claude/assinatura', {method: 'POST'}); toast(r.ok ? r.msg : 'Falhou: ' + r.msg, !r.ok); assTela(Object.assign(await api('/api/claude/assinatura'))); });
  };
  api('/api/claude/assinatura').then(assTela).catch(() => {});
  if ($('#dp-open-app')) $('#dp-open-app').onclick = () => safe(async () => { const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_app'}}); toast(r.msg); });
  if ($('#dp-open-local')) $('#dp-open-local').onclick = () => safe(async () => { const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_local_programa'}}); toast(r.msg); });
  if ($('#dp-open-folder')) $('#dp-open-folder').onclick = () => safe(async () => { const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_pasta'}}); toast(r.msg); });
  $$('[data-kadd]').forEach(b => b.onclick = () => {
    const prov = b.dataset.kadd;
    const nomeProv = prov === 'openai' ? 'GPT (OpenAI sk-...)' : prov === 'darkplanner' ? 'DarkPlanner (dpk_...)' : prov;
    modal(`<h3>Nova chave — ${nomeProv}</h3><div class="f"><label>Chave</label><input id="nk-key" type="password" placeholder="${prov === 'openai' ? 'sk-...' : prov === 'darkplanner' ? 'dpk_...' : ''}"></div>
    ${prov === 'gemini' ? '<div class="f"><label>Tipo</label><select id="nk-tipo"><option value="gratuita">Gratuita</option><option value="paga">Paga (com faturamento)</option></select></div>' : ''}
    ${prov === 'azure' ? '<div class="f"><label>Região</label><input id="nk-reg" value="brazilsouth"></div>' : ''}
    <div class="row end"><button onclick="fecharModal()">Cancelar</button><button class="pri" id="nk-ok">Testar e guardar</button></div>`);
    $('#nk-ok').onclick = () => safe(async () => {
      const r = await api('/api/chaves/' + prov, {json: {key: $('#nk-key').value, tipo: $('#nk-tipo')?.value, regiao: $('#nk-reg')?.value}});
      fecharModal(); toast(r.ok ? 'Chave conectada!' : 'Guardada, mas o teste falhou: ' + r.msg, !r.ok); rec();
    });
  });
  $$('[data-kt]').forEach(b => b.onclick = () => safe(async () => { const [p, id] = b.dataset.kt.split(':'); b.textContent = '…'; const r = await api(`/api/chaves/${p}/${id}/testar`, {method: 'POST'}); toast(r.ok ? 'OK: ' + (r.msg || 'funcionando') : 'Falhou: ' + r.msg, !r.ok); rec(); }));
  $$('[data-kd]').forEach(b => b.onclick = () => safe(async () => { if (!confirm('Excluir esta chave?')) return; const [p, id] = b.dataset.kd.split(':'); await api(`/api/chaves/${p}/${id}`, {method: 'DELETE'}); rec(); }));
  $$('[data-kx]').forEach(b => b.onclick = () => safe(async () => { const nova = prompt('Cole a chave nova:'); if (!nova) return; const [p, id] = b.dataset.kx.split(':'); await api(`/api/chaves/${p}/${id}`, {method: 'PATCH', json: {key: nova}}); rec(); }));
  $$('[data-ktipo]').forEach(sel => sel.onchange = () => safe(async () => { await api(`/api/chaves/gemini/${sel.dataset.ktipo}`, {method: 'PATCH', json: {tipo: sel.value}}); toast('Tipo salvo'); }));
  $$('[data-sksave]').forEach(b => b.onclick = () => safe(async () => { const k = b.dataset.sksave, v = $(`[data-sk="${k}"]`).value.trim(); if (!v) return; S.settings = await api('/api/settings', {json: {[k]: v}}); toast('Chave guardada'); rec(); }));
  $$('[data-skdel]').forEach(b => b.onclick = () => safe(async () => { S.settings = await api('/api/settings', {json: {[b.dataset.skdel]: ''}}); rec(); }));
  $('#cx-salvar').onclick = () => safe(async () => {
    const tarefas = Object.fromEntries($$('[data-cltar]').map(x => [x.dataset.cltar, x.checked]));
    S.settings = await api('/api/settings', {json: {gemini_ordem: $('#g-ordem').value, gemini_so_gratuitas: $('#g-sograt').checked, gemini_modelo_pagas: $('#g-mp').value.trim(),
      gemini_modelo_gratis: $('#g-mg').value.trim(), youtube_assuntos: Number($('#y-ass').value), aceitar_cc_by_sa: $('#s-sa').checked,
      claude_modelo: $('#cl-mod').value, gpt_modelo: $('#cl-mod').value, claude_modo: $('#cl-modo').value,
      claude_tarefas: tarefas, gpt_tarefas: tarefas,
      darkplanner_exe: $('#dp-path-in')?.value.trim() || 'C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner',
      antigravity_palavras: Number($('#ag-pal')?.value || 2000), antigravity_blocos: Number($('#ag-blk')?.value || 6)}});
    toast('Preferências salvas');
  });
}

// ---------------- Consumo ----------------
async function consumoView() {
  const c = await api('/api/consumo');
  const dias = Object.keys(c.gemini).sort().reverse().slice(0, 14);
  const meses = Object.keys(c.tts).sort().reverse();
  const ytd = Object.keys(c.youtube).sort().reverse().slice(0, 14);
  const brl0 = n => Number(n || 0).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'});
  main.innerHTML = `<h1>Consumo</h1><p class="sub">Quanto você usou de cada serviço (Gemini, GPT, Antigravity V8 e DarkPlanner). Chaves gratuitas custam R$ 0,00.</p>
  <div class="grid g2">
  <div class="card"><h3>Gemini por dia</h3><table><tr><th>Dia</th><th>Chamadas</th><th>Tokens (entrada/saída)</th><th>Custo</th></tr>
    ${dias.map(d => { const g = c.gemini[d].geral || {}; return `<tr><td>${d}</td><td>${fmt(g.chamadas)}</td><td class="small">${fmt(g.tokens_in)} / ${fmt(g.tokens_out)}</td><td>${brl0(g.custo_brl)}</td></tr>`; }).join('') || '<tr><td colspan="4" class="mut">Nada ainda</td></tr>'}</table></div>
  ${Object.keys(c.claude || {}).length ? `<div class="card"><h3>GPT (OpenAI) por dia</h3><table><tr><th>Dia</th><th>Chamadas</th><th>Tokens (entrada/saída)</th><th>Custo</th></tr>
    ${Object.keys(c.claude).sort().reverse().slice(0, 14).map(d => { const a = c.claude[d].geral || {}, b = c.claude[d]['gpt-4o'] || c.claude[d]['gpt-4o-mini'] || {}; const g = {chamadas: (a.chamadas || 0) + (b.chamadas || 0), tokens_in: (a.tokens_in || 0) + (b.tokens_in || 0), tokens_out: (a.tokens_out || 0) + (b.tokens_out || 0), custo_brl: (a.custo_brl || 0) + (b.custo_brl || 0)}; return `<tr><td>${d}</td><td>${fmt(g.chamadas)}</td><td class="small">${fmt(g.tokens_in)} / ${fmt(g.tokens_out)}</td><td>${brl0(g.custo_brl)}</td></tr>`; }).join('')}</table></div>` : ''}
  <div class="card"><h3>Chaves hoje (${c.dia_cota})</h3>
    ${c.chaves.gemini.map(k => `<div class="row small"><span class="sp">Gemini ${esc(k.final)} (${k.tipo || 'gratuita'})</span><b>${k.usos || 0} chamadas</b>${k.esgotada ? '<span class="pill bad">esgotada</span>' : ''}</div>`).join('')}
    ${c.chaves.youtube.map(k => `<div class="row small"><span class="sp">YouTube ${esc(k.final)}</span><b>${fmt(k.unidades)} / 10.000</b></div><div class="prog" style="margin:4px 0 8px"><div style="width:${Math.min(100, (k.unidades || 0) / 100)}%"></div></div>`).join('')}</div>
  <div class="card"><h3>Vozes por mês</h3><table><tr><th>Mês</th><th>Provedor</th><th>Caracteres</th></tr>
    ${meses.map(m => Object.entries(c.tts[m]).map(([p, x]) => `<tr><td>${m}</td><td>${esc(p)}</td><td>${fmt(x.caracteres)}</td></tr>`).join('')).join('') || '<tr><td colspan="3" class="mut">Nada ainda</td></tr>'}</table>
    <p class="small mut">Referência: Azure Free 500 mil caracteres/mês · ElevenLabs Free 10 mil créditos/mês · Fish US$ 15 por 1 milhão de bytes.</p></div>
  <div class="card"><h3>YouTube por dia</h3><table><tr><th>Dia</th><th>Unidades</th></tr>${ytd.map(d => `<tr><td>${d}</td><td>${fmt((c.youtube[d].geral || {}).unidades)}</td></tr>`).join('') || '<tr><td colspan="2" class="mut">Nada ainda</td></tr>'}</table></div>
  <div class="card"><h3>Custo de IA por vídeo</h3><table><tr><th>Vídeo</th><th>Chamadas</th><th>Custo</th></tr>${c.videos.map(v => `<tr><td>${esc(v.titulo)}</td><td>${v.chamadas_ia}</td><td>${brl0(v.custo_ia_brl)}</td></tr>`).join('') || '<tr><td colspan="3" class="mut">Nada ainda</td></tr>'}</table></div>
  </div>`;
}

// ---------------- Configurações: custos ----------------
const _configOrig = config;
config = async function () {
  await _configOrig();
  const s = S.settings;
  const cardChaves = $('#s-yt')?.closest('.card');
  if (cardChaves) { cardChaves.style.display = 'none'; cardChaves.insertAdjacentHTML('afterend', `<div class="card"><h3>Chaves</h3><p class="small">As chaves (Gemini, YouTube, bancos de imagem e vozes) agora ficam em <a href="#" onclick="go('conexoes');return false">Conexões e chaves</a>, com rodízio e teste.</p></div>`); }
  main.insertAdjacentHTML('beforeend', `<div class="card" style="margin-top:14px"><h3>Custos e limites</h3>
  <div class="grid g4"><div class="f"><label>Limite de gasto por vídeo (R$)</label><input id="c-lim" type="number" step="0.5" value="${s.limite_gasto_video}"></div>
  <div class="f"><label>Gemini — entrada (US$ / 1 milhão de tokens)</label><input id="c-pin" type="number" step="0.01" value="${s.gemini_preco_in}"></div>
  <div class="f"><label>Gemini — saída, com raciocínio (US$ / 1 milhão)</label><input id="c-pout" type="number" step="0.01" value="${s.gemini_preco_out}"></div>
  <div class="f"><label>Preços conferidos em</label><input id="c-pdata" type="date" value="${esc(s.precos_conferidos_em)}"></div>
  <div class="f"><label>Dólar (R$)</label><input id="c-dol" type="number" step="0.0001" value="${s.dolar}"></div>
  <div class="f"><label>Data da cotação</label><input id="c-ddata" type="date" value="${esc(s.dolar_data)}"></div></div>
  <p class="small mut">Ao chegar no limite, as chaves pagas param para aquele vídeo e só as gratuitas continuam. Confira os preços na <a href="https://ai.google.dev/gemini-api/docs/pricing" target="_blank">tabela oficial do Google</a>. Padrão do dólar: PTAX de venda do Banco Central (o cartão pode cobrar IOF e outra cotação). Pixabay, Pexels, Wikimedia, museus, Openverse e YouTube são grátis.</p>
  <button class="pri" id="c-ok">Salvar custos</button></div>`);
  $('#c-ok').onclick = () => safe(async () => {
    S.settings = await api('/api/settings', {json: {limite_gasto_video: Number($('#c-lim').value), gemini_preco_in: Number($('#c-pin').value), gemini_preco_out: Number($('#c-pout').value),
      precos_conferidos_em: $('#c-pdata').value, dolar: Number($('#c-dol').value), dolar_data: $('#c-ddata').value}});
    toast('Custos salvos');
  });
};

// ---------------- Canal: personagens ----------------
const _formCanalOrig = formCanal;
formCanal = function (c) {
  _formCanalOrig(c);
  const campo = $('#c-personagem')?.closest('.f');
  const lista = (c.personagens && c.personagens.length) ? c.personagens : (c.personagem ? [{nome: 'Personagem', descricao: c.personagem}] : []);
  if (campo) campo.outerHTML = `<div class="f"><label>Personagens do canal (originais, criados por você — não use pessoa real). Um por linha: <b>Nome: descrição visual</b></label>
    <textarea id="c-pers" style="min-height:70px;font-family:inherit" placeholder="Velho Tião: homem de 70 anos, barba branca, chapéu de palha, camisa xadrez desbotada">${esc(lista.map(p => `${p.nome}: ${p.descricao}`).join('\n'))}</textarea>
    <input type="hidden" id="c-personagem" value=""></div>`;
  const btn = $('#c-salvar'), velho = btn.onclick;
  btn.onclick = async () => {
    const pers = $('#c-pers').value.split('\n').map(l => l.trim()).filter(Boolean).map(l => { const i = l.indexOf(':'); return i > 0 ? {nome: l.slice(0, i).trim(), descricao: l.slice(i + 1).trim()} : {nome: 'Personagem', descricao: l}; });
    $('#c-personagem').value = pers.map(p => `${p.nome}: ${p.descricao}`).join(' | ');
    const _api = api;
    window.api = async (url, opt) => { if (url === '/api/channels' && opt?.json) opt.json.personagens = pers; return _api(url, opt); };
    try { await velho(); } finally { window.api = _api; }
  };
};

// ---------------- VozLab: todos os provedores ----------------
stNarracao = async function (v) {
  if (!v.roteiro) { step().innerHTML = '<div class="empty">Cole o roteiro primeiro.</div>'; return; }
  const ch = S.channels.find(c => c.id === v.channel_id) || {};
  const idioma = ch.idioma || 'pt';
  const blocos = v.blocos_voz || [];
  const prontos = blocos.filter(b => b.status === 'pronto').length;
  const cfg = Object.assign({motor: S.settings.voz_motor || 'edge', velocidade: '+0%', estilo: ''}, v.voz || {});
  const motores = {edge: 'Edge — grátis, sem chave', gemini: 'Gemini', darkplanner: 'DarkPlanner', azure: 'Azure AI Speech', elevenlabs: 'ElevenLabs', fish: 'Fish Audio'};
  step().innerHTML = `
  <div class="card" style="border-color:#9333ea;background:linear-gradient(135deg,rgba(147,51,234,.12),rgba(15,23,42,.95));margin-bottom:14px">
    <div class="row">
      <div class="sp">
        <div class="row" style="gap:8px;margin-bottom:4px">
          <h3 style="margin:0">🎙 Gerador de Áudio DarkPlanner (<code>audio-generator</code>) + Editar SRT Tempo VEO</h3>
          <span class="pill ok">Sincronizado</span>
        </div>
        <p class="small mut" style="margin:0">Marca o canal que você escolheu (ex.: <b>${esc(ch.nome || 'Seu Canal')}</b>), cola o roteiro, gera o áudio MP3 nos <b>Resultados</b> e abre o <b>Editor SRT Tempo VEO</b> para você escolher a <b>Quebra por Frase</b> antes de finalizar!</p>
      </div>
      <button class="pri" id="vz-open-dp-gen" style="background:#9333ea;border-color:#a855f7">🎙 Abrir Gerador de Áudio + Editor SRT Tempo VEO</button>
      <a class="btn sm" href="https://app.darkplanner.com.br/audio-generator" target="_blank">🌐 Abrir no Site</a>
    </div>
  </div>
  <div class="grid g2"><div class="card"><h3>Voz</h3>
    <div class="grid g2"><div class="f"><label>Provedor</label><select id="vz-motor">${Object.entries(motores).map(([k, n]) => `<option value="${k}" ${cfg.motor === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    <div class="f"><label>Voz</label><select id="vz-voz"><option>carregando…</option></select><input id="vz-voz-txt" placeholder="ID da voz (reference_id do fish.audio)" style="display:none;margin-top:6px"></div>
    <div class="f" id="vz-f-vel"><label>Velocidade</label><select id="vz-vel">${['-15%', '-10%', '-5%', '+0%', '+5%', '+10%', '+15%'].map(x => `<option ${cfg.velocidade === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
    <div class="f" id="vz-f-mod"><label>Modelo ElevenLabs</label><select id="vz-mod"><option value="eleven_multilingual_v2">Multilingual v2 (melhor qualidade)</option><option value="eleven_turbo_v2_5">Turbo v2.5 (mais barato)</option><option value="eleven_flash_v2_5">Flash v2.5 (mais rápido)</option></select></div></div>
    <div class="f" id="vz-f-est"><label>Direção da voz (Gemini) — como narrar</label><input id="vz-est" value="${esc(cfg.estilo)}" placeholder="Ex.: Narre em tom sombrio e misterioso, ritmo calmo, pausas dramáticas"></div>
    <div class="small mut" id="vz-info" style="margin-bottom:8px"></div>
    <div class="row"><button id="vz-teste">▶ Ouvir amostra</button><button id="vz-salvar">Salvar voz</button><a href="#" onclick="go('conexoes');return false" class="small">Conexões</a><audio id="vz-audio" controls style="height:34px;flex:1;display:none"></audio></div>
  </div>
  <div class="card"><h3>Já tem a narração pronta?</h3><p class="small mut">Se gravou ou gerou fora, envie aqui e pule o VozLab.</p>
    <div class="row"><input type="file" id="vz-up" accept="audio/*" style="flex:1"><button id="vz-up-ok">Enviar</button></div>
    ${v.narracao ? `<h3 style="margin-top:16px">Narração atual <span class="pill ok">${(v.narracao_duracao / 60 || 0).toFixed(1)} min · ${v.narracao_origem === 'vozlab' ? 'VozLab' : 'enviada'}</span></h3><audio controls style="width:100%" src="/api/videos/${v.id}/voz/final?t=${Date.now()}"></audio>
    <div class="row end" style="margin-top:8px"><button class="pri" onclick="proxima('narracao')">Ir para cenas →</button></div>` : ''}
    ${(v.cenas_cfg || {}).personagem_fala ? '<div class="hint" style="margin-top:12px">Modo <b>personagem fala</b> ligado: a voz sai dos próprios clipes do Flow. Você pode pular esta etapa.</div>' : ''}</div></div>
  <div class="card"><div class="row"><h3 style="margin:0" class="sp">Blocos de narração ${blocos.length ? `<span class="pill">${prontos}/${blocos.length} prontos</span>` : ''}</h3>
    <button id="vz-prep">${blocos.length ? 'Dividir de novo' : 'Dividir roteiro em blocos'}</button>
    ${blocos.length ? `<button class="pri" id="vz-gerar">${prontos ? 'Gerar os que faltam' : 'Gerar todos'}</button><button id="vz-refazer">Refazer todos com a voz atual</button>` : ''}
    ${blocos.length && prontos === blocos.length ? '<button class="pri" id="vz-juntar">Juntar e usar como narração</button>' : ''}</div>
    <div id="vz-prog" style="margin-top:10px"></div>
    ${blocos.map(b => `<div style="border-top:1px solid var(--line);padding:10px 0"><div class="row"><b>${String(b.i).padStart(2, '0')}</b>
      <span class="pill ${b.status === 'pronto' ? 'ok' : b.status === 'erro' ? 'bad' : ''}">${b.status}${b.duracao ? ' · ' + b.duracao.toFixed(1) + 's' : ''}</span><span class="sp"></span>
      ${b.status === 'pronto' ? `<audio controls preload="none" src="/api/videos/${v.id}/voz/audio/${b.i}?t=${encodeURIComponent(b.arquivo)}" style="height:30px"></audio>` : ''}
      <button class="sm" data-regerar="${b.i}">${b.status === 'pronto' ? 'Regerar' : 'Gerar'}</button></div>
      ${b.erro ? `<div class="small danger">${esc(b.erro)}</div>` : ''}
      <textarea data-btxt="${b.i}" style="min-height:70px;font-family:inherit;margin-top:6px">${esc(b.texto)}</textarea></div>`).join('')}
  </div>`;
  const cache = S.vozesCache || (S.vozesCache = {});
  const vozAtual = m => cfg['voz_' + m] || '';
  async function carregarVozes() {
    const m = $('#vz-motor').value;
    $('#vz-f-vel').style.display = ['edge', 'azure', 'darkplanner'].includes(m) ? '' : 'none';
    $('#vz-f-est').style.display = m === 'gemini' ? '' : 'none';
    $('#vz-f-mod').style.display = m === 'elevenlabs' ? '' : 'none';
    $('#vz-voz-txt').style.display = m === 'fish' ? '' : 'none';
    $('#vz-info').textContent = {edge: 'Grátis e sem chave.', gemini: 'Usa suas chaves do Gemini (gratuito: poucos pedidos por dia).', azure: 'Usa sua conta Azure (Free: 500 mil caracteres/mês).', elevenlabs: 'Usa sua conta ElevenLabs (Free sem licença comercial).', fish: 'Usa sua conta Fish Audio. Cole o ID de qualquer voz do fish.audio ou escolha uma das suas.', darkplanner: 'Usa a sua API da DarkPlanner. Aqui no VozLab cada bloco gasta 1 áudio do limite diário; no Estúdio 1 clique a narração inteira sai num pedido só.'}[m];
    const sel = $('#vz-voz');
    try {
      const d = cache[m] || (cache[m] = await api('/api/vozes/' + m));
      let html = '';
      if (m === 'edge') html = Object.entries(d).map(([lg, lst]) => `<optgroup label="${IDIOMAS[lg]}">${lst.map(([id, n]) => `<option value="${id}">${esc(n)}</option>`).join('')}</optgroup>`).join('');
      else html = (d.todas || []).map(([id, n]) => `<option value="${esc(id)}">${esc(n)}</option>`).join('');
      sel.innerHTML = html || '<option value="">(nenhuma voz)</option>';
      const atual = vozAtual(m) || (m === 'edge' ? (S.settings['voz_edge_' + idioma] || '') : m === 'azure' ? (S.settings['voz_edge_' + idioma] || '') : '');
      if (atual && [...sel.options].some(o => o.value === atual)) sel.value = atual;
      if (m === 'fish') $('#vz-voz-txt').value = vozAtual('fish');
    } catch (e) { delete cache[m]; sel.innerHTML = `<option value="">${esc(e.message)}</option>`; }
  }
  if ($('#vz-open-dp-gen')) $('#vz-open-dp-gen').onclick = () => {
    if (typeof window.abrirModalAudioGeneratorDP === 'function') {
      window.abrirModalAudioGeneratorDP({canal_id: v.channel_id, vid: v.id, titulo: v.titulo, roteiro: v.roteiro});
    }
  };
  $('#vz-motor').onchange = carregarVozes; await carregarVozes();
  if (cfg.modelo_elevenlabs) $('#vz-mod').value = cfg.modelo_elevenlabs;
  const lerCfg = () => { const m = $('#vz-motor').value; const voz = m === 'fish' ? ($('#vz-voz-txt').value.trim() || $('#vz-voz').value) : $('#vz-voz').value;
    return {motor: m, ['voz_' + m]: voz, velocidade: $('#vz-vel').value, estilo: $('#vz-est').value, modelo_elevenlabs: $('#vz-mod').value, _voz: voz}; };
  const salvarCfg = (extra = {}) => { const c = lerCfg(); delete c._voz; return api(`/api/videos/${v.id}/voz/config`, {method: 'PATCH', json: {...c, ...extra}}); };
  $('#vz-salvar').onclick = () => safe(async () => { await salvarCfg(); const c = lerCfg();
    const extra = c.motor === 'edge' ? {['voz_edge_' + idioma]: c._voz} : c.motor === 'azure' ? {['voz_azure_' + idioma]: c._voz} : c.motor === 'gemini' ? {voz_gemini: c._voz} : c.motor === 'elevenlabs' ? {voz_elevenlabs: c._voz} : c.motor === 'darkplanner' ? {voz_darkplanner: c._voz} : {voz_fish: c._voz};
    S.settings = await api('/api/settings', {json: {voz_motor: c.motor, voz_velocidade: c.velocidade, voz_estilo: c.estilo, ...extra}}).catch(() => S.settings); toast('Voz salva'); });
  $('#vz-teste').onclick = () => safe(async () => {
    const c = lerCfg(); toast('Gerando amostra…');
    const r = await fetch('/api/voz/teste', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({motor: c.motor, voz: c._voz, velocidade: c.velocidade, estilo: c.estilo, texto: (blocos[0]?.texto || v.roteiro).slice(0, 220)})});
    if (!r.ok) { let m = 'Falha na amostra'; try { m = (await r.json()).erro; } catch {} throw new Error(m); }
    const a = $('#vz-audio'); a.src = URL.createObjectURL(await r.blob()); a.style.display = ''; a.play();
  });
  $('#vz-up-ok').onclick = () => safe(async () => { const f = $('#vz-up').files[0]; if (!f) return toast('Escolha o áudio', true); const fd = new FormData(); fd.append('arquivo', f); toast('Enviando…'); await api(`/api/videos/${v.id}/narracao`, {method: 'POST', body: fd}); toast('Narração salva'); videoView(); });
  $('#vz-prep').onclick = () => safe(async () => { if (blocos.length && !confirm('Dividir de novo apaga os áudios gerados. Continuar?')) return; await salvarCfg(); await api(`/api/videos/${v.id}/voz/preparar`, {json: {max_chars: $('#vz-motor').value === 'gemini' ? 1500 : 900}}); videoView(); });
  const gerar = i => safe(async () => { await salvarCfg(); await api(`/api/videos/${v.id}/voz/gerar`, {json: i ? {i} : {}}); acompanharVoz(v.id); });
  if ($('#vz-gerar')) $('#vz-gerar').onclick = () => gerar();
  if ($('#vz-refazer')) $('#vz-refazer').onclick = () => safe(async () => { if (!confirm('Gerar de novo todos os blocos com a voz atual?')) return; await salvarCfg({refazer_todos: true}); await api(`/api/videos/${v.id}/voz/gerar`, {json: {}}); acompanharVoz(v.id); });
  $$('[data-regerar]').forEach(b => b.onclick = () => gerar(+b.dataset.regerar));
  $$('[data-btxt]').forEach(t => t.onchange = () => safe(async () => { await api(`/api/videos/${v.id}/voz/bloco/${t.dataset.btxt}`, {method: 'PATCH', json: {texto: t.value}}); toast('Texto do bloco salvo — gere o áudio de novo'); }));
  if ($('#vz-juntar')) $('#vz-juntar').onclick = () => safe(async () => { toast('Juntando…'); await api(`/api/videos/${v.id}/voz/juntar`, {json: {}}); toast('Narração pronta!'); videoView(); });
  const st = await api(`/api/videos/${v.id}/voz/status`); if (st.rodando) acompanharVoz(v.id);
};

// ---------------- Cenas e SRT: tipo, estilo visual, personagens, meta-prompt ----------------
const _stCenasOrig = stCenas;
stCenas = async function (v) {
  await _stCenasOrig(v);
  if (!v.cenas.length) return;
  const cfg = v.cenas_cfg || {};
  const estilos = await api('/api/estilos');
  const ch = S.channels.find(c => c.id === v.channel_id) || {};
  const pers = ch.personagens || (ch.personagem ? [{nome: 'Personagem', descricao: ch.personagem}] : []);
  const com = v.cenas.filter(c => c.prompt_ia || c.prompt_video).length;
  const painel = document.createElement('div');
  painel.innerHTML = `<div class="card" style="border-color:#6b3a14"><h3>Visual das cenas (meta-prompt para o Flow)</h3>
  <div class="row" style="margin-bottom:10px"><label style="margin:0;color:var(--txt)"><input type="checkbox" id="mc-fala" ${cfg.personagem_fala ? 'checked' : ''}> <b>O personagem vai falar dentro do vídeo?</b> Modo personagem fala (voz do Flow): o roteiro vira falas curtas e o personagem diz cada uma no clipe — sem narração separada.</label></div>
  <div class="grid g3"><div class="f"><label>As cenas vão ser</label><select id="mc-tipo"><option value="imagens" ${cfg.tipo_cenas !== 'videos' ? 'selected' : ''}>Imagens (sem limite de tamanho)</option><option value="videos" ${cfg.tipo_cenas === 'videos' ? 'selected' : ''}>Vídeos (clipes de 8 s do Veo)</option></select></div>
  <div class="f"><label>Estilo visual</label><select id="mc-est">${estilos.map(e => `<option value="${e.id}" ${(cfg.estilo || 'cinematic') === e.id ? 'selected' : ''}>${esc(e.nome)}${e.meu ? ' (meu)' : ''}</option>`).join('')}</select>
    <a href="#" id="mc-novo" class="small">+ Criar meu estilo</a></div>
  <div class="f"><label>Personagens do canal</label><div class="small">${pers.length ? pers.map(p => `<span class="tag">${esc(p.nome)}</span>`).join('') : '<span class="mut">nenhum cadastrado</span>'} <a href="#" onclick="go('canais');return false">editar no canal</a></div></div></div>
  ${cfg.tipo_cenas === 'videos' ? '<p class="small mut">O clipe do Veo tem 8 s: use "uma cena a cada 8 segundos" acima. Cada cena deve ter até ~12 s de fala para o clipe não ficar parado.</p>' : ''}
  <button id="mc-salvar">Salvar visual</button> <span class="small mut">${com}/${v.cenas.length} cenas com prompt visual</span></div>
  ${blocoPrompt('pmeta', 'Meta-prompt (prompts de imagem/vídeo de todas as cenas)', 'Gera o prompt do Flow de cada cena com o mesmo estilo e os personagens do canal. Use ⚡ para o Gemini fazer direto.')}
  <div class="card"><h3>Cole o JSON do meta-prompt</h3><textarea id="meta-json"></textarea><div class="row end" style="margin-top:8px"><button class="pri" id="meta-ok">Aplicar nas cenas</button></div></div>`;
  step().appendChild(painel);
  const salvar = () => api(`/api/videos/${v.id}/cenas_cfg`, {method: 'PATCH', json: {tipo_cenas: $('#mc-tipo').value, estilo: $('#mc-est').value, personagem_fala: $('#mc-fala').checked}});
  $('#mc-salvar').onclick = () => safe(async () => { await salvar(); toast('Visual salvo'); videoView(); });
  ['#mc-tipo', '#mc-est', '#mc-fala'].forEach(k => $(k).onchange = () => safe(async () => { await salvar(); ligarPrompt('pmeta', (await api(`/api/videos/${v.id}/meta_prompt`)).prompt); toast('Visual salvo — prompt atualizado'); }));
  $('#mc-novo').onclick = e => { e.preventDefault();
    modal(`<h3>Criar meu estilo</h3><div class="f"><label>Nome</label><input id="ne-n"></div><div class="f"><label>Descrição visual (em inglês funciona melhor)</label><textarea id="ne-p" style="min-height:80px;font-family:inherit" placeholder="dark gothic engraving style, ink cross-hatching, sepia paper"></textarea></div>
    <div class="row end"><button onclick="fecharModal()">Cancelar</button><button class="pri" id="ne-ok">Criar</button></div>`);
    $('#ne-ok').onclick = () => safe(async () => { const e2 = await api('/api/estilos', {json: {nome: $('#ne-n').value, prompt: $('#ne-p').value}}); fecharModal(); await api(`/api/videos/${v.id}/cenas_cfg`, {method: 'PATCH', json: {estilo: e2.id}}); videoView(); });
  };
  ligarPrompt('pmeta', (await api(`/api/videos/${v.id}/meta_prompt`)).prompt);
  $('#meta-ok').onclick = () => safe(async () => { await salvar(); const r = await api(`/api/videos/${v.id}/meta_colar`, {json: {texto: $('#meta-json').value}}); toast(`${r.aplicadas}/${r.total} cenas com prompt visual`, r.aplicadas < r.total); videoView(); });
};

// ---------------- Real Lab: Mídia + Revisão ----------------
S.marcadas = S.marcadas || new Set();
function classeChip(c) {
  const m = c.midia;
  if (!m) return c.status === 'vazia' ? '' : 'ia';
  if (m.origem === 'ia') return 'iag';
  if (m.origem === 'manual') return 'man';
  return m.match === 'exata' ? 'ok' : 'par';
}
stMidia = async function (v) {
  if (!v.cenas.length) { step().innerHTML = '<div class="empty">Divida o roteiro em cenas primeiro.</div>'; return; }
  const s = S.settings;
  const total = v.cenas.length;
  const comMidia = v.cenas.filter(c => c.midia).length;
  const comVideo = v.cenas.filter(c => c.midia && c.midia.tipo === 'video').length;
  const ia = v.cenas.filter(c => c.midia && c.midia.origem === 'ia').length;
  const sem = v.cenas.filter(c => !c.midia).length;
  const usos = {};
  v.cenas.forEach(c => { const k = c.midia && (c.midia.download || c.midia.arquivo); if (k) usos[k] = (usos[k] || 0) + 1; });
  const dif = Object.keys(usos).length, maxUso = Math.max(0, ...Object.values(usos)), repet = Object.values(usos).filter(n => n > 1).length;
  const filtros = {todas: () => true, ia: c => !c.midia, parecidas: c => c.midia && c.midia.match !== 'exata' && c.midia.origem !== 'ia', exatas: c => c.midia && c.midia.match === 'exata', iaGerada: c => c.midia && c.midia.origem === 'ia', avisos: c => (c.avisos || []).length, marcadas: c => S.marcadas.has(c.n)};
  const lista = v.cenas.filter(filtros[S.filtroCena] || filtros.todas);
  const conn = await api('/api/conexoes');
  const temGem = conn.gemini.length > 0, temYt = conn.youtube.length > 0;
  const looks = {auto: 'Automático (medido nas fotos reais aprovadas)', pb_arquivo: 'Preto e branco de arquivo', vintage: 'Vintage desbotado', moderno_4k: 'Moderno e nítido (4K)', documental: 'Documental natural', noturno: 'Escuro e dramático', custom: 'Meu look (texto em Configurações)'};
  const nomesLook = {pb_arquivo: 'Preto e branco de arquivo', vintage: 'Vintage desbotado', moderno_4k: 'Moderno e nítido (4K)', documental: 'Documental natural', noturno: 'Escuro e dramático'};
  step().innerHTML = `
  <div class="card"><div class="row"><div class="sp"><b>${comMidia} de ${total}</b> cenas prontas · ${comVideo} com vídeo · ${comMidia - comVideo} com imagem · ${ia} por IA · <span style="color:var(--warn)">${sem} sem mídia</span>
    <div class="small mut">Repetição agora: ${dif} mídias diferentes · a mais usada aparece em ${maxUso} cena(s) · ${repet} mídia(s) em mais de uma cena · custo de IA neste vídeo: ${brl(v.custo_ia_brl || 0)}</div></div>
    <button id="m-diag" title="Testa cada banco de imagens e o Gemini">Testar fontes</button><button class="pri" id="m-buscar">${comMidia ? 'Buscar de novo (só pendentes)' : 'Buscar mídia de todas as cenas'}</button>${comMidia ? '<button id="m-buscar-tudo">Refazer tudo</button>' : ''}</div>
    <div class="small" style="margin-top:6px">${temGem ? '✓ Gemini escolhe os termos e confere cada mídia' : '<span class="aviso">Sem chave do Gemini: a busca usa só os termos e não confere as imagens.</span> <a href="#" onclick="go(\'conexoes\');return false">Conectar</a>'} · ${temYt ? `✓ YouTube CC (${s.youtube_assuntos || 0} assuntos)` : '<span class="mut">YouTube CC desligado (sem chave)</span>'}</div>
    <div class="row" style="margin-top:10px;padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--panel2)">
      <b>Preferir:</b>${[['fotos', 'Fotos'], ['equilibrado', 'Equilibrado'], ['videos', 'Vídeos (mais movimento)']].map(([k, n]) => `<label style="margin:0;color:var(--txt)"><input type="radio" name="m-pref" value="${k}" ${(s.preferencia_midia || 'equilibrado') === k ? 'checked' : ''}> ${n}</label>`).join('')}
      <span class="sp"></span><button class="pri" id="m-videos">🎬 Trocar fotos por vídeos (${v.cenas.filter(c => c.midia && c.midia.tipo === 'foto' && !['manual', 'ia'].includes(c.midia.origem)).length} cenas)</button></div>
    <div class="small" style="margin-top:6px;color:#10b981">✓ Pixabay, Unsplash e Smithsonian conectados via API · ✓ <b>Pexels Modo Direto no Site</b> (sua conta conectada): clique em <b>🎬 Pexels Vídeos (Download Manual)</b> em qualquer cena para abrir o Pexels já pesquisado e subir o arquivo baixado!</div>
    <div id="m-prog" style="margin-top:10px"></div>
    <div class="chips" style="margin-top:10px">${v.cenas.map(c => `<div class="chip ${classeChip(c)}" data-chip="${c.n}" title="Cena ${c.n}${c.midia ? ' · ' + esc(c.midia.fonte || '') : ' · sem mídia'}">${c.n}${(c.avisos || []).length ? '<span class="dot"></span>' : ''}</div>`).join('')}</div>
    <div class="small mut" style="margin-top:6px">verde = exata · amarelo = parecida · azul = sua · roxo = IA · vermelho = sem mídia · ponto = teve mídia reprovada</div></div>

  <div class="card"><h3>IA nas cenas sem mídia real boa</h3>
    <div class="row">${[['so_real', 'Só mídia real'], ['real_ia', 'Real + IA (recomendado)'], ['mais_ia', 'Mais IA']].map(([k, n]) => `<label style="margin:0;color:var(--txt)"><input type="radio" name="m-modo" value="${k}" ${(s.modo_ia || 'real_ia') === k ? 'checked' : ''}> ${n}</label>`).join('')}
    <label style="margin:0">máximo de cenas por IA <input id="m-pct" type="number" min="0" max="100" value="${s.max_cenas_ia_pct}" style="width:70px"> %</label></div>
    <p class="small mut">A cena sem mídia real boa é gerada por IA. A IA nunca desenha rosto nem aparência de pessoa real: o pedido descreve o contexto (lugar, época, objetos, multidão de longe, silhueta, de costas, mãos), sem letreiro, logo nem marca d'água.</p>
    <div class="grid g3"><div class="f"><label style="color:var(--txt)"><input type="checkbox" id="m-auto" ${s.ia_auto ? 'checked' : ''}> Gerar com IA automaticamente quando faltar mídia</label></div>
    <div class="f"><label>Motor da IA</label><select id="m-motor"><option value="pollinations" ${s.ia_motor === 'pollinations' ? 'selected' : ''}>Pollinations (grátis, sem chave)</option><option value="gemini" ${s.ia_motor === 'gemini' ? 'selected' : ''}>Gemini imagem / Nano Banana (sua chave)</option><option value="manual" ${s.ia_motor === 'manual' ? 'selected' : ''}>Manual: eu gero no Google Flow</option></select></div>
    <div class="f"><label>Look da IA</label><select id="m-look">${Object.entries(looks).map(([k, n]) => `<option value="${k}" ${(s.ia_look_modo || 'auto') === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div></div>
    <div class="row"><label style="margin:0;color:var(--txt)"><input type="checkbox" id="m-grao" ${s.grao ? 'checked' : ''}> Mesmo tratamento de cor e grão em todas as cenas (real e IA)</label><span class="sp"></span>
    ${v.look_ia ? `<span class="small">Look usado neste vídeo: <b>${nomesLook[v.look_ia] || v.look_ia}</b> (medido em ${v.look_medido_em || 0} foto(s) reais aprovadas)</span>` : ''}</div>
    <div class="row" style="margin-top:10px"><button id="m-ia-agora" class="pri">Gerar IA agora nas ${sem} cena(s) sem mídia</button><button id="m-pflow">Copiar prompts para o Flow</button>
    <a class="btn" href="https://labs.google/fx/tools/flow" target="_blank">Abrir Google Flow</a><span class="sp"></span>
    <input type="file" id="m-lote" multiple accept="image/*,video/*" style="width:auto"><button id="m-lote-ok">Importar lote (001.png, 002.mp4…)</button></div>
    <p class="small mut">Google Flow: gere com suas contas (até 3), salve com o número da cena no nome e importe o lote — cada arquivo entra na cena certa. Modelo de hoje no Flow: vídeo Veo, imagem Nano Banana.</p></div>

  <details class="adv"><summary>Configurações avançadas · fontes, conferência, repetição, custos</summary>
    <div class="grid g3" style="margin-top:10px">
    <div class="f"><label>Fontes ativas</label>${['Wikimedia', 'Pixabay', 'Pexels', 'Internet Archive', 'NASA', 'Unsplash', 'Openverse', 'Met', 'Smithsonian', 'Europeana'].map(f => `<label style="margin:2px 0;color:var(--txt)"><input type="checkbox" data-fonte="${f}" ${(s.fontes_ativas || {})[f] !== false ? 'checked' : ''}> ${f}</label>`).join('')}</div>
    <div class="f"><label style="color:var(--txt)"><input type="checkbox" id="m-conf" ${s.conferir_com_ia !== false ? 'checked' : ''}> Conferir cada mídia com o Gemini</label>
      <label>Conferências por cena (máx.)</label><input id="m-nconf" type="number" min="1" max="8" value="${s.conferencias_por_cena || 3}">
      <label style="margin-top:8px">Mesma mídia em no máximo</label><input id="m-rep" type="number" min="1" max="10" value="${s.max_repeticao || 3}"> <span class="small mut">cenas</span>
      <label style="margin-top:8px;color:var(--txt)"><input type="checkbox" id="m-rap" ${s.modo_rapido ? 'checked' : ''}> Modo rápido (confere menos e aceita direto nota alta)</label>
      <label style="margin-top:8px">Cenas ao mesmo tempo</label><select id="m-par">${[1, 2, 3, 4, 6].map(n => `<option value="${n}" ${Number(s.cenas_paralelo || 3) === n ? 'selected' : ''}>${n}${n === 3 ? ' (padrão)' : ''}</option>`).join('')}</select>
      <label style="margin-top:8px;color:var(--txt)"><input type="checkbox" id="m-gpar" ${s.gemini_paralelo !== false ? 'checked' : ''}> Usar todas as chaves gratuitas do Gemini ao mesmo tempo</label></div>
    <div class="f"><label>Buscas do YouTube por vídeo (assuntos)</label><select id="m-yt">${[0, 4, 6, 8, 10, 15, 20].map(n => `<option value="${n}" ${Number(s.youtube_assuntos) === n ? 'selected' : ''}>${n === 0 ? 'Desligado' : n}</option>`).join('')}</select>
      <p class="small mut">Cada assunto = 2 buscas (EN + PT) de 100 unidades. Chaves, limites e preços: <a href="#" onclick="go('conexoes');return false">Conexões</a> · <a href="#" onclick="go('config');return false">Custos</a></p></div></div>
    <button id="m-adv-ok">Salvar</button></details>

  ${S.marcadas.size ? `<div class="card bulk"><div class="row"><b>${S.marcadas.size} cena(s) marcada(s)</b><span class="sp"></span>
    <button class="sm" data-lote="buscar">Buscar de novo</button><button class="sm" data-lote="mandar_ia">Mandar para IA</button><button class="sm pri" data-lote="gerar_ia">Gerar IA agora</button><button class="sm" id="m-desmarcar">Desmarcar</button></div></div>` : ''}
  <div class="row" style="margin-bottom:10px">${Object.entries({todas: 'Todas', ia: 'Sem mídia', parecidas: 'Parecidas', exatas: 'Exatas', iaGerada: 'IA', avisos: 'Com reprovadas', marcadas: 'Marcadas'}).map(([k, n]) => `<button class="sm ${S.filtroCena === k ? 'pri' : ''}" data-f="${k}">${n}</button>`).join('')}
    <button class="sm" id="m-marcar-vis">Marcar visíveis</button><span class="sp"></span><button class="pri" onclick="proxima('midia')">Ir para o editor →</button></div>
  <div class="scene-grid">${lista.map(cardCena).join('')}</div>`;

  $$('[data-f]').forEach(b => b.onclick = () => { S.filtroCena = b.dataset.f; stMidia(v); });
  $$('input[name=m-pref]').forEach(r => r.onchange = () => safe(async () => { S.settings = await api('/api/settings', {json: {preferencia_midia: r.value}}); toast(r.value === 'videos' ? 'Preferência: vídeos. Use "Trocar fotos por vídeos" para aplicar neste vídeo.' : 'Preferência salva'); }));
  $('#m-videos').onclick = () => safe(async () => {
    const ns = v.cenas.filter(c => c.midia && c.midia.tipo === 'foto' && !['manual', 'ia'].includes(c.midia.origem)).map(c => c.n);
    if (!ns.length) return toast('Não há fotos automáticas para trocar.');
    if (!confirm(`Buscar vídeos para ${ns.length} cenas que hoje têm foto? Onde não houver vídeo bom, a foto continua. As cenas que você escolheu na mão não mudam.`)) return;
    S.settings = await api('/api/settings', {json: {preferencia_midia: 'videos'}});
    await api(`/api/videos/${v.id}/lote`, {json: {acao: 'buscar', ns}}); acompanharMidia(v.id);
  });
  $$('[data-chip]').forEach(ch => ch.onclick = () => { S.filtroCena = 'todas'; stMidia(v).then(() => { const el = $('#sc-' + ch.dataset.chip); if (el) { el.scrollIntoView({behavior: 'smooth', block: 'center'}); el.style.outline = '2px solid var(--acc)'; } }); });
  const iniciar = so => safe(async () => { await api(`/api/videos/${v.id}/buscar_midia`, {json: {so_pendentes: so}}); acompanharMidia(v.id); });
  $('#m-buscar').onclick = () => iniciar(comMidia > 0);
  if ($('#m-buscar-tudo')) $('#m-buscar-tudo').onclick = () => confirm('Refazer a busca de todas as cenas (menos as que você escolheu na mão)?') && iniciar(false);
  const salvarIA = () => api('/api/settings', {json: {modo_ia: $('input[name=m-modo]:checked').value, max_cenas_ia_pct: Number($('#m-pct').value), ia_auto: $('#m-auto').checked, ia_motor: $('#m-motor').value, ia_look_modo: $('#m-look').value, grao: $('#m-grao').checked}}).then(x => S.settings = x);
  ['#m-pct', '#m-auto', '#m-motor', '#m-look', '#m-grao'].forEach(k => $(k).onchange = () => safe(salvarIA));
  $$('input[name=m-modo]').forEach(r => r.onchange = () => safe(salvarIA));
  $('#m-ia-agora').onclick = () => safe(async () => {
    await salvarIA(); const ns = v.cenas.filter(c => !c.midia).map(c => c.n); if (!ns.length) return toast('Todas as cenas têm mídia');
    if ($('#m-motor').value === 'manual') return toast('Motor manual: copie os prompts para o Flow e importe o lote.', true);
    await api(`/api/videos/${v.id}/lote`, {json: {acao: 'gerar_ia', ns}}); acompanharMidia(v.id);
  });
  $('#m-pflow').onclick = () => safe(async () => { const r = await api(`/api/videos/${v.id}/prompts_flow`); if (!r.quantidade) return toast('Todas as cenas têm mídia'); copiar(r.texto); toast(`${r.quantidade} prompts copiados`); });
  $('#m-lote-ok').onclick = () => safe(async () => {
    const fs = $('#m-lote').files; if (!fs.length) return toast('Escolha os arquivos', true);
    const fd = new FormData(); [...fs].forEach(f => fd.append('arquivos', f)); toast('Enviando…');
    const r = await api(`/api/videos/${v.id}/importar_lote`, {method: 'POST', body: fd});
    toast(`${r.importados} importado(s)` + (r.ignorados.length ? ` · ignorados: ${r.ignorados.join(', ')}` : '')); videoView();
  });
  $('#m-adv-ok').onclick = () => safe(async () => {
    const fontes = {}; $$('[data-fonte]').forEach(x => fontes[x.dataset.fonte] = x.checked);
    S.settings = await api('/api/settings', {json: {fontes_ativas: fontes, conferir_com_ia: $('#m-conf').checked, conferencias_por_cena: Number($('#m-nconf').value), max_repeticao: Number($('#m-rep').value), youtube_assuntos: Number($('#m-yt').value),
      modo_rapido: $('#m-rap').checked, cenas_paralelo: Number($('#m-par').value), gemini_paralelo: $('#m-gpar').checked}});
    toast('Configurações salvas');
  });
  $$('[data-lote]').forEach(b => b.onclick = () => safe(async () => {
    await api(`/api/videos/${v.id}/lote`, {json: {acao: b.dataset.lote, ns: [...S.marcadas]}});
    if (b.dataset.lote === 'mandar_ia') { S.video = await api('/api/videos/' + v.id); stMidia(S.video); } else acompanharMidia(v.id);
  }));
  if ($('#m-desmarcar')) $('#m-desmarcar').onclick = () => { S.marcadas.clear(); stMidia(v); };
  $('#m-marcar-vis').onclick = () => { lista.forEach(c => S.marcadas.add(c.n)); stMidia(v); };
  ligarCenas(v);
  $('#m-diag').onclick = () => safe(async () => {
    const termo = prompt('Termo para testar as fontes (inglês funciona melhor):', (v.cenas.find(c => (c.termos_busca || []).length)?.termos_busca || ['map of Brazil'])[0]); if (!termo) return;
    modal('<h3>Testando as fontes…</h3><p class="mut">Pode levar até 1 minuto.</p>');
    const r = await api('/api/diagnostico_fontes', {json: {termo}});
    modal(`<h3>Teste das fontes — "${esc(r.termo)}"</h3><table>${r.resultados.map(x => `<tr><td><b>${esc(x.fonte)}</b></td><td>${x.status === 'ok' ? `<span class="pill ok">ok · ${x.qtd}</span>` : x.status === 'sem chave' ? '<span class="pill">sem chave</span>' : x.status === 'vazio' ? '<span class="pill warn">0 resultados</span>' : '<span class="pill bad">erro</span>'}</td><td class="small mut">${esc(x.erro || (x.seg != null ? x.seg + ' s' : ''))}</td></tr>`).join('')}</table>
      <p class="small mut">Se aparecer erro, me mande o print desta janela.</p><div class="row end"><button onclick="fecharModal()">Fechar</button></div>`);
  });
  const st = await api(`/api/videos/${v.id}/midia_status`);
  if (st.rodando) acompanharMidia(v.id);
  else if (st.erro || (st.erros || []).length) $('#m-prog').innerHTML = `<div class="hint"><b>Última busca:</b> ${esc(st.etapa || '')}${st.erro ? `<div class="danger">${esc(st.erro)}</div>` : ''}${[...new Set(st.erros || [])].slice(0, 8).map(e => `<div class="small">• ${esc(e)}</div>`).join('')}</div>`;
};

cardCena = function (c) {
  const m = c.midia, vid = S.video.id;
  const src = m ? (m.arquivo ? `/api/videos/${vid}/midia/${c.n}?t=${encodeURIComponent(m.arquivo)}` : (m.preview || '').replace('/480px-', '/500px-')) : '';
  const thumb = m ? (m.arquivo && m.tipo === 'video' ? `<video src="${src}#t=1" muted preload="metadata"></video>` : `<img src="${esc(src)}" loading="lazy" onerror="this.outerHTML='<span class=&quot;small mut&quot;>${m.tipo === 'video' ? '▶ vídeo — prévia indisponível (o vídeo entra normal)' : 'prévia indisponível — use Ver outros candidatos'}</span>'">`) : (c.status === 'vazia' ? 'deixada sem mídia' : 'sem mídia — vai para IA');
  const badge = m ? `<span class="pill ${m.origem === 'ia' ? 'acc' : m.match === 'exata' ? 'ok' : m.match === 'parecida' ? 'warn' : 'bad'}">${m.origem === 'ia' ? 'IA' : m.match === 'exata' ? 'Exata' : m.match === 'parecida' ? 'Parecida' : m.origem === 'manual' ? 'Sua' : 'Genérica'}</span><span class="pill">${m.origem === 'ia' ? 'gerada' : 'real'}</span>${m.nota != null && m.origem !== 'ia' ? `<span class="pill">nota ${m.nota}/10</span>` : ''}${m.conferida ? '<span class="pill ok">conferida</span>' : ''}` : '<span class="pill bad">IA</span>';
  const aberto = S.abertos.has(c.n);
  const termoPexels = encodeURIComponent(((c.termos_busca || [])[0] || c.termo_busca || (c.texto || '').split(/\s+/).slice(0, 4).join(' ') || 'cinematic').trim());
  return `<div class="scene" id="sc-${c.n}"><label class="small" style="margin:0;color:var(--mut)"><input type="checkbox" data-marca="${c.n}" ${S.marcadas.has(c.n) ? 'checked' : ''}> marcar</label>
  <div class="thumb">${thumb}${m?.tipo === 'video' ? '<span class="vt">▶ vídeo</span>' : ''}</div>
  <div>${badge}</div>
  <div class="small"><b>${String(c.n).padStart(2, '0')}</b> <span class="mut">${esc(m?.fonte || '')} · ${m ? (m.tipo === 'video' ? 'vídeo' : 'foto') + ' · pronta' : 'pendente'} · ${tempo(c.inicio)}</span></div>
  <div class="txt">${esc(c.texto)}</div>
  ${m?.na_imagem ? `<div class="small mut">na imagem: ${esc(m.na_imagem)}</div>` : ''}
  ${m?.pagina ? `<div class="small"><span class="mut">${esc(m.licenca || '')} · ${esc((m.autor || '').slice(0, 40))}</span> · <a href="${esc(m.pagina)}" target="_blank">ver a origem</a></div>` : ''}
  ${(c.avisos || []).map(a => `<div class="aviso">${esc(a)}</div>`).join('')}
  ${c.descricao_visual ? `<div class="small mut">plano da cena: ${esc(c.descricao_visual)}</div>` : ''}
  <div class="acts">
    <button class="sm" data-cand="${c.n}">${aberto ? 'Fechar' : 'Ver outros candidatos'} (${(c.candidatos || []).length})</button>
    <button class="sm" data-denovo="${c.n}">Buscar de novo</button>
    <button class="sm" data-termos="${c.n}">Buscar com meus termos</button>
    <a class="btn sm" href="https://www.pexels.com/pt-br/procurar/videos/${termoPexels}/" target="_blank" style="background:rgba(16,185,129,.15);border-color:#10b981;color:#34d399" title="Abre o Pexels com a sua conta conectada já pesquisando esta cena para download manual">🎬 Pexels Vídeos (Download Manual)</a>
    <a class="btn sm" href="https://www.pexels.com/pt-br/procurar/${termoPexels}/" target="_blank" title="Abre o Pexels Fotos com o termo desta cena">📸 Pexels Fotos</a>
    <label class="btn sm" style="margin:0;color:var(--txt)">📤 Usar arquivo baixado<input type="file" data-arq="${c.n}" accept="image/*,video/*" hidden></label>
    <button class="sm" data-pessoa="${c.n}">Pessoa real</button>
    <button class="sm" data-contexto="${c.n}">Trocar por mídia de contexto</button>
    <button class="sm" data-yt="${c.n}">YouTube CC</button>
    ${m ? `<button class="sm" data-conf="${c.n}">Conferir com IA</button>` : ''}
    <button class="sm" data-ia="${c.n}">Mandar para IA</button>
    <button class="sm" data-gia="${c.n}">Gerar IA agora</button>
  </div>
  ${aberto ? `<div class="cands">${(c.candidatos || []).map((x, i) => `<div class="cand" data-pick="${c.n}:${i}"><img src="${esc((x.preview || '').replace('/480px-', '/500px-'))}" loading="lazy"><div>${x.tipo === 'video' ? '▶ ' : ''}${esc(x.fonte)} · ${x.nota}/10<br><span class="mut">${esc((x.titulo || '').slice(0, 50))}</span></div></div>`).join('') || '<span class="mut small">Nenhum candidato. Busque com outros termos.</span>'}</div>` : ''}
  </div>`;
};

const _ligarCenasOrig = ligarCenas;
ligarCenas = function (v) {
  _ligarCenasOrig(v);
  const vid = v.id;
  $$('[data-marca]').forEach(x => x.onchange = () => { const n = +x.dataset.marca; x.checked ? S.marcadas.add(n) : S.marcadas.delete(n); stMidia(v); });
  $$('[data-denovo]').forEach(b => b.onclick = () => safe(async () => { await api(`/api/videos/${vid}/lote`, {json: {acao: 'buscar', ns: [+b.dataset.denovo]}}); acompanharMidia(vid); }));
  $$('[data-gia]').forEach(b => b.onclick = () => safe(async () => { await api(`/api/videos/${vid}/lote`, {json: {acao: 'gerar_ia', ns: [+b.dataset.gia]}}); acompanharMidia(vid); }));
  $$('[data-conf]').forEach(b => b.onclick = () => safe(async () => {
    b.textContent = 'conferindo…'; const r = await api(`/api/videos/${vid}/cenas/${b.dataset.conf}/conferir`, {method: 'POST'});
    toast(r.resultado.serve ? `Serve: ${r.resultado.na_imagem}` : `Não serve: ${r.resultado.na_imagem}`, !r.resultado.serve);
    S.video = await api('/api/videos/' + vid); stMidia(S.video);
  }));
};

// ---------------- Video Lab (editor de linha do tempo) ----------------
const FILTRO_CSS = {nenhum: '', pb: 'grayscale(1)', sepia: 'sepia(.85)', quente: 'sepia(.25) saturate(1.2)', frio: 'saturate(.9) hue-rotate(12deg) brightness(1.02)', contraste: 'contrast(1.25) saturate(1.1)', dramatico: 'contrast(1.2) saturate(.75) brightness(.95)'};
const FILTRO_NOME = {nenhum: 'Nenhum', pb: 'Preto e branco', sepia: 'Sépia', quente: 'Quente', frio: 'Frio', contraste: 'Contraste alto', dramatico: 'Dramático'};
function parseSrt(t) {
  const ts = x => { const m = x.match(/(\d+):(\d+):(\d+),(\d+)/); return m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000 : 0; };
  return (t || '').split(/\r?\n\r?\n/).map(b => { const l = b.trim().split(/\r?\n/); if (l.length < 3) return null; const [a, z] = l[1].split('-->'); return {i: ts(a), f: ts(z), t: l.slice(2).join(' ')}; }).filter(Boolean);
}
stEditor = async function (v) {
  if (!v.cenas.length) { step().innerHTML = '<div class="empty">Divida o roteiro em cenas primeiro.</div>'; return; }
  const ed = Object.assign({template: 'nenhum', filtro: 'nenhum', transicao: 'corte', legenda: {}, ctas: []}, v.editor || {});
  const leg = Object.assign({ativa: true, tamanho: 15, cor: '#FFFFFF', posicao: 'baixo', caixa: false}, ed.legenda || {});
  const total = v.cenas[v.cenas.length - 1].fim;
  const E = S.ed = Object.assign({sel: v.cenas[0].n, zoom: 22, aba: 'midia', t: 0}, S.ed && S.ed.vid === v.id ? S.ed : {}, {vid: v.id});
  const cues = parseSrt(v.srt);
  const selC = () => v.cenas.find(c => c.n === E.sel) || v.cenas[0];
  const srcCena = c => c.midia ? (c.midia.arquivo ? `/api/videos/${v.id}/midia/${c.n}?t=${encodeURIComponent(c.midia.arquivo)}` : (c.midia.preview || '').replace('/480px-', '/500px-')) : '';
  const W = Math.max(600, Math.round(total * E.zoom));
  const passo = total > 600 ? 60 : total > 180 ? 30 : 10;
  step().innerHTML = `<div class="vl"><div id="vl-dl"></div>
  <div class="card row" style="margin:0"><b class="sp">Video Lab · ${v.cenas.length} cenas · ${tempo(total)}</b>
    <label style="margin:0">Template <select id="vl-tpl" style="width:auto">${[['nenhum', 'Nenhum'], ['documentario', 'Documentário'], ['telejornal', 'Telejornal']].map(([k, n]) => `<option value="${k}" ${ed.template === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <label style="margin:0">Filtro <select id="vl-filtro" style="width:auto">${Object.entries(FILTRO_NOME).map(([k, n]) => `<option value="${k}" ${ed.filtro === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <label style="margin:0">Transição <select id="vl-trans" style="width:auto">${[['corte', 'Corte seco'], ['fade', 'Fade (escurece)'], ['flash', 'Flash branco']].map(([k, n]) => `<option value="${k}" ${ed.transicao === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <button id="vl-undo" ${(v.historico || []).length ? '' : 'disabled'}>↶ Desfazer</button><button id="vl-hist">Histórico</button>
    <button class="pri" id="vl-export">Exportar vídeo →</button></div>
  <div class="vl-main">
    <div class="card" style="margin:0"><div class="vl-tabs">${[['midia', 'Mídia'], ['texto', 'Texto'], ['legendas', 'Legendas'], ['audio', 'Áudio'], ['cta', 'CTA'], ['efeitos', 'Efeitos']].map(([k, n]) => `<button class="${E.aba === k ? 'pri' : ''}" data-aba="${k}">${n}</button>`).join('')}</div><div id="vl-aba"></div></div>
    <div class="card" style="margin:0"><div class="stage" id="vl-stage"></div>
      <div class="row" style="margin-top:8px"><button id="vl-prev">⏮</button><button class="pri" id="vl-play">▶ Tocar</button><button id="vl-next">⏭</button>
      <span id="vl-tempo" class="small">00:00 / ${tempo(total)}</span><span class="sp"></span><span class="small mut" id="vl-info"></span><button class="sm" id="vl-render1">Prévia renderizada desta cena</button></div>
      ${v.narracao ? `<audio id="vl-audio" src="/api/videos/${v.id}/voz/final" preload="auto"></audio>` : '<p class="small aviso">Sem narração: a prévia não toca som. Gere na etapa Narração.</p>'}</div>
    <div class="card" style="margin:0" id="vl-insp"></div>
  </div>
  <div class="card" style="margin:0;padding:8px"><div class="row small" style="margin-bottom:6px"><span class="mut">Clique para posicionar · arraste a borda direita de uma cena para mudar a duração · espaço = tocar/pausar · ← → = cena anterior/próxima</span><span class="sp"></span>
    <button class="sm" id="vl-zm">−</button><span class="small">${E.zoom} px/s</span><button class="sm" id="vl-zp">+</button></div>
  <div class="tl" id="vl-tl"><div class="tl-in" style="width:${W + 92}px">
    <div class="tl-ruler" style="margin-left:92px">${Array.from({length: Math.floor(total / passo) + 1}, (_, i) => `<i style="left:${i * passo * E.zoom}px">${tempo(i * passo)}</i>`).join('')}</div>
    <div class="tl-row"><div class="tl-lab">Legendas ${leg.ativa ? '' : '(off)'}</div><div style="position:absolute;left:92px;top:0;bottom:0;width:${W}px">${cues.map(q => `<div class="tl-blk l" style="left:${q.i * E.zoom}px;width:${Math.max(2, (q.f - q.i) * E.zoom - 1)}px" title="${esc(q.t)}">${esc(q.t)}</div>`).join('')}</div></div>
    <div class="tl-row"><div class="tl-lab">CTA</div><div style="position:absolute;left:92px;top:0;bottom:0;width:${W}px">${(ed.ctas || []).map(q => `<div class="tl-blk cta" style="left:${q.inicio * E.zoom}px;width:${Math.max(4, q.duracao * E.zoom)}px">${esc(q.texto || 'INSCREVA-SE')}</div>`).join('')}</div></div>
    <div class="tl-row cenas"><div class="tl-lab">Cenas ${v.cenas.length}</div><div id="vl-trk" style="position:absolute;left:92px;top:0;bottom:0;width:${W}px">${v.cenas.map((c, i) => `<div class="tl-blk c ${!c.midia ? 's' : c.midia.origem === 'ia' ? 'ia' : c.midia.tipo === 'video' ? 'v' : ''} ${c.n === E.sel ? 'sel' : ''}" data-tc="${c.n}" style="left:${c.inicio * E.zoom}px;width:${Math.max(3, (c.fim - c.inicio) * E.zoom - 1)}px"><b>${String(c.n).padStart(3, '0')}</b> ${esc(((c.midia || {}).arquivo || (c.midia || {}).fonte || 'sem mídia').split(/[\\/]/).pop())}${i < v.cenas.length - 1 ? `<span class="tl-h" data-th="${c.n}"></span>` : ''}</div>`).join('')}</div></div>
    <div class="tl-row narr"><div class="tl-lab">Narração</div><div style="position:absolute;left:92px;top:0;bottom:0;width:${v.narracao_duracao ? v.narracao_duracao * E.zoom : W}px">${v.narracao ? `<img src="/api/videos/${v.id}/onda.png" style="width:100%;height:100%;opacity:.9" onerror="this.remove()">` : ''}</div></div>
    <div class="tl-play" id="vl-ph" style="left:92px"></div>
  </div></div></div></div>`;

  const audio = $('#vl-audio');
  const stage = $('#vl-stage');
  let atual = null;
  function desenharStage(t) {
    const c = v.cenas.find(x => t >= x.inicio && t < x.fim) || (t >= total ? v.cenas[v.cenas.length - 1] : v.cenas[0]);
    const cue = leg.ativa ? cues.find(q => t >= q.i && t < q.f) : null;
    const cta = (ed.ctas || []).find(q => t >= q.inicio && t < q.inicio + q.duracao);
    if (c !== atual) {
      atual = c;
      const m = c.midia, src = srcCena(c), filtro = FILTRO_CSS[c.filtro || ed.filtro] || '';
      const midia = m ? (m.tipo === 'video' && m.arquivo ? `<video class="m" src="${src}" muted autoplay loop playsinline style="filter:${filtro}"></video>` : `<img class="m" src="${esc(src)}" style="filter:${filtro}">`) : '<div class="vazio">sem mídia</div>';
      const nome = c.nome_tela != null ? c.nome_tela : (ed.doc_nome_auto !== false ? (c.pessoa_real || '') : '');
      if (ed.template === 'documentario') stage.className = 'stage doc', stage.innerHTML = `<div class="doc-t">${esc((c.titulo_tela || ed.titulo_doc || '').toUpperCase())}</div><div class="box">${midia}</div>${nome ? `<div class="doc-n">${esc(nome.toUpperCase())}</div>` : ''}<div class="leg ${leg.posicao} ${leg.caixa ? 'caixa' : ''}" id="vl-leg"></div><div id="vl-cta"></div>`;
      else stage.className = 'stage', stage.innerHTML = midia + (ed.template === 'telejornal' ? `<div class="tj"><b>${esc((c.nome_tela || ed.rotulo || 'URGENTE').toUpperCase())}</b><span>${esc(c.titulo_tela || ed.manchete || v.titulo)}</span></div>` : '') + `<div class="leg ${leg.posicao} ${leg.caixa ? 'caixa' : ''}" id="vl-leg"></div><div id="vl-cta"></div>`;
      $('#vl-info').textContent = `cena ${String(c.n).padStart(3, '0')} · ${m ? (m.fonte || '') : 'sem mídia'}`;
      if (!E.tocando && E.sel !== c.n) { E.sel = c.n; }
      $$('[data-tc]').forEach(b => b.classList.toggle('sel', +b.dataset.tc === c.n));
    }
    const lg = $('#vl-leg'); if (lg) { lg.innerHTML = cue ? `<span>${esc(cue.t)}</span>` : ''; lg.style.color = leg.cor; lg.style.fontSize = (leg.tamanho / 15 * 1.5) + 'vw'; }
    const ct = $('#vl-cta'); if (ct) ct.innerHTML = cta ? `<div class="cta">${esc((cta.texto || 'INSCREVA-SE').toUpperCase())}</div>` : '';
    $('#vl-ph').style.left = (92 + t * E.zoom) + 'px';
    $('#vl-tempo').textContent = `${tempo(t)} / ${tempo(total)}`;
  }
  function ir(t, rolar = true) {
    E.t = Math.max(0, Math.min(total, t));
    if (audio) audio.currentTime = E.t;
    atual = null; desenharStage(E.t);
    const c = v.cenas.find(x => E.t >= x.inicio && E.t < x.fim); if (c) { E.sel = c.n; inspetor(); }
    if (rolar) { const tl = $('#vl-tl'); const x = 92 + E.t * E.zoom; if (x < tl.scrollLeft + 100 || x > tl.scrollLeft + tl.clientWidth - 100) tl.scrollLeft = x - tl.clientWidth / 3; }
  }
  if (audio) {
    audio.ontimeupdate = () => { E.t = audio.currentTime; desenharStage(E.t); };
    audio.onended = () => { E.tocando = false; $('#vl-play').textContent = '▶ Tocar'; };
  }
  $('#vl-play').onclick = () => { if (!audio) return toast('Sem narração para tocar', true); if (audio.paused) { audio.currentTime = E.t; audio.play(); E.tocando = true; $('#vl-play').textContent = '⏸ Pausar'; } else { audio.pause(); E.tocando = false; $('#vl-play').textContent = '▶ Tocar'; inspetor(); } };
  const pular = d => { const i = v.cenas.findIndex(c => c.n === E.sel); const c = v.cenas[Math.max(0, Math.min(v.cenas.length - 1, i + d))]; ir(c.inicio + 0.01); };
  $('#vl-prev').onclick = () => pular(-1); $('#vl-next').onclick = () => pular(1);
  document.onkeydown = e => { if (S.view !== 'video' || S.step !== 'editor' || ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return; if (e.code === 'Space') { e.preventDefault(); $('#vl-play')?.click(); } if (e.code === 'ArrowLeft') pular(-1); if (e.code === 'ArrowRight') pular(1); };
  $('#vl-tl').onclick = e => { if (e.target.closest('[data-th]')) return; const r = $('#vl-tl .tl-in').getBoundingClientRect(); const x = e.clientX - r.left - 92; if (x >= 0) ir(x / E.zoom, false); };
  $('#vl-zm').onclick = () => { E.zoom = Math.max(4, Math.round(E.zoom / 1.5)); stEditor(v); };
  $('#vl-zp').onclick = () => { E.zoom = Math.min(120, Math.round(E.zoom * 1.5)); stEditor(v); };
  // arrastar a borda da cena
  $$('[data-th]').forEach(h => h.onmousedown = e => {
    e.preventDefault(); e.stopPropagation();
    const n = +h.dataset.th, blk = h.parentElement, x0 = e.clientX, w0 = blk.offsetWidth, c = v.cenas.find(x => x.n === n);
    const mv = ev => { blk.style.width = Math.max(10, w0 + ev.clientX - x0) + 'px'; };
    const up = ev => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up);
      const dur = (c.fim - c.inicio) + (ev.clientX - x0) / E.zoom;
      safe(async () => { S.video = await api(`/api/videos/${v.id}/cenas/${n}/editor`, {method: 'PATCH', json: {duracao: Math.round(dur * 10) / 10}}); stEditor(S.video); }); };
    document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
  });
  const salvarEd = async json => { S.video = await api(`/api/videos/${v.id}/editor`, {method: 'PATCH', json}); return S.video; };
  $('#vl-tpl').onchange = e => safe(async () => stEditor(await salvarEd({template: e.target.value})));
  $('#vl-filtro').onchange = e => safe(async () => stEditor(await salvarEd({filtro: e.target.value})));
  $('#vl-trans').onchange = e => safe(async () => stEditor(await salvarEd({transicao: e.target.value})));
  $('#vl-undo').onclick = () => safe(async () => { S.video = await api(`/api/videos/${v.id}/editor/desfazer`, {method: 'POST'}); toast('Desfeito'); stEditor(S.video); });
  $('#vl-hist').onclick = () => safe(async () => {
    const h = await api(`/api/videos/${v.id}/editor/historico`);
    modal(`<h3>Histórico</h3>${h.length ? h.slice().reverse().map(x => `<div class="row" style="border-bottom:1px solid var(--line);padding:6px 0"><span class="small mut">${x.quando}</span><span class="sp small">antes de: ${esc(x.acao)}</span><button class="sm" data-rest="${x.i}">Voltar para cá</button></div>`).join('') : '<p class="mut">Sem alterações ainda.</p>'}<div class="row end" style="margin-top:10px"><button onclick="fecharModal()">Fechar</button></div>`);
    $$('[data-rest]').forEach(b => b.onclick = () => safe(async () => { S.video = await api(`/api/videos/${v.id}/editor/restaurar`, {json: {i: +b.dataset.rest}}); fecharModal(); toast('Versão restaurada'); stEditor(S.video); }));
  });
  $('#vl-export').onclick = () => safe(async () => { await api('/api/videos/' + v.id, {method: 'PATCH', json: {etapas: {editor: true}}}); if (audio) audio.pause(); proxima('editor'); });
  $('#vl-render1').onclick = () => safe(async () => {
    const b = $('#vl-render1'); b.textContent = 'renderizando…';
    try { const r = await api(`/api/videos/${v.id}/cenas/${E.sel}/previa`, {method: 'POST'});
      modal(`<h3>Prévia renderizada da cena ${E.sel}</h3><video controls autoplay src="${r.url}?t=${Date.now()}"></video><p class="small mut">É exatamente como vai sair no MP4 (template, filtro, movimento, transição).</p><div class="row end"><button onclick="fecharModal()">Fechar</button></div>`);
    } finally { b.textContent = 'Prévia renderizada desta cena'; }
  });
  $$('[data-tc]').forEach(b => b.onclick = e => { if (e.target.closest('[data-th]')) return; e.stopPropagation(); const c = v.cenas.find(x => x.n === +b.dataset.tc); ir(c.inicio + 0.01, false); });

  function inspetor() {
    const c = selC(), m = c.midia;
    $('#vl-insp').innerHTML = `<h3>CENA ${String(c.n).padStart(3, '0')}</h3>
    <table class="small"><tr><td class="mut">Início</td><td>${tempo(c.inicio)} (${c.inicio.toFixed(2)} s)</td></tr><tr><td class="mut">Fim</td><td>${tempo(c.fim)} (${c.fim.toFixed(2)} s)</td></tr></table>
    <div class="f" style="margin-top:6px"><label>Duração (s)</label><input type="number" step="0.1" id="in-dur" value="${(c.fim - c.inicio).toFixed(1)}" ${c.n === v.cenas[v.cenas.length - 1].n ? 'disabled' : ''}></div>
    <div class="small"><b>${m ? (m.tipo === 'video' ? 'VÍDEO' : 'IMAGEM') : 'SEM MÍDIA'}</b><br><span class="mut">${m ? esc(((m.arquivo || m.titulo || '') + '').split(/[\\/]/).pop()) + ' · ' + esc(m.fonte || '') : ''}</span>${m?.na_imagem ? `<br><span class="mut">na imagem: ${esc(m.na_imagem)}</span>` : ''}</div>
    <div class="row" style="margin:8px 0;flex-direction:column;align-items:stretch">
      <button class="pri" id="in-trocar">Trocar imagem</button>
      <label class="btn" style="margin:0;color:var(--txt);justify-content:center">Escolher do computador<input type="file" id="in-arq" accept="image/*,video/*" hidden></label>
      <button id="in-ia">Gerar com IA</button><button id="in-vazia">Deixar sem mídia</button></div>
    <div class="f"><label>Movimento</label><select id="in-mov" ${m && m.tipo === 'video' ? 'disabled' : ''}>${Object.entries({auto: 'Automático', zoom_in: 'Zoom in', zoom_out: 'Zoom out', pan_dir: 'Pan →', pan_esq: '← Pan', parado: 'Parado'}).map(([k, n]) => `<option value="${k}" ${(c.movimento || 'auto') === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    <div class="f"><label>Filtro desta cena</label><select id="in-filtro"><option value="">Igual ao vídeo</option>${Object.entries(FILTRO_NOME).map(([k, n]) => `<option value="${k}" ${c.filtro === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    ${ed.template !== 'nenhum' ? `<div class="f"><label>${ed.template === 'telejornal' ? 'Manchete desta cena' : 'Título no topo'}</label><input id="in-tit" value="${esc(c.titulo_tela || '')}" placeholder="${ed.template === 'telejornal' ? esc(ed.manchete || v.titulo) : esc(ed.titulo_doc || '')}"></div>
    <div class="f"><label>${ed.template === 'telejornal' ? 'Selo (ex.: URGENTE)' : 'Nome na etiqueta'}</label><input id="in-nome" value="${esc(c.nome_tela ?? '')}" placeholder="${esc(ed.template === 'telejornal' ? (ed.rotulo || 'URGENTE') : (c.pessoa_real || ''))}"></div>` : ''}
    <p class="small mut">${esc(c.texto)}</p>`;
    const patch = json => safe(async () => { S.video = await api(`/api/videos/${v.id}/cenas/${c.n}/editor`, {method: 'PATCH', json}); stEditor(S.video); });
    $('#in-dur').onchange = e => patch({duracao: Number(e.target.value)});
    $('#in-mov').onchange = e => patch({movimento: e.target.value});
    $('#in-filtro').onchange = e => patch({filtro: e.target.value});
    if ($('#in-tit')) { $('#in-tit').onchange = e => patch({titulo_tela: e.target.value}); $('#in-nome').onchange = e => patch({nome_tela: e.target.value}); }
    $('#in-vazia').onclick = () => confirm('Deixar esta cena sem mídia (fundo escuro)?') && patch({sem_midia: true});
    $('#in-arq').onchange = () => safe(async () => { const fd = new FormData(); fd.append('arquivo', $('#in-arq').files[0]); toast('Enviando…'); await api(`/api/videos/${v.id}/cenas/${c.n}/arquivo`, {method: 'POST', body: fd}); S.video = await api('/api/videos/' + v.id); stEditor(S.video); });
    $('#in-ia').onclick = () => safe(async () => { await api(`/api/videos/${v.id}/lote`, {json: {acao: 'gerar_ia', ns: [c.n]}}); toast('Gerando por IA… (acompanhe na etapa Mídia)'); });
    $('#in-trocar').onclick = () => {
      const cands = c.candidatos || [];
      modal(`<h3>Trocar imagem — cena ${c.n}</h3><p class="small mut">${esc(c.texto)}</p>
      <div class="row"><input id="tr-q" placeholder="buscar com outros termos (inglês funciona melhor)" style="flex:1" value="${esc((c.termos_busca || [])[0] || '')}"><button id="tr-go">Buscar</button></div>
      <div class="cands" id="tr-c" style="max-height:55vh;overflow:auto">${cands.map((x, i) => `<div class="cand" data-tp="${i}"><img src="${esc((x.preview || '').replace('/480px-', '/500px-'))}" loading="lazy"><div>${x.tipo === 'video' ? '▶ ' : ''}${esc(x.fonte)} · ${x.nota}/10</div></div>`).join('') || '<span class="mut small">Sem candidatos.</span>'}</div>
      <div class="row end" style="margin-top:10px"><button onclick="fecharModal()">Fechar</button></div>`);
      const ligar = () => $$('[data-tp]').forEach(d => d.onclick = () => safe(async () => { await api(`/api/videos/${v.id}/cenas/${c.n}/escolher`, {json: {indice: +d.dataset.tp}}); fecharModal(); S.video = await api('/api/videos/' + v.id); stEditor(S.video); }));
      ligar();
      $('#tr-go').onclick = () => safe(async () => { $('#tr-c').innerHTML = '<span class="mut small">buscando…</span>'; const r = await api(`/api/videos/${v.id}/cenas/${c.n}/buscar`, {json: {termos: $('#tr-q').value.split(';')}}); c.candidatos = r.cena.candidatos;
        $('#tr-c').innerHTML = c.candidatos.map((x, i) => `<div class="cand" data-tp="${i}"><img src="${esc((x.preview || '').replace('/480px-', '/500px-'))}" loading="lazy"><div>${x.tipo === 'video' ? '▶ ' : ''}${esc(x.fonte)} · ${x.nota}/10</div></div>`).join('') || '<span class="mut small">Nada encontrado.</span>'; ligar(); });
    };
  }

  function aba() {
    const el = $('#vl-aba');
    $$('[data-aba]').forEach(b => b.classList.toggle('pri', b.dataset.aba === E.aba));
    if (E.aba === 'midia') {
      el.innerHTML = `<div class="small mut" style="margin-bottom:6px">${v.cenas.filter(c => c.midia).length} mídias · ${v.cenas.length} cenas</div>
      <div class="mini-grid">${v.cenas.map(c => { const s2 = srcCena(c); return `<div data-mg="${c.n}" class="${c.n === E.sel ? 'sel' : ''}">${c.midia ? (c.midia.tipo === 'video' && c.midia.arquivo ? `<video src="${s2}#t=1" muted preload="metadata"></video>` : `<img src="${esc(s2)}" loading="lazy">`) : ''}<span>${c.n}</span></div>`; }).join('')}</div>
      <label class="btn sm" style="margin-top:8px;color:var(--txt)">Importar lote (001.png…)<input type="file" id="mg-lote" multiple accept="image/*,video/*" hidden></label>`;
      $$('[data-mg]').forEach(d => d.onclick = () => { const c = v.cenas.find(x => x.n === +d.dataset.mg); ir(c.inicio + 0.01); });
      $('#mg-lote').onchange = () => safe(async () => { const fd = new FormData(); [...$('#mg-lote').files].forEach(f => fd.append('arquivos', f)); const r = await api(`/api/videos/${v.id}/importar_lote`, {method: 'POST', body: fd}); toast(`${r.importados} importado(s)`); S.video = await api('/api/videos/' + v.id); stEditor(S.video); });
    } else if (E.aba === 'texto') {
      el.innerHTML = ed.template === 'documentario' ? `<div class="f"><label>Título no topo (todas as cenas)</label><input id="tx-tit" value="${esc(ed.titulo_doc || '')}" placeholder="THE UNBROKEN STREAK"></div>
        <label style="color:var(--txt)"><input type="checkbox" id="tx-auto" ${ed.doc_nome_auto !== false ? 'checked' : ''}> Etiqueta com o nome da pessoa real da cena</label>`
        : ed.template === 'telejornal' ? `<div class="f"><label>Manchete padrão</label><input id="tx-man" value="${esc(ed.manchete || '')}" placeholder="${esc(v.titulo)}"></div><div class="f"><label>Selo</label><input id="tx-rot" value="${esc(ed.rotulo || '')}" placeholder="URGENTE"></div>`
        : '<p class="small mut">Escolha o template Documentário ou Telejornal para ter textos na tela. Títulos por cena ficam no painel da direita.</p>';
      const sv = j => safe(async () => stEditor(await salvarEd(j)));
      if ($('#tx-tit')) { $('#tx-tit').onchange = e => sv({titulo_doc: e.target.value}); $('#tx-auto').onchange = e => sv({doc_nome_auto: e.target.checked}); }
      if ($('#tx-man')) { $('#tx-man').onchange = e => sv({manchete: e.target.value}); $('#tx-rot').onchange = e => sv({rotulo: e.target.value}); }
    } else if (E.aba === 'legendas') {
      el.innerHTML = `<label style="color:var(--txt)"><input type="checkbox" id="lg-on" ${leg.ativa ? 'checked' : ''}> Legenda gravada no vídeo</label>
      <div class="f"><label>Tamanho: <b id="lg-tv">${leg.tamanho}</b></label><input type="range" id="lg-t" min="10" max="30" value="${leg.tamanho}"></div>
      <div class="f"><label>Cor</label><input type="color" id="lg-c" value="${leg.cor}" style="height:36px"></div>
      <div class="f"><label>Posição</label><select id="lg-p">${[['baixo', 'Embaixo'], ['meio', 'No meio'], ['topo', 'Em cima']].map(([k, n]) => `<option value="${k}" ${leg.posicao === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
      <div class="f"><label>Estilo</label><select id="lg-e">${[['', 'Clássica (contorno)'], ['jornal', 'Jornal (faixa amarela)'], ['vermelha', 'Urgente (faixa vermelha)'], ['destaque', 'Destaque (palavra-chave amarela)'], ['karaoke', 'Karaokê (palavra acende)'], ['pilula', 'Pílula (caixa arredondada)'], ['caixa', 'Caixa preta'], ['neon', 'Neon (brilho)'], ['cinema', 'Cinema (fina, sombra)'], ['maquina', 'Máquina de escrever']].map(([k, n]) => `<option value="${k}" ${(leg.estilo || '') === k ? 'selected' : ''}>${n}</option>`).join('')}</select>
        <img id="lg-prev" src="/api/legenda/previa/${leg.estilo || 'classica'}?perfil=${esc(ed.estilo_edicao || 'padrao')}" style="width:100%;border-radius:8px;margin-top:6px"></div>
      <label style="color:var(--txt)"><input type="checkbox" id="lg-b" ${leg.caixa ? 'checked' : ''}> Caixa escura atrás do texto</label>
      <p class="small mut" style="margin-top:8px"><a href="/api/videos/${v.id}/arquivo/legendas.srt?baixar=1">Baixar SRT</a></p>`;
      const sv = () => safe(async () => stEditor(await salvarEd({legenda: {ativa: $('#lg-on').checked, tamanho: +$('#lg-t').value, cor: $('#lg-c').value, posicao: $('#lg-p').value, caixa: $('#lg-b').checked, estilo: $('#lg-e').value}})));
      $('#lg-t').oninput = e => $('#lg-tv').textContent = e.target.value;
      ['#lg-on', '#lg-t', '#lg-c', '#lg-p', '#lg-b', '#lg-e'].forEach(k => $(k).onchange = sv);
    } else if (E.aba === 'audio') {
      el.innerHTML = `<p class="small">${v.narracao ? `Narração: <b>${tempo(v.narracao_duracao || 0)}</b> (${v.narracao_origem === 'vozlab' ? 'VozLab' : 'enviada'})` : '<span class="aviso">Sem narração</span>'}</p>
      <div class="f"><label>Trilha de fundo ${v.musica ? '<span class="pill ok">✓</span>' : ''}</label><input type="file" id="au-m" accept="audio/*"></div>
      <div class="f"><label>Volume da trilha: <b id="au-vv">${Math.round((v.musica_volume || .12) * 100)}%</b></label><input type="range" id="au-v" min="0" max="0.5" step="0.01" value="${v.musica_volume || .12}"></div>
      <label style="color:var(--txt)"><input type="checkbox" id="au-cl" ${ed.audio_dos_clipes ? 'checked' : ''}> Usar o som dos clipes (personagem fala / voz do Flow)</label>`;
      $('#au-m').onchange = () => safe(async () => { const fd = new FormData(); fd.append('arquivo', $('#au-m').files[0]); await api(`/api/videos/${v.id}/musica`, {method: 'POST', body: fd}); toast('Trilha enviada'); S.video = await api('/api/videos/' + v.id); stEditor(S.video); });
      $('#au-v').oninput = e => $('#au-vv').textContent = Math.round(e.target.value * 100) + '%';
      $('#au-v').onchange = e => api('/api/videos/' + v.id, {method: 'PATCH', json: {musica_volume: Number(e.target.value)}});
      $('#au-cl').onchange = e => safe(async () => stEditor(await salvarEd({audio_dos_clipes: e.target.checked})));
    } else if (E.aba === 'cta') {
      const ctas = ed.ctas || [];
      el.innerHTML = `<p class="small mut">Botão de chamada (ex.: INSCREVA-SE) que aparece no canto em momentos do vídeo.</p>
      ${ctas.map((q, i) => `<div class="kcard small"><div class="row"><b class="sp">${esc(q.texto || 'INSCREVA-SE')}</b><button class="sm danger" data-cdel="${i}">×</button></div>${tempo(q.inicio)} por ${q.duracao}s</div>`).join('')}
      <div class="f"><label>Texto</label><input id="ct-t" value="INSCREVA-SE"></div><div class="grid g2"><div class="f"><label>Início (s)</label><input id="ct-i" type="number" value="${Math.round(E.t)}"></div><div class="f"><label>Duração (s)</label><input id="ct-d" type="number" value="5"></div></div>
      <button class="sm pri" id="ct-add">+ Adicionar CTA no tempo atual</button>`;
      $$('[data-cdel]').forEach(b => b.onclick = () => safe(async () => { const n2 = ctas.slice(); n2.splice(+b.dataset.cdel, 1); stEditor(await salvarEd({ctas: n2})); }));
      $('#ct-add').onclick = () => safe(async () => stEditor(await salvarEd({ctas: [...ctas, {texto: $('#ct-t').value, inicio: Number($('#ct-i').value), duracao: Number($('#ct-d').value)}]})));
    } else if (E.aba === 'efeitos') {
      const s = S.settings;
      el.innerHTML = `<label style="color:var(--txt)"><input type="checkbox" id="ef-g" ${s.grao ? 'checked' : ''}> Cor uniforme + grão + vinheta</label><br>
      <label style="color:var(--txt)"><input type="checkbox" id="ef-z" ${s.zoom_suave ? 'checked' : ''}> Movimento (zoom/pan) nas fotos</label>
      <div class="f" style="margin-top:8px"><label>Formato</label><select id="ef-r">${[['1920x1080', '16:9 (1920×1080)'], ['1080x1920', '9:16 Shorts'], ['1280x720', '16:9 (1280×720) rápido']].map(([k, n]) => `<option value="${k}" ${s.resolucao === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
      <p class="small mut">Foto em pé entra inteira, no centro, sobre ela mesma desfocada.</p>`;
      const sv = () => safe(async () => { S.settings = await api('/api/settings', {json: {grao: $('#ef-g').checked, zoom_suave: $('#ef-z').checked, resolucao: $('#ef-r').value}}); toast('Efeitos salvos'); });
      ['#ef-g', '#ef-z', '#ef-r'].forEach(k => $(k).onchange = sv);
    }
  }
  $$('[data-aba]').forEach(b => b.onclick = () => { E.aba = b.dataset.aba; aba(); });
  aba(); inspetor();
  // baixa as mídias para o computador (o editor e a montagem usam os arquivos locais)
  (async function acompanharDL(iniciado) {
    if (S.view !== 'video' || S.step !== 'editor' || S.video?.id !== v.id) return;
    S.dl = S.dl || {};
    const el = $('#vl-dl'); if (!el) return;
    let st = await api(`/api/videos/${v.id}/baixar_midias`);
    if (!st.rodando && st.faltam > 0 && !iniciado && !S.dl[v.id]) { S.dl[v.id] = 'iniciado'; await api(`/api/videos/${v.id}/baixar_midias`, {method: 'POST'}); return setTimeout(() => acompanharDL(true), 800); }
    if (!st.rodando && !iniciado) { if (typeof S.dl[v.id] === 'string' && S.dl[v.id] !== 'iniciado') el.innerHTML = S.dl[v.id]; return; }
    if (st.rodando) {
      el.innerHTML = `<div class="hint" style="margin:0">Baixando as mídias para o seu computador (${st.feito || 0}/${st.total || '?'}) — as imagens vão aparecendo. ${esc(st.etapa || '')}<div class="prog" style="margin-top:6px"><div style="width:${st.total ? Math.round(st.feito / st.total * 100) : 0}%"></div></div></div>`;
      return setTimeout(() => acompanharDL(true), 2000);
    }
    if (iniciado) {
      S.dl[v.id] = st.falhas?.length ? `<div class="hint" style="margin:0">Mídias baixadas. ${st.falhas.length} não baixaram (cenas ${st.falhas.slice(0, 15).join(', ')}) — use "Trocar imagem" nelas.</div>` : 'ok';
      S.video = await api('/api/videos/' + v.id); stEditor(S.video);
    }
  })(false);
  const c0 = selC(); ir(Math.max(c0.inicio + 0.01, Math.min(E.t, c0.fim - 0.01)) || 0.01);
};

// ---------------- Janela de app: links de fora abrem no seu navegador normal (onde você já está logado) ----------------
(function () {
  const externo = u => /^https?:\/\//.test(u || '') && !u.startsWith(location.origin);
  const abrir = u => fetch('/api/abrir_externo', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({url: u})});
  const _open = window.open.bind(window);
  window.open = (u, ...r) => externo(u) ? (abrir(u), null) : _open(u, ...r);
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href]');
    if (a && externo(a.href)) { e.preventDefault(); abrir(a.href); }
  }, true);
})();
