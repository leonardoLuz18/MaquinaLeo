// Fábrica Dark v5 — Oficina do roteiro, Sugestão do dia, Kanban e controle pelo celular
(function () {
  window.EXTRA_VIEWS = window.EXTRA_VIEWS || {};
  const corNota = n => n >= 80 ? 'var(--ok)' : n >= 60 ? 'var(--warn)' : 'var(--bad)';
  const anel = (n, nome) => `<div class="of-anel" style="--p:${n || 0};--c:${corNota(n || 0)}"><div><b>${n ?? '–'}</b></div><small>${esc(nome)}</small></div>`;

  // ---------------------------------------------------------------- oficina do roteiro
  window.oficinaRoteiro = async function (v, box) {
    if (!box) return;
    let st;
    try { st = await api(`/api/videos/${v.id}/oficina`); } catch (e) { box.innerHTML = ''; return; }
    const desenhar = () => {
      const a = st.avaliacao, j = st.job || {};
      box.innerHTML = `<div class="card of-card">
        <div class="row"><h3 style="margin:0" class="sp">✨ Oficina do roteiro</h3>
          ${st.versoes.length ? `<button class="sm" id="of-undo" title="${esc(st.versoes[st.versoes.length - 1].motivo)}">↶ Desfazer</button>` : ''}
          <button id="of-aval">${a ? 'Avaliar de novo' : 'Dar nota'}</button>
          <button class="pri" id="of-melh" ${j.rodando ? 'disabled' : ''}>${j.rodando ? 'Melhorando…' : '✨ Melhorar'}</button></div>
        ${j.rodando || j.erro ? `<p class="small ${j.erro ? 'bad' : 'mut'}">${esc(j.erro || j.etapa || '')}</p>` : ''}
        ${st.tem_narracao || st.tem_cenas ? '<p class="small mut">Atenção: se o texto mudar, as cenas e a narração deste vídeo são refeitas (o seu áudio enviado fica).</p>' : ''}
        <div class="of-notas">${a ? `<div class="of-geral" style="color:${corNota(a.geral)}">${a.geral}<small>nota geral</small></div>` : ''}
          ${st.criterios.map(c => anel(a ? a.notas[c.id] : null, c.nome)).join('')}</div>
        ${a ? `<p class="small">${esc(a.resumo || '')}</p>
          <div class="of-coments">${st.criterios.map(c => `<div><b style="color:${corNota(a.notas[c.id])}">${esc(c.nome)}</b> <span class="small mut">${esc((a.comentarios || {})[c.id] || '')}</span></div>`).join('')}</div>
          ${(a.problemas || []).length ? `<details open><summary class="small"><b>${a.problemas.length} trecho(s) para corrigir</b></summary>${a.problemas.map(p => `<div class="of-prob"><q>${esc(p.trecho)}</q><div class="small"><span class="pill">${esc(p.criterio || '')}</span> ${esc(p.problema)}</div><div class="small mut">→ ${esc(p.sugestao)}</div></div>`).join('')}</details>` : ''}` :
          `<p class="small mut">Nota de 0 a 100 em: ${st.criterios.map(c => `<b>${esc(c.nome)}</b> (${esc(c.desc)})`).join('; ')}.</p>`}
        <div class="f" style="margin-top:8px"><input id="of-pedido" placeholder="(opcional) o que priorizar no Melhorar — ex.: abertura mais forte, menos repetição"></div>
        <h3 style="margin-top:14px">Conversar com o roteirista</h3>
        <div class="of-chat" id="of-chat">${st.chat.length ? st.chat.map(m => `<div class="of-msg ${m.de === 'eu' ? 'eu' : 'ia'}">${esc(m.texto)}${(m.alteracoes || []).length ? `<details class="small"><summary>ver mudanças</summary>${m.alteracoes.map(x => `<div class="of-diff"><s>${esc(x.antes)}</s><ins>${esc(x.depois)}</ins></div>`).join('')}</details>` : ''}</div>`).join('') : '<p class="small mut">Peça mudanças em linguagem normal: "deixa a abertura mais misteriosa", "corta a parte repetida do meio", "o final está fraco".</p>'}</div>
        <div class="row" style="margin-top:8px"><input id="of-msg" class="sp" placeholder="Escreva para o roteirista…"><button class="pri" id="of-env">Enviar</button></div>
      </div>`;
      const atualizarTexto = () => { const t = $('#r-txt'); if (t) { t.value = st.roteiro; t.dispatchEvent(new Event('input')); } };
      const confirma = () => !(st.tem_narracao || st.tem_cenas) || confirm('O texto vai mudar e as cenas/narração deste vídeo serão refeitas. Continuar?');
      $('#of-aval').onclick = () => safe(async () => {
        const t = $('#r-txt'); if (t && t.value.trim() !== st.roteiro.trim()) st = await api(`/api/videos/${v.id}/oficina/salvar`, {json: {texto: t.value}});
        $('#of-aval').disabled = true; $('#of-aval').textContent = 'Avaliando…';
        try { st = await api(`/api/videos/${v.id}/oficina/avaliar`, {json: {}}); } finally { desenhar(); }
      });
      $('#of-melh').onclick = () => safe(async () => {
        if (!confirma()) return;
        st = await api(`/api/videos/${v.id}/oficina/melhorar`, {json: {pedido: $('#of-pedido').value}});
        st.job = {rodando: true, etapa: 'Começando'}; desenhar(); acompanhar();
      });
      $('#of-undo') && ($('#of-undo').onclick = () => safe(async () => { st = await api(`/api/videos/${v.id}/oficina/desfazer`, {json: {}}); atualizarTexto(); desenhar(); toast('Voltei para a versão anterior'); }));
      const enviar = () => safe(async () => {
        const m = $('#of-msg').value.trim(); if (!m) return;
        if (!confirma()) return;
        $('#of-env').disabled = true; $('#of-chat').insertAdjacentHTML('beforeend', `<div class="of-msg eu">${esc(m)}</div><div class="of-msg ia mut">escrevendo…</div>`);
        try { st = await api(`/api/videos/${v.id}/oficina/chat`, {json: {mensagem: m}}); atualizarTexto(); } finally { desenhar(); const c = $('#of-chat'); c.scrollTop = c.scrollHeight; }
      });
      $('#of-env').onclick = enviar;
      $('#of-msg').onkeydown = e => { if (e.key === 'Enter') enviar(); };
      const c = $('#of-chat'); c.scrollTop = c.scrollHeight;
    };
    const acompanhar = async () => {
      if (!document.body.contains(box)) return;
      st = await api(`/api/videos/${v.id}/oficina`);
      if (st.job.rodando) { const e = $('.of-card p.small'); if (e) e.textContent = st.job.etapa; setTimeout(acompanhar, 2000); return; }
      desenhar(); const t = $('#r-txt'); if (t) { t.value = st.roteiro; t.dispatchEvent(new Event('input')); }
      if (!st.job.erro) toast('Roteiro melhorado — clique em "Avaliar de novo" para ver as notas novas');
    };
    desenhar();
    if (st.job.rodando) acompanhar();
  };

  // ---------------------------------------------------------------- sugestão do dia (DNA Editorial + Diagnóstico YouTube + Verificação de Temas Já Feitos)
  EXTRA_VIEWS.pauta = async function () {
    if (!S.channels.length) { main.innerHTML = '<h1>Sugestão do dia</h1><div class="empty">Cadastre um canal primeiro.</div>'; return; }
    S.pautaCanal = S.pautaCanal || S.channels[0].id;
    if (S.pautaOcultarConcluidos === undefined) S.pautaOcultarConcluidos = false;
    const ch = S.channels.find(c => c.id === S.pautaCanal) || S.channels[0];
    main.innerHTML = `<div class="row" style="gap:10px;flex-wrap:wrap;margin-bottom:10px">
      <div class="sp">
        <h1>☀️ Sugestões do Dia & Diagnóstico de Otimização do Canal</h1>
        <p class="sub">Verificação automática do que já foi produzido/publicado no canal, alertas específicos do que fazer para crescer mais rápido e vinculação direta com suas contas do YouTube.</p>
      </div>
      <select id="pa-canal" style="min-width:230px;font-weight:700">${chOptions(ch.id)}</select>
      <button class="pri" id="pa-novo">↻ Gerar Novas Sugestões Inéditas</button>
    </div>
    <div id="pa-box"><div class="empty"><span class="spin"></span> Analisando histórico do canal, vídeos feitos e sugestões do dia…</div></div>`;
    $('#pa-canal').onchange = () => { S.pautaCanal = $('#pa-canal').value; go('pauta'); };
    let timer = null;
    const addKb = (t, tr, extra = {}) => safe(async () => {
      await api('/api/kanban', {json: Object.assign({titulo: t, traducao: tr || '', channel_id: ch.id}, extra)});
      toast('✓ Mandado para o Kanban!');
    });
    const gerar = t => { S.estCanal = ch.id; S.estTitulo = t; go('estudio'); };
    const _CHAVE_LS_TEMAS_FEITOS = 'fd_temas_feitos_v2';
    const _normTitTema = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
    const _lerTemasFeitosLocal = cid => {
      try {
        const obj = JSON.parse(localStorage.getItem(_CHAVE_LS_TEMAS_FEITOS) || '{}') || {};
        const cur = obj[cid] || {};
        return {
          feitos: Array.isArray(cur.feitos) ? cur.feitos : [],
          ocultos: Array.isArray(cur.ocultos) ? cur.ocultos : [],
        };
      } catch (_e) {
        return {feitos: [], ocultos: []};
      }
    };
    const _gravarTemaLocal = (cid, titulo, acaoApi) => {
      try {
        const tN = _normTitTema(titulo);
        if (!cid || !tN) return;
        const obj = JSON.parse(localStorage.getItem(_CHAVE_LS_TEMAS_FEITOS) || '{}') || {};
        const cur = obj[cid] || {feitos: [], ocultos: []};
        const feitos = (Array.isArray(cur.feitos) ? cur.feitos : []).filter(x => _normTitTema(x) !== tN);
        const ocultos = (Array.isArray(cur.ocultos) ? cur.ocultos : []).filter(x => _normTitTema(x) !== tN);
        if (acaoApi === 'concluir') feitos.push(titulo);
        else if (acaoApi === 'ocultar') ocultos.push(titulo);
        obj[cid] = {feitos, ocultos};
        localStorage.setItem(_CHAVE_LS_TEMAS_FEITOS, JSON.stringify(obj));
        const chRef = (S.channels || []).find(c => c.id === cid);
        if (chRef) {
          chRef.temas_concluidos_manual = feitos.slice();
          chRef.temas_ocultos_manual = ocultos.slice();
        }
      } catch (_e) {}
    };

    const marcarTema = (titulo, acao) => safe(async () => {
      const cidAtual = ($('#pa-canal')?.value || (ch && ch.id) || S.pautaCanal || (S.channels[0] || {}).id || '').trim();
      const titLimpo = String(titulo || '').trim();
      if (!cidAtual || !titLimpo) {
        toast('Selecione o canal e o título do tema.', true);
        return;
      }
      const acaoApi = acao === 'desmarcar' ? 'reabrir' : (acao || 'concluir');
      _gravarTemaLocal(cidAtual, titLimpo, acaoApi);
      await api('/api/pauta/marcar-tema', {
        json: {
          canal: cidAtual,
          canal_id: cidAtual,
          channel_id: cidAtual,
          titulo: titLimpo,
          acao: acaoApi
        }
      });
      const msgMap = {
        concluir: '✅ Tema marcado permanentemente como Já Feito!',
        ocultar: '🗑️ Tema removido da lista!',
        desmarcar: '↩️ Tema restaurado como Pendente!',
        reabrir: '↩️ Tema restaurado como Pendente!',
      };
      toast(msgMap[acao] || 'Atualizado!');
      await carregar(false);
    });

    const carregar = async novo => {
      const r = await api(`/api/pauta?canal=${ch.id}${novo ? '&novo=1' : ''}`);
      const p = r.pauta;
      const pf = (p && p.perfil_editorial) || r.perfil_editorial || {};
      const diag = r.diagnostico_canal || (p && p.diagnostico_canal) || {};
      const alertas = diag.alertas_otimizacao || [];
      const topVidsYt = diag.top_videos_canal || [];
      const memLocal = _lerTemasFeitosLocal(ch.id);
      const setFeitosLoc = new Set(memLocal.feitos.map(_normTitTema).filter(Boolean));
      const setOcultosLoc = new Set(memLocal.ocultos.map(_normTitTema).filter(Boolean));
      const rawPrioridades = (pf.temas_prioritarios_aprovados || []).map(pr => {
        const k = _normTitTema(pr.titulo || '');
        const copia = Object.assign({}, pr);
        if (k && setOcultosLoc.has(k)) copia.oculto = true;
        if (k && setFeitosLoc.has(k) && !copia.ja_feito) {
          copia.ja_feito = true;
          copia.motivo_ja_feito = copia.motivo_ja_feito || 'Marcado manualmente como Já Feito';
        } else if (copia.ja_feito && String(copia.motivo_ja_feito || '').toLowerCase().includes('manual') && k && !setFeitosLoc.has(k)) {
          _gravarTemaLocal(ch.id, copia.titulo, 'concluir');
        }
        return copia;
      });
      // Garante sincronia imediata caso algum tema tenha sido marcado apenas no localStorage antes de reiniciar o servidor
      const faltandoNoServidor = rawPrioridades.filter(pr => pr.ja_feito && setFeitosLoc.has(_normTitTema(pr.titulo || '')) && !(pf.temas_prioritarios_aprovados || []).find(orig => _normTitTema(orig.titulo) === _normTitTema(pr.titulo) && orig.ja_feito));
      if (faltandoNoServidor.length) {
        Promise.all(faltandoNoServidor.map(pr => api('/api/pauta/marcar-tema', {
          json: {canal: ch.id, canal_id: ch.id, channel_id: ch.id, titulo: pr.titulo, acao: 'concluir'}
        }).catch(() => null)));
      }
      const todasPrioridades = rawPrioridades.filter(pr => !pr.oculto);
      const prioridadesVisiveis = S.pautaOcultarConcluidos
        ? todasPrioridades.filter(pr => !pr.ja_feito)
        : todasPrioridades;
      const qtdConcluidosPrio = todasPrioridades.filter(pr => pr.ja_feito).length;
      const qtdPendentesPrio = todasPrioridades.length - qtdConcluidosPrio;
      const canaisVirais = (p && p.canais_virais_nicho) || [];
      const velha = p && p.data !== r.hoje;

      // 1. ABA RECOLHÍVEL (FECHADA POR PADRÃO): VINCULAÇÃO COM O YOUTUBE + DIAGNÓSTICO E ALERTAS DO CANAL
      const htmlDiagnosticoYoutube = `<details id="pa-diag-details" class="card" ${S.pautaDiagAberto ? 'open' : ''} style="border:1px solid var(--line);background:var(--panel);margin-bottom:10px;padding:10px 14px">
        <summary class="row" style="cursor:pointer;gap:8px;flex-wrap:wrap;list-style:none">
          <b style="color:#e6edf3;font-size:13.5px">📡 Diagnóstico YouTube — ${esc(ch.nome)}</b>
          ${diag.youtube_vinculado
            ? `<span class="pill ok" style="font-size:11px">✅ YouTube Vinculado</span>`
            : `<span class="pill warn" style="font-size:11px">⚠️ Vincular YouTube</span>`}
          <span class="pill" style="font-size:11px">✅ ${qtdConcluidosPrio} Concluídos · ⏳ ${qtdPendentesPrio} Pendentes</span>
          ${alertas.length ? `<span class="pill" style="font-size:11px">💡 ${alertas.length} Dicas</span>` : ''}
          <span class="sp"></span>
          <span class="pill" style="font-size:11px">🔽 Abrir / Fechar</span>
        </summary>

        <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--line)">
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:10px;padding:9px;border-radius:8px;background:#0c1016;border:1px solid var(--line)">
            <span class="small" style="font-weight:600;color:var(--mut)">🔗 Link / @Handle do Canal:</span>
            <input id="pa-yt-url" class="sp" value="${esc(diag.youtube_url || ch.youtube_url || '')}" placeholder="https://www.youtube.com/@SeuCanal ou ID UC..." style="min-width:240px">
            <button type="button" class="pri sm" id="pa-yt-sync-btn">🔄 Vincular e Sincronizar</button>
            <button type="button" class="sm" id="pa-yt-all-modal-btn">📺 Contas (${S.channels.length})</button>
          </div>

          <div class="grid g4" style="gap:8px;margin-bottom:10px">
            <div style="padding:8px 10px;border-radius:8px;background:#0c1016;border:1px solid var(--line)">
              <div class="small mut">Inscritos & Views</div>
              <div style="font-size:14px;font-weight:700;color:#fff;margin-top:2px">${Number(diag.inscritos || 0).toLocaleString('pt-BR')} insc. · ${Number(diag.views_totais || 0).toLocaleString('pt-BR')} views</div>
            </div>
            <div style="padding:8px 10px;border-radius:8px;background:#0c1016;border:1px solid var(--line)">
              <div class="small mut">Vídeos Feitos / Publicados</div>
              <div style="font-size:14px;font-weight:700;color:#34d399;margin-top:2px">${diag.videos_concluidos_sistema || 0} sistema · ${diag.videos_importados_yt || diag.videos_publicados_yt || 0} YouTube</div>
            </div>
            <div style="padding:8px 10px;border-radius:8px;background:#0c1016;border:1px solid var(--line)">
              <div class="small mut">Média Views (Top 5)</div>
              <div style="font-size:14px;font-weight:700;color:#e6edf3;margin-top:2px">${diag.media_views_top5 ? Number(diag.media_views_top5).toLocaleString('pt-BR') + ' views' : 'Sincronize p/ medir'}</div>
            </div>
            <div style="padding:8px 10px;border-radius:8px;background:#0c1016;border:1px solid var(--line)">
              <div class="small mut">Skill & Meta Ideal</div>
              <div style="font-size:13px;font-weight:700;color:#a7f3d0;margin-top:2px">${esc(diag.skill_recomendada || 'skill6_cenas_flow')} · ${esc(String(diag.duracao_ideal_min || 18))} min</div>
            </div>
          </div>

          <div style="display:grid;gap:6px">
            ${alertas.map((al, aIdx) => {
              return `<div style="padding:8px 11px;border-radius:8px;border-left:3px solid #10b981;background:#0c1016">
                <div class="row" style="gap:8px;flex-wrap:wrap">
                  <b class="sp" style="color:#fff;font-size:12.5px">${esc(al.titulo || '')}</b>
                  ${al.titulo_sugerido ? `<button type="button" class="sm pri" data-ger-alerta="${aIdx}">⚡ Produzir Este Agora</button>` : ''}
                </div>
                <div class="small mut" style="margin-top:3px;line-height:1.4">${esc(al.detalhe || '')}</div>
              </div>`;
            }).join('')}
          </div>

          ${topVidsYt.length ? `<details style="margin-top:8px;padding:7px 10px;border-radius:8px;background:#0c1016;border:1px solid var(--line)">
            <summary class="small" style="cursor:pointer;color:#6ee7b7;font-weight:600">📺 Vídeos Publicados no YouTube (${diag.videos_importados_yt || topVidsYt.length})</summary>
            <div class="grid g2" style="gap:6px;margin-top:8px">
              ${topVidsYt.map(v => {
                const vUrl = v.url || (v.video_id ? `https://www.youtube.com/watch?v=${encodeURIComponent(v.video_id)}` : `https://www.youtube.com/results?search_query=${encodeURIComponent(v.titulo || '')}`);
                return `<div class="row" style="padding:5px 8px;border-radius:6px;background:rgba(0,0,0,.35);gap:8px">
                  <span class="pill ok" style="font-size:10px">✅</span>
                  <a href="${esc(vUrl)}" target="_blank" rel="noopener" class="small sp" style="color:#7dd3fc;text-decoration:underline;font-weight:600" title="Clique para abrir este vídeo no YouTube">${esc(v.titulo || '')} ↗</a>
                  ${v.views ? `<span class="pill" style="font-size:10px">${Number(v.views).toLocaleString('pt-BR')} views</span>` : ''}
                </div>`;
              }).join('')}
            </div>
          </details>` : ''}
        </div>
      </details>`;

      // 2. ABA RECOLHÍVEL DE TEMAS RECOMENDADOS PARA O CANAL
      const htmlPrioridades = todasPrioridades.length ? `<details id="pa-prio-details" class="card" ${S.pautaPrioFechado ? '' : 'open'} style="border:1px solid var(--line);background:var(--panel);margin-bottom:10px;padding:10px 14px">
        <summary class="row" style="cursor:pointer;gap:8px;flex-wrap:wrap;list-style:none">
          <b style="color:#34d399;font-size:14px">⭐ Temas Recomendados — ${esc(ch.nome)}</b>
          <span class="pill ok" style="font-size:11px">✅ ${qtdConcluidosPrio} Concluído(s)</span>
          <span class="pill" style="font-size:11px">⏳ ${qtdPendentesPrio} Pendente(s)</span>
          <span class="sp"></span>
          <label class="row small" onclick="event.stopPropagation()" style="gap:6px;cursor:pointer;padding:3px 9px;border-radius:6px;background:#0c1016;border:1px solid var(--line);color:var(--txt);margin:0">
            <input type="checkbox" id="pa-chk-ocultar-feitos" ${S.pautaOcultarConcluidos ? 'checked' : ''}>
            <b>Ocultar concluídos</b>
          </label>
          <span class="pill" style="font-size:11px">🔽 Abrir / Fechar</span>
        </summary>
        <div style="margin-top:10px">
          ${!prioridadesVisiveis.length ? `<div class="empty" style="padding:14px;color:#6ee7b7">🎉 Todos os temas prioritários já foram concluídos! Veja abaixo as <b>Sugestões do Dia</b>.</div>` : `
          <div style="overflow-x:auto">
            <table class="tbl">
              <thead><tr><th style="width:46px">#</th><th style="width:120px">Status</th><th>Título Analisado (Títulos Neurais V8)</th><th style="width:270px">Ações</th></tr></thead>
              <tbody>
                ${prioridadesVisiveis.map((pr, idx) => {
                  const feito = !!pr.ja_feito;
                  const ctr = pr.ctr_score || (pr.campeao_neural ? 99 : Math.max(95, 99 - idx));
                  const gat = pr.gatilho_neural || 'Fórmula Neural V8';
                  return `<tr style="${feito ? 'background:rgba(16,185,129,.06);opacity:0.85' : ''}">
                    <td><span class="pill ${feito ? 'ok' : (pr.campeao_neural || idx === 0 ? 'acc' : '')}"><b>#${pr.prioridade || (idx + 1)}</b></span></td>
                    <td>
                      ${feito
                        ? `<span class="pill ok" style="font-weight:700;font-size:10.5px">✅ CONCLUÍDO</span>`
                        : `<span class="pill" style="font-size:10.5px">⏳ Pendente</span>`}
                    </td>
                    <td>
                      <div class="row" style="gap:6px;flex-wrap:wrap">
                        <b style="color:${feito ? '#6ee7b7' : '#e6edf3'};font-size:13px;${feito ? 'text-decoration:line-through' : ''}">${esc(pr.titulo)}</b>
                        <span class="pill ok" style="font-size:10px">${ctr}% CTR</span>
                        <span class="pill" style="font-size:10px">${esc(gat)}</span>
                      </div>
                      ${pr.traducao ? `<div class="small mut" style="margin-top:2px">${esc(pr.traducao)}</div>` : ''}
                    </td>
                    <td>
                      <div class="row" style="gap:5px;flex-wrap:wrap">
                        ${feito
                          ? `${pr.video_id ? `<button type="button" class="sm" onclick="go('video','${esc(pr.video_id)}')">📂 Ver</button>` : ''}
                             <button type="button" class="sm" data-marcar-acao="ocultar" data-marcar-tit="${esc(pr.titulo)}" style="border-color:rgba(248,81,73,.4);color:#fca5a5" title="Apagar da lista">🗑️ Apagar</button>
                             <button type="button" class="sm" data-marcar-acao="desmarcar" data-marcar-tit="${esc(pr.titulo)}" title="Voltar para pendente">↩️</button>`
                          : `<button type="button" class="sm pri" data-ger-tit="${esc(pr.titulo)}">⚡ Gerar</button>
                             <button type="button" class="sm" data-kb-tit="${esc(pr.titulo)}" data-kb-tr="${esc(pr.traducao || '')}" data-kb-nt="${esc(pr.gancho || pr.potencial_narrativo || '')}">+ Kanban</button>
                             <button type="button" class="sm" data-marcar-acao="concluir" data-marcar-tit="${esc(pr.titulo)}" style="border-color:rgba(16,185,129,.45);color:#6ee7b7" title="Marcar como já feito">✅ Já Feito</button>
                             <button type="button" class="sm" data-marcar-acao="ocultar" data-marcar-tit="${esc(pr.titulo)}" style="border-color:rgba(248,81,73,.4);color:#fca5a5" title="Apagar da lista">🗑️</button>`}
                      </div>
                    </td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>`}
        </div>
      </details>` : '';

      const aprendDiario = (p && p.aprendizado_diario) || diag.aprendizado_diario || {};
      const padroesAprendidos = Array.isArray(aprendDiario.padroes_extraidos) ? aprendDiario.padroes_extraidos : [];
      const emAltaDetalhado = (p && Array.isArray(p.em_alta_detalhado) && p.em_alta_detalhado.length)
        ? p.em_alta_detalhado
        : ((p && p.em_alta) || []).map((txt, idxE) => {
            const cvRef = canaisVirais[idxE % Math.max(1, canaisVirais.length)] || {};
            return {
              texto: typeof txt === 'string' ? txt : (txt.titulo || ''),
              titulo: typeof txt === 'object' ? (txt.titulo || '') : String(txt || '').split(' — ')[0],
              canal: (typeof txt === 'object' && txt.canal) || cvRef.canal || '',
              url_video: (typeof txt === 'object' && txt.url_video) || cvRef.url_video || `https://www.youtube.com/results?search_query=${encodeURIComponent(String(txt || ''))}`,
              url_canal: (typeof txt === 'object' && txt.url_canal) || cvRef.url_canal || `https://www.youtube.com/results?search_query=${encodeURIComponent(cvRef.canal || String(txt || ''))}`,
            };
          });

      const htmlAprendizadoDiario = `<div class="card" style="border:1px solid rgba(56,189,248,.4);background:rgba(14,116,144,.1);margin-bottom:10px;padding:10px 14px">
        <div class="row" style="gap:8px;flex-wrap:wrap">
          <span class="pill ok" style="background:rgba(16,185,129,.2);border-color:#10b981;color:#6ee7b7;font-weight:700">🧠 APRENDIZADO DIÁRIO ATIVO (${esc(aprendDiario.ultimo_aprendizado_data || (p && p.data) || r.hoje || 'Hoje')})</span>
          <b class="sp" style="color:#e0f2fe;font-size:13px">Verificação Diária Automática de Canais em Ascensão — ${esc(ch.nome)}</b>
          <span class="pill" style="font-size:10.5px">📈 ${Number(aprendDiario.total_canais_monitorados || canaisVirais.length || 3)} canais monitorados</span>
          <span class="pill" style="font-size:10.5px">🔄 Rotação Diária Automática</span>
        </div>
        ${padroesAprendidos.length ? `<div class="small" style="margin-top:6px;color:#bae6fd;line-height:1.45">
          ${padroesAprendidos.slice(0, 3).map(pd => `<div>• ${esc(pd)}</div>`).join('')}
        </div>` : `<div class="small mut" style="margin-top:4px">O motor analisa diariamente os vídeos e canais em ascensão do nicho para renovar a Sugestão do Dia e evoluir os títulos neurais.</div>`}
      </div>`;

      const htmlCanaisVirais = canaisVirais.length ? `<details open class="card" style="border:1px solid var(--line);background:var(--panel)">
        <summary class="row small" style="cursor:pointer;color:#6ee7b7;font-weight:600;font-size:13px;list-style:none;gap:8px">
          <span class="sp">🔥 Canais Virais Benchmark do Nicho (${canaisVirais.length} canais — Clique no canal ou no vídeo para avaliar no YouTube)</span>
          <span class="pill ok" style="font-size:10.5px">🔗 Links Diretos Ativos</span>
        </summary>
        <div class="grid g2" style="gap:8px;margin-top:10px">
          ${canaisVirais.map(cv => {
            const urlCanal = cv.url_canal || cv.url || `https://www.youtube.com/results?search_query=${encodeURIComponent(cv.canal || '')}`;
            const urlVideo = cv.url_video || `https://www.youtube.com/results?search_query=${encodeURIComponent((cv.canal || '') + ' ' + (cv.melhor_video || cv.destaque || ''))}`;
            const tituloVid = cv.melhor_video || cv.video_destaque || cv.destaque || 'Ver vídeo em alta';
            return `<div style="padding:10px 12px;border-radius:8px;background:#0c1016;border:1px solid var(--line)">
              <div class="row" style="gap:6px;flex-wrap:wrap">
                <a href="${esc(urlCanal)}" target="_blank" rel="noopener" class="sp" style="color:#38bdf8;font-weight:700;font-size:13.5px;text-decoration:underline" title="Clique para abrir o canal ${esc(cv.canal)} no YouTube">📺 ${esc(cv.canal)} ↗</a>
                <span class="pill ok" style="font-size:10px">${esc(cv.destaque || 'Viral')}</span>
                ${cv.views_totais ? `<span class="pill" style="font-size:10px">${Number(cv.views_totais).toLocaleString('pt-BR')} views</span>` : ''}
              </div>
              <div class="small mut" style="margin-top:3px">${esc(cv.categoria || '')}${cv.inscritos ? ` · ${Number(cv.inscritos).toLocaleString('pt-BR')} inscritos` : ''}</div>
              <div class="small" style="margin-top:6px">
                🎬 Vídeo referência: <a href="${esc(urlVideo)}" target="_blank" rel="noopener" style="color:#6ee7b7;text-decoration:underline;font-weight:600" title="Clique para assistir e avaliar este vídeo no YouTube">${esc(tituloVid)} ↗</a>
              </div>
              ${cv.observacoes ? `<div class="small" style="margin-top:4px;color:#cbd5e1">${esc(cv.observacoes)}</div>` : ''}
              <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:8px">
                <a class="btn sm" href="${esc(urlCanal)}" target="_blank" rel="noopener" style="border-color:#38bdf8;color:#7dd3fc">🔗 Abrir Canal</a>
                <a class="btn sm" href="${esc(urlVideo)}" target="_blank" rel="noopener" style="border-color:#10b981;color:#6ee7b7">▶️ Assistir Vídeo</a>
                <button type="button" class="sm pri" data-ref-est-url="${esc(urlVideo)}" data-ref-est-tit="${esc(cv.melhor_video || '')}">⚡ Usar de Referência no Estúdio</button>
              </div>
            </div>`;
          }).join('')}
        </div>
      </details>` : '';

      const htmlEmAlta = emAltaDetalhado.length ? `<details open class="card" style="border:1px solid var(--line);background:var(--panel)">
        <summary class="row small" style="cursor:pointer;color:#7dd3fc;font-weight:600;font-size:13px;list-style:none;gap:8px">
          <span class="sp">📈 Vídeos e Referências em Alta Analisados no Nicho (Clique para abrir o vídeo ou o canal)</span>
          <span class="pill ok" style="font-size:10.5px">${emAltaDetalhado.length} referências clicáveis</span>
        </summary>
        <div style="display:grid;gap:6px;margin-top:10px">
          ${emAltaDetalhado.map(item => {
            const uVid = item.url_video || `https://www.youtube.com/results?search_query=${encodeURIComponent(item.titulo || item.texto || '')}`;
            const uCan = item.url_canal || `https://www.youtube.com/results?search_query=${encodeURIComponent(item.canal || item.titulo || '')}`;
            return `<div class="row" style="padding:8px 10px;border-radius:8px;background:#0c1016;border:1px solid var(--line);gap:8px;flex-wrap:wrap">
              <div class="sp">
                <a href="${esc(uVid)}" target="_blank" rel="noopener" style="color:#6ee7b7;font-weight:700;text-decoration:underline;font-size:13px" title="Clique para assistir ao vídeo no YouTube">▶️ ${esc(item.titulo || item.texto)} ↗</a>
                ${item.canal ? `<span class="small mut" style="margin-left:6px">por <a href="${esc(uCan)}" target="_blank" rel="noopener" style="color:#38bdf8;text-decoration:underline;font-weight:600">📺 ${esc(item.canal)} ↗</a></span>` : ''}
                ${item.views ? `<span class="pill" style="font-size:10px;margin-left:6px">${Number(item.views).toLocaleString('pt-BR')} views</span>` : ''}
              </div>
              <div class="row" style="gap:6px">
                <a class="btn sm" href="${esc(uVid)}" target="_blank" rel="noopener" style="border-color:#10b981;color:#6ee7b7">▶️ Ver Vídeo</a>
                ${item.canal ? `<a class="btn sm" href="${esc(uCan)}" target="_blank" rel="noopener" style="border-color:#38bdf8;color:#7dd3fc">🔗 Abrir Canal</a>` : ''}
                <button type="button" class="sm pri" data-ref-est-url="${esc(uVid)}" data-ref-est-tit="${esc(item.titulo || '')}">⚡ Analisar no Estúdio</button>
              </div>
            </div>`;
          }).join('')}
        </div>
      </details>` : '';

      // 3. SUGESTÕES DO DIA ABAIXO DOS TEMAS RECOMENDADOS
      const titulosTemaDia = ((p && p.tema && p.tema.titulos) || []).filter(t => !t.oculto && (!S.pautaOcultarConcluidos || !t.ja_feito));
      const novosDoDia = ((p && p.novos) || []).filter(t => !t.oculto && (!S.pautaOcultarConcluidos || !t.ja_feito));
      const cvPrincipal = canaisVirais[0] || {};
      const urlRefTema = (p && p.tema && p.tema.url_referencia) || cvPrincipal.url_video || `https://www.youtube.com/results?search_query=${encodeURIComponent((p && p.tema && p.tema.assunto) || ch.nome || '')}`;
      const urlCanalTema = (p && p.tema && p.tema.url_canal_referencia) || cvPrincipal.url_canal || `https://www.youtube.com/results?search_query=${encodeURIComponent(cvPrincipal.canal || ch.nome || '')}`;

      $('#pa-box').innerHTML =
        htmlDiagnosticoYoutube +
        htmlAprendizadoDiario +
        htmlPrioridades +
        (r.rodando ? `<div class="card" style="border-color:#10b981"><span class="spin"></span> Gerando novas sugestões do dia para <b>${esc(ch.nome)}</b>…</div>` : '') +
        (r.erro ? `<div class="card est-alerta">${esc(r.erro)}</div>` : '') +
        (p ? `${velha ? '<p class="small mut">Sugestão de ' + esc(p.data) + ' (atualizando com a análise de hoje…).</p>' : ''}
        <div class="card pa-tema" style="border-color:rgba(16,185,129,.4)">
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <span class="pill ok">🌟 SUGESTÃO DO DIA (${esc(p.data || r.hoje || 'Hoje')})</span>
            <span class="pill acc" style="font-weight:700">🏆 ${esc(String(p.tema.ctr_score || 99))}% CTR</span>
            ${p.tema.gatilho_neural ? `<span class="pill">🧠 ${esc(p.tema.gatilho_neural)}</span>` : ''}
            ${p.tema.ja_feito ? `<span class="pill ok" style="font-weight:700">✅ JÁ FEITO</span>` : `<span class="pill ok">✨ Inédito Hoje</span>`}
            <span class="sp"></span>
            <a class="btn sm" href="${esc(urlRefTema)}" target="_blank" rel="noopener" style="border-color:#10b981;color:#6ee7b7">▶️ Avaliar Vídeo Referência ↗</a>
            ${cvPrincipal.canal ? `<a class="btn sm" href="${esc(urlCanalTema)}" target="_blank" rel="noopener" style="border-color:#38bdf8;color:#7dd3fc">📺 Canal ${esc(cvPrincipal.canal)} ↗</a>` : ''}
          </div>
          <h2 style="margin:6px 0"><a href="${esc(urlRefTema)}" target="_blank" rel="noopener" style="color:#f8fafc;text-decoration:none" title="Clique para buscar/avaliar referências deste tema no YouTube">${esc(p.tema.assunto)} 🔗</a></h2>
          <p class="small mut" style="line-height:1.5">${esc(p.tema.por_que || '')}</p>
          ${p.tema.gancho ? `<p class="pa-gancho">“${esc(p.tema.gancho)}”</p>` : ''}
          <h3>Variações de Título</h3>
          ${titulosTemaDia.map((t, idxT) => {
            const ctrT = t.ctr_score || (idxT === 0 ? 99 : Math.max(95, 98 - idxT));
            const gatT = t.gatilho_neural || 'Alto CTR Neural V8';
            const uBuscaTit = t.url_referencia || `https://www.youtube.com/results?search_query=${encodeURIComponent(t.titulo || '')}`;
            return `<div class="pa-tit" style="${t.ja_feito ? 'background:rgba(16,185,129,.08);border-color:#10b981' : ''}">
            <div class="sp">
              <div class="row" style="gap:6px;flex-wrap:wrap">
                <a href="${esc(uBuscaTit)}" target="_blank" rel="noopener" style="color:${t.ja_feito ? '#6ee7b7' : '#e6edf3'};font-weight:700;text-decoration:underline;${t.ja_feito ? 'text-decoration:line-through' : ''}" title="Clique para avaliar vídeos com este tema no YouTube">${esc(t.titulo)} ↗</a>
                <span class="pill ok" style="font-size:10px">${ctrT}% CTR</span>
                <span class="pill" style="font-size:10px">${esc(gatT)}</span>
                ${t.ja_feito ? `<span class="pill ok" style="font-size:10px">✅ CONCLUÍDO</span>` : ''}
              </div>
              ${t.traducao ? `<div class="small mut">${esc(t.traducao)}</div>` : ''}
            </div>
            <a class="btn sm" href="${esc(uBuscaTit)}" target="_blank" rel="noopener" title="Avaliar no YouTube">🔍 YouTube</a>
            <button type="button" class="sm" data-kb-tit="${esc(t.titulo)}" data-kb-tr="${esc(t.traducao || '')}" data-kb-nt="${esc(p.tema.gancho || '')}">+ Kanban</button>
            <button type="button" class="sm pri" data-ger-tit="${esc(t.titulo)}">⚡ Gerar</button>
            ${t.ja_feito
              ? `<button type="button" class="sm" data-marcar-acao="ocultar" data-marcar-tit="${esc(t.titulo)}" style="border-color:rgba(248,81,73,.4);color:#fca5a5">🗑️ Apagar</button>`
              : `<button type="button" class="sm" data-marcar-acao="concluir" data-marcar-tit="${esc(t.titulo)}" style="border-color:rgba(16,185,129,.45);color:#6ee7b7">✅ Já Feito</button>
                 <button type="button" class="sm" data-marcar-acao="ocultar" data-marcar-tit="${esc(t.titulo)}" style="border-color:rgba(248,81,73,.4);color:#fca5a5">🗑️</button>`}
          </div>`;
          }).join('')}
        </div>
        <div class="card">
          <div class="row" style="margin-bottom:8px;flex-wrap:wrap;gap:8px">
            <h3 style="margin:0" class="sp">💡 Mais Sugestões Inéditas do Dia</h3>
            <span class="small mut">Verificadas contra os vídeos do canal · Clique em qualquer título para avaliar no YouTube</span>
          </div>
          ${novosDoDia.map((t, idxN) => {
            const ctrN = t.ctr_score || Math.max(94, 98 - (idxN % 5));
            const gatN = t.gatilho_neural || t.emocao_viral || 'Fórmula Neural V8';
            const uBuscaNov = t.url_referencia || `https://www.youtube.com/results?search_query=${encodeURIComponent(t.titulo || '')}`;
            return `<div class="pa-tit" style="${t.ja_feito ? 'background:rgba(16,185,129,.08);border-color:#10b981' : ''}">
            <div class="sp">
              <div class="row" style="gap:6px;flex-wrap:wrap">
                <a href="${esc(uBuscaNov)}" target="_blank" rel="noopener" style="color:${t.ja_feito ? '#6ee7b7' : '#e6edf3'};font-weight:700;text-decoration:underline;${t.ja_feito ? 'text-decoration:line-through' : ''}" title="Clique para avaliar este tema no YouTube">${esc(t.titulo)} ↗</a>
                <span class="pill ok" style="font-size:10px">${ctrN}% CTR</span>
                <span class="pill" style="font-size:10px">${esc(gatN)}</span>
                ${t.ja_feito ? `<span class="pill ok" style="font-size:10px">✅ CONCLUÍDO</span>` : ''}
              </div>
              ${t.traducao ? `<div class="small mut">${esc(t.traducao)}</div>` : ''}
              <div class="small mut" style="margin-top:2px">${esc(t.por_que || '')}</div>
            </div>
            <a class="btn sm" href="${esc(uBuscaNov)}" target="_blank" rel="noopener" title="Avaliar no YouTube">🔍 YouTube</a>
            <button type="button" class="sm" data-kb-tit="${esc(t.titulo)}" data-kb-tr="${esc(t.traducao || '')}" data-kb-nt="${esc(t.por_que || '')}">+ Kanban</button>
            <button type="button" class="sm pri" data-ger-tit="${esc(t.titulo)}">⚡ Gerar</button>
            ${t.ja_feito
              ? `<button type="button" class="sm" data-marcar-acao="ocultar" data-marcar-tit="${esc(t.titulo)}" style="border-color:rgba(248,81,73,.4);color:#fca5a5">🗑️ Apagar</button>`
              : `<button type="button" class="sm" data-marcar-acao="concluir" data-marcar-tit="${esc(t.titulo)}" style="border-color:rgba(16,185,129,.45);color:#6ee7b7">✅ Já Feito</button>
                 <button type="button" class="sm" data-marcar-acao="ocultar" data-marcar-tit="${esc(t.titulo)}" style="border-color:rgba(248,81,73,.4);color:#fca5a5">🗑️</button>`}
          </div>`;
          }).join('')}
        </div>
        ${htmlCanaisVirais}
        ${htmlEmAlta}` : (r.rodando ? htmlCanaisVirais : '<div class="empty">Clique em "↻ Gerar Novas Sugestões Inéditas" acima.</div>'));

      $$('[data-ref-est-url]').forEach(b => b.onclick = () => {
        S.estCanal = ch.id;
        S.estYoutubeCloneUrl1 = b.dataset.refEstUrl || '';
        S.estYoutubeCloneUrl = b.dataset.refEstUrl || '';
        if (b.dataset.refEstTit && !S.estTitulo) S.estTitulo = b.dataset.refEstTit;
        go('estudio');
      });

      if ($('#pa-diag-details')) {
        $('#pa-diag-details').ontoggle = e => { S.pautaDiagAberto = !!e.target.open; };
      }
      if ($('#pa-prio-details')) {
        $('#pa-prio-details').ontoggle = e => { S.pautaPrioFechado = !e.target.open; };
      }
      if ($('#pa-chk-ocultar-feitos')) {
        $('#pa-chk-ocultar-feitos').onchange = e => {
          S.pautaOcultarConcluidos = !!e.target.checked;
          carregar(false);
        };
      }
      if ($('#pa-yt-sync-btn')) {
        $('#pa-yt-sync-btn').onclick = () => safe(async () => {
          const urlYt = ($('#pa-yt-url')?.value || '').trim();
          const btnS = $('#pa-yt-sync-btn');
          const tOld = btnS.textContent;
          btnS.disabled = true;
          btnS.textContent = '⏳ Vinculando e Lendo Canal no YouTube…';
          try {
            const resYt = await api('/api/canais/vincular-youtube', {
              json: {canal_id: ch.id, youtube_url: urlYt, importar_videos: true}
            });
            S.channels = await api('/api/channels');
            toast(`✅ Canal vinculado ao YouTube! ${resYt.total_videos_lidos || 0} vídeos publicados lidos e verificados.`);
            await carregar(false);
          } finally {
            btnS.disabled = false;
            btnS.textContent = tOld;
          }
        });
      }
      if ($('#pa-yt-all-modal-btn')) {
        $('#pa-yt-all-modal-btn').onclick = () => {
          modal(`<div style="min-width:min(92vw,820px)">
            <div class="row" style="margin-bottom:10px">
              <h3 style="margin:0">📺 Vincular e Sincronizar Todas as Suas Contas do YouTube</h3>
              <span class="sp"></span>
              <button type="button" class="sm" onclick="fecharModal()">✕ Fechar</button>
            </div>
            <p class="small mut" style="margin-bottom:12px">Cadastre ou atualize o link / <code>@handle</code> do YouTube de cada um dos seus canais. O sistema puxa inscritos, views, todos os vídeos já publicados e otimiza as sugestões do dia de forma personalizada:</p>
            <div style="display:grid;gap:8px;max-height:65vh;overflow-y:auto">
              ${S.channels.map(cItem => `<div class="kcard row" style="margin:0;gap:10px;flex-wrap:wrap;background:#111827">
                <div style="min-width:170px">
                  <b style="color:#fff">${esc(cItem.nome)}</b>
                  <div class="small mut">${esc(cItem.idioma || 'pt')} · ${Number((cItem.youtube_stats || {}).subscriber_count || cItem.inscritos || 0).toLocaleString('pt-BR')} insc.</div>
                </div>
                <input class="sp" data-yt-inp-cid="${esc(cItem.id)}" value="${esc(cItem.youtube_url || '')}" placeholder="https://www.youtube.com/@SeuCanal ou UC...">
                <button type="button" class="pri sm" data-yt-save-cid="${esc(cItem.id)}" style="background:#0284c7;border-color:#38bdf8;color:#fff">🔗 Vincular & Sincronizar</button>
              </div>`).join('')}
            </div>
          </div>`);
          $$('[data-yt-save-cid]').forEach(b => b.onclick = () => safe(async () => {
            const cidAlvo = b.dataset.ytSaveCid;
            const inp = $(`[data-yt-inp-cid="${cidAlvo}"]`);
            const uVal = (inp?.value || '').trim();
            const t0 = b.textContent;
            b.disabled = true;
            b.textContent = '⏳ Sincronizando…';
            try {
              const rSync = await api('/api/canais/vincular-youtube', {
                json: {canal_id: cidAlvo, youtube_url: uVal, importar_videos: true}
              });
              S.channels = await api('/api/channels');
              b.textContent = `✅ OK (${rSync.total_videos_lidos || 0} vídeos)`;
              toast(`✅ Canal sincronizado com o YouTube (${rSync.total_videos_lidos || 0} vídeos lidos)!`);
              if (cidAlvo === ch.id) await carregar(false);
            } finally {
              setTimeout(() => { b.disabled = false; b.textContent = t0; }, 2000);
            }
          }));
        };
      }

      $$('[data-ger-alerta]').forEach(b => b.onclick = () => {
        const al = alertas[+b.dataset.gerAlerta];
        if (al && al.titulo_sugerido) gerar(al.titulo_sugerido);
      });
      $$('[data-ger-tit]').forEach(b => b.onclick = () => gerar(b.dataset.gerTit));
      $$('[data-kb-tit]').forEach(b => b.onclick = () => {
        addKb(b.dataset.kbTit, b.dataset.kbTr || '', {notas: b.dataset.kbNt || ''});
        b.textContent = '✓ no Kanban';
        b.disabled = true;
      });
      $$('[data-marcar-acao]').forEach(b => b.onclick = () => {
        marcarTema(b.dataset.marcarTit, b.dataset.marcarAcao);
      });
      if (r.rodando && S.view === 'pauta') timer = setTimeout(() => carregar(false), 3000);
    };
    $('#pa-novo').onclick = () => safe(async () => {
      clearTimeout(timer);
      const btnN = $('#pa-novo');
      const tOld = btnN ? btnN.textContent : '';
      if (btnN) { btnN.disabled = true; btnN.textContent = '⏳ Gerando novas sugestões…'; }
      try {
        await carregar(true);
        toast('✨ Novas sugestões inéditas carregadas!');
      } finally {
        if (btnN) { btnN.disabled = false; btnN.textContent = tOld || '↻ Gerar Novas Sugestões Inéditas'; }
      }
    });
    await carregar(false);
  };

  // ---------------------------------------------------------------- kanban
  const NOMES_COL = {planejamento: 'Planejamento', producao: 'Produção', finalizado: 'Finalizado', publicado: 'Publicado'};
  EXTRA_VIEWS.kanban = async function () {
    const r = await api('/api/kanban' + (S.kbCanal ? `?canal=${S.kbCanal}` : ''));
    main.innerHTML = `<div class="row"><div><h1>📋 Kanban</h1><p class="sub">Do planejamento ao publicado. O checklist se marca sozinho conforme o vídeo avança no app.</p></div><span class="sp"></span>
      <select id="kb-canal">${chOptions(S.kbCanal || '', true)}</select><button class="pri" id="kb-novo">+ Cartão</button></div>
      <div class="kb">${r.colunas.map(col => `<div class="kb-col" data-col="${col}"><div class="kb-cab">${NOMES_COL[col]} <span class="pill">${r.cards.filter(k => k.coluna === col).length}</span></div>
        ${r.cards.filter(k => k.coluna === col).map(k => { const ck = k.checklist || {}, feitos = r.check.filter(([c]) => ck[c]).length;
          return `<div class="kb-card" draggable="true" data-k="${k.id}">${chDot(k.channel_id)}<b>${esc(k.titulo)}</b>${k.traducao ? `<div class="small mut">${esc(k.traducao)}</div>` : ''}
          <div class="kb-prog"><i style="width:${Math.round(feitos / r.check.length * 100)}%"></i></div><div class="small mut">${feitos}/${r.check.length}${k.data_publicacao ? ' · 📅 ' + esc(k.data_publicacao) : ''}${k._estudio && k._estudio.rodando ? ` · ⚡ ${k._estudio.progresso}%` : ''}</div></div>`; }).join('')}
      </div>`).join('')}</div>`;
    $('#kb-canal').onchange = () => { S.kbCanal = $('#kb-canal').value; go('kanban'); };
    $('#kb-novo').onclick = () => cartao({titulo: '', channel_id: S.kbCanal || (S.channels[0] || {}).id, coluna: 'planejamento', checklist: {}}, r);
    $$('.kb-card').forEach(el => {
      el.onclick = () => cartao(r.cards.find(k => k.id === el.dataset.k), r);
      el.ondragstart = e => e.dataTransfer.setData('text', el.dataset.k);
    });
    $$('.kb-col').forEach(c => {
      c.ondragover = e => { e.preventDefault(); c.classList.add('alvo'); };
      c.ondragleave = () => c.classList.remove('alvo');
      c.ondrop = e => { e.preventDefault(); safe(async () => { await api('/api/kanban/' + e.dataTransfer.getData('text'), {method: 'PATCH', json: {coluna: c.dataset.col}}); go('kanban'); }); };
    });
  };
  function cartao(k, r) {
    const novo = !k.id, ck = k.checklist || {};
    modal(`<h3>${novo ? 'Novo cartão' : 'Cartão'}</h3>
      <div class="f"><label>Título</label><input id="k-tit" value="${esc(k.titulo)}"></div>
      <div class="grid g2"><div class="f"><label>Canal</label><select id="k-canal">${chOptions(k.channel_id)}</select></div>
        <div class="f"><label>Coluna</label><select id="k-col">${r.colunas.map(c => `<option value="${c}" ${k.coluna === c ? 'selected' : ''}>${NOMES_COL[c]}</option>`).join('')}</select></div></div>
      <div class="f"><label>Data de publicação</label><input id="k-data" type="date" value="${esc(k.data_publicacao || '')}"></div>
      ${novo ? '' : `<div class="f"><label>Checklist</label><div class="kb-check">${r.check.map(([c, n]) => `<label><input type="checkbox" data-ck="${c}" ${ck[c] ? 'checked' : ''}> ${n}</label>`).join('')}</div></div>`}
      <div class="f"><label>Notas</label><textarea id="k-notas" style="min-height:70px">${esc(k.notas || '')}</textarea></div>
      <div class="row">${novo ? '' : `<button class="bad" id="k-del">Excluir</button>`}<span class="sp"></span>
        ${k.video_id ? `<button id="k-abrir">Abrir vídeo</button>` : novo ? '' : `<button id="k-gerar">⚡ Gerar no Estúdio</button>`}
        <button onclick="fecharModal()">Cancelar</button><button class="pri" id="k-ok">Salvar</button></div>`);
    const dados = () => {
      const d = {titulo: $('#k-tit').value.trim(), channel_id: $('#k-canal').value, coluna: $('#k-col').value, data_publicacao: $('#k-data').value, notas: $('#k-notas').value};
      if (!novo) { d.checklist = {}; $$('[data-ck]').forEach(x => d.checklist[x.dataset.ck] = x.checked); }
      return d;
    };
    $('#k-ok').onclick = () => safe(async () => { await api(novo ? '/api/kanban' : '/api/kanban/' + k.id, novo ? {json: dados()} : {method: 'PATCH', json: dados()}); fecharModal(); go('kanban'); });
    $('#k-del') && ($('#k-del').onclick = () => safe(async () => { if (!confirm('Excluir este cartão?')) return; await api('/api/kanban/' + k.id, {method: 'DELETE'}); fecharModal(); go('kanban'); }));
    $('#k-abrir') && ($('#k-abrir').onclick = () => { fecharModal(); go('video', k.video_id); });
    $('#k-gerar') && ($('#k-gerar').onclick = () => safe(async () => { await api('/api/kanban/' + k.id, {method: 'PATCH', json: dados()}); fecharModal(); S.estCanal = $('#k-canal') ? k.channel_id : S.estCanal; S.estTitulo = k.titulo; go('estudio'); }));
  }

  // ---------------------------------------------------------------- celular
  EXTRA_VIEWS.celular = async function () {
    const c = await api('/api/celular/config');
    const urlPrincipalQr = c.endereco_autologin || c.endereco || c.tunel_autologin;
    const alts = c.enderecos_alternativos || [];
    main.innerHTML = `<div class="row" style="gap:10px;flex-wrap:wrap;margin-bottom:8px">
        <div class="sp">
          <h1>📱 Controle pelo celular (App Mobile V8 + QR Code Instantâneo)</h1>
          <p class="sub">Aponte a câmera do celular para o QR Code ao lado ou use a <b>Opção 1 (Wi-Fi Local Instantâneo)</b> para abrir o App Mobile V8 já logado.</p>
        </div>
        <button type="button" class="pri sm" id="cel-testar" style="background:#059669;border-color:#10b981;color:#fff;font-weight:800;padding:8px 14px">🔍 Testar Conexão Agora</button>
        <a class="btn sm" href="/celular?c=${encodeURIComponent(c.codigo || '')}" target="_blank" style="border-color:#f59e0b;color:#fde68a;font-weight:700;padding:8px 12px">📱 Abrir App Mobile (Teste)</a>
      </div>
      <div id="cel-diag-banner" style="display:none;margin-bottom:10px;padding:10px 14px;border-radius:10px;border:1.5px solid #10b981;background:rgba(16,185,129,.12);color:#d1fae5;font-size:13px"></div>
      <div class="card">
        <div class="row" style="gap:12px;flex-wrap:wrap;margin-bottom:10px">
          <label class="row" style="gap:10px;cursor:pointer"><input type="checkbox" id="cel-on" ${c.ativo ? 'checked' : ''}> <b>Liberar acesso pelo celular</b></label>
          <span class="pill ok">● Rede Wi-Fi 0.0.0.0:${c.porta || 5077} Ativa (1ms)</span>
          <span class="pill ok">🛡️ Firewall Liberado</span>
          ${c.tunel_url ? `<span class="pill ok">🌐 Link 4G Ativo (${esc(c.tunel_provedor || 'HTTPS')})</span>` : `<span class="pill warn">📶 Wi-Fi Local Pronto · 4G Sob Demanda</span>`}
          <span class="sp"></span>
          <button type="button" class="sm" id="cel-retunel">🔄 Gerar / Renovar Link 4G</button>
        </div>

        ${c.ativo ? `<div class="grid g2" style="gap:16px;align-items:start;margin-top:10px">
          <div>
            <!-- OPÇÃO 1 (PRINCIPAL E INSTANTÂNEA): WI-FI LOCAL DIRETO -->
            <div class="card" style="margin:0 0 12px;border:2px solid #10b981;background:rgba(16,185,129,.09)">
              <div class="row" style="margin-bottom:6px;flex-wrap:wrap;gap:6px">
                <b class="sp" style="color:#6ee7b7;font-size:15px">📶 Opção 1 (Principal e Instantânea) — Rede Wi-Fi Local</b>
                <span class="pill ok">Velocidade Máxima (Sem Delay)</span>
              </div>
              <div class="small mut" style="margin-bottom:4px">1️⃣ <b>App Mobile V8 Nativo</b> (já entra logado sem digitar código):</div>
              <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:8px">
                <code id="cel-code-auto" style="font-size:14px;padding:7px 10px;background:#0d0f17;border:1px solid #10b981;border-radius:8px;color:#6ee7b7;word-break:break-all;font-weight:700" class="sp">${esc(c.endereco_autologin)}</code>
                <button type="button" class="sm pri" data-copy-cel="${esc(c.endereco_autologin)}" style="background:#059669;border-color:#10b981">📋 Copiar</button>
                <button type="button" class="sm" data-qr-cel="${esc(c.endereco_autologin)}">📷 Ver no QR</button>
              </div>
              <div class="small mut" style="margin-bottom:4px">2️⃣ <b>Tela Completa de PC Adaptada para Celular</b> (com menu inferior e lateral):</div>
              <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:6px">
                <code id="cel-code-est" style="font-size:13px;padding:6px 10px;background:#0d0f17;border:1px solid #38bdf8;border-radius:8px;color:#7dd3fc;word-break:break-all" class="sp">${esc(c.endereco_estudio)}</code>
                <button type="button" class="sm" data-copy-cel="${esc(c.endereco_estudio)}">📋 Copiar</button>
                <button type="button" class="sm" data-qr-cel="${esc(c.endereco_estudio)}">📷 QR Tela Completa</button>
              </div>
              ${alts.length > 1 ? `<div style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,.08)">
                <div class="small mut" style="margin-bottom:4px">Se o seu PC tiver mais de uma placa de rede, escolha o IP do seu Wi-Fi para atualizar o QR Code:</div>
                <div class="row" style="gap:6px;flex-wrap:wrap">
                  ${alts.map(a => `<button type="button" class="sm ${a.ip === c.ip_local ? 'pri' : ''}" data-cel-ip="${esc(a.autologin)}" data-cel-est="${esc(a.estudio)}">📡 ${esc(a.ip)}${a.virtual ? ' (Virtual)' : ' (Wi-Fi/LAN)'}</button>`).join('')}
                </div>
              </div>` : ''}
              <div class="small mut" style="margin-top:6px">Endereço curto (pede o código <b>${esc(c.codigo)}</b>): <code>${esc(c.endereco)}</code></div>
            </div>

            <!-- OPÇÃO 2 (ABA RECOLHÍVEL): TÚNEL HTTPS ONLINE (PARA USAR FORA DE CASA NO 4G/5G) -->
            <details class="card" ${c.tunel_url ? 'open' : ''} style="margin:0;border:1px solid #38bdf8;background:rgba(2,132,199,.08);padding:10px 14px">
              <summary class="row" style="cursor:pointer;list-style:none;gap:8px">
                <b class="sp" style="color:#7dd3fc">🌐 Opção 2 — Acesso Externo 4G / 5G (Fora de Casa)</b>
                <span class="pill">${c.tunel_url ? 'Online' : 'Clique para abrir'}</span>
              </summary>
              <div style="margin-top:10px">
                ${c.tunel_url ? `
                  <div class="small mut" style="margin-bottom:4px">Use este link quando estiver na rua (4G/5G longe do Wi-Fi de casa):</div>
                  <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:6px">
                    <code style="font-size:13px;padding:6px 10px;background:#0d0f17;border:1px solid var(--line);border-radius:8px;color:#bae6fd;word-break:break-all" class="sp">${esc(c.tunel_autologin)}</code>
                    <button type="button" class="sm" data-copy-cel="${esc(c.tunel_autologin)}">📋 Copiar</button>
                    <button type="button" class="sm" data-qr-cel="${esc(c.tunel_autologin)}">📷 QR 4G</button>
                  </div>
                  <div class="small mut">Tela Completa via 4G: <code>${esc(c.tunel_estudio)}</code></div>
                ` : `<div class="small" style="color:#fde68a">Para acesso no Wi-Fi de casa, use a <b>Opção 1 acima</b> (é instantânea e não depende de servidor externo). Se precisar sair no 4G, clique em <b>"🔄 Gerar / Renovar Link 4G"</b> no topo.</div>`}
              </div>
            </details>

            <div class="row" style="margin-top:12px;gap:10px;flex-wrap:wrap">
              <span>🔑 Código de 6 dígitos: <b class="cel-cod" style="font-size:22px;color:#fbbf24;letter-spacing:3px">${esc(c.codigo)}</b></span>
              <button class="sm" id="cel-cod">🔄 Trocar código</button>
            </div>
          </div>

          <!-- COLUNA DO QR CODE ESCANEÁVEL -->
          <div class="card" style="margin:0;text-align:center;border:1px solid var(--acc);background:#0d0f17">
            <b style="color:#fbbf24;font-size:15px">📷 Aponte a Câmera do Celular Aqui</b>
            <div class="small mut" style="margin:4px 0 10px">Abre o App Mobile V8 instantaneamente já logado!</div>
            <div style="background:#fff;padding:12px;border-radius:12px;display:inline-block">
              <img id="cel-qr-img" src="/api/celular/qrcode?url=${encodeURIComponent(urlPrincipalQr)}&t=${Date.now()}" onerror="this.onerror=null;this.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data='+encodeURIComponent('${esc(urlPrincipalQr)}')" style="width:210px;height:210px;display:block" alt="QR Code Celular">
            </div>
            <div id="cel-qr-lbl" class="small" style="margin-top:8px;color:#86efac;word-break:break-all"><code>${esc(urlPrincipalQr)}</code></div>
            <div class="row" style="justify-content:center;gap:6px;margin-top:10px;flex-wrap:wrap">
              <button type="button" class="sm pri" data-qr-cel="${esc(c.endereco_autologin)}">📶 QR App Mobile (Wi-Fi)</button>
              <button type="button" class="sm" data-qr-cel="${esc(c.endereco_estudio)}">💻 QR Tela Completa (Wi-Fi)</button>
              ${c.tunel_autologin ? `<button type="button" class="sm" data-qr-cel="${esc(c.tunel_autologin)}">🌐 QR 4G Externo</button>` : ''}
            </div>
          </div>
        </div>` : '<p class="small mut">Desligado: o app só aceita conexões do próprio PC.</p>'}
      </div>`;
    const trocarQr = (u) => {
      const img = $('#cel-qr-img');
      if (img) {
        img.onerror = () => {
          img.onerror = null;
          img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=' + encodeURIComponent(u);
        };
        img.src = `/api/celular/qrcode?url=${encodeURIComponent(u)}&t=${Date.now()}`;
      }
      if ($('#cel-qr-lbl')) $('#cel-qr-lbl').innerHTML = `<code>${esc(u)}</code>`;
    };
    $('#cel-on').onchange = () => safe(async () => { await api('/api/celular/config', {json: {ativo: $('#cel-on').checked}}); go('celular'); });
    $('#cel-cod') && ($('#cel-cod').onclick = () => safe(async () => { await api('/api/celular/config', {json: {novo_codigo: true}}); go('celular'); }));
    $('#cel-retunel') && ($('#cel-retunel').onclick = () => safe(async () => {
      $('#cel-retunel').disabled = true;
      $('#cel-retunel').textContent = '⏳ Criando novo link…';
      await api('/api/celular/config', {json: {reiniciar_tunel: true}});
      go('celular');
    }));
    $('#cel-testar') && ($('#cel-testar').onclick = () => safe(async () => {
      const btn = $('#cel-testar');
      btn.disabled = true;
      btn.textContent = '⏳ Testando Wi-Fi, Porta e QR…';
      const r = await api('/api/celular/testar', {json: {}});
      btn.disabled = false;
      btn.textContent = '🔍 Testar Conexão Agora';
      const b = $('#cel-diag-banner');
      if (b) {
        b.style.display = 'block';
        b.innerHTML = `<b>${esc(r.resumo || 'Conexão verificada!')}</b>
          <div class="small" style="margin-top:4px;color:#a7f3d0">IP Principal: <code>${esc(r.ip_principal)}:${r.porta}</code> · QR Code PNG: <b>${r.qrcode_ok ? 'OK' : 'Fallback Ativo'}</b> · Firewall Windows: <b>Liberado</b> · IPs na máquina: <code>${esc((r.ips_detectados || []).join(', '))}</code></div>`;
      }
      toast(r.resumo || 'Vinculação com celular testada e aprovada!');
    }));
    $$('[data-copy-cel]').forEach(b => b.onclick = () => copiar(b.dataset.copyCel));
    $$('[data-qr-cel]').forEach(b => b.onclick = () => trocarQr(b.dataset.qrCel));
    $$('[data-cel-ip]').forEach(b => b.onclick = () => {
      $$('[data-cel-ip]').forEach(x => x.classList.remove('pri'));
      b.classList.add('pri');
      const uAuto = b.dataset.celIp;
      const uEst = b.dataset.celEst;
      if ($('#cel-code-auto')) $('#cel-code-auto').textContent = uAuto;
      if ($('#cel-code-est') && uEst) $('#cel-code-est').textContent = uEst;
      trocarQr(uAuto);
      toast('QR Code atualizado para o IP selecionado!');
    });
  };

  // ---------------------------------------------------------------- canais (Tela Limpa Oficial https://app.darkplanner.com.br/canais vinculada ao Estúdio 1 Clique)
  window.canais = async function () {
    const sync = await api('/api/darkplanner/sync' + (S.dpForceSync ? '?forcar=1' : ''));
    S.dpForceSync = false;
    S.channels = sync.channels || S.channels;
    const todosVideos = sync.videos || [];
    const cloud = sync.cloud || {};
    const userDp = cloud.user || {};
    const subDp = cloud.subscription || {};

    main.innerHTML = `<div class="row" style="flex-wrap:wrap;gap:10px;margin-bottom:10px">
      <div>
        <h1 style="margin:0">🎬 Canais — DarkPlanner Oficial (Vinculado ao Estúdio 1 Clique)</h1>
        <p class="sub" style="margin:2px 0 0">Navegue e edite diretamente na tela oficial do DarkPlanner abaixo. Tudo o que você alterar reflete automaticamente no <b>⚡ Estúdio 1 clique</b> (${S.channels.length} canais · ${todosVideos.length} vídeos · ${(cloud.prompts || []).length} Prompts Mestres sincronizados com <b>${esc(userDp.email || 'leonardo.sluz18@gmail.com')}</b>).</p>
      </div>
      <span class="sp"></span>
      <span class="pill ok">● ${esc(userDp.name || 'Leonardo Luz')} (${esc((subDp.plan || 'PRO').toUpperCase())})</span>
      <button class="sm" id="dp-btn-sync">🔄 Sincronizar com Estúdio 1 Clique</button>
      <button class="sm pri" onclick="S.dpForceSync=true;go('estudio')">⚡ Ir para o Estúdio 1 Clique</button>
      <button class="sm ai-dp" id="dp-btn-exe">🚀 Abrir App Desktop</button>
    </div>

    <div class="card" style="padding:0;overflow:hidden;border-color:#9333ea">
      <iframe id="dp-iframe-full" src="https://app.darkplanner.com.br/canais" style="width:100%;height:calc(100vh - 145px);min-height:680px;border:0;display:block;background:#090a0f" allow="clipboard-read; clipboard-write; microphone; autoplay"></iframe>
    </div>`;

    if ($('#dp-btn-sync')) $('#dp-btn-sync').onclick = () => safe(async () => {
      $('#dp-btn-sync').textContent = '⏳ Sincronizando…';
      S.dpForceSync = true;
      await go('canais');
      toast('Canais, vídeos, vozes e Prompts Mestres sincronizados com o Estúdio 1 Clique!');
    });
    if ($('#dp-btn-exe')) $('#dp-btn-exe').onclick = () => safe(async () => {
      const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_app'}});
      toast(r.msg);
    });
  };

  async function modalEditarCanalDp(c) {
    const dp = c.dp || {};
    const nar = dp.narrator || {};
    let vozesDp = [];
    try { vozesDp = (await api('/api/vozes/darkplanner')).todas || []; } catch {}
    modal(`<h3>${c.id ? '✏️ Editar Canal (Sincroniza c/ DarkPlanner)' : '+ Novo Canal no DarkPlanner'}</h3>
      <div class="grid g2">
        <div class="f"><label>Nome do Canal</label><input id="dc-nome" value="${esc(c.nome || '')}"></div>
        <div class="f"><label>Idioma no DarkPlanner</label><select id="dc-idioma-dp">
          ${[['pt', 'Português'], ['en', 'Inglês'], ['es', 'Espanhol'], ['fr', 'Francês']].map(([k, n]) => `<option value="${k}" ${(c.idioma || 'pt') === k ? 'selected' : ''}>${n}</option>`).join('')}
        </select></div>
        <div class="f"><label>Horários de Postagem (separados por vírgula)</label><input id="dc-horario" value="${esc((dp.horario_postagem || ['19:00']).join(', '))}"></div>
        <div class="f"><label>Frequência de Postagem</label><input id="dc-freq" value="${esc(dp.frequencia_postagem || 'Diário')}"></div>
        <div class="f"><label>Nicho</label><input id="dc-nicho" value="${esc(c.nicho || '')}"></div>
        <div class="f"><label>Perfil Visual no Estúdio</label><select id="dc-perfil">${PERFIS_CANAL.map(([k, n, d]) => `<option value="${k}" ${(c.perfil || 'padrao') === k ? 'selected' : ''}>${n} — ${d}</option>`).join('')}</select></div>
      </div>
      <div class="f"><label>🎙 Narrador Oficial do Canal no DarkPlanner</label>
        <select id="dc-voz">
          <option value="">— Manter narrador atual (${esc(nar.voice_name || 'nenhum')}) —</option>
          ${vozesDp.map(([id, nome]) => `<option value="${esc(id)}" data-nome="${esc(nome.split(' (')[0].replace(/^⭐\s*/, ''))}" ${nar.voice_id === id ? 'selected' : ''}>${esc(nome)}</option>`).join('')}
        </select>
      </div>
      <div class="f"><label>Anotações / Tese do Canal (salvo em Anotações no DarkPlanner)</label><textarea id="dc-anot" style="min-height:80px">${esc(dp.anotacoes || c.tese || '')}</textarea></div>
      <div class="row end">
        ${c.id ? `<button class="danger" id="dc-del" style="margin-right:auto">Excluir Canal</button>` : ''}
        <button onclick="fecharModal()">Cancelar</button>
        <button class="pri" id="dc-salvar">💾 Salvar no DarkPlanner</button>
      </div>`);
    if ($('#dc-del')) $('#dc-del').onclick = () => safe(async () => {
      if (!confirm('Tem certeza que deseja excluir este canal também no DarkPlanner?')) return;
      await api('/api/channels/' + c.id, {method: 'DELETE'});
      fecharModal(); toast('Canal excluído!'); S.dpForceSync = true; go('canais');
    });
    $('#dc-salvar').onclick = () => safe(async () => {
      $('#dc-salvar').disabled = true; $('#dc-salvar').textContent = 'Salvando no DarkPlanner…';
      const idiomaCod = $('#dc-idioma-dp').value;
      const idiomaMap = {pt: 'Português', en: 'Inglês', es: 'Espanhol', fr: 'Francês'};
      const optVoz = $('#dc-voz').selectedOptions[0];
      const payload = {
        id: c.id,
        nome: $('#dc-nome').value.trim(),
        idioma: idiomaCod,
        idioma_dp: idiomaMap[idiomaCod] || 'Português',
        horario_postagem: $('#dc-horario').value.split(',').map(x => x.trim()).filter(Boolean),
        frequencia_postagem: $('#dc-freq').value.trim(),
        nicho: $('#dc-nicho').value.trim(),
        perfil: $('#dc-perfil').value,
        anotacoes: $('#dc-anot').value.trim(),
        tese: $('#dc-anot').value.trim(),
        voice_id: $('#dc-voz').value || nar.voice_id || '',
        voice_name: (optVoz && optVoz.dataset.nome) || nar.voice_name || '',
      };
      await api('/api/channels', {json: payload});
      fecharModal(); toast('Canal atualizado no DarkPlanner!'); S.dpForceSync = true; go('canais');
    });
  }

  function modalVideoDp(v) {
    const vp = v.dp_video || {};
    const novo = !v.id;
    modal(`<h3>${novo ? '+ Novo Vídeo no DarkPlanner' : '✏️ Editar Vídeo no DarkPlanner'}</h3>
      <div class="grid g2">
        <div class="f"><label>Canal</label><select id="dv-canal">${chOptions(v.channel_id)}</select></div>
        <div class="f"><label>Número do Vídeo (ex.: Vídeo 15)</label><input id="dv-num" value="${esc(v.numero_video || vp.numero_video || '')}" placeholder="Automático se vazio"></div>
      </div>
      <div class="f"><label>Título do Vídeo</label><input id="dv-tit" value="${esc(v.titulo || '')}"></div>
      <div class="f"><label>Data de Postagem</label><input id="dv-data" type="date" value="${esc((v.data_publicacao || '').slice(0, 10))}"></div>
      <div class="f"><label>Notas / Briefing no DarkPlanner</label><textarea id="dv-notas" style="min-height:70px">${esc(vp.notas || '')}</textarea></div>
      ${novo ? '' : `<div class="f"><label>Checklists no DarkPlanner</label>
        <div class="row" style="flex-wrap:wrap;gap:12px">
          <label><input type="checkbox" id="dv-ck-tit" ${vp.checklist_titulo ? 'checked' : ''}> Título</label>
          <label><input type="checkbox" id="dv-ck-rot" ${vp.checklist_roteiro ? 'checked' : ''}> Roteiro Pronto</label>
          <label><input type="checkbox" id="dv-ck-aud" ${vp.checklist_audio ? 'checked' : ''}> Áudio Pronto</label>
          <label><input type="checkbox" id="dv-ck-mp4" ${vp.checklist_pronto ? 'checked' : ''}> Vídeo Pronto</label>
          <label><input type="checkbox" id="dv-ck-thb" ${vp.checklist_thumbnail ? 'checked' : ''}> Thumbnail</label>
          <label><input type="checkbox" id="dv-ck-pub" ${vp.checklist_postagem ? 'checked' : ''}> Publicado</label>
        </div>
      </div>`}
      <div class="row end">
        <button onclick="fecharModal()">Cancelar</button>
        <button class="pri" id="dv-ok">💾 Salvar no DarkPlanner</button>
      </div>`);
    $('#dv-ok').onclick = () => safe(async () => {
      $('#dv-ok').disabled = true; $('#dv-ok').textContent = 'Salvando…';
      const body = {
        channel_id: $('#dv-canal').value,
        numero_video: $('#dv-num').value.trim(),
        titulo: $('#dv-tit').value.trim(),
        data_publicacao: $('#dv-data').value,
        notas: $('#dv-notas').value.trim(),
      };
      if (!novo) {
        body.checklist_titulo = $('#dv-ck-tit').checked ? 'Publicado' : '';
        body.checklist_roteiro = $('#dv-ck-rot').checked ? 'Pronto' : '';
        body.checklist_audio = $('#dv-ck-aud').checked ? 'Pronto' : '';
        body.checklist_pronto = $('#dv-ck-mp4').checked ? 'Pronto' : '';
        body.checklist_thumbnail = $('#dv-ck-thb').checked ? 'Pronto' : '';
        body.checklist_postagem = $('#dv-ck-pub').checked ? 'Publicado' : '';
      }
      if (novo) await api('/api/videos', {json: body});
      else await api('/api/videos/' + v.id, {method: 'PATCH', json: body});
      fecharModal(); toast('Vídeo salvo no DarkPlanner!'); S.dpForceSync = true; go('canais');
    });
  }

  function modalPromptDp(p) {
    modal(`<h3>${p.id ? '✏️ Editar Prompt Mestre no DarkPlanner' : '+ Novo Prompt Mestre no DarkPlanner'}</h3>
      <div class="grid g2">
        <div class="f"><label>Canal</label><select id="dp-pm-canal">${chOptions(p.canal_id)}</select></div>
        <div class="f"><label>Categoria / Idioma</label><input id="dp-pm-cat" value="${esc(p.categoria || '')}" placeholder="Ex.: INGLES, PORTUGUES, FINANCAS"></div>
      </div>
      <div class="f"><label>Nome do Prompt Mestre</label><input id="dp-pm-nome" value="${esc(p.nome || '')}" placeholder="Ex.: PROMPT MESTRE RECOMECO AUSTRALIA"></div>
      <div class="f"><label>Conteúdo Completo do Prompt Mestre</label><textarea id="dp-pm-txt" style="min-height:260px;font-family:inherit">${esc(p.conteudo || '')}</textarea></div>
      <div class="row end">
        <button onclick="fecharModal()">Cancelar</button>
        <button class="pri" id="dp-pm-save">💾 Salvar no DarkPlanner</button>
      </div>`);
    $('#dp-pm-save').onclick = () => safe(async () => {
      $('#dp-pm-save').disabled = true; $('#dp-pm-save').textContent = 'Salvando…';
      await api('/api/darkplanner/prompts', {json: {
        id: p.id,
        canal_id: $('#dp-pm-canal').value,
        nome: $('#dp-pm-nome').value.trim(),
        categoria: $('#dp-pm-cat').value.trim(),
        conteudo: $('#dp-pm-txt').value,
      }});
      fecharModal(); toast('Prompt Mestre salvo no DarkPlanner!'); S.dpForceSync = true; go('canais');
    });
  }

  // ============================================================================
  // GERADOR DE ÁUDIO DARKPLANNER (/audio-generator — Foto 4 & 5) + EDITAR SRT TEMPO VEO
  // ============================================================================
  window.limparApenasRoteiro = function (texto) {
    if (!texto) return '';
    const tFull = String(texto);
    // Se o texto inteiro for apenas uma Estrutura/Análise em tópicos (e não o roteiro narrado), descarta para puxar o roteiro real
    const marcadoresEstrutura = [
      /meta de palavras/i,
      /loop aberto/i,
      /cliffhanger/i,
      /alinhamento conversacional/i,
      /potencial de ctr/i,
      /estrutura detalhada/i,
      /o que acontece no bloco/i,
      /tese\/conflito/i,
      /aprovar a estrutura/i,
    ];
    if (marcadoresEstrutura.filter(rx => rx.test(tFull)).length >= 2) {
      return '';
    }

    const metaRe = /(palavras por minuto|words per minute|\b\d+\s*ppm\b|dura[çc][ãa]o de aproximadamente|dura[çc][ãa]o estimada|garantindo uma dura[çc][ãa]o|aqui est[áa] o roteiro|abaixo est[áa] o roteiro|segue o roteiro|escrevi o roteiro|here is the (complete |full )?script|contagem de palavras|total de palavras|word count|meta configurada|estrutura detalhada|alinhamento conversacional|c[áa]lculo exato de tempo|potencial de ctr|espero que (goste|este roteiro)|se precisar de (algum ajuste|altera[çc][õo]es)|arquitetura v8 ninja pro|ritmo constante de \d+|meta de palavras|tempo em tela|loop aberto|cliffhanger)/i;
    const blocoHdrRe = /^\s*(?:[#*>•\-]+|\d+[\.\)]\s*|\*\*|\[|\()?\s*(?:bloco|block|ato|act|parte|part|cena|scene|cap[íi]tulo|chapter|gancho|hook|introdu[çc][ãa]o|intro|conclus[ãa]o|cta|fechamento|abertura|se[çc][ãa]o|section|meta|tempo|dura[çc][ãa]o|tese|conflito|loop|objetivo|resumo|nota|diagn[óo]stico)(?:\s+\d+|\s*[:\-–—]|[\]\)\*])\s*.*$/i;
    const speakerRe = /^\s*\**(?:narrador|narrator|locutor|voice\s*over|voiceover|voz|host|apresentador)\**\s*:\s*\**/i;

    const linhas = tFull.replace(/\r\n/g, '\n').split('\n');
    const out = [];
    for (let raw of linhas) {
      let s = raw.trim();
      if (!s) {
        if (out.length && out[out.length - 1] !== '') out.push('');
        continue;
      }
      if (/^[-*_═━]{3,}\s*$/.test(s)) continue;
      if (/^#{1,6}\s+/.test(s)) continue;
      if (/^(?:[\*\-•]|\d+[\.\)])\s+\*\*[^*]+\*\*\s*:/.test(s)) continue;
      if (/^[\[\(][^\]\)]{1,120}[\]\)]\s*$/.test(s) && !/^\[pause/i.test(s)) continue;
      if (s.length <= 180 && blocoHdrRe.test(s)) continue;
      if (metaRe.test(s)) continue;
      s = s.replace(speakerRe, '').trim();
      // Remove marcadores de tempo ou blocos entre colchetes/parênteses como [00:00], [000], [01:30], (00:00), [Bloco 1], etc.
      s = s.replace(/\[\s*\d{1,3}(?:\s*[:\-–—]\s*\d{1,3}){0,3}\s*\]/g, ' ');
      s = s.replace(/\(\s*\d{1,2}:\d{2}(?::\d{2})?(?:\s*[-–—]\s*\d{1,2}:\d{2}(?::\d{2})?)?\s*\)/g, ' ');
      s = s.replace(/^\s*\d{1,2}:\d{2}(?::\d{2})?\s*[-–—:]\s*/, '');
      s = s.replace(/\[[^\]\n]{1,80}\]/g, ' ');
      s = s.replace(/\*{1,3}([^*]+)\*{1,3}/g, '$1').replace(/^>\s*/, '').replace(/\s{2,}/g, ' ').trim();
      if (s) out.push(s);
    }
    return out.join('\n').split(/\n{2,}/).map(p => p.trim()).filter(Boolean).join('\n\n');
  };

  window.abrirModalAudioGeneratorDP = async function (opts = {}) {
    let canalId = opts.canal_id || S.estCanal || (S.channels[0] || {}).id || '';
    let vid = opts.vid || S.estVideoId || (S.video || {}).id || '';
    let tituloAudio = opts.titulo || (S.video || {}).titulo || '';
    let textoRoteiro = window.limparApenasRoteiro(opts.roteiro || (S.video || {}).roteiro || '');

    modal(`<div style="min-width:min(94vw,1120px)">
      <div class="row" style="margin-bottom:10px">
        <div>
          <h3 style="margin:0">🎙 Gerador de Áudio DarkPlanner (<code>/audio-generator</code>) + Resultados + Editar SRT Tempo VEO</h3>
          <div class="small mut">Selecione o canal, cole o roteiro (apenas a fala limpa do narrador), clique em <b>Gerar Áudio</b> e, ao lado em <b>Resultados</b>, baixe o MP3 e clique em <b>✏️ Editar SRT Tempo VEO</b> para escolher a <b>Quebra por Frase</b>!</div>
        </div>
        <span class="sp"></span>
        <a class="btn sm" href="https://app.darkplanner.com.br/audio-generator" target="_blank">🌐 Abrir no Site</a>
        <button onclick="fecharModal()">✕ Fechar</button>
      </div>
      <div id="dp-ag-body"><div class="empty"><span class="spin"></span> Carregando configuração de voz do canal e Resultados do DarkPlanner…</div></div>
    </div>`);

    let cfgData = {config: {voice_id: 'pVZP5KM07ddb72CT2019', speed: 1, volume: 1, subtitle_words: 5, subtitle_case: 'normal', subtitle_veo_words: 5, subtitle_veo_min: 0, subtitle_veo_max: 8}, voz: {name: 'Paul - Australian Professional Presenter'}, roteiros: [], vozes: []};
    let histList = [];
    let pollTimer = null;

    async function carregarDados(mudouCanal = false) {
      try {
        const [cRes, hRes] = await Promise.all([
          api('/api/darkplanner/audio/config?canal_id=' + encodeURIComponent(canalId || '')),
          api('/api/darkplanner/audio/history?limit=60'),
        ]);
        cfgData = cRes || cfgData;
        histList = (hRes || {}).history || [];
        if (mudouCanal && (cfgData.roteiros || []).length) {
          const r0 = cfgData.roteiros[0];
          if (r0 && (r0.roteiro_conteudo || r0.conteudo) && (!textoRoteiro || opts._trocaCanalManual)) {
            textoRoteiro = window.limparApenasRoteiro(r0.roteiro_conteudo || r0.conteudo || '');
            if (!tituloAudio || opts._trocaCanalManual) tituloAudio = r0.titulo || '';
          }
        }
      } catch (e) {
        toast(e.message || 'Erro ao carregar áudio DarkPlanner', true);
      }
      renderPainel();
    }

    function fmtDur(s) {
      s = Math.max(0, Math.round(Number(s || 0)));
      const m = Math.floor(s / 60), r = s % 60;
      return `${m}m ${r}s`;
    }

    function renderPainel() {
      const box = $('#dp-ag-body');
      if (!box) { clearTimeout(pollTimer); return; }
      const chAtual = S.channels.find(c => String(c.id) === String(canalId)) || {};
      const vozAtual = cfgData.voz || {voice_id: cfgData.config?.voice_id || 'pVZP5KM07ddb72CT2019', name: 'Paul - Australian Professional Presenter'};
      const rots = cfgData.roteiros || [];
      const todasVozes = cfgData.vozes || [];

      box.innerHTML = `<div class="grid g2" style="gap:14px;align-items:start">
        <!-- COLUNA ESQUERDA: FOTO 4 (GERADOR DE ÁUDIO) -->
        <div class="card" style="margin:0;background:#0d0f17;border-color:#262938">
          <div class="kcard" style="background:#131622;border-color:#272b3f;padding:12px;margin-bottom:12px">
            <div class="row" style="gap:12px">
              <div style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,#f43f5e,#a855f7);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff">🎙</div>
              <div class="sp">
                <div style="font-weight:700;font-size:15px;color:#fff" id="dp-ag-vname">${esc(vozAtual.name || 'Paul - Australian Professional Presenter')}</div>
                <div class="small mut">${esc(vozAtual.gender || 'Profissional')} · 🌍 ${esc(vozAtual.language || chAtual.idioma_dp || 'Multilíngue')} · <span style="color:#38bdf8">11Labs / DarkPlanner</span></div>
              </div>
            </div>
            <div class="f" style="margin-top:8px;margin-bottom:0">
              <select id="dp-ag-voice" style="background:#0b0d14;font-size:12px">
                <option value="${esc(vozAtual.voice_id || '')}">🎙 ${esc(vozAtual.name || 'Voz do Canal')} (Padrão do Canal)</option>
                ${todasVozes.slice(0, 250).map(v => `<option value="${esc(v.voice_id)}" ${v.voice_id === vozAtual.voice_id ? 'selected' : ''}>${esc(v.name)} (${esc(v.language || '')})</option>`).join('')}
              </select>
            </div>
          </div>

          <div class="grid g2" style="gap:10px;margin-bottom:6px">
            <div class="f" style="margin:0">
              <label style="letter-spacing:.06em;font-size:11px;color:#94a3b8">CANAL</label>
              <select id="dp-ag-canal" style="background:#131622;border-color:#2d324a;font-weight:600">
                ${S.channels.map(c => `<option value="${esc(c.id)}" ${String(c.id) === String(canalId) ? 'selected' : ''}>${esc(c.nome)}</option>`).join('')}
              </select>
            </div>
            <div class="f" style="margin:0">
              <label style="letter-spacing:.06em;font-size:11px;color:#94a3b8">ROTEIRO <span style="color:#10b981;font-weight:700">${rots.length} DISPONÍVEIS</span></label>
              <select id="dp-ag-rot-sel" style="background:#131622;border-color:#2d324a">
                <option value="">Selecionar roteiro...</option>
                ${rots.map((r, idx) => `<option value="${idx}">${esc(r.numero_video ? r.numero_video + ' - ' : '')}${esc(r.titulo || 'Roteiro ' + (idx + 1))}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="small" style="color:#94a3b8;font-style:italic;margin-bottom:10px">⚙ Configuração do canal '${esc(chAtual.nome || cfgData.channel_name || 'Selecionado')}' aplicada</div>

          <div style="border:1px solid #1e3a5f;border-radius:12px;background:#090b10;padding:12px">
            <div class="row" style="gap:8px;margin-bottom:10px;flex-wrap:wrap">
              <label class="btn sm" style="margin:0;border-radius:20px;background:#131622;color:#cbd5e1">
                ↑ Arquivo .txt/.docx
                <input type="file" id="dp-ag-file" accept=".txt,.srt,.md" hidden>
              </label>
              <button type="button" class="sm" id="dp-ag-pausa" style="border-radius:20px;background:#131622">⏸ Pausa ▾</button>
              <button type="button" class="sm" id="dp-ag-limpar" style="border-radius:20px;background:#131622;border-color:#0ea5e9;color:#38bdf8" title="Remove títulos (#), divisórias (---), cabeçalhos de blocos e introduções da IA, deixando apenas a fala do narrador">🧹 Deixar só o roteiro</button>
              <span class="small mut" id="dp-ag-stats">0 caracteres · 0 palavras</span>
              <span class="sp"></span>
              <span class="pill ok" id="dp-ag-t1" style="border-radius:50%;padding:6px 8px;font-size:11px">0m 0s</span>
              <span class="pill warn" id="dp-ag-t2" style="border-radius:50%;padding:6px 8px;font-size:11px">0m 0s</span>
            </div>
            <textarea id="dp-ag-txt" style="min-height:220px;background:transparent;border:none;outline:none;font-family:inherit;font-size:14px;line-height:1.6;width:100%;resize:vertical" placeholder="Digite ou cole seu texto aqui para converter em áudio...">${esc(textoRoteiro)}</textarea>
            <div class="small mut" style="border-top:1px solid #1e293b;padding-top:6px;margin-top:4px"><b id="dp-ag-chars">0</b> / 150.000</div>
          </div>

          <div class="row" style="gap:10px;margin-top:12px">
            <input id="dp-ag-title" value="${esc(tituloAudio)}" placeholder="Nome do áudio (opcional)" style="flex:1;background:#131622;border-color:#2d324a;padding:10px 12px;border-radius:10px">
            <button type="button" class="pri" id="dp-ag-go" style="background:linear-gradient(135deg,#0284c7,#2563eb);border:none;padding:10px 20px;border-radius:10px;font-weight:700">🎙 Gerar Áudio →</button>
          </div>
        </div>

        <!-- COLUNA DIREITA: FOTO 5 (RESULTADOS + BAIXAR MP3 + EDITAR SRT TEMPO VEO) -->
        <div class="card" style="margin:0;background:#0d0f17;border-color:#262938;max-height:74vh;overflow-y:auto">
          <div class="row" style="margin-bottom:12px">
            <b style="font-size:15px">🎧 Resultados <span class="mut">(${histList.length})</span></b>
            <span class="sp"></span>
            <button class="sm" id="dp-ag-refresh">🔄 Atualizar Resultados</button>
          </div>
          <div id="dp-ag-hist-list" style="display:flex;flex-direction:column;gap:10px">
            ${histList.map((it, idx) => {
              const st = it.status || 'completed';
              const pronto = st === 'completed';
              const nome = it.file_name || it.title || ('Áudio #' + (idx + 1));
              const vName = it.voice_name || vozAtual.name || 'Narrador';
              const jid = it.job_id || '';
              const aUrl = it.audio_url || (jid ? `https://cdn.darkplanner.com.br/audios/${jid}/audio.mp3` : '');
              const srtUrl = it.srt_url || (jid ? `https://cdn.darkplanner.com.br/audios/${jid}/legenda.srt` : '');
              const srtPalUrl = it.srt_palavra_url || (jid ? `https://cdn.darkplanner.com.br/audios/${jid}/srtsyncpalavra.srt` : '');
              const srtVeoUrl = it.srt_tempo_url || it.srt_veo_url || (jid ? `https://cdn.darkplanner.com.br/audios/${jid}/srtsynctempo.srt` : '');
              const dlMp3Href = jid ? `/api/darkplanner/audio/download/${encodeURIComponent(jid)}/mp3?nome=${encodeURIComponent(nome)}&url=${encodeURIComponent(aUrl)}` : aUrl;
              const dlSrtHref = jid ? `/api/darkplanner/audio/download/${encodeURIComponent(jid)}/srt?nome=${encodeURIComponent(nome)}&url=${encodeURIComponent(srtUrl)}` : srtUrl;
              const dlSrtPalHref = jid ? `/api/darkplanner/audio/download/${encodeURIComponent(jid)}/srt_palavra?nome=${encodeURIComponent(nome)}&url=${encodeURIComponent(srtPalUrl)}` : srtPalUrl;
              const dlSrtVeoHref = jid ? `/api/darkplanner/audio/download/${encodeURIComponent(jid)}/srt_veo?nome=${encodeURIComponent(nome)}&url=${encodeURIComponent(srtVeoUrl)}` : srtVeoUrl;
              return `<div class="kcard" style="background:#131622;border-color:${idx === 0 && pronto ? '#0ea5e9' : '#262938'};padding:12px;border-radius:12px">
                <div class="row" style="gap:8px;margin-bottom:6px">
                  ${pronto && aUrl ? `<audio controls preload="none" src="${esc(aUrl)}" style="height:32px;flex:1"></audio>` : `<span class="pill warn"><span class="spin"></span> Gerando áudio (${esc(st)})…</span><span class="sp"></span>`}
                  <button class="sm danger" data-ag-del="${esc(jid)}" title="Excluir do histórico">🗑</button>
                </div>
                <div style="font-weight:700;font-size:14px;color:#fff;margin-bottom:2px">${esc(nome)}</div>
                <div class="row small mut" style="margin-bottom:10px">
                  <span class="sp">🎙 ${esc(vName)}</span>
                  ${pronto ? '<span style="color:#10b981">✓ Pronto</span>' : ''}
                </div>
                ${pronto ? `
                  <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:6px">
                    <a class="btn sm" href="${esc(dlMp3Href)}" download="${esc(nome)}.mp3" data-ag-dl-idx="${idx}" data-ag-dl-tipo="mp3" style="background:rgba(14,165,233,.15);border-color:#0ea5e9;color:#38bdf8;font-weight:600">⬇ Baixar MP3</a>
                    <a class="btn sm" href="${esc(dlSrtVeoHref)}" download="${esc(nome)}_srtsynctempo.srt" data-ag-dl-idx="${idx}" data-ag-dl-tipo="srt_veo" style="border-color:#a855f7;color:#e9d5ff;font-weight:600">🕒 Baixar SRT Tempo (Quebra por Frases)</a>
                  </div>
                  <div class="row" style="gap:6px;flex-wrap:wrap">
                    <button type="button" class="sm pri" data-ag-veo="${idx}" style="background:rgba(14,165,233,.22);border-color:#38bdf8;color:#e0f2fe;font-weight:700">✏️ Editar SRT Tempo VEO (Quebra por Frases)</button>
                    <button type="button" class="sm" data-ag-use="${idx}" style="margin-left:auto;border-color:#10b981;color:#34d399;font-size:11px;font-weight:700" title="Baixar MP3 + Único SRT Tempo VEO direto para este vídeo">✅ Usar no Vídeo (MP3 + 1 SRT Tempo)</button>
                  </div>
                ` : ''}
              </div>`;
            }).join('') || '<div class="empty">Nenhum áudio em Resultados ainda.</div>'}
          </div>
        </div>
      </div>`;

      const atuContagem = () => {
        const t = $('#dp-ag-txt')?.value || '';
        textoRoteiro = t;
        const chars = t.length;
        const words = t.trim() ? t.trim().split(/\s+/).length : 0;
        if ($('#dp-ag-stats')) $('#dp-ag-stats').textContent = `${chars.toLocaleString('pt-BR')} caracteres · ${words.toLocaleString('pt-BR')} palavras`;
        if ($('#dp-ag-chars')) $('#dp-ag-chars').textContent = chars.toLocaleString('pt-BR');
        if ($('#dp-ag-t1')) $('#dp-ag-t1').textContent = fmtDur(words / 2.5);
        if ($('#dp-ag-t2')) $('#dp-ag-t2').textContent = fmtDur(words / 2.2);
      };
      atuContagem();
      if ($('#dp-ag-txt')) $('#dp-ag-txt').oninput = atuContagem;
      if ($('#dp-ag-title')) $('#dp-ag-title').oninput = e => { tituloAudio = e.target.value; };

      if ($('#dp-ag-canal')) $('#dp-ag-canal').onchange = e => {
        canalId = e.target.value;
        opts._trocaCanalManual = true;
        carregarDados(true);
      };
      if ($('#dp-ag-rot-sel')) $('#dp-ag-rot-sel').onchange = e => {
        const r = rots[+e.target.value];
        if (r) {
          textoRoteiro = window.limparApenasRoteiro(r.roteiro_conteudo || r.conteudo || '');
          tituloAudio = r.titulo || tituloAudio;
          renderPainel();
          toast('Roteiro limpo do canal carregado!');
        }
      };
      if ($('#dp-ag-file')) $('#dp-ag-file').onchange = async e => {
        const f = e.target.files[0];
        if (!f) return;
        textoRoteiro = window.limparApenasRoteiro(await f.text());
        if (!tituloAudio) tituloAudio = f.name.replace(/\.[^.]+$/, '');
        renderPainel();
      };
      if ($('#dp-ag-limpar')) $('#dp-ag-limpar').onclick = () => {
        const ta = $('#dp-ag-txt');
        if (!ta) return;
        ta.value = window.limparApenasRoteiro(ta.value);
        ta.dispatchEvent(new Event('input'));
        toast('🧹 Títulos, blocos e introduções removidos — ficou apenas o roteiro!');
      };
      if ($('#dp-ag-pausa')) $('#dp-ag-pausa').onclick = () => {
        const ta = $('#dp-ag-txt');
        if (!ta) return;
        const st = ta.selectionStart || ta.value.length;
        ta.value = ta.value.slice(0, st) + ' ... ' + ta.value.slice(st);
        ta.dispatchEvent(new Event('input'));
      };
      if ($('#dp-ag-refresh')) $('#dp-ag-refresh').onclick = () => carregarDados(false);

      if ($('#dp-ag-go')) $('#dp-ag-go').onclick = () => safe(async () => {
        const txt = window.limparApenasRoteiro(($('#dp-ag-txt')?.value || '').trim());
        if ($('#dp-ag-txt')) { $('#dp-ag-txt').value = txt; atuContagem(); }
        if (!txt) throw new Error('Digite ou cole o roteiro primeiro.');
        const btn = $('#dp-ag-go');
        btn.disabled = true; btn.textContent = '⏳ Enviando para Gerar Áudio…';
        try {
          const voiceEscolhida = $('#dp-ag-voice')?.value || vozAtual.voice_id || cfgData.config?.voice_id || 'cdf1ce4c-bbe0-43f5-b4ad-df00daae27ad';
          const tit = ($('#dp-ag-title')?.value || '').trim() || tituloAudio || 'Áudio Roteiro';
          await api('/api/darkplanner/audio/generate', {json: {
            canal_id: canalId,
            voice_id: voiceEscolhida,
            title: tit,
            text: txt,
            speed: Number(cfgData.config?.speed) || 1.0,
            volume: Number(cfgData.config?.volume) || 1.0,
            subtitle_words: Math.max(1, Number(cfgData.config?.subtitle_words) || 5),
            subtitle_case: cfgData.config?.subtitle_case || 'normal',
            subtitle_veo_words: Math.max(1, Number(cfgData.config?.subtitle_veo_words) || 5),
            subtitle_veo_min: Math.max(1, Number(cfgData.config?.subtitle_veo_min) || 3),
            subtitle_veo_max: Math.max(4, Number(cfgData.config?.subtitle_veo_max) || 8),
          }});
          toast('🎙 Geração de áudio iniciada no DarkPlanner! Acompanhe ao lado em Resultados.');
          await carregarDados(false);
        } finally {
          if ($('#dp-ag-go')) { $('#dp-ag-go').disabled = false; $('#dp-ag-go').textContent = '🎙 Gerar Áudio →'; }
        }
      });

      $$('[data-ag-del]').forEach(b => b.onclick = () => safe(async () => {
        if (!confirm('Excluir este áudio de Resultados?')) return;
        await api('/api/darkplanner/audio/history/' + b.dataset.agDel, {method: 'DELETE'});
        carregarDados(false);
      }));

      // Se o áudio mais recente em Resultados já está concluído, atualiza imediatamente o Passo 4 para 100% Concluído
      const topCompleted = histList.find(x => (x.status || 'completed') === 'completed');
      if (topCompleted && typeof window.estSetStep === 'function') {
        const stP4 = (S.estLiveSteps || []).find(s => s.id === 'p4');
        if (stP4 && stP4.status === 'rodando') {
          window.estSetStep('p4', 'ok', `Áudio MP3 pronto no DarkPlanner (${topCompleted.file_name || topCompleted.title || topCompleted.job_id})`);
        }
      }

      // Detecta automaticamente quando o usuário clica em "⬇ Baixar MP3" ou "🕒 Baixar SRT Tempo"
      $$('[data-ag-dl-idx]').forEach(aEl => aEl.addEventListener('click', () => {
        const item = histList[+aEl.dataset.agDlIdx];
        if (!item) return;
        const jid = item.job_id || '';
        const nome = item.file_name || item.title || 'audio_darkplanner';
        S.estJobId = jid;
        S._mp3JaBaixadoNoNavegador = S._mp3JaBaixadoNoNavegador || {};
        if (jid && (aEl.href || '').includes('/mp3')) {
          S._mp3JaBaixadoNoNavegador[jid] = true;
        }
        if (typeof window.estSetStep === 'function') {
          window.estSetStep('p4', 'ok', `Áudio MP3 baixado (${nome})`);
        }
        setTimeout(async () => {
          try {
            const pVeo = typeof window.obterPayloadVeoFaixas === 'function'
              ? window.obterPayloadVeoFaixas()
              : {quebrar_frases: true, min_s: 4, max_s: 8, faixas: [{count: 60, minMs: 2000, maxMs: 4000}, {minMs: 4000, maxMs: 8000}]};
            const dVeo = await api('/api/darkplanner/audio/srt-veo', {json: {
              job_id: jid,
              quebrar_frases: pVeo.quebrar_frases,
              min_s: pVeo.min_s,
              max_s: pVeo.max_s,
              faixas: pVeo.faixas,
            }});
            await new Promise(r => setTimeout(r, 1800));
            const rVinc = await api('/api/darkplanner/audio/vincular', {json: {
              job_id: jid,
              audio_url: item.audio_url || '',
              srt_texto: dVeo?.srt_texto || '',
              vid,
              file_name: nome,
              faixas: pVeo.faixas,
              quebrar_frases: pVeo.quebrar_frases,
              min_s: pVeo.min_s,
              max_s: pVeo.max_s,
            }});
            if (typeof opts.onUsarNoEstudio === 'function') {
              await opts.onUsarNoEstudio({
                jobId: jid,
                totalBlocos: dVeo.total_blocos,
                mp3Url: rVinc.download_mp3_url || (jid ? `/api/darkplanner/audio/file/${encodeURIComponent(jid)}/audio.mp3` : ''),
                srtTexto: dVeo.srt_texto,
                nome,
                silencioso: true,
              });
            }
          } catch (e) {}
        }, 1400);
      }));

      $$('[data-ag-veo]').forEach(b => b.onclick = () => {
        const item = histList[+b.dataset.agVeo];
        if (item) window.abrirEditorSrtTempoVeo(item, {vid, canalId, onUsarNoEstudio: opts.onUsarNoEstudio, voltarGerador: () => window.abrirModalAudioGeneratorDP(opts)});
      });

      $$('[data-ag-use]').forEach(b => b.onclick = () => safe(async () => {
        const item = histList[+b.dataset.agUse];
        if (!item) return;
        const jid = item.job_id || '';
        const nome = item.file_name || item.title || 'audio_darkplanner';
        const aUrl = item.audio_url || (jid ? `https://cdn.darkplanner.com.br/audios/${jid}/audio.mp3` : '');
        const dlUrl = jid ? `/api/darkplanner/audio/download/${encodeURIComponent(jid)}/mp3?nome=${encodeURIComponent(nome)}&url=${encodeURIComponent(aUrl)}` : aUrl;
        const internalMp3Url = jid ? `/api/darkplanner/audio/file/${encodeURIComponent(jid)}/audio.mp3` : dlUrl;
        S._mp3JaBaixadoNoNavegador = S._mp3JaBaixadoNoNavegador || {};
        if (dlUrl && (!jid || !S._mp3JaBaixadoNoNavegador[jid])) {
          if (jid) S._mp3JaBaixadoNoNavegador[jid] = true;
          const aMp3 = document.createElement('a');
          aMp3.href = dlUrl;
          aMp3.download = (nome.replace(/[^\w\-]+/g, '_') || 'audio') + '.mp3';
          document.body.appendChild(aMp3);
          aMp3.click();
          aMp3.remove();
        }
        S.estJobId = jid;
        S.estMp3Url = internalMp3Url;
        fecharModal();
        toast('✅ Áudio MP3 e Único SRT Tempo VEO (Quebra por Frases) baixados e aplicados no vídeo!');
        (async () => {
          try {
            const pVeo = typeof window.obterPayloadVeoFaixas === 'function'
              ? window.obterPayloadVeoFaixas()
              : {quebrar_frases: true, min_s: 4, max_s: 8, faixas: [{count: 60, minMs: 2000, maxMs: 4000}, {minMs: 4000, maxMs: 8000}]};
            const dVeo = await api('/api/darkplanner/audio/srt-veo', {json: {
              job_id: jid,
              quebrar_frases: pVeo.quebrar_frases,
              min_s: pVeo.min_s,
              max_s: pVeo.max_s,
              faixas: pVeo.faixas,
            }}).catch(() => ({}));
            await new Promise(r => setTimeout(r, 2000));
            const r = await api('/api/darkplanner/audio/vincular', {json: {
              job_id: jid,
              audio_url: aUrl,
              srt_texto: dVeo?.srt_texto || '',
              vid,
              file_name: item.file_name || '',
              faixas: pVeo.faixas,
              quebrar_frases: pVeo.quebrar_frases,
              min_s: pVeo.min_s,
              max_s: pVeo.max_s,
            }}).catch(() => ({}));
            await new Promise(r => setTimeout(r, 1500));
            if (typeof opts.onUsarNoEstudio === 'function') {
              await opts.onUsarNoEstudio({
                jobId: jid,
                totalBlocos: dVeo?.total_blocos || 0,
                mp3Url: r?.download_mp3_url || internalMp3Url,
                srtTexto: dVeo?.srt_texto || '',
                nome: item.file_name || 'audio',
              });
            }
            if (S.view === 'video') videoView();
          } catch (e) {}
        })();
      }));

      clearTimeout(pollTimer);
      if (histList.some(x => x.status && x.status !== 'completed' && x.status !== 'failed')) {
        pollTimer = setTimeout(() => carregarDados(false), 3500);
      }
    }

    await carregarDados(true);
  };

  // ============================================================================
  // MODAL INTERATIVO: EDITAR SRT TEMPO VEO (ESCOLHER QUEBRA POR FRASE)
  // ============================================================================
  window.abrirEditorSrtTempoVeo = async function (item, ctx = {}) {
    const jid = item.job_id || '';
    const nome = item.file_name || item.title || 'audio_darkplanner';
    const aUrl = item.audio_url || (jid ? `https://cdn.darkplanner.com.br/audios/${jid}/audio.mp3` : '');
    const srtTempoUrl = item.srt_tempo_url || item.srt_veo_url || (jid ? `https://cdn.darkplanner.com.br/audios/${jid}/srtsynctempo.srt` : '');
    const dlMp3Href = jid ? `/api/darkplanner/audio/download/${encodeURIComponent(jid)}/mp3?nome=${encodeURIComponent(nome)}&url=${encodeURIComponent(aUrl)}` : aUrl;

    modal(`<div style="min-width:min(95vw,1140px)">
      <div class="row" style="margin-bottom:10px">
        <div>
          <div class="row" style="gap:8px">
            <h3 style="margin:0">✏️ Editor de SRT Tempo — <span style="color:#38bdf8">${esc(nome)}</span></h3>
            <span class="pill ok">VEO · SYNC</span>
          </div>
          <div class="small mut">Escolha abaixo a <b>🪄 Quebra por Frase</b> (duração mín. e máx. em segundos) ou edite bloco a bloco. Os timestamps reais de cada palavra permanecem 100% sincronizados com a fala!</div>
        </div>
        <span class="sp"></span>
        ${ctx.voltarGerador ? `<button class="sm" id="veo-back">← Voltar aos Resultados</button>` : ''}
        <button onclick="fecharModal()">✕ Fechar</button>
      </div>
      <div id="veo-editor-body"><div class="empty"><span class="spin"></span> Carregando legenda e tempos das palavras (<code>words_time.json</code>)…</div></div>
    </div>`);

    if ($('#veo-back') && ctx.voltarGerador) $('#veo-back').onclick = () => ctx.voltarGerador();

    const pVeoInit = typeof window.obterPayloadVeoFaixas === 'function'
      ? window.obterPayloadVeoFaixas()
      : {ativo: true, primeiros_blocos: 60, primeiros_min_s: 2, primeiros_max_s: 4, resto_min_s: 4, resto_max_s: 8, quebrar_frases: true};

    let stVeo = null;
    let historicoBreaks = [];
    let futuroBreaks = [];
    let minSec = Number(pVeoInit.resto_min_s ?? 4);
    let maxSec = Number(pVeoInit.resto_max_s || 8);
    let usarFaixas = pVeoInit.ativo !== false;
    let faixaCount = Number(pVeoInit.primeiros_blocos || 60);
    let faixaMinSec = Number(pVeoInit.primeiros_min_s ?? 2);
    let faixaMaxSec = Number(pVeoInit.primeiros_max_s || 4);

    async function requisitarVeo(payload) {
      return await api('/api/darkplanner/audio/srt-veo', {json: Object.assign({
        job_id: jid,
        srt_tempo_url: srtTempoUrl,
      }, payload)});
    }

    try {
      const faixasInit = usarFaixas
        ? [{count: Number(faixaCount || 60), minMs: Number(faixaMinSec ?? 2) * 1000, maxMs: Number(faixaMaxSec || 4) * 1000}, {minMs: minSec * 1000, maxMs: maxSec * 1000}]
        : [{minMs: minSec * 1000, maxMs: maxSec * 1000}];
      stVeo = await requisitarVeo({
        quebrar_frases: pVeoInit.quebrar_frases !== false,
        min_s: minSec,
        max_s: maxSec,
        faixas: faixasInit,
      });
    } catch (e) {
      $('#veo-editor-body').innerHTML = `<div class="card danger">${esc(e.message || 'Erro ao carregar SRT Tempo VEO')}</div>`;
      return;
    }

    async function aplicarBreaks(novosBreaks, salvarHist = true) {
      if (salvarHist && stVeo) {
        historicoBreaks.push([...(stVeo.breaks || [])]);
        futuroBreaks = [];
      }
      stVeo = await requisitarVeo({breaks: novosBreaks});
      desenharEditor();
    }

    async function aplicarQuebraPorFrases(minS, maxS) {
      if (stVeo) {
        historicoBreaks.push([...(stVeo.breaks || [])]);
        futuroBreaks = [];
      }
      minSec = Number(minS ?? minSec);
      maxSec = Number(maxS ?? maxSec);
      if (S.estVeoFaixasCfg) {
        S.estVeoFaixasCfg.ativo = usarFaixas;
        S.estVeoFaixasCfg.primeiros_blocos = Number(faixaCount || 60);
        S.estVeoFaixasCfg.primeiros_min_s = Number(faixaMinSec ?? 2);
        S.estVeoFaixasCfg.primeiros_max_s = Number(faixaMaxSec || 4);
        S.estVeoFaixasCfg.resto_min_s = minSec;
        S.estVeoFaixasCfg.resto_max_s = maxSec;
        S.estVeoFaixasCfg.quebrar_frases = true;
        try { localStorage.setItem('fd_veo_faixas_cfg', JSON.stringify(S.estVeoFaixasCfg)); } catch (_e) {}
      }
      const faixas = usarFaixas
        ? [{count: Number(faixaCount || 60), minMs: Number(faixaMinSec ?? 2) * 1000, maxMs: Number(faixaMaxSec || 4) * 1000}, {minMs: minSec * 1000, maxMs: maxSec * 1000}]
        : [{minMs: minSec * 1000, maxMs: maxSec * 1000}];
      stVeo = await requisitarVeo({quebrar_frases: true, min_s: minSec, max_s: maxSec, faixas});
      toast(`🪄 Pronto! ${stVeo.total_blocos} blocos quebrados por frases (${usarFaixas ? `primeiros ${faixaCount} de ${faixaMinSec}-${faixaMaxSec}s + demais ` : ''}${minSec}s a ${maxSec}s).`);
      desenharEditor();
    }

    function baixarSrtNoNavegador(textoSrt, sufixo = '_veo_editado.srt') {
      const blob = new Blob([textoSrt], {type: 'text/plain;charset=utf-8'});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = (nome.replace(/[^\w\-]+/g, '_') || 'legenda') + sufixo;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }

    function desenharEditor() {
      const box = $('#veo-editor-body');
      if (!box || !stVeo) return;
      const blocos = stVeo.blocos || [];

      box.innerHTML = `
        <!-- BARRA DE ESCOLHA DE QUEBRA POR FRASE -->
        <div class="card" style="margin:0 0 12px 0;background:#111522;border-color:#0ea5e9">
          <div class="row" style="flex-wrap:wrap;gap:8px;margin-bottom:10px">
            <b style="color:#38bdf8">🪄 Escolher Quebra por Frase (1 Clique):</b>
            <button type="button" class="sm ${minSec === 0 && maxSec === 5 ? 'pri' : ''}" data-veo-preset="0:5">⚡ 0s a 5s (Rápido / Dinâmico)</button>
            <button type="button" class="sm ${minSec === 0 && maxSec === 8 ? 'pri' : ''}" data-veo-preset="0:8">🎬 0s a 8s (Padrão VEO 8s)</button>
            <button type="button" class="sm ${minSec === 4 && maxSec === 8 ? 'pri' : ''}" data-veo-preset="4:8">✨ 4s a 8s (Frases Equilibradas)</button>
            <button type="button" class="sm ${minSec === 5 && maxSec === 10 ? 'pri' : ''}" data-veo-preset="5:10">📖 5s a 10s (Narrativo)</button>
            <button type="button" class="sm ${minSec === 8 && maxSec === 14 ? 'pri' : ''}" data-veo-preset="8:14">🏛 8s a 14s (Documentário Longo)</button>
          </div>

          <div class="row" style="flex-wrap:wrap;gap:10px;padding-top:8px;border-top:1px solid #1e293b">
            <span class="small"><b>Tempo por bloco:</b></span>
            <label class="small" style="margin:0">Mín (s) <input type="number" id="veo-min" min="0" max="30" step="0.5" value="${minSec}" style="width:68px;padding:4px 6px"></label>
            <span class="small">a</span>
            <label class="small" style="margin:0">Máx (s) <input type="number" id="veo-max" min="2" max="60" step="0.5" value="${maxSec}" style="width:68px;padding:4px 6px"></label>
            <button type="button" class="pri sm" id="veo-smart-btn" style="background:#0284c7;border-color:#38bdf8">🪄 Quebrar por frases</button>
            <button type="button" class="sm ${usarFaixas ? 'pri' : ''}" id="veo-faixas-toggle">🎚 Faixas (${usarFaixas ? 'Ativo' : 'Opcional'})</button>
            <span class="sp"></span>
            <span class="pill">${stVeo.total_blocos} blocos · ${stVeo.total_words} palavras</span>
            <button type="button" class="sm" id="veo-undo" ${historicoBreaks.length ? '' : 'disabled'}>↶ Desfazer</button>
            <button type="button" class="sm" id="veo-redo" ${futuroBreaks.length ? '' : 'disabled'}>↷ Refazer</button>
            <button type="button" class="sm" id="veo-reset">🔄 Restaurar original</button>
          </div>

          ${usarFaixas ? `
            <div class="row small" style="margin-top:8px;padding:8px;background:#090b10;border-radius:8px;gap:8px;flex-wrap:wrap">
              <span>Os primeiros</span>
              <input type="number" id="veo-f-cnt" min="1" max="100" value="${faixaCount}" style="width:60px;padding:3px 6px">
              <span>blocos terão tempo de</span>
              <input type="number" id="veo-f-min" min="0" max="20" step="0.5" value="${faixaMinSec}" style="width:60px;padding:3px 6px">
              <span>a</span>
              <input type="number" id="veo-f-max" min="2" max="30" step="0.5" value="${faixaMaxSec}" style="width:60px;padding:3px 6px">
              <span>s (os demais usam ${minSec}s a ${maxSec}s)</span>
            </div>
          ` : ''}
        </div>

        <!-- LISTA DE BLOCOS INTERATIVOS + PREVIEW SRT -->
        <div class="grid g2" style="gap:12px;align-items:start">
          <div class="card" style="margin:0;max-height:52vh;overflow-y:auto;background:#0b0d14">
            <div class="small mut" style="margin-bottom:8px">💡 <b>Clique em qualquer palavra</b> para dividir o bloco naquele ponto, ou use <b>⇈ Juntar</b> e as setas <b>▲ / ▼</b> para mover palavras entre blocos vizinhos:</div>
            ${blocos.map((b, idx) => `
              <div class="kcard" style="margin-bottom:8px;background:#131622;border-color:${b.durationSec > maxSec + 0.5 ? '#f59e0b' : '#262938'}">
                <div class="row small" style="margin-bottom:6px;gap:6px">
                  <span class="pill acc">#${b.index}</span>
                  <code style="color:#38bdf8">${esc(b.startSrt)} → ${esc(b.endSrt)}</code>
                  <span class="pill ${b.durationSec <= maxSec + 0.4 ? 'ok' : 'warn'}">${b.durationSec}s · ${b.wordCount} pal.</span>
                  ${b.gapAfterSec > 0.15 ? `<span class="small mut">· ${b.gapAfterSec}s de silêncio</span>` : ''}
                  <span class="sp"></span>
                  ${idx > 0 ? `<button type="button" class="sm" data-veo-pull="${idx}" title="Puxar a primeira palavra para o bloco de cima">▲</button>` : ''}
                  ${idx < blocos.length - 1 ? `<button type="button" class="sm" data-veo-push="${idx}" title="Mandar a última palavra para o bloco de baixo">▼</button>` : ''}
                  ${idx > 0 ? `<button type="button" class="sm" data-veo-merge="${idx}" title="Juntar com o bloco de cima">⇈ Juntar</button>` : ''}
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:4px;line-height:1.6">
                  ${(b.words || []).map((w, wIdx) => {
                    const globalIdx = b.startWordIdx + wIdx;
                    return `<span data-veo-split="${globalIdx}" style="padding:1px 5px;border-radius:4px;background:rgba(255,255,255,.04);cursor:${wIdx > 0 ? 'pointer' : 'default'};font-size:13px" title="${wIdx > 0 ? 'Clique para quebrar um novo bloco aqui (' + (w.startMs / 1000).toFixed(2) + 's)' : ''}">${esc(w.word)}</span>`;
                  }).join('')}
                </div>
              </div>
            `).join('')}
          </div>

          <div class="card" style="margin:0;background:#0b0d14">
            <div class="row" style="margin-bottom:6px">
              <b class="small">📄 Pré-visualização do Arquivo <code>.SRT</code> Final (${stVeo.total_blocos} blocos)</b>
              <span class="sp"></span>
              <button class="sm" id="veo-copy-srt">📋 Copiar SRT</button>
            </div>
            <textarea id="veo-srt-preview" style="min-height:44vh;font-family:monospace;font-size:12px;line-height:1.5;background:#07090e">${esc(stVeo.srt_texto || '')}</textarea>
          </div>
        </div>

        <!-- BARRA FINAL DE DOWNLOAD DO MP3 + SRT EDITADO -->
        <div class="row" style="margin-top:12px;padding:12px;background:#131622;border:1px solid #0ea5e9;border-radius:12px;gap:10px;flex-wrap:wrap">
          ${aUrl ? `<audio controls preload="none" src="${esc(aUrl)}" style="height:34px"></audio>` : ''}
          <span class="sp"></span>
          ${aUrl ? `<a class="btn" id="veo-dl-mp3" href="${esc(dlMp3Href)}" download="${esc(nome)}.mp3" style="background:rgba(14,165,233,.15);border-color:#0ea5e9;color:#38bdf8">⬇ 1. Baixar Áudio MP3</a>` : ''}
          <button type="button" class="pri" id="veo-dl-srt" style="background:#0284c7;border-color:#38bdf8">⬇ 2. Baixar SRT Editado (.srt)</button>
          <button type="button" class="pri" id="veo-apply-video" style="background:#10b981;border-color:#34d399;color:#052e16;font-weight:700">✅ 3. Baixar MP3 + Usar SRT Editado no Vídeo (Finalizar)</button>
        </div>
      `;

      if ($('#veo-dl-mp3') && jid) {
        $('#veo-dl-mp3').addEventListener('click', () => {
          S._mp3JaBaixadoNoNavegador = S._mp3JaBaixadoNoNavegador || {};
          S._mp3JaBaixadoNoNavegador[jid] = true;
        });
      }

      $$('[data-veo-preset]').forEach(b => b.onclick = () => {
        const [mn, mx] = b.dataset.veoPreset.split(':').map(Number);
        aplicarQuebraPorFrases(mn, mx);
      });

      if ($('#veo-smart-btn')) $('#veo-smart-btn').onclick = () => {
        minSec = Number($('#veo-min')?.value || 0);
        maxSec = Number($('#veo-max')?.value || 8);
        if (usarFaixas) {
          faixaCount = Number($('#veo-f-cnt')?.value || 5);
          faixaMinSec = Number($('#veo-f-min')?.value || 0);
          faixaMaxSec = Number($('#veo-f-max')?.value || 5);
        }
        aplicarQuebraPorFrases(minSec, maxSec);
      };

      if ($('#veo-faixas-toggle')) $('#veo-faixas-toggle').onclick = () => {
        usarFaixas = !usarFaixas;
        desenharEditor();
      };

      if ($('#veo-undo')) $('#veo-undo').onclick = () => {
        if (!historicoBreaks.length) return;
        futuroBreaks.push([...(stVeo.breaks || [])]);
        const ant = historicoBreaks.pop();
        aplicarBreaks(ant, false);
      };
      if ($('#veo-redo')) $('#veo-redo').onclick = () => {
        if (!futuroBreaks.length) return;
        historicoBreaks.push([...(stVeo.breaks || [])]);
        const prox = futuroBreaks.pop();
        aplicarBreaks(prox, false);
      };
      if ($('#veo-reset')) $('#veo-reset').onclick = () => {
        aplicarBreaks([...(stVeo.breaks_originais || [])], true);
        toast('SRT restaurado para as quebras originais.');
      };

      $$('[data-veo-split]').forEach(el => el.onclick = () => {
        const gIdx = +el.dataset.veoSplit;
        const brks = new Set(stVeo.breaks || []);
        if (gIdx > 0 && !brks.has(gIdx)) {
          brks.add(gIdx);
          aplicarBreaks([...brks].sort((a, b) => a - b), true);
        }
      });

      $$('[data-veo-merge]').forEach(b => b.onclick = () => {
        const bIdx = +b.dataset.veoMerge;
        const brks = [...(stVeo.breaks || [])];
        if (bIdx > 0 && bIdx - 1 < brks.length) {
          brks.splice(bIdx - 1, 1);
          aplicarBreaks(brks, true);
        }
      });

      $$('[data-veo-pull]').forEach(b => b.onclick = () => {
        const bIdx = +b.dataset.veoPull;
        const brks = [...(stVeo.breaks || [])];
        if (bIdx > 0 && bIdx - 1 < brks.length) {
          brks[bIdx - 1] = brks[bIdx - 1] + 1;
          aplicarBreaks(brks, true);
        }
      });

      $$('[data-veo-push]').forEach(b => b.onclick = () => {
        const bIdx = +b.dataset.veoPush;
        const brks = [...(stVeo.breaks || [])];
        if (bIdx >= 0 && bIdx < brks.length) {
          brks[bIdx] = Math.max(1, brks[bIdx] - 1);
          aplicarBreaks(brks, true);
        }
      });

      if ($('#veo-copy-srt')) $('#veo-copy-srt').onclick = () => copiar($('#veo-srt-preview')?.value || stVeo.srt_texto || '');
      const internalMp3Url = jid ? `/api/darkplanner/audio/file/${encodeURIComponent(jid)}/audio.mp3` : (aUrl || dlMp3Href);
      if ($('#veo-dl-srt')) $('#veo-dl-srt').onclick = async () => {
        const txtFinal = $('#veo-srt-preview')?.value || stVeo.srt_texto || '';
        S.estSrtTexto = txtFinal;
        S.estJobId = jid;
        S.estTotalBlocosSrt = stVeo.total_blocos;
        if (internalMp3Url) S.estMp3Url = internalMp3Url;
        baixarSrtNoNavegador(txtFinal, '_srt_tempo_veo.srt');
        if (typeof ctx.onUsarNoEstudio === 'function') {
          ctx.onUsarNoEstudio({jobId: jid, totalBlocos: stVeo.total_blocos, mp3Url: internalMp3Url, srtTexto: txtFinal, nome, silencioso: true});
        }
        toast('⬇ Download do SRT Tempo VEO concluído e vinculado automaticamente aos Passos 4, 5 e 6!');
        api('/api/darkplanner/audio/vincular', {json: {
          job_id: jid,
          audio_url: aUrl,
          srt_texto: txtFinal,
          vid: ctx.vid || '',
          file_name: nome,
          criar_cenas_veo: true,
        }}).then(r => {
          if (r && r.download_mp3_url) S.estMp3Url = r.download_mp3_url;
        }).catch(() => {});
      };

      if ($('#veo-apply-video')) $('#veo-apply-video').onclick = () => safe(async () => {
        const txtFinal = $('#veo-srt-preview')?.value || stVeo.srt_texto || '';
        S.estSrtTexto = txtFinal;
        S.estJobId = jid;
        S.estTotalBlocosSrt = stVeo.total_blocos;
        if (internalMp3Url) S.estMp3Url = internalMp3Url;
        baixarSrtNoNavegador(txtFinal, '_srt_tempo_veo.srt');
        S._mp3JaBaixadoNoNavegador = S._mp3JaBaixadoNoNavegador || {};
        if (dlMp3Href && (!jid || !S._mp3JaBaixadoNoNavegador[jid])) {
          if (jid) S._mp3JaBaixadoNoNavegador[jid] = true;
          const aMp3 = document.createElement('a');
          aMp3.href = dlMp3Href;
          aMp3.download = (nome.replace(/[^\w\-]+/g, '_') || 'audio') + '.mp3';
          document.body.appendChild(aMp3);
          aMp3.click();
          aMp3.remove();
        }
        if (typeof ctx.onUsarNoEstudio === 'function') {
          ctx.onUsarNoEstudio({jobId: jid, totalBlocos: stVeo.total_blocos, mp3Url: internalMp3Url, srtTexto: txtFinal, nome});
        }
        fecharModal();
        toast(`✅ Áudio MP3 e SRT Tempo VEO (${stVeo.total_blocos} blocos) baixados e vinculados! Escolha agora a Skill do Passo 6.`);
        if (S.view === 'video') videoView();
        api('/api/darkplanner/audio/vincular', {json: {
          job_id: jid,
          audio_url: aUrl,
          srt_texto: txtFinal,
          vid: ctx.vid || '',
          file_name: nome,
          criar_cenas_veo: true,
        }}).then(r => {
          if (r && r.download_mp3_url) S.estMp3Url = r.download_mp3_url;
        }).catch(() => {});
      });
    }

    desenharEditor();
  };

  // ---------------------------------------------------------------- como usar o site (guia completo)
  EXTRA_VIEWS.guia = async function () {
    main.innerHTML = `<div class="row"><div><h1>📖 Como Utilizar Todo o Site (Guia Completo Passo a Passo)</h1>
      <p class="sub">Manual interativo da sua <b>Fábrica Dark</b> — conectada com <b>GPT (OpenAI)</b>, <b>Gemini</b>, <b>Antigravity (Motor V8 Ninja Pro)</b> e <b>DarkPlanner</b>.</p></div>
      <span class="sp"></span>
      <button class="ai-dp" id="guia-dp-open">🎬 Abrir DarkPlanner Agora</button>
      <button class="pri" onclick="go('estudio')">⚡ Ir para o Estúdio 1 Clique</button></div>

      <div class="card" style="border-color:var(--acc);background:rgba(249,115,22,.06)">
        <h3>🚀 Visão Geral: Como funciona a sua máquina de produção</h3>
        <p class="small">Você tem <b>2 formas de trabalhar</b> aqui dentro, além das ferramentas de pesquisa e gestão:</p>
        <div class="grid g2">
          <div class="kcard">
            <b>1️⃣ Modo Automático (⚡ Estúdio 1 clique + Antigravity V8)</b>
            <p class="small mut" style="margin:6px 0">Você coloca um título, analisa ou estrutura os blocos com o <b>Assistente Conversacional V8</b> (escolhendo quantas palavras e quantos blocos quer, com cálculo exato de tempo a 145 PPM) e depois clica em <b>⚡ Gerar vídeo completo</b>. O sistema escreve, narra, baixa vídeos/fotos reais, confere cada imagem com IA, monta o MP4 com efeitos e entrega tudo pronto.</p>
            <button class="sm pri" onclick="go('estudio')">Abrir Estúdio 1 Clique →</button>
          </div>
          <div class="kcard">
            <b>2️⃣ Modo Passo a Passo (Aba Vídeos — 10 Etapas + Oficina)</b>
            <p class="small mut" style="margin:6px 0">Para quando você quer controlar cada detalhe manualmente nas <b>10 abas</b>: 1. Briefing → 2. Roteiro (com <b>Oficina do Roteiro</b> que dá nota de 0 a 100 e conversa com você) → 3. Análise → 4. Narração (VozLab) → 5. Cenas e SRT → 6. Mídia (Real Lab) → 7. Editor (Video Lab) → 8. Montagem → 9. Descrição/SEO → 10. Thumbnail.</p>
            <button class="sm" onclick="go('videos')">Abrir Aba Vídeos →</button>
          </div>
        </div>
      </div>

      <div class="grid g2">
        <div class="card">
          <h3>PASSO 1 · 🔑 Conexões, Chaves e DarkPlanner</h3>
          <p class="small mut">Antes de produzir, confira suas conexões na aba <b>Conexões e chaves</b>:</p>
          <ul class="small" style="line-height:1.65;padding-left:18px">
            <li><b>Gemini (Google AI Studio):</b> Sua chave gratuita já vem configurada e faz fallback automático para o modelo <code>gemini-flash-lite-latest</code>. Você pode colocar até 4 chaves para somar cota diária.</li>
            <li><b>GPT (OpenAI API) + Antigravity V8:</b> O <b>Motor Antigravity V8 Ninja Pro</b> já vem <b>Ativo nativamente</b>. Se quiser usar também o GPT via API, basta colar sua chave <code>sk-...</code> da OpenAI e escolher entre <code>GPT-4o</code>, <code>GPT-4o Mini</code> ou <code>o3-mini</code>.</li>
            <li><b>🎬 DarkPlanner (Desktop + API):</b>
              <br>• Clique em <b>🎬 Abrir DarkPlanner</b> no menu lateral esquerdo (ou em qualquer botão roxo do site) para abrir direto o seu programa instalado em <code>C:\\Users\\leona\\AppData\\Local\\Programs\\darkplanner\\Dark Planner.exe</code>.
              <br>• Se tiver chave <code>dpk_...</code> da API de áudio do DarkPlanner, adicione-a em Conexões para gerar narrações completas num pedido só com legenda <code>.srt</code> sincronizada.</li>
            <li><b>YouTube Data API & Bancos de Imagem:</b> Adicione chaves gratuitas do YouTube, Pixabay e Pexels para liberar o Radar de Nichos, DarkMetrics e busca de filmagens reais.</li>
          </ul>
          <div class="row"><button class="sm pri" onclick="go('conexoes')">Ir para Conexões e Chaves →</button><button class="sm ai-dp" id="guia-dp-local">📁 Abrir Pasta do DarkPlanner no PC</button></div>
        </div>

        <div class="card">
          <h3>PASSO 2 · 📺 Canais, Pesquisa de Nichos e Ideias</h3>
          <p class="small mut">Prepare a base estratégica dos seus canais dark:</p>
          <ul class="small" style="line-height:1.65;padding-left:18px">
            <li><b>Canais:</b> Cadastre cada canal com seu Idioma (Português, Inglês ou Espanhol), Nicho, Subnicho, Público-alvo e <b>Perfil Visual</b> (Documentário, Investigação, Mistério, Notícia, etc.).</li>
            <li><b>☀️ Sugestão do dia:</b> Todo dia a IA analisa o que o seu canal já publicou e o que está em alta no YouTube para sugerir o <b>Tema do Dia</b> + 5 títulos prontos e 6 novos assuntos.</li>
            <li><b>Radar de nichos & DarkMetrics:</b> Encontre vídeos virais (outliers que tiveram muitas views em canais pequenos) e analise métricas completas de qualquer canal concorrente.</li>
            <li><b>Mapa de nichos & Ideias e títulos:</b> Gere árvores de subnichos inexplorados e bancos de títulos magnéticos usando <b>⚡ Gerar direto (Gemini / GPT / Antigravity V8)</b>.</li>
            <li><b>📋 Kanban:</b> Organize seus vídeos em colunas (<i>Planejamento → Produção → Finalizado → Publicado</i>). O checklist se marca sozinho conforme o vídeo avança!</li>
          </ul>
          <div class="row"><button class="sm" onclick="go('canais')">Canais →</button><button class="sm" onclick="go('pauta')">☀️ Sugestão do Dia →</button><button class="sm" onclick="go('radar')">Radar →</button><button class="sm" onclick="go('kanban')">📋 Kanban →</button></div>
        </div>

        <div class="card" style="border-color:#f97316">
          <h3>PASSO 3 · 🧠 Assistente Conversacional Antigravity V8 (Analisar antes de escrever)</h3>
          <p class="small mut">Dentro do <b>⚡ Estúdio 1 clique</b>, você não precisa gerar o vídeo às cegas! Use o bloco <b>🧠 Assistente Conversacional Antigravity V8</b>:</p>
          <ol class="small" style="line-height:1.65;padding-left:18px">
            <li>Defina a <b>Meta de Palavras (V8)</b> (ex.: <code>2000</code> ou <code>4000</code>) e a <b>Qtd. de Blocos (V8)</b> (ex.: <code>6</code>). O sistema calcula na hora o <b>tempo exato de fala a 145 palavras/min</b> (ex.: 2000 palavras = <code>13.8 min</code>).</li>
            <li>Digite o <b>Título</b> (em português, inglês ou espanhol — o V8 detecta o idioma sozinho!) e qualquer instrução extra no campo de Contexto.</li>
            <li>Escolha o que quer fazer no seletor e clique em <b>🚀 Executar no Antigravity V8</b>:
              <br>• <b>🧱 Somente Estruturar Roteiro:</b> Monta o esqueleto bloco a bloco + cálculo exato de tempo para o nicho, <b>sem escrever o roteiro completo ainda</b>, para você analisar primeiro!
              <br>• <b>🎯 Analisar Título / Tema:</b> Dá nota de CTR (0 a 100), analisa a psicologia do clique, tempo ideal para o nicho e entrega 5 variações virais.
              <br>• <b>📊 Analisar Canal / Nicho:</b> Faz diagnóstico estratégico de retenção, formato ideal e sugere 5 temas.
              <br>• <b>📝 Escrever Roteiro Completo V8:</b> Escreve o roteiro inteiro seguindo os blocos e palavras definidos.</li>
            <li>Gostou da estrutura? Clique em <b>📝 Aprovar Estrutura e Escrever Roteiro Completo</b> ou <b>🎬 Enviar para DarkPlanner</b>!</li>
          </ol>
          <button class="sm pri" onclick="go('estudio')">Testar Assistente Conversacional V8 →</button>
        </div>

        <div class="card">
          <h3>PASSO 4 · ⚡ Estúdio 1 Clique (Produção Completa Automática)</h3>
          <p class="small mut">Quando estiver pronto para produzir o vídeo completo no <b>⚡ Estúdio 1 clique</b>:</p>
          <ol class="small" style="line-height:1.65;padding-left:18px">
            <li>Escolha se quer <b>🎙 Narrar com voz de IA</b> (Edge grátis, Gemini TTS, <b>DarkPlanner</b>, Azure, ElevenLabs ou Fish) ou <b>🎧 Tenho o áudio</b> (solte seu <code>.mp3/.wav</code> e <code>.srt</code>).</li>
            <li>Em <b>"2. Como deve ficar"</b>, escolha o <b>Perfil visual</b>, o estilo da <b>Legenda</b> (com prévia visual), a preferência de <b>Mídia</b> (<i>Vídeo primeiro</i>, <i>Equilibrado</i> ou <i>Fotos</i>), <b>Moldura</b>, <b>Cor</b>, <b>Transição</b> e <b>Thumbnail</b>.</li>
            <li>Clique em <b>⚡ Gerar vídeo completo</b>. O Estúdio executa as 12 etapas sozinho:
              <br><i>1. Roteiro → 2. Cenas → 3. Pesquisa profunda → 4. Narração → 5. Busca e conferência de mídia real → 6. IA nas cenas sem mídia → 7. Download → 8. Legendas e impacto → 9. Montagem MP4 → 10. Revisão QA → 11. SEO e Thumbnail → 12. Pasta de Entrega + Pacote CapCut!</i></li>
          </ol>
          <button class="sm pri" onclick="go('estudio')">Ir para o Estúdio 1 Clique →</button>
        </div>

        <div class="card">
          <h3>PASSO 5 · 🎬 Produção Manual em 10 Etapas + Oficina do Roteiro</h3>
          <p class="small mut">Na aba <b>Vídeos</b>, clique em qualquer vídeo para abrir a barra de <b>10 etapas</b>:</p>
          <ul class="small" style="line-height:1.65;padding-left:18px">
            <li><b>1. Briefing & 2. Roteiro:</b> Gere por partes ou completo. Use a <b>✨ Oficina do Roteiro</b> para receber nota de 0 a 100 em 4 critérios (<i>Humano, Qualidade, Políticas do YouTube, Estrutura</i>), clicar em <b>✨ Melhorar</b> ou conversar no chat pedindo alterações pontuais!</li>
            <li><b>3. Análise & 4. Narração (VozLab):</b> Gere áudio por blocos ou envie seu áudio pronto.</li>
            <li><b>5. Cenas e SRT & 6. Mídia (Real Lab):</b> Divida em cenas, gere prompts para vídeo/imagem ou busque filmagens reais no Wikimedia, Archive.org, Pexels, Pixabay e YouTube CC com conferência automática por IA.</li>
            <li><b>7. Editor (Video Lab) & 8. Montagem:</b> Linha do tempo visual para ajustar duração, zoom, filtros, textos de tela, renderizar o <code>final.mp4</code> ou baixar o pacote ZIP para CapCut.</li>
            <li><b>9. Descrição e tags & 10. Thumbnail (ThumbLab):</b> Gere SEO completo e crie miniaturas de alto impacto.</li>
          </ul>
          <button class="sm" onclick="go('videos')">Abrir Aba Vídeos (10 Etapas) →</button>
        </div>

        <div class="card">
          <h3>PASSO 6 · 📱 Celular, 💰 Financeiro, 📊 Consumo e ⚙️ Configurações</h3>
          <ul class="small" style="line-height:1.65;padding-left:18px">
            <li><b>📱 Celular:</b> Ative o controle pelo celular na mesma rede Wi-Fi (com código de 6 dígitos) para mandar títulos para o Kanban ou disparar vídeos no Estúdio direto do sofá!</li>
            <li><b>💰 Financeiro:</b> Controle todas as receitas (AdSense, patrocinadores, produtos) e despesas por canal e por mês, com exportação para Excel (<code>.csv</code>).</li>
            <li><b>📊 Consumo:</b> Acompanhe quantas chamadas e tokens foram usados no Gemini, GPT, YouTube e motores de voz, além do custo exato por vídeo.</li>
            <li><b>⚙️ Configurações:</b> Ajuste resolução (Full HD <code>1920x1080</code>), FPS, palavras por minuto, limite de gasto por vídeo (R$) e personalize a saudação musical de abertura do aplicativo!</li>
          </ul>
          <div class="row"><button class="sm" onclick="go('celular')">📱 Celular →</button><button class="sm" onclick="go('financeiro')">💰 Financeiro →</button><button class="sm" onclick="go('consumo')">📊 Consumo →</button><button class="sm" onclick="go('config')">⚙️ Configurações →</button></div>
        </div>
      </div>`;
    if ($('#guia-dp-open')) $('#guia-dp-open').onclick = () => safe(async () => { const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_app'}}); toast(r.msg); });
    if ($('#guia-dp-local')) $('#guia-dp-local').onclick = () => safe(async () => { const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_local_programa'}}); toast(r.msg); });
  };

  // ---------------------------------------------------------------- menu
  const nav = $('#nav');
  if (nav) {
    const depois = nav.querySelector('[data-view="estudio"]') || nav.firstChild;
    [['guia', '📖 Como usar o site'], ['pauta', '☀️ Sugestão do dia'], ['kanban', '📋 Kanban'], ['celular', '📱 Celular']].reverse().forEach(([v, n]) => {
      if (nav.querySelector(`[data-view="${v}"]`)) return;
      const a = document.createElement('a'); a.dataset.view = v; a.textContent = n; a.onclick = () => go(v);
      depois && depois.nextSibling ? nav.insertBefore(a, depois.nextSibling) : nav.appendChild(a);
    });
  }
  const btnSideAudiogen = $('#btn-side-audiogen');
  if (btnSideAudiogen) {
    btnSideAudiogen.onclick = () => {
      if (typeof window.abrirModalAudioGeneratorDP === 'function') window.abrirModalAudioGeneratorDP({});
    };
  }
  const btnSideDp = $('#btn-side-dp');
  if (btnSideDp) {
    btnSideDp.onclick = () => safe(async () => {
      const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_app'}});
      toast(r.msg || 'Abrindo DarkPlanner…');
    });
  }
  const btnSideDesktop = $('#btn-side-desktop');
  if (btnSideDesktop) {
    btnSideDesktop.onclick = () => safe(async () => {
      const r = await api('/api/darkplanner/acao', {json: {acao: 'abrir_janela_desktop'}});
      toast(r.msg || 'Abrindo em modo App Desktop…');
    });
  }
})();

// ---------------------------------------------------------------- atualização automática (cópias compartilhadas)
(function () {
  const checar = async () => {
    let a; try { a = await api('/api/atualizacao'); } catch { return; }
    if (!a.ativo || !a.nova || document.getElementById('upd-banner')) return;
    const b = document.createElement('div'); b.id = 'upd-banner'; b.className = 'upd-banner';
    b.innerHTML = `<b>Versão nova disponível (${esc(a.versao)})</b><span class="small">${esc(a.novidades || '')}</span><span class="sp"></span>
      <button class="pri" id="upd-go">Atualizar agora</button><button id="upd-x">Depois</button>`;
    document.body.prepend(b);
    $('#upd-x').onclick = () => b.remove();
    $('#upd-go').onclick = () => safe(async () => {
      if (!confirm('A Fábrica Dark vai baixar a versão nova e reabrir sozinha. Seus canais, vídeos e chaves ficam. Se estiver gerando um vídeo, espere terminar. Atualizar agora?')) return;
      await api('/api/atualizacao', {json: {}});
      b.innerHTML = '<b>Atualizando…</b><span class="small">a janela vai fechar e abrir de novo em alguns segundos.</span>';
      const ver = async () => { try { const s = await api('/api/atualizacao'); if (s.estado && s.estado.erro) { b.innerHTML = `<b>Não deu para atualizar:</b> <span class="small">${esc(s.estado.erro)}</span>`; return; } } catch { } setTimeout(ver, 2000); };
      setTimeout(ver, 2000);
    });
  };
  setTimeout(checar, 4000);
  setInterval(checar, 3 * 3600 * 1000);
})();

// ---------------------------------------------------------------- abertura: música + saudação com o nome
(function () {
  if (window.__aberturaFeita) return; window.__aberturaFeita = true;
  let musica = null, vozA = null;
  const parar = () => { [musica, vozA].forEach(a => { if (!a) return; const v0 = a.volume; let k = 0; const t = setInterval(() => { k++; a.volume = Math.max(0, v0 * (1 - k / 10)); if (k >= 10) { clearInterval(t); a.pause(); } }, 60); }); };
  const fechar = () => { const o = $('#abertura'); if (!o) return; o.classList.add('sai'); parar(); setTimeout(() => o.remove(), 700); };
  const tocar = (a) => {
    if (a.musica) { musica = new Audio(a.musica); musica.volume = 0.55; musica.onended = () => setTimeout(fechar, 600); }
    if (a.voz) { vozA = new Audio(a.voz); vozA.volume = 1; vozA.onplay = () => musica && (musica.volume = 0.22); vozA.onended = () => musica && (musica.volume = 0.5); }
    const ir = () => { const p = []; if (musica) p.push(musica.play()); if (vozA) setTimeout(() => vozA.play().catch(() => {}), 1300); return Promise.all(p); };
    ir().catch(() => { // navegador comum bloqueia som sem clique: toca no primeiro clique
      const b = $('#ab-som'); if (b) { b.style.display = ''; b.onclick = e => { e.stopPropagation(); b.style.display = 'none'; ir(); }; }
    });
    if (!musica) setTimeout(fechar, 6000);
  };
  const tela = (a) => {
    const o = document.createElement('div'); o.id = 'abertura';
    o.innerHTML = `<div class="ab-luz"></div><div class="ab-box">
      <div class="ab-logo">▲</div>
      ${a.nome ? `<div class="ab-oi">${esc(a.saudacao)},</div><div class="ab-nome">${esc(a.nome)}</div><div class="ab-frase">${esc(a.frase)}</div>
        <div class="ab-data">${(d => d[0].toUpperCase() + d.slice(1))(new Date().toLocaleDateString('pt-BR', {weekday: 'long', day: 'numeric', month: 'long'}))}</div>
        <div class="ab-bts"><button class="pri" id="ab-ok">Entrar</button><button id="ab-som" style="display:none">🔊 Tocar som</button><a href="#" id="ab-cfg">ajustar abertura</a></div>`
      : `<div class="ab-oi">${esc(a.saudacao)}!</div><div class="ab-frase">Como você quer ser chamado?</div>
        <div class="ab-bts"><input id="ab-in" placeholder="Seu nome" maxlength="30"><button class="pri" id="ab-salvar">Salvar</button></div>`}
    </div>`;
    document.body.appendChild(o);
    if (!a.nome) {
      const salvar = () => safe(async () => { const n = $('#ab-in').value.trim(); if (!n) return; await api('/api/abertura', {json: {nome_usuario: n}}); o.remove(); iniciar(); });
      $('#ab-salvar').onclick = salvar; $('#ab-in').onkeydown = e => { if (e.key === 'Enter') salvar(); }; $('#ab-in').focus();
      return;
    }
    $('#ab-ok').onclick = fechar;
    $('#ab-cfg').onclick = e => { e.preventDefault(); fechar(); setTimeout(ajustes, 400); };
    o.onclick = e => { if (e.target === o || e.target.classList.contains('ab-luz')) fechar(); };
    document.addEventListener('keydown', function esc_(e) { if (e.key === 'Escape') { fechar(); document.removeEventListener('keydown', esc_); } });
    tocar(a);
    setTimeout(fechar, 15000);
  };
  async function ajustes() {
    const a = await api('/api/abertura'); const s = await api('/api/settings');
    modal(`<h3>Abertura</h3>
      <div class="f"><label>Seu nome</label><input id="abn" value="${esc(a.nome)}"></div>
      <label style="color:var(--txt)"><input type="checkbox" id="aba" ${s.abertura_ativa !== false ? 'checked' : ''}> Mostrar a abertura quando abrir a ferramenta</label>
      <label style="color:var(--txt)"><input type="checkbox" id="abm" ${s.abertura_musica !== false ? 'checked' : ''}> Música</label>
      <label style="color:var(--txt)"><input type="checkbox" id="abv" ${s.abertura_voz !== false ? 'checked' : ''}> Voz falando "${esc(a.saudacao)}, ${esc(a.nome || 'nome')}!"</label>
      <div class="f" style="margin-top:10px"><label>Usar a sua própria música (mp3)</label><div class="row"><input type="file" id="abf" accept="audio/*"><button class="sm" id="abpad">Voltar à música padrão</button></div></div>
      <div class="row end"><button id="abtest">▶ Testar</button><button onclick="fecharModal()">Cancelar</button><button class="pri" id="abok">Salvar</button></div>`);
    const salvar = async () => {
      if ($('#abf').files[0]) { const fd = new FormData(); fd.append('arquivo', $('#abf').files[0]); await fetch('/api/abertura/musica', {method: 'POST', body: fd}); }
      await api('/api/abertura', {json: {nome_usuario: $('#abn').value.trim(), abertura_ativa: $('#aba').checked, abertura_musica: $('#abm').checked, abertura_voz: $('#abv').checked}});
    };
    $('#abok').onclick = () => safe(async () => { await salvar(); fecharModal(); toast('Abertura salva'); });
    $('#abtest').onclick = () => safe(async () => { await salvar(); fecharModal(); tela(await api('/api/abertura')); });
    $('#abpad').onclick = () => safe(async () => { await api('/api/abertura/musica', {method: 'DELETE'}); toast('Voltou para a música padrão'); });
  }
  window.ajustesAbertura = ajustes;
  async function iniciar() {
    if (window.innerWidth <= 820 || /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent || '')) return;
    let a; try { a = await api('/api/abertura?inicio=1'); } catch { return; }
    if (a.ativa === false) return;
    tela(a);
  }
  iniciar();
})();

// ---------------------------------------------------------------- Navegação Mobile Nativa na Tela Completa (/?c=...)
(function () {
  if (document.getElementById('mob-top')) return;
  const top = document.createElement('header');
  top.id = 'mob-top';
  top.innerHTML = `
    <button type="button" id="mob-btn-menu" style="padding:7px 11px;font-weight:800;border-color:var(--acc);color:var(--acc2)">☰ Menu</button>
    <div style="display:flex;align-items:center;gap:7px;font-weight:800;font-size:14px">
      <span style="width:24px;height:24px;border-radius:7px;background:var(--acc);color:#111;display:grid;place-items:center;font-weight:900;font-size:12px">▲</span>
      <span>Fábrica Dark</span>
    </div>
    <div style="display:flex;gap:6px">
      <button type="button" class="sm pri" id="mob-btn-est" style="padding:6px 10px">⚡ Estúdio</button>
      <a class="btn sm" href="/celular${location.search || ''}" style="padding:6px 9px;border-color:#10b981;color:#6ee7b7">📱 App Leve</a>
    </div>
  `;
  const backdrop = document.createElement('div');
  backdrop.id = 'mob-backdrop';
  const bnav = document.createElement('nav');
  bnav.id = 'mob-bnav';
  bnav.innerHTML = `
    <button type="button" data-mview="estudio" class="on"><span class="ic">⚡</span><span>Estúdio V8</span></button>
    <button type="button" data-mview="canais"><span class="ic">📺</span><span>Canais</span></button>
    <button type="button" data-mview="pauta"><span class="ic">☀️</span><span>Sugestão</span></button>
    <button type="button" data-mview="kanban"><span class="ic">📋</span><span>Kanban</span></button>
    <button type="button" id="mob-bnav-menu"><span class="ic">☰</span><span>Mais</span></button>
  `;
  document.body.prepend(top);
  document.body.appendChild(backdrop);
  document.body.appendChild(bnav);

  const toggleMenu = (forcar) => {
    const abrir = typeof forcar === 'boolean' ? forcar : !document.body.classList.contains('mob-menu-open');
    document.body.classList.toggle('mob-menu-open', abrir);
  };
  document.getElementById('mob-btn-menu').onclick = () => toggleMenu();
  document.getElementById('mob-bnav-menu').onclick = () => toggleMenu();
  backdrop.onclick = () => toggleMenu(false);
  document.getElementById('mob-btn-est').onclick = () => { toggleMenu(false); go('estudio'); };

  bnav.querySelectorAll('[data-mview]').forEach(btn => {
    btn.onclick = () => {
      toggleMenu(false);
      go(btn.dataset.mview);
    };
  });

  // Fecha a gaveta lateral quando clicar em qualquer item do menu lateral no celular
  document.addEventListener('click', (e) => {
    if (e.target.closest('#nav a') || e.target.closest('.side button')) {
      toggleMenu(false);
    }
  });

  // Sincroniza aba ativa da barra inferior quando muda de tela
  const origGo = window.go;
  if (typeof origGo === 'function') {
    window.go = async function (view, extra) {
      document.body.classList.remove('mob-menu-open');
      bnav.querySelectorAll('[data-mview]').forEach(b => {
        b.classList.toggle('on', b.dataset.mview === view || (view === 'acompanhar' && b.dataset.mview === 'estudio'));
      });
      return origGo(view, extra);
    };
  }

  // No celular, abre direto o Estúdio 1 Clique V8 para facilitar o uso imediato
  if (window.innerWidth <= 820 || /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent || '')) {
    setTimeout(() => { if (S.view === 'painel') go('estudio'); }, 150);
  }
})();

// ---------------------------------------------------------------- sinal de vida da janela + auto-reload quando chega atualização na nuvem
setInterval(() => { fetch('/api/ping').catch(() => {}); }, 60000);
(function () {
  const getVerScript = () => {
    const s = document.querySelector('script[src*="/static/v4.js"]');
    if (!s) return '';
    const m = (s.getAttribute('src') || '').match(/\?v=([^&"'\s]+)/);
    return m ? m[1] : '';
  };
  const vInicial = getVerScript();
  if (!vInicial) return;
  setInterval(async () => {
    try {
      const r = await fetch('/?_vcheck=' + Date.now(), {cache: 'no-store'});
      if (!r.ok) return;
      const html = await r.text();
      const m = html.match(/\/static\/v4\.js\?v=([^&"'\s>]+)/);
      if (m && m[1] && m[1] !== vInicial) {
        location.reload();
      }
    } catch (_e) {}
  }, 8000);
})();
